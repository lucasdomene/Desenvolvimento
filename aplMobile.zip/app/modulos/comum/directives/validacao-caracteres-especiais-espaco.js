(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("sfCaracteresEspeciaisEspaco", validarCaracteresEspeciais);

    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: validarCaracteresEspeciais
     * @module arq-spa-base.validacoes
     *  
     * @description
     * Método responsável por verificar se o e-mail informado é valido.
     */
    function validarCaracteresEspeciais() {
        return {
            restrict: "A",
            link: link
        };

        /**
        * @ngdoc object
        * @name link
        * 
        * @description
        * Método responsável por verificar se o campo de confirmação é igual o campo informado anteriormente.
        */
        function link(scope, element) {
            var regex = new RegExp("^([a-zA-Z0-9])*$");
            element.bind("keypress paste", bloquearCaracteres);

            /**
             * @ngdoc object
             * @name bloquearCaracteres
             * 
             * @description
             * Método contendo a lógica para bloquear os caracteres especiais informados no HTML do código.
             */
            function bloquearCaracteres(event) {
                if (event.code != "Enter") {
                    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);

                    if (!regex.test(key)) {
                        event.preventDefault();
                    }
                }
            }
        }
    }
})();