(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("permissionamento", permissionamento);

    permissionamento.$inject = ["$window", "$document", "validapermissionamento"];

    /**
     * @description Diretiva criada para aplicar a validação do permissionamento 
     */
    function permissionamento($window, $document, validapermissionamento) {
        return {
            restrict: "A",
            replace: false,
            transclude: false,
            link: validaPermissao
        };

        /**
         * @description Ação que valida Permissao.
         */
        function validaPermissao(scope, element, attrs) {
            var grupo = attrs.permissaogrupo;
            var servico = attrs.permissaoservico;
            var nivel = attrs.permissaonivel;

            var permitido = validapermissionamento.validacao(grupo, servico, nivel);

            if (!permitido)
            {
                element.html("");
            }
        }
    }
})(); 