(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name identificarComprovanteCompartilhadoFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:identificarComprovanteCompartilhadoFactory
    *
    * @description
    * Factory de conexão com API identificarComprovanteCompartilhadoFactory
    **/
    angular.module("apl-mobile-pj.comum")
        .factory("identificarComprovanteCompartilhadoFactory", identificarComprovanteCompartilhadoFactory);

    identificarComprovanteCompartilhadoFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name identificarComprovanteCompartilhadoFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:identificarComprovanteCompartilhadoFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function identificarComprovanteCompartilhadoFactory(conectorAPI, appSettings, utilitarios) {

        return {
            identificarComprovanteCompartilhado: identificarComprovanteCompartilhado
        };

        /**
        * @ngdoc method
        * @name identificarComprovanteCompartilhado
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento:identificarComprovanteCompartilhado
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function identificarComprovanteCompartilhado(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "marcar-comprovante-compartilhado"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();