/**
 * @ngdoc overview
 * @name apl-mobile-pj.areaPrincipal
 * 
 * @require apl-mobile-pj.comum
 * 
 * @description
 * Módulo que define os fluxos de navegacao da area Logada.
 **/

angular.module("apl-mobile-pj.areaPrincipal",
    ["ui.bootstrap",
        "ngAnimate"])
    .config(areaPrincipalModule)
    .run(["sfTradutor", function (tradutor) {
        tradutor.adicionarDicionarios(["app/modulos/areaPrincipal/home/internacionalizacao"]);
    }]);


areaPrincipalModule.$inject = ["sfNavegadorProvider"];

/**
* @ngdoc method
* @name apl-mobile-pj.areaPrincipal 
* 
* @param {provider} sfNavegadorProvider instancia do sfNavegadorProvider
* 
* @description
* metodo responsavel por inicar o modulo.
**/
function areaPrincipalModule(sfNavegadorProvider) {
    sfNavegadorProvider.adicionarFluxoNavegacao(
        sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-home")
            .adicionarEstado("home", {
                templateUrl: "./app/modulos/areaPrincipal/home/views/home.html",
                controller: "homeController as hCtrl"
            }, [
                {
                    acao: "gestao-maquinas",
                    fluxo: "apl-mobile-pj-orquestrador-seguranca"
                },
                {
                    acao: "cadastrar-maquinas",
                    fluxo: "apl-mobile-pj-novo-dispositivo"
                },
                {
                    acao: "encerrar-sessao",
                    fluxo: "apl-mobile-pj-login"
                },
                {
                    acao: "autorizar-pagamentos",
                    fluxo: "apl-mobile-pj-autorizacaoPagamento"
                },
                {
                    acao: "extrato",
                    fluxo: "apl-mobile-pj-extrato"
                },
                {
                    acao: "investimentos",
                    fluxo: "apl-mobile-pj-investimentos"
                },
                {
                    acao: "ativar-token",
                    fluxo: "apl-mobile-pj-ativar-token"
                }

            ], {
                cabecalho: {
                    mostrarlogo: true,
                    mostrarmenu: true
                }
            })
            .definirEstadoInicial("home")
    );
}