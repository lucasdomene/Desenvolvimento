angular.module("apl-mobile-pj.extrato").filter("filtroCamposTela", function () {
    return function (lista, filtro) {
        if (filtro == undefined || filtro == null || filtro == "") {
            return lista;
        }

        return lista.filter(function (item) {
            if (item.EXCC_EV_DTMOT == undefined ||
                item.EXCC_EV_HISTO == undefined ||
                item.EXCC_EV_NMFAV == undefined ||
                item.EXCC_EV_SALDO == undefined ||
                item.EXCC_EV_VALOR == undefined) {

                return false;
            } else {
                
                return item.EXCC_EV_DTMOT.toLowerCase().indexOf(filtro.toLowerCase()) > -1 ||
                    item.EXCC_EV_HISTO.toLowerCase().indexOf(filtro.toLowerCase()) > -1 ||
                    item.EXCC_EV_NMFAV.toLowerCase().indexOf(filtro.toLowerCase()) > -1 ||
                    item.EXCC_EV_SALDO.toLowerCase().indexOf(filtro.toLowerCase()) > -1 ||
                    item.EXCC_EV_VALOR.toLowerCase().indexOf(filtro.toLowerCase()) > -1;
            }
        });
    };
});