(function () {
    "use strict";
    /**
    * @ngdoc controller
    * @name apl-mobile-pj.orquestradorSeguranca:orquestradorSegurancaController
    *
    * @requires
    *
    * @description
    * DescricaoComentario
    **/
    angular.module("apl-mobile-pj.orquestradorSeguranca")
        .controller("orquestradorSegurancaController", orquestradorSegurancaController);

    orquestradorSegurancaController.$inject = ["sfNavegador", "sfContexto", "validapermissionamento"];

    /**
    * @ngdoc method
    * @name orquestradorSegurancaController
    *
    * @requires
    *
    * @methodOf apl-mobile-pj.orquestradorSeguranca:orquestradorSegurancaController
    *
    * @description
    * Contem as definições do controller.
    **/
    function orquestradorSegurancaController(sfNavegador, sfContexto, validapermissionamento) {
        iniciar();

        /*Funções*/

        /**
        * @ngdoc method
        * @name iniciar
        *
        * @methodOf apl-mobile-pj.orquestradorSeguranca:orquestradorSegurancaController
        *
        * @description
        * Método responsável por carregar o estado orquestradorSeguranca dos elementos da view.
        **/
        function iniciar() {
            var permissao = validapermissionamento.validacao("", "", "MASTER");
            if (permissao) {
                sfNavegador.navegar("gestao-maquinas");
            }
            else {
                sfContexto.definirValorContextoTrabalho("usuarioLogadoSemPermissaoMaquinas", true);                
                sfNavegador.navegar("alterar-senha");
            }

        }
    }
})();