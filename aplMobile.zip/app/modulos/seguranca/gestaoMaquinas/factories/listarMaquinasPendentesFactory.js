(function () {

    "use strict";

    angular.module("apl-mobile-pj.seguranca").factory("listarMaquinasPendentesFactory", listarMaquinasPendentesFactory);

    listarMaquinasPendentesFactory.$inject = ["sfConectorAPI"];
    
    /*Funções*/
    /**
    * @ngdoc method
    * @name iniciar
    *  
    * @description
    * Factory responsável por definir todas as funções utilizadas na gestão de máquinas
    **/
    function listarMaquinasPendentesFactory(conectorAPI) {

        return {
            listarMaquinasPendentes: listarMaquinasPendentes
        };

        /**
        * @ngdoc method
        * @name iniciar
        *  
        * @description
        * Função responsável por consultar as máquinas liberadas
        **/
        function listarMaquinasPendentes(PLLM_RC_CHCLI) {
            var param = {
                "PLLM_RC_CHCLI": PLLM_RC_CHCLI
             };

            var req = {
                method: "POST",
                url: "listar-maquinas-pendentes",
                data: param,
                dataType: "json"
            };
            
            return conectorAPI.executar(req, true);
        }
             
    }
    
    
})();