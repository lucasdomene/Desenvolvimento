/**
* @ngdoc overview
* @name apl-mobile-pj.areaAberta
* 
* @require apl-mobile-pj.comum
* 
* @description
* Módulo que define os fluxos de navegacao da area aberta.
**/
angular.module("apl-mobile-pj.areaAberta", [
    "ui.bootstrap",
    "ngAnimate",
    "ui.mask",
    "angular-progress-arc"
    ]).config(areaAbertaModulo)
    .run(["sfTradutor", function (tradutor) {
        tradutor.adicionarDicionarios(["app/modulos/areaAberta/login/internacionalizacao"]);
    }]);

areaAbertaModulo.$inject = ["sfNavegadorProvider"];

/**
* @ngdoc method
* @name apl-mobile-pj.areaAberta 
* 
* @param {provider} sfNavegadorProvider instancia do sfNavegadorProvider
* 
* @description
* metodo responsavel por inicar o modulo.
**/
function areaAbertaModulo(sfNavegadorProvider) {
    sfNavegadorProvider.adicionarFluxoNavegacao(
        sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-login")
            .adicionarEstado("login", {
                controller: "loginController as lCtrl",
                templateUrl: "./app/modulos/areaAberta/login/views/inicio.html",
                abstract: true
            })

            .adicionarEstado("login.login-inicio", {
                templateUrl: "./app/modulos/areaAberta/login/views/login.html",
                parent: "login"
            }, [
                {
                    acao: "senha-eletronica",
                    estadoDestino: "login.senha-eletronica"
                },
                {
                    acao: "ativar-token",
                    fluxo: "apl-mobile-pj-ativar-token"
                }
            ])

            .adicionarEstado("login.senha-eletronica", {
                templateUrl: "./app/modulos/areaAberta/login/views/senhaEletronica.html",
                parent: "login"
            }, [
                {
                    acao: "token",
                    estadoDestino: "login.token"
                },
                {
                    acao: "voltar",
                    estadoDestino: "login.login-inicio"
                },
                {
                    acao: "alterar-senha",
                    fluxo: "apl-mobile-pj-alterar-senha"
                },
                {
                    acao: "ativar-token",
                    fluxo: "apl-mobile-pj-ativar-token"
                }
            ])

            .adicionarEstado("login.token", {
                templateUrl: "./app/modulos/areaAberta/login/views/token.html",
                parent: "login"
            }, [
                {
                    acao: "areaPrincipal.home",
                    fluxo: "apl-mobile-pj-home"
                },
                {
                    acao: "voltar",
                    estadoDestino: "login.login-inicio"
                },
                {
                    acao: "cadastrar-maquina",
                    fluxo: "apl-mobile-pj-novo-dispositivo"
                },
                {
                    acao: "ativar-token",
                    fluxo: "apl-mobile-pj-ativar-token"
                }
            ])
            .definirEstadoInicial("login.login-inicio")
    );
    sfNavegadorProvider.adicionarFluxoNavegacao(
        sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-token")
            .adicionarEstado("login-token", {
                controller: "loginController as lCtrl",
                templateUrl: "./app/modulos/areaAberta/login/views/inicio.html",
                abstract: true
            })

            .adicionarEstado("login.token-direto", {
                templateUrl: "./app/modulos/areaAberta/login/views/token.html",
                parent: "login-token"
            }, [
                {
                    acao: "areaPrincipal.home",
                    fluxo: "apl-mobile-pj-home"
                },
                {
                    acao: "voltar",
                    fluxo: "apl-mobile-pj-login"
                }
            ])
            .definirEstadoInicial("login.token-direto")
    );
}