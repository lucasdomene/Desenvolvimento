(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name validarIPFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:validarIPFactory
    *
    * @description
    * Factory de conexão com API validarIPFactory
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .factory("validarIPFactory", validarIPFactory);

    validarIPFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name validarIP
    *
    * @methodOf apl-mobile-pj.extrato:validarIPFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function validarIPFactory(conectorAPI, appSettings, utilitarios) {

        return {
            validarIP: validarIP
        };

        /**
        * @ngdoc method
        * @name validarIP
        *
        * @methodOf apl-mobile-pj.extrato:validarIP
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function validarIP(requisicao) {

            var param = requisicao;

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "validar-ip"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();