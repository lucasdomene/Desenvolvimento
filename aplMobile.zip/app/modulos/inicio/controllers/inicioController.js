(function () {
    "use strict";
    /**
    * @ngdoc controller
    * @name apl-mobile-pj.inicio:inicioController
    *
    * @requires
    *
    * @description
    * DescricaoComentario
    **/
    angular.module("apl-mobile-pj.inicio")
        .controller("inicioController", inicioController);

    inicioController.$inject = ["sfNavegador", "$window"];

    /**
    * @ngdoc method
    * @name inicioController
    *
    * @requires
    *
    * @methodOf apl-mobile-pj.inicio:inicioController
    *
    * @description
    * Contem as definições do controller.
    **/
    function inicioController(sfNavegador, $window) {
        iniciar();

        /*Funções*/

        /**
        * @ngdoc method
        * @name iniciar
        *
        * @methodOf apl-mobile-pj.inicio:inicioController
        *
        * @description
        * Método responsável por carregar o estado inicio dos elementos da view.
        **/
        function iniciar() {
            console.log("inicio");

            //document.getElementsByTagName("main").style =  "height:" + $window.innerHeight + "px";
            var myEl = angular.element(document.querySelector("html")); 
            myEl.css("height", $window.innerHeight + "px");
            sfNavegador.navegar("iniciar");
        }
    }
})();