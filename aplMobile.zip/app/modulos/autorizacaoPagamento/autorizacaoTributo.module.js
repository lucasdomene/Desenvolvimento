(function () {

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.autorizacaoTributo
     * 
     * @require ui.bootstrap
     * 
     * @description
     * Módulo que define os fluxos de navegacao pelos controles de autorizacao de pagamento.
     **/
    angular.module("apl-mobile-pj.autorizacaoTributo", ["ui.bootstrap", "ngAnimate", "rzModule"])
        .config(autorizacaoTributoModule)
        .run(["sfTradutor", function (tradutor) {
            tradutor.adicionarDicionarios(["app/modulos/autorizacaoPagamento/internacionalizacao"]);
        }]);


    autorizacaoTributoModule.$inject = ["sfNavegadorProvider"];

    /**
    * @ngdoc overview
    * @name autorizacaoTributoModule
    * 
    * @description
    * Navegação do módulo autorizacaoTributoModule.
    **/
    function autorizacaoTributoModule(sfNavegadorProvider) {
        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-autorizacaoTributo")
                .adicionarEstado("tributo", {
                    templateUrl: "./app/modulos/autorizacaoPagamento/tributos/views/autorizacao.html",
                    controller: "autorizarTributoController as auttribCtrl",
                    abstract: true
                })
                .adicionarEstado("tributo.tributo", {
                    templateUrl: "./app/modulos/autorizacaoPagamento/tributos/views/autorizacaoTributo.html",
                    parent: "tributo"
                },
                [
                    {
                        acao: "filtrar-pagamentos",
                        estadoDestino: "tributo.pagamentos"
                    },
                    {
                        acao: "detalhar-pagamento",
                        fluxo: "apl-mobile-pj-detalhes-pagamento"
                    },
                    {
                        acao: "autorizacao-pagamento",
                        fluxo: "apl-mobile-pj-autorizacaoPagamento"
                    }
                ])

                .adicionarEstado("tributo.pagamentos", {
                    templateUrl: "./app/modulos/autorizacaoPagamento/tributos/views/filtroPagamentos.html",
                    parent: "tributo"
                })
                .definirEstadoInicial("tributo.tributo")
        );

        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-comprovante-tributos")
                .adicionarEstado("tributo.comprovante", {
                    templateUrl: "./app/modulos/autorizacaoPagamento/tributos/views/exibirComprovante.html",
                    controller: "comprovantesTributosController as comtribCtrl"
                })
                .definirEstadoInicial("tributo.comprovante")
        );
    }
})();