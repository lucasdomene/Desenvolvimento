(function () {
    "use strict";

    angular.module("apl-mobile-pj.autorizacaoTributo")
        .controller("comprovantesTributosController", comprovantesTributosController);

    comprovantesTributosController.$inject = ["sfContexto", "sfNavegador",  "sfMemorizador"];
    /**
     * @description Controller de comprovantes tributos
     * @name comprovantesTributosController
     */
    function comprovantesTributosController(sfContexto, sfNavegador, sfMemorizador) {

// var mockCC = {
        //     "PGGD_EV_TP_PAG": "CC",
        //     "PGGD_EV_AGENCIA": 200,
        //     "PGGD_EV_CONTA": 1636800,
        //     "PGGD_EV_VLR_DOC": 22500,
        //     "PGGD_EV_VLR_DES_DOC": 0,
        //     "PGGD_EV_VLR_JUR_DOC": 0,
        //     "PGGD_EV_VLR_TOT_DOC": 22500,
        //     "PGGD_EV_DT_CRED": 20160428,
        //     "PGGD_EV_BCO_DEST": 422,
        //     "PGGD_EV_AGE_DEST": 200,
        //     "PGGD_EV_DV_AG_DEST": 0,
        //     "PGGD_EV_CTA_DEST": 1637491,
        //     "PGGD_EV_NOM_FORN": "TESTE 1637491",
        //     "PGGD_EV_CGC_FORN_DOC": 6805308607,
        //     "PGGD_EV_FINALID": "CREDITO EM CONTA CORRENTE",
        //     "PGGD_EV_COMPR_DOC": "OUT222",
        //     "PGGD_EV_SIT_DOC": 5,
        //     "PGGD_EV_MOT_DOC": 0,
        //     "PGGD_EV_SEU_NUM_DOC": "",
        //     "PGGD_EV_TP_PESS_DOC": "1",
        //     "statusProcessamento": {
        //         "mensagem": {
        //             "codigo": "",
        //             "descricao": "",
        //             "severidade": "00"
        //         }
        //     }
        // };

        // var mockBLQ = {
        //     "PGGD_EV_TP_PAG": "BLQ",
        //     "PGGD_EV_AGENCIA": 200,
        //     "PGGD_EV_CONTA": 1636800,
        //     "PGGD_EV_VLR_BLQ": 1100,
        //     "PGGD_EV_VLR_DES": 0,
        //     "PGGD_EV_VLR_JUR": 0,
        //     "PGGD_EV_VLR_TOT": 1100,
        //     "PGGD_EV_DT_PAG_BLQ": 20151105,
        //     "PGGD_EV_NOM_CED": "TESTE 56789",
        //     "PGGD_EV_AGE_CED": 0,
        //     "PGGD_EV_CTA_CED": 0,
        //     "PGGD_EV_COMPR_BLQ": "BLQ567567",
        //     "PGGD_EV_ESP_DOC": "",
        //     "PGGD_EV_NUM_BLQ": "",
        //     "PGGD_EV_IC_NEG_COE_BLQ": "N",
        //     "PGGD_EV_TP_PESS_BLQ": "2",
        //     "PGGD_EV_CART": "",
        //     "PGGD_EV_ESPECIE": "R$",
        //     "PGGD_EV_LIN_DIG": "23798664400000011001234501234567899876543210",
        //     "PGGD_EV_CGC_FORN_BLQ": 891373888,
        //     "PGGD_EV_TP_COB": "COB",
        //     "PGGD_EV_SIT_BLQ": 1,
        //     "PGGD_EV_MOT_BLQ": 0,
        //     "PGGD7_EV_SEGD_SACD": "",
        //     "PGGD7_EV_USO_EXCL": "",
        //     "PGGD7_EV_DT_VCTO": 20151105,
        //     "PGGD7_EV_IC_SC_AGR": 0,
        //     "PGGD7_EV_NM_SC_AGR": "",
        //     "PGGD7_EV_TP_SC_AGR": null,
        //     "PGGD7_EV_CNPJ_SC_AGR": null,
        //     "PGGD7_EV_ID_TIT_DDA": "123",
        //     "PGGD7_EV_CNPJ_CD_ORIG": null,
        //     "PGGD7_EV_FL_EMIT_BLQ": "",
        //     "PGGD7_EV_VLR_DEV": null,
        //     "PGGD7_EV_MOEDA": "",
        //     "PGGD7_EV_TPES_CD_ORIG": "",
        //     "statusProcessamento": {
        //         "mensagem": {
        //             "codigo": "",
        //             "descricao": "",
        //             "severidade": "00"
        //         }
        //     }
        // };

        // var mockCHQ = {
        //     "PGGD_EV_TP_PAG": "CHQ",
        //     "PGGD_EV_AGENCIA": 200,
        //     "PGGD_EV_CONTA": 1636800,
        //     "PGGD_EV_VLR_CHQ": 1266,
        //     "PGGD_EV_VLR_DES_CHQ": 0,
        //     "PGGD_EV_VLR_JUR_CHQ": 0,
        //     "PGGD_EV_VLR_TOT_CHQ": 1266,
        //     "PGGD_EV_DT_PAG_CHQ": 20160707,
        //     "PGGD_EV_CED_CHQ": "TESTE MARIO 2",
        //     "PGGD_EV_AGE_PAG_CHQ": 20500,
        //     "PGGD_EV_CGC_FORN_CHQ": 3379,
        //     "PGGD_EV_NRO_CHQ": 0,
        //     "PGGD_EV_COMPR_CHQ": "OUT4587",
        //     "PGGD_EV_SIT_CHQ": 5,
        //     "PGGD_EV_MOT_CHQ": 0,
        //     "PGGD_EV_SEU_NUM_CHQ": "",
        //     "PGGD_EV_TP_PES_CHQ": "2",
        //     "PGGD7_EV_IC_NEG_COE_CHQ": "N",
        //     "PGGD7_EV_FIL_CHQ": "",
        //     "statusProcessamento": {
        //         "mensagem": {
        //             "codigo": "",
        //             "descricao": "",
        //             "severidade": "00"
        //         }
        //     }
        // };

        // var mockDOC = {
        //     "PGGD_EV_TP_PAG": "DOC",
        //     "PGGD_EV_AGENCIA": 200,
        //     "PGGD_EV_CONTA": 1636800,
        //     "PGGD_EV_VLR_DOC": 2800,
        //     "PGGD_EV_VLR_DES_DOC": 0,
        //     "PGGD_EV_VLR_JUR_DOC": 0,
        //     "PGGD_EV_VLR_TOT_DOC": 2800,
        //     "PGGD_EV_DT_CRED": 20141105,
        //     "PGGD_EV_BCO_DEST": 237,
        //     "PGGD_EV_AGE_DEST": 523,
        //     "PGGD_EV_DV_AG_DEST": 0,
        //     "PGGD_EV_CTA_DEST": 228,
        //     "PGGD_EV_NOM_FORN": "FDFDSADFSA",
        //     "PGGD_EV_CGC_FORN_DOC": 2080208020,
        //     "PGGD_EV_FINALID": "CREDITO EM CONTA CORRENTE",
        //     "PGGD_EV_COMPR_DOC": "OUTT40028",
        //     "PGGD_EV_SIT_DOC": 5,
        //     "PGGD_EV_MOT_DOC": 0,
        //     "PGGD_EV_SEU_NUM_DOC": "",
        //     "PGGD_EV_TP_PESS_DOC": "1",
        //     "PGGD7_EV_IC_NEG_COE_DOC": "N",
        //     "PGGD7_EV_ISPB": "0",
        //     "PGGD7_EV_FIL_DOC": "0000000",
        //     "statusProcessamento": {
        //         "mensagem": {
        //             "codigo": "",
        //             "descricao": "",
        //             "severidade": "00"
        //         }
        //     }
        // };

        // var mockTED = {
        //     "PGGD_EV_TP_PAG": "TED",
        //     "PGGD_EV_AGENCIA": 200,
        //     "PGGD_EV_CONTA": 1636800,
        //     "PGGD_EV_VLR_DOC": 150000,
        //     "PGGD_EV_VLR_DES_DOC": 0,
        //     "PGGD_EV_VLR_JUR_DOC": 0,
        //     "PGGD_EV_VLR_TOT_DOC": 150000,
        //     "PGGD_EV_DT_CRED": 20160211,
        //     "PGGD_EV_BCO_DEST": 341,
        //     "PGGD_EV_AGE_DEST": 4300,
        //     "PGGD_EV_DV_AG_DEST": 0,
        //     "PGGD_EV_CTA_DEST": 4251234567,
        //     "PGGD_EV_NOM_FORN": "LEONARDO ITALLO MARTINS",
        //     "PGGD_EV_CGC_FORN_DOC": 36923151805,
        //     "PGGD_EV_FINALID": "CREDITO EM CONTA CORRENTE",
        //     "PGGD_EV_COMPR_DOC": "OUT222",
        //     "PGGD_EV_SIT_DOC": 5,
        //     "PGGD_EV_MOT_DOC": 0,
        //     "PGGD_EV_SEU_NUM_DOC": "",
        //     "PGGD_EV_TP_PESS_DOC": "1",
        //     "statusProcessamento": {
        //         "mensagem": {
        //             "codigo": "",
        //             "descricao": "",
        //             "severidade": "00"
        //         }
        //     }
        // };

        var vm = this;

        vm.preencherDadosTransferencias = preencherDadosTransferencias;
        vm.preencherDadosBoleto = preencherDadosBoleto;
        vm.preencherDadosOrdemPagamento = preencherDadosOrdemPagamento;
        vm.verificarTemplate = verificarTemplate;
        vm.voltar = voltar;

        //Variaveis de tela
        pagamentoDetalhado = "";
        vm.autenticacao = "";
        vm.nomeRemetente = "";
        vm.agenciaContaRemetente = "";
        vm.agenciaEmissora = "";
        vm.dataVencimento = "";
        vm.dataPagamento = "";
        vm.jurosMulta = "";
        vm.desconto = "";
        vm.nomeBeneficiario = "";
        vm.cpfcnpj = "";
        vm.valor = "";
        vm.valorTotal = "";
        vm.dataEmissao = "";
        vm.numeroCompromisso = "";
        vm.bancoTransferencia = "";
        vm.agenciaTransferencia = "";
        vm.contaTransferencia = "";
        vm.dataTransferencia = "";
        vm.finalidade = "";
        vm.codigoBarras = "";
        vm.identificacaoDDA = "";
        vm.contaRemetente = "";

        vm.templateCC = false;
        vm.templateDOC = false;
        vm.templateTED = false;
        vm.templateBLQ = false;
        vm.templateCHQ = false;
        vm.templateTRF = false;
        vm.templateBLT = false;
        vm.templateDDA = false;

        vm.iniciar = iniciar;

        var pagamentoDetalhado;

        vm.iniciar();

        /**
         * @description Inicia o controller
         * @name iniciar
         */
        function iniciar() {
            pagamentoDetalhado = sfContexto.obterValorContextoTrabalho("pagamentoDetalhadoFornecedor");
            vm.contaRemetente = sfMemorizador.obter("autorizacaoPagamento.contaPreferencial");
            verificarTemplate();
        }

        /**
         * @description Verifica o template
         * @name verificarTemplate
         */
        function verificarTemplate() {
            switch (pagamentoDetalhado.PGGD_EV_TP_PAG) {
                case "DOC":
                    vm.templateDOC = true;
                    vm.templateTRF = true;
                    preencherDadosTransferencias();
                    break;
                case "TED":
                    vm.templateTED = true;
                    vm.templateTRF = true;
                    preencherDadosTransferencias();
                    break;
                case "CC":
                    vm.templateCC = true;
                    vm.templateTRF = true;
                    preencherDadosTransferencias();
                    break;
                case "BLQ":
                    vm.templateBLQ = true;
                    preencherDadosBoleto();
                    break;
                case "CHQ":
                    vm.templateCHQ = true;
                    preencherDadosOrdemPagamento();
                    break;
                default:
                    break;
            }

        }

        /**
         * @description preenche os dados de Boleto
         * @name preencherDadosBoleto
         */
        function preencherDadosBoleto() {

            if (pagamentoDetalhado.PGGD7_EV_ID_TIT_DDA == "") {
                vm.templateBLT = true;
                vm.codigoBarras = pagamentoDetalhado.PGGD_EV_LIN_DIG;
            }
            else {
                vm.templateDDA = true;
                vm.identificacaoDDA = pagamentoDetalhado.PGGD7_EV_ID_TIT_DDA;
            }

            vm.dataVencimento = pagamentoDetalhado.PGGD7_EV_DT_VCTO;
            vm.dataPagamento = pagamentoDetalhado.PGGD_EV_DT_PAG_BLQ;
            vm.valor = pagamentoDetalhado.PGGD_EV_VLR_BLQ;
            vm.jurosMulta = pagamentoDetalhado.PGGD_EV_VLR_JUR;
            vm.desconto = pagamentoDetalhado.PGGD_EV_VLR_DES;
            vm.valorTotal = pagamentoDetalhado.PGGD_EV_VLR_TOT;
            vm.numeroCompromisso = pagamentoDetalhado.PGGD_EV_COMPR_BLQ;
            vm.nomeBeneficiario = pagamentoDetalhado.PGGD_EV_NOM_CED;
            vm.cpfcnpj = pagamentoDetalhado.PGGD_EV_CGC_FORN_BLQ;

            vm.autenticacao = "";
        }

        /**
         * @description preenche os dados de Ord Pagto
         * @name preencherDadosOrdemPagamento
         */
        function preencherDadosOrdemPagamento() {

            vm.nomeRemetente = vm.contaRemetente.nome; 
            vm.agenciaEmissora = vm.contaRemetente.agencia;
            vm.nomeBeneficiario = pagamentoDetalhado.PGGD_EV_CED_CHQ;
            vm.cpfcnpj = pagamentoDetalhado.PGGD_EV_CGC_FORN_CHQ;
            vm.valor = pagamentoDetalhado.PGGD_EV_VLR_CHQ;
            vm.dataEmissao = pagamentoDetalhado.PGGD_EV_DT_PAG_CHQ;
            vm.numeroCompromisso = pagamentoDetalhado.PGGD_EV_COMPR_CHQ;

            vm.autenticacao = "";
        }

        /**
         * @description preenche os dados de TRF
         * @name preencherDadosTransferencias
         */
        function preencherDadosTransferencias() {

            vm.nomeRemetente = vm.contaRemetente.nome; 
            vm.agenciaContaRemetente = vm.contaRemetente.agencia + "/" + vm.contaRemetente.numero;
            vm.nomeBeneficiario = pagamentoDetalhado.PGGD_EV_NOM_FORN;
            vm.cpfcnpj = pagamentoDetalhado.PGGD_EV_CGC_FORN_DOC;
            vm.bancoTransferencia = pagamentoDetalhado.PGGD_EV_BCO_DEST;
            vm.agenciaTransferencia = pagamentoDetalhado.PGGD_EV_AGE_DEST;
            vm.contaTransferencia = pagamentoDetalhado.PGGD_EV_CTA_DEST;
            vm.valor = pagamentoDetalhado.PGGD_EV_VLR_DOC;
            vm.dataTransferencia = pagamentoDetalhado.PGGD_EV_DT_CRED;
            vm.finalidade = pagamentoDetalhado.PGGD_EV_FINALID;
            vm.numeroCompromisso = pagamentoDetalhado.PGGD_EV_COMPR_DOC;

            vm.autenticacao = "";
        }

        /**
         * @description metodo voltar
         * @name voltar
         */
        function voltar() {
            sfNavegador.voltar();
        }
    }
})();