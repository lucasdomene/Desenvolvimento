(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name autorizarPagamentosTributoPorContaFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:autorizarPagamentosTributoPorContaFactory
    *
    * @description
    * Factory de conexão com API autorizarPagamentosTributoPorContaFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoTributo")
        .factory("autorizarPagamentosTributoPorContaFactory", autorizarPagamentosTributoPorContaFactory);

    autorizarPagamentosTributoPorContaFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name autorizarPagamentosTributoPorContaFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:autorizarPagamentosTributoPorContaFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function autorizarPagamentosTributoPorContaFactory(conectorAPI, appSettings, utilitarios) {

        return {
            autorizarTributos: autorizarTributos
        };

        /**
        * @ngdoc method
        * @name autorizarTributos
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento:autorizarTributos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function autorizarTributos(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "autorizar-tributos-por-conta"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();