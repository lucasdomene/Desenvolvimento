(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name autorizarPagamentosTributoPorPagamentoFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:autorizarPagamentosTributoPorPagamentoFactory
    *
    * @description
    * Factory de conexão com API autorizarPagamentosTributoPorPagamentoFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoTributo")
        .factory("autorizarPagamentosTributoPorPagamentoFactory", autorizarPagamentosTributoPorPagamentoFactory);

    autorizarPagamentosTributoPorPagamentoFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name autorizarPagamentosTributoPorPagamentoFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:autorizarPagamentosTributoPorPagamentoFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function autorizarPagamentosTributoPorPagamentoFactory(conectorAPI, appSettings, utilitarios) {

        return {
            autorizarTributos: autorizarTributos
        };

        /**
        * @ngdoc method
        * @name autorizarTributos
        *
        * @methodOf apl-mobile-pj.autorizacaoTributo:autorizarTributos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function autorizarTributos(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "autorizar-pagamentos-por-pagamento"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();