(function () {
    "use strict";

    /**
    * @ngdoc overview
    * @name apl-mobile-pj.extrato
    *  
    * @require navegador
    *  
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Extrato de Movimentações.
    **/
    angular.module("apl-mobile-pj.autorizacaoPagamento")
        .controller("autorizarPagamentoController", autorizarPagamentoController);

    autorizarPagamentoController.$inject = ["sfNavegador",
        "sfMemorizador",
        "modal",
        "sfContexto",
        "sfUtilitarios",
        "interpretadorComunicacao",
        "autorizarPagamentosFornecedorPorModalidadeFactory",
        "autorizarPagamentosFornecedorPorPagamentoFactory",
        "listarContasPagamentosFactory",
        "listarPagamentosFornecedorPorContaFactory",
        "listarPagamentosFornecedorPorModalidadeFactory",
        "listarPagamentosFornecedorPorPagamentoFactory",
        "$filter"
    ];

    /**
    * @ngdoc overview
    * @name autorizarPagamentoController
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Extrato de Movimentações.
    **/
    function autorizarPagamentoController(sfNavegador,
        sfMemorizador,
        modal,
        contexto,
        utilitarios,
        interpretadorComunicacao,
        autorizarPagamentosFornecedorPorModalidadeFactory,
        autorizarPagamentosFornecedorPorPagamentoFactory,
        listarContasFactory,
        listarPagamentosFornecedorPorContaFactory,
        listarPagamentosFornecedorPorModalidadeFactory,
        listarPagamentosFornecedorPorPagamentoFactory,
        $filter
    ) {

        var vm = this;

        vm.iniciar = iniciar;
        vm.voltar = voltar;
        vm.confirmar = confirmar;

        vm.removeFiltroDataModalidade = removeFiltroDataModalidade;
        vm.removeFiltroDataPagamento = removeFiltroDataPagamento;
        vm.removeFiltroDataConta = removeFiltroDataConta;
        vm.filtrarModalidade = filtrarModalidade;
        vm.filtrarPagamento = filtrarPagamento;
        vm.filtrarConta = filtrarConta;
        vm.carregaDatePickerModalidade = carregaDatePickerModalidade;
        vm.carregaDatePickerPagamento = carregaDatePickerPagamento;
        vm.carregaDatePickerConta = carregaDatePickerConta;

        vm.alertasModalidade = [];
        vm.alertasPagamento = [];
        vm.alertasConta = [];
        vm.alertasDados = [];

        //variaveis utilizadas no filtra de datas
        var dtInicio;
        var pickerDtMaximo, pickerDtMinimo;
        var tipoFiltroPagamentoModalidade = null;

        vm.filtroAberto = false;

        vm.conta = {
            visivel: true,
            exibir: exibir,
            ocultar: ocultar,
            cnpj: null,
            agencia: null,
            numero: null,
            dv: null,
            abrirModal: abrirModalSelecaoConta,
            lista: null,
            erroNaTransacao: false
        };

        vm.contaPreferencial = {
            agencia: null,
            numero: null,
            cnpj: null,
            dv: null
        };

        vm.atualizarTotalizador = atualizarTotalizador;
        vm.atualizarTotalizadorSelecionado = atualizarTotalizadorSelecionado;

        vm.listaPagamentosPorConta = {};

        vm.listaPagamentosPorModalidade = {};

        vm.listaPagamentosPorPagamento = {};

        vm.validarSenha = validarSenha;

        vm.autorizarConta = {
            desabilitado: false
        };

        vm.autorizarModalidade = {
            desabilitado: false
        };

        vm.autorizarPagamento = {
            desabilitado: false
        };

        /**
        * FORNECEDORES 
        * TRIBUTOS
        **/
        vm.tipoAutorizacao = null;

        /**
        * MODALIDADE 
        * CONTA
        * PAGAMENTOS
        **/
        vm.tipoPagamento = null;

        /**
        * TED 
        * VRBOLETOS
        * MAIS
        **/
        vm.tipoFiltroPagamento = null;

        vm.filtroValorMaximo = null;
        vm.filtroValorMinimo = null;
        vm.filtroDocumento = null;

        vm.pagamentoContaSelecionado = null;
        vm.selecionarPagamentoConta = selecionarPagamentoConta;
        vm.selecionarPagamentoModalidade = selecionarPagamentoModalidade;

        vm.valorTotalSelecionadoPagamentoPorPagamentos = 0;
        vm.valorTotalPagamentoPorPagamentos = 0;

        vm.abrirAutorizacaoFornecedores = abrirAutorizacaoFornecedores;
        vm.abrirAutorizacaoTributos = abrirAutorizacaoTributos;

        vm.abrirAbaModalidades = abrirAbaModalidades;
        vm.abrirAbaContas = abrirAbaContas;
        vm.abrirAbaPagamentos = abrirAbaPagamentos;
        vm.abrirFiltrarPagamentos = abrirFiltrarPagamentos;

        vm.filtrarPagamentosTED = filtrarPagamentosTED;
        vm.filtrarPagamentosVRBoletos = filtrarPagamentosVRBoletos;
        vm.filtrarPagamentosDDA = filtrarPagamentosDDA;
        vm.filtrarPagamentosDOC = filtrarPagamentosDOC;
        vm.filtrarPagamentosTransferencias = filtrarPagamentosTransferencias;
        vm.filtrarPagamentosChequeADM = filtrarPagamentosChequeADM;

        vm.iniciar();


        /**
        * @ngdoc overview
        * @name iniciar
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método responsável por inicializar as variáveis da controller
        **/
        function iniciar() {
            vm.autorizarConta.desabilitado = true;
            vm.autorizarModalidade.desabilitado = true;
            vm.autorizarPagamento.desabilitado = true;

            carregarPreferencial();

            if (vm.contaPreferencial.agencia != null
                && vm.contaPreferencial.numero != null) {

                transacaoListarPagamentosPorModalidade();
            } else {
                transacaoConta();
            }

            vm.tipoAutorizacao = "FORNECEDORES";
            vm.tipoPagamento = "MODALIDADE";
            vm.tipoFiltroPagamento = "";

            iniciaDatePicker();
            vm.dtpickerInicioModalidadeAberto = false;
            vm.dtpickerInicioPagamentoAberto = false;
            vm.dtpickerInicioContaAberto = false;

            iniciarSlider();
        }

        /**
         * @ngdoc overview
         * 
         * @name SelecionarPagamentoConta
         * 
         * @memberOf autorizarPagamentoController.js
         * 
         * @description
         * Método responsável pela seleção do pagto
         */
        function selecionarPagamentoConta() {
            if (vm.pagamentoContaSelecionado != null) {
                vm.autorizarConta.desabilitado = false;
            }
            else {
                vm.autorizarConta.desabilitado = true;
            }
        }

        /**
         * @ngdoc overview
         * 
         * @name SelecionarPagamentoModalidade
         * 
         * @memberOf autorizarPagamentoController.js
         * 
         * @description
         * Método responsável pela seleção do pagto
         */
        function selecionarPagamentoModalidade() {
            if (vm.pagamentoSelecionado != null) {
                vm.autorizarModalidade.desabilitado = false;
                tipoFiltroPagamentoModalidade = vm.pagamentoSelecionado;
            }
            else {
                vm.autorizarModalidade.desabilitado = true;
            }
        }

        /**
        * @ngdoc overview
        * @name carregarPreferencial
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método responsável por recupeara a conta preferencial e popular a conta exibida.
        **/
        function carregarPreferencial() {
            var contaPreferencial = sfMemorizador.obter("autorizacaoPagamento.contaPreferencial");

            if (angular.isDefined(contaPreferencial) && contaPreferencial != null) {
                vm.conta.cnpj = contaPreferencial.cnpj;
                vm.conta.agencia = contaPreferencial.agencia;
                vm.conta.numero = contaPreferencial.numero;
                vm.contaPreferencial = contaPreferencial;
                atualizarConta();
            }
        }

        /**
        * @ngdoc overview
        * @name atualizarConta
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método responsável por atualizar a conta em uso através da conta preferencial.
        **/
        function atualizarConta() {
            vm.conta.agencia = vm.contaPreferencial.agencia;
            vm.conta.numero = vm.contaPreferencial.numero;
            vm.conta.cnpj = vm.contaPreferencial.cnpj;
        }

        /**
        * @ngdoc overview
        * @name abrirModalSelecaoConta
        *
        * @memberOf autorizarPagamentoController.js
        *
        * @description
        * Método incializa e abre a modal de seleção de contas do cliente
        **/
        function abrirModalSelecaoConta() {
            transacaoConta();
        }

        /**
        * @ngdoc overview
        * @name abrirModalAutorizarPagamento
        *
        * @memberOf autorizarPagamentoController.js
        *
        * @description
        * Método incializa e abre a modal de seleção de contas do cliente
        **/
        function abrirModalAutorizarPagamento() {
            modal.abrirModal(undefined,
                undefined,
                "modalAutorizarPagamento",
                validarSenha,
                undefined, {
                    "valorTotalSelecionado": vm.valorTotalSelecionadoPagamentoPorPagamentos,
                    "quantidadeItens": "25"
                },
                undefined,
                "scCtrl",
                "md");
        }

        /**
        * @ngdoc overview
        * @name atualizarContaEmUso
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método que atualiza a conta preferencial com base na conta selecionada na modal
        **/
        function atualizarContaEmUso(conta) {
            if (angular.isUndefined(conta)
                || conta == null
                || isNaN(conta.agencia)
                || isNaN(conta.conta)) {
                return false;
            }

            vm.contaPreferencial.agencia = conta.agencia;
            vm.contaPreferencial.numero = conta.conta;
            vm.contaPreferencial.cnpj = conta.cnpj;
            vm.contaPreferencial.nome = conta.nome;

            sfMemorizador.definir("autorizacaoPagamento.contaPreferencial", vm.contaPreferencial);
            atualizarConta();

            iniciaDatePicker();
            vm.dtpickerInicioModalidadeAberto = false;
            vm.dtpickerInicioPagamentoAberto = false;
            vm.dtpickerInicioContaAberto = false;

            iniciarSlider();

            if (vm.tipoPagamento == "CONTA") {
                transacaoListarPagamentosPorConta();
            }
            else if (vm.tipoPagamento == "MODALIDADE") {
                transacaoListarPagamentosPorModalidade();
            }
            else if (vm.tipoPagamento == "PAGAMENTOS") {
                transacaoListarPagamentosPorPagamento();
            }

            return false;
        }

        /**
        * @ngdoc overview
        * @name exibir
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método responsável por mostrar o controle atráves da variável 'visivel'.
        **/
        function exibir() {
            this.visivel = true;
        }

        /**
        * @ngdoc overview
        * @name ocultar
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método responsável por esconder o controle atráves da variável 'visivel'.
        **/
        function ocultar() {
            this.visivel = false;
        }

        /**
       * @ngdoc overview
       * @name abrirAutorizacaoFornecedores
       * 
       * @memberOf autorizarPagamentoController.js
       *
       * @description        
       * Método incializar e abrir a aba de fornecedores
       **/
        function abrirAutorizacaoFornecedores() {
            vm.tipoAutorizacao = "FORNECEDORES";
        }
        /**
        * @ngdoc overview
        * @name abrirAutorizacaoTributos
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método incializar e abrir a aba de tributos
        **/
        function abrirAutorizacaoTributos() {
            vm.tipoAutorizacao = "TRIBUTOS";
            sfNavegador.navegar("autorizacao-tributo");
        }

        /**
        * @ngdoc overview
        * @name abrirAbaModalidades
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método incializar e abrir a aba de modalidades
        **/
        function abrirAbaModalidades() {
            vm.tipoPagamento = "MODALIDADE";
            transacaoListarPagamentosPorModalidade();

            selecionarPagamentoModalidade();
        }
        /**
        * @ngdoc overview
        * @name abrirAbaContas
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método incializar e abrir a aba de contas
        **/
        function abrirAbaContas() {
            vm.tipoPagamento = "CONTA";
            transacaoListarPagamentosPorConta();

            selecionarPagamentoConta();
        }
        /**
        * @ngdoc overview
        * @name abrirAbaPagamentos
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método incializar e abrir a aba de pagamentos
        **/
        function abrirAbaPagamentos() {
            vm.tipoPagamento = "PAGAMENTOS";
            transacaoListarPagamentosPorPagamento();
        }

        /**
        * @ngdoc overview
        * @name abrirAbaModalidades
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método incializar e abrir a aba de modalidades
        **/
        function filtrarPagamentosTED() {
            vm.tipoFiltroPagamento = "TED";
            transacaoListarPagamentosPorPagamento();
            //atualizarTotalizadorSelecionado();
        }
        /**
        * @ngdoc overview
        * @name abrirAbaContas
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método incializar e abrir a aba de contas
        **/
        function filtrarPagamentosVRBoletos() {
            vm.tipoFiltroPagamento = "BLQ";
            transacaoListarPagamentosPorPagamento();
            //atualizarTotalizadorSelecionado();
        }
        /**
        * @ngdoc overview
        * @name filtrarPagamentosDDA
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método que filtra os pgtos
        **/
        function filtrarPagamentosDDA() {
            vm.tipoFiltroPagamento = "DDA";
            transacaoListarPagamentosPorPagamento();
            //atualizarTotalizadorSelecionado();
        }

        /**
        * @ngdoc overview
        * @name filtrarPagamentosDOC
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método que filtra os pgtos
        **/
        function filtrarPagamentosDOC() {
            vm.tipoFiltroPagamento = "DOC";
            transacaoListarPagamentosPorPagamento();
            //atualizarTotalizadorSelecionado();
        }

        /**
        * @ngdoc overview
        * @name filtrarPagamentosTransferencias
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método que filtra os pgtos
        **/
        function filtrarPagamentosTransferencias() {
            vm.tipoFiltroPagamento = "CC ";
            transacaoListarPagamentosPorPagamento();
            //atualizarTotalizadorSelecionado();
        }

        /**
        * @ngdoc overview
        * @name filtrarPagamentosChequeADM
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método que filtra os pgtos
        **/
        function filtrarPagamentosChequeADM() {
            vm.tipoFiltroPagamento = "CHQ";
            transacaoListarPagamentosPorPagamento();
            //atualizarTotalizadorSelecionado();
        }

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento
        *
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltar() {
            vm.filtroAberto = false;
            sfNavegador.voltar();
        }

        /**
        * @ngdoc method
        * @name confirmar
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento
        *
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function confirmar() {
            transacaoListarPagamentosPorPagamento();
            sfNavegador.voltar();
        }

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento
        *
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function abrirFiltrarPagamentos() {
            vm.filtroAberto = true;
            sfNavegador.navegar("filtrar-pagamentos");
        }

        /**
        * @ngdoc method
        * @name transacaoListarPagamentosPorConta
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento
        *
        * @description
        * Método responsável por realizar a transação que lista os pagamentos.
        **/
        function transacaoListarPagamentosPorConta() {

            var filtroData = formatarDataAAAAMMDD(obterDataSelecionada(vm.dtpickerInicioConta, vm.sliderInicioConta));

            limparVariaveis();
            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            interpretadorComunicacao.interpretar(
                listarPagamentosFornecedorPorContaFactory
                    .listarPagamentos({
                        "PGPC_RC_DT_PGTO": filtroData,
                        "shortname": dadosLogin.shortname,
                        "userId": dadosLogin.username
                    }))
                .sucesso(listarPagamentosFornecedorPorContaSucesso)
                .aviso(listarPagamentosFornecedorPorContaErro)
                .erro(listarPagamentosFornecedorPorContaErro);

            /**
            * @ngdoc method
            * @name sucesso
            *
            * @methodOf apl-mobile-pj.autorizacaoPagamento
            *
            * @description
            * Método de callback disparado em caso de sucesso na transação de listar pagamentos.
            **/
            function listarPagamentosFornecedorPorContaSucesso(data) {
                vm.listaPagamentosPorConta = data.PGPC_EV_ITEM;
            }

            /**
            * @ngdoc method
            * @name erro
            *
            * @methodOf apl-mobile-pj.autorizacaoPagamento
            *
            * @description
            * Método de callback disparado em caso de erro na transação de listar pagamentos
            **/
            function listarPagamentosFornecedorPorContaErro() {
                preencherAlertaDados("warning", "Não há dados", "./app/assets/img/Pendencias_60x60pt_Ocre.png");
            }

        }


        /**
        * @ngdoc method
        * @name transacaoListarPagamentosPorModalidade
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento
        *
        * @description
        * Método responsável por realizar a transação que lista os pagamentos.
        **/
        function transacaoListarPagamentosPorModalidade() {

            //TODO XASAN Tirar mock
            var filtroData = formatarDataAAAAMMDD(obterDataSelecionada(vm.dtpickerInicioModalidade, vm.sliderInicioModalidade));
            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var requisicao = {
                PGPM_RC_DT_PGTO: filtroData,
                PGPM_RC_AGENCIA: vm.conta.agencia.toString(),
                PGPM_RC_CONTA: vm.conta.numero.toString(),
                shortname: dadosLogin.shortname,
                userId: dadosLogin.username
            };

            limparVariaveis();

            interpretadorComunicacao
                .interpretar(listarPagamentosFornecedorPorModalidadeFactory
                    .listarPagamentos(requisicao))
                .sucesso(listarPagamentosFornecedorPorModalidadeSucesso)
                .aviso(listarPagamentosFornecedorPorModalidadeErro)
                .erro(listarPagamentosFornecedorPorModalidadeErro);

            /**
            * @ngdoc method
            * @name erro
            *
            * @methodOf apl-mobile-pj.autorizacaoPagamento
            *
            * @description
            * Método de callback disparado em caso de erro na transação de listar pagamentos
            **/
            function listarPagamentosFornecedorPorModalidadeErro() {
                preencherAlertaDados("warning", "Não há dados", "./app/assets/img/Pendencias_60x60pt_Ocre.png");
            }

            /**
            * @ngdoc method
            * @name sucesso
            *
            * @methodOf apl-mobile-pj.autorizacaoPagamento
            *
            * @description
            * Método de callback disparado em caso de sucesso na transação de listar pagamentos.
            **/
            function listarPagamentosFornecedorPorModalidadeSucesso(data) {
                vm.listaPagamentosPorModalidade = data.PGPM_EV_ITEM;
            }
        }


        /**
        * @ngdoc method
        * @name transacaoAutorizarPagamentosPorModalidade
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento
        *
        * @description
        * Método responsável por realizar a transação que lista os pagamentos.
        **/
        function transacaoAutorizarPagamentosPorModalidadeOuConta(dataFiltro, senha) {
            if (vm.conta.agencia == null
                || vm.conta.numero == null) {
                return;
            }

            if (tipoFiltroPagamentoModalidade == undefined || tipoFiltroPagamentoModalidade == null) {
                tipoFiltroPagamentoModalidade = "";
            }

            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var dataFormatada = formatarDataAAAAMMDD(dataFiltro);
            var requisicao = {
                PGGC_RC_DT_PAG_INI: dataFormatada,
                PGGC_RC_DT_PAG_FIM: dataFormatada,
                PGGC_RC_TP_PAG: tipoFiltroPagamentoModalidade,
                PGGC_RC_SENHA: senha,
                PGGC_RC_QT_OCOR: 1,
                PGGC_RC_OCOR: [{
                    PGGC_RC_CD_AG: vm.conta.agencia,
                    PGGC_RC_CD_CT: vm.conta.numero
                }],
                agencia: vm.conta.agencia,
                contaCorrente: vm.conta.numero,
                baseCGC: vm.conta.cnpj,
                shortname: dadosLogin.shortName,
                userId: dadosLogin.username
            };

            interpretadorComunicacao.interpretar(autorizarPagamentosFornecedorPorModalidadeFactory
                .autorizarPagamentos(requisicao))
                .sucesso(autorizarPagamentosFornecedorPorModalidadeSucesso)
                .aviso(autorizarPagamentosFornecedorPorModalidadeAviso)
                .erro(autorizarPagamentosFornecedorPorModalidadeErro);

            // var data = {"PGAG_EV_OCOR": [{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "61086336000103","PGAG_EV_COMPROM": "DDATESTE","PGAG_EV_DT_PAG": "20141010","PGAG_EV_VLR_COMPROM": "00000000000093918","PGAG_EV_SITUACAO": "AUTORIZACAO REGISTRADA","PGAG_EV_MENS_OCOR": "CONTA NAO HABILITADA PARA PAGAMENTO DE TITULOS DDA","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00000740736809","PGAG_EV_COMPROM": "OUTFSGSGH","PGAG_EV_DT_PAG": "20141010","PGAG_EV_VLR_COMPROM": "00000000000004100","PGAG_EV_SITUACAO": "AUTORIZACAO REGISTRADA","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "02878230000183","PGAG_EV_COMPROM": "BLQWERWER","PGAG_EV_DT_PAG": "20141107","PGAG_EV_VLR_COMPROM": "00000000000000456","PGAG_EV_SITUACAO": "AUTORIZACAO REGISTRADA","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00000442272138","PGAG_EV_COMPROM": "OUTT1011141","PGAG_EV_DT_PAG": "20141110","PGAG_EV_VLR_COMPROM": "00000000000045100","PGAG_EV_SITUACAO": "AUTORIZACAO REGISTRADA","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "99999900000232","PGAG_EV_COMPROM": "BLL0114122739","PGAG_EV_DT_PAG": "20150114","PGAG_EV_VLR_COMPROM": "00000000000006512","PGAG_EV_SITUACAO": "   ","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "99999900000151","PGAG_EV_COMPROM": "BLL0114120252","PGAG_EV_DT_PAG": "20150114","PGAG_EV_VLR_COMPROM": "00000000000006512","PGAG_EV_SITUACAO": "AUTORIZACAO REGISTRADA","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "02558157000162","PGAG_EV_COMPROM": "BLL0114120456","PGAG_EV_DT_PAG": "20150114","PGAG_EV_VLR_COMPROM": "00000000000000233","PGAG_EV_SITUACAO": "AUTORIZACAO REGISTRADA","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "61602199019484","PGAG_EV_COMPROM": "OUT123456000","PGAG_EV_DT_PAG": "20151013","PGAG_EV_VLR_COMPROM": "000000000001500,00","PGAG_EV_SITUACAO": "AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00034721535805","PGAG_EV_COMPROM": "OUT15048490","PGAG_EV_DT_PAG": "20151013","PGAG_EV_VLR_COMPROM": "00000000000123000","PGAG_EV_SITUACAO": "AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00036923151805","PGAG_EV_COMPROM": "OUT123465088","PGAG_EV_DT_PAG": "20151013","PGAG_EV_VLR_COMPROM": "00000000000150000","PGAG_EV_SITUACAO": "PAGAMENTO AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00036923151805","PGAG_EV_COMPROM": "OUT1234567490","PGAG_EV_DT_PAG": "20151013","PGAG_EV_VLR_COMPROM": "00000000000150000","PGAG_EV_SITUACAO": "PAGAMENTO AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00036923151805","PGAG_EV_COMPROM": "OUT1515654888","PGAG_EV_DT_PAG": "20151013","PGAG_EV_VLR_COMPROM": "00000000000150000","PGAG_EV_SITUACAO": "AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00036923151805","PGAG_EV_COMPROM": "OUT1234567890","PGAG_EV_DT_PAG": "20151013","PGAG_EV_VLR_COMPROM": "00000000000150000","PGAG_EV_SITUACAO": "AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "S"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00036923151805","PGAG_EV_COMPROM": "OUT123456407/","PGAG_EV_DT_PAG": "20151013","PGAG_EV_VLR_COMPROM": "00000000001260000","PGAG_EV_SITUACAO": "NAO AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "N"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00036923151805","PGAG_EV_COMPROM": "OUT123456789","PGAG_EV_DT_PAG": "20151014","PGAG_EV_VLR_COMPROM": "00000000000150000","PGAG_EV_SITUACAO": "NAO AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "N"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00008521716842","PGAG_EV_COMPROM": "OUT1015000","PGAG_EV_DT_PAG": "20151014","PGAG_EV_VLR_COMPROM": "00000000000150000","PGAG_EV_SITUACAO": "NAO AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "N"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00036923151805","PGAG_EV_COMPROM": "OUT1234156000","PGAG_EV_DT_PAG": "20151015","PGAG_EV_VLR_COMPROM": "00000000000150000","PGAG_EV_SITUACAO": "NAO AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "N"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00013141244987","PGAG_EV_COMPROM": "OUT12312312","PGAG_EV_DT_PAG": "20151015","PGAG_EV_VLR_COMPROM": "00000000000100000","PGAG_EV_SITUACAO": "NAO AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "N"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00036923151805","PGAG_EV_COMPROM": "OUT1230","PGAG_EV_DT_PAG": "20151016","PGAG_EV_VLR_COMPROM": "00000000000123000","PGAG_EV_SITUACAO": "NAO AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "N"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00036923151805","PGAG_EV_COMPROM": "OUT123011","PGAG_EV_DT_PAG": "20151016","PGAG_EV_VLR_COMPROM": "00000000000015000","PGAG_EV_SITUACAO": "NAO AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "N"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00011808915895","PGAG_EV_COMPROM": "OUT15600","PGAG_EV_DT_PAG": "20151016","PGAG_EV_VLR_COMPROM": "00000000000150000","PGAG_EV_SITUACAO": "NAO AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "N"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00000891373888","PGAG_EV_COMPROM": "BLQ567567","PGAG_EV_DT_PAG": "20151105","PGAG_EV_VLR_COMPROM": "00000000000001100","PGAG_EV_SITUACAO": "NAO AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "N"},{"PGAG_EV_AGENCIA": "00200","PGAG_EV_CONTA": "001636800","PGAG_EV_CGC_CPF_FORN": "00003635343692","PGAG_EV_COMPROM": "OUT123789","PGAG_EV_DT_PAG": "20151205","PGAG_EV_VLR_COMPROM": "00000000000001000","PGAG_EV_SITUACAO": "NAO AUTORIZADO","PGAG_EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","PGAG_EV_I_SUCESS": "N"}],"statusProcessamento": {"mensagem": {"codigo": "","descricao": "","severidade": "00"}} };

            // autorizarPagamentosFornecedorPorModalidadeSucesso(data);

            /**
            * @ngdoc method
            * @name sucesso
            *
            * @methodOf apl-mobile-pj.autorizacaoPagamento
            *
            * @description
            * Método de callback disparado em caso de sucesso na transação de Autorizar pagamentos.
            **/
            function autorizarPagamentosFornecedorPorModalidadeSucesso(data) {
                var estadoAutorizacao = {
                    "estado": "success"
                };
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos", data);
                contexto.definirValorContextoTrabalho("estadoAutorizacao", estadoAutorizacao);
                sfNavegador.navegar("detalhar-pagamento");
            }

            /**
            * @ngdoc method
            * @name Erro
            *
            * @methodOf apl-mobile-pj.autorizacaoPagamento
            *
            * @description
            * Método de callback disparado em caso de erro na transação de Autorizar pagamentos.
            **/
            function autorizarPagamentosFornecedorPorModalidadeErro(data) {
                var estadoAutorizacao = {
                    "estado": "danger"
                };
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos", data);
                contexto.definirValorContextoTrabalho("estadoAutorizacao", estadoAutorizacao);
                sfNavegador.navegar("detalhar-pagamento");
            }

            /**
            * @ngdoc method
            * @name Aviso
            *
            * @methodOf apl-mobile-pj.autorizacaoPagamento
            *
            * @description
            * Método de callback disparado em caso de aviso na transação de Autorizar pagamentos.
            **/
            function autorizarPagamentosFornecedorPorModalidadeAviso(data) {
                var estadoAutorizacao = {
                    "estado": "warning"
                };
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos", data);
                contexto.definirValorContextoTrabalho("estadoAutorizacao", estadoAutorizacao);
                sfNavegador.navegar("detalhar-pagamento");
            }
        }


        /**
        * @ngdoc method
        * @name transacaoListarPagamentosPorPagamento
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento
        *
        * @description
        * Método responsável por realizar a transação que lista os pagamentos.
        **/
        function transacaoListarPagamentosPorPagamento() {

            //TODO XASAN remover mock
            var dataFormatada = formatarDataAAAAMMDD(obterDataSelecionada(vm.dtpickerInicioPagamento, vm.sliderInicioPagamento));
            //var dataFormatada = "20151013";
            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var requerimento = {
                PGCC7_RC_AGENCIA: vm.conta.agencia.toString(),
                PGCC7_RC_CONTA: vm.conta.numero.toString(),
                PGCC7_RC_DT_PAG_INI: dataFormatada,
                PGCC7_RC_DT_PAG_FIN: dataFormatada,
                PGCC7_RC_TP_PAG: vm.tipoFiltroPagamento,
                PGCC7_RC_CGC_FORN: vm.filtroDocumento == null ? "" : vm.filtroDocumento,
                PGCC7_RC_VLR_MIN: vm.filtroValorMinimo == null ? "" : vm.filtroValorMinimo,
                PGCC7_RC_VLR_MAX: vm.filtroValorMaximo == null ? "" : vm.filtroValorMaximo,
                PGCC7_RC_DT_VCT_INI: dataFormatada,
                PGCC7_RC_DT_VCT_FIN: dataFormatada,
                agencia: vm.conta.agencia,
                contaCorrente: vm.conta.numero,
                baseCGC: vm.conta.cnpj,
                shortname: dadosLogin.shortname,
                userId: dadosLogin.username
            };

            limparVariaveis();

            interpretadorComunicacao.interpretar(
                listarPagamentosFornecedorPorPagamentoFactory
                    .listarPagamentos(requerimento))
                .sucesso(listarPagamentosFornecedorPorPagamentoSucesso)
                .aviso(listarPagamentosFornecedorPorPagamentoErro)
                .erro(listarPagamentosFornecedorPorPagamentoErro);

            /**
            * @ngdoc method
            * @name sucesso
            *
            * @methodOf apl-mobile-pj.autorizacaoPagamento
            *
            * @description
            * Método de callback disparado em caso de sucesso na transação de listar pagamentos.
            **/
            function listarPagamentosFornecedorPorPagamentoSucesso(data) {
                vm.listaPagamentosPorPagamento = data.PGCC7_EV_ITEM;
                atualizarTotalizador(data.PGCC7_EV_ITEM);
            }

            /**
            * @ngdoc method
            * @name erro
            *
            * @methodOf apl-mobile-pj.autorizacaoPagamento
            *
            * @description
            * Método de callback disparado em caso de erro na transação de listar pagamentos
            **/
            function listarPagamentosFornecedorPorPagamentoErro() {
                preencherAlertaDados("warning", "Não há dados", "./app/assets/img/Pendencias_60x60pt_Ocre.png");
            }
        }


        /**
        * @ngdoc method
        * @name transacaoAutorizarPagamentosPorPagamento
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento
        *
        * @description
        * Método responsável por realizar a transação que lista os pagamentos.
        **/
        function transacaoAutorizarPagamentosPorPagamento(senha) {

            var pagamentosSelecionados = vm.listaPagamentosPorPagamento
                .filter(function (data) {
                    return data.selecionado;
                });
            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var pagamentosPendenteAutorizacao = {
                PGOP_RC_AGENCIA: vm.conta.agencia,
                PGOP_RC_CONTA: vm.conta.numero,
                PGOP_RC_SENHA: senha,
                PGOP_RC_QT_OCOR: pagamentosSelecionados.length,
                PGOP_RC_OCOR: [],
                agencia: vm.conta.agencia,
                contaCorrente: vm.conta.numero,
                baseCGC: vm.conta.cnpj,
                shortname: dadosLogin.shortname,
                userId: dadosLogin.username
            };


            angular.forEach(pagamentosSelecionados, function (value) {
                pagamentosPendenteAutorizacao.PGOP_RC_OCOR.push({
                    "PGOP_RC_CGC_CPF_FORN": value.PGCC7_EV_CGC_FORN,
                    "PGOP_RC_COMPROM": value.PGCC7_EV_COMPRP,
                    "PGOP_RC_DT_PAG": value.PGCC7_EV_DT_PAG,
                    "PGOP_RC_VLR_COMPROM": value.PGCC7_EV_VLR_CPR,
                    "PGOP_RC_TP_COMPROM": value.PGCC7_EV_TP_PAG,
                    "PGOP_RC_CEDENTE": value.PGCC7_EV_NOM_FORN,
                    "PGOP_RC_SITUACAO": value.PGCC7_EV_SIT
                });
            });

            //definirContexto(vm.conta.cnpj, vm.conta.agencia, vm.conta.numero);

            interpretadorComunicacao.interpretar(
                autorizarPagamentosFornecedorPorPagamentoFactory
                    .autorizarPagamentos(pagamentosPendenteAutorizacao))
                .sucesso(autorizarPagamentosFornecedorPorPagamentoSucesso)
                .aviso(autorizarPagamentosFornecedorPorPagamentoAviso)
                .erro(autorizarPagamentosFornecedorPorPagamentoErro);


            /**
            * @ngdoc method
            * @name sucesso
            *
            * @methodOf apl-mobile-pj.autorizacaoPagamento
            *
            * @description
            * Método de callback disparado em caso de sucesso na transação de Autorizar pagamentos.
            **/
            function autorizarPagamentosFornecedorPorPagamentoSucesso(data) {
                var estadoAutorizacao = {
                    "estado": "success"
                };
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos", data);
                contexto.definirValorContextoTrabalho("estadoAutorizacao", estadoAutorizacao);
                sfNavegador.navegar("detalhar-pagamento");
            }

            /**
            * @ngdoc method
            * @name erro
            *
            * @methodOf apl-mobile-pj.autorizacaoPagamento
            *
            * @description
            * Método de callback disparado em caso de erro na transação de Autorizar pagamentos
            **/
            function autorizarPagamentosFornecedorPorPagamentoErro(data) {
                var estadoAutorizacao = {
                    "estado": "danger"
                };
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos", data);
                contexto.definirValorContextoTrabalho("estadoAutorizacao", estadoAutorizacao);
                sfNavegador.navegar("detalhar-pagamento");
            }

            /**
            * @ngdoc method
            * @name aviso
            *
            * @methodOf apl-mobile-pj.autorizacaoPagamento
            *
            * @description
            * Método de callback disparado em caso de aviso na transação de Autorizar pagamentos
            **/
            function autorizarPagamentosFornecedorPorPagamentoAviso(data) {
                var estadoAutorizacao = {
                    "estado": "warning"
                };
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos", data);
                contexto.definirValorContextoTrabalho("estadoAutorizacao", estadoAutorizacao);
                sfNavegador.navegar("detalhar-pagamento");
            }
        }



        /**
        * @ngdoc method
        * @name atualizarTotalizador
        *  
        * @description
        * Método responsável atualizar valor total de pagamento por pagamentos
        **/
        function atualizarTotalizador(data) {
            var valorTotal = 0;
            for (var item in data) {
                var element = data[item];
                valorTotal += parseFloat(element.PGCC7_EV_VLR_CPR);
            }

            vm.valorTotalPagamentoPorPagamentos = valorTotal;

            vm.filtroValorMinimo = 0;
            vm.filtroValorMaximo = parseInt(valorTotal);

            preencheOpcoesSliderFiltroPag(vm.filtroValorMaximo);
        }

        /**
        * @ngdoc method
        * @name atualizarTotalizadorSelecionado
        *  
        * @description
        * Método responsável atualizar variavel que controle o check de pagamento por pagamentos
        * e somar o valor total selecionado
        **/
        function atualizarTotalizadorSelecionado() {

            var itensSelecionados = vm.listaPagamentosPorPagamento.filter(function (item) {
                return item.selecionado == true;
            });

            var quantidadeItens = 0;
            var valorTotalSelecionado = 0;
            for (var item in itensSelecionados) {
                var element = itensSelecionados[item];
                valorTotalSelecionado += parseFloat(element.PGCC7_EV_VLR_CPR);
                quantidadeItens++;
            }

            vm.valorTotalSelecionadoPagamentoPorPagamentos = valorTotalSelecionado;

            if (quantidadeItens > 0) {
                vm.autorizarPagamento.desabilitado = false;

                if (quantidadeItens == 25) {

                    angular.forEach(vm.listaPagamentosPorPagamento, function (pgto) {

                        if (pgto.selecionado == true) {
                            pgto.desabilitado = false;
                        }
                        else {
                            pgto.desabilitado = true;
                        }
                    });
                    abrirModalAutorizarPagamento();
                }
                else {
                    angular.forEach(vm.listaPagamentosPorPagamento, function (pgto) {
                        pgto.desabilitado = false;
                    });
                }
            }
            else {
                vm.autorizarPagamento.desabilitado = true;
            }
        }

        /**
        * @ngdoc overview
        * @name transacaoConta
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método que realiza a consulta das contas vinculadas ao cliente
        **/
        function transacaoConta() {

            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var requisicao = {
                shortname: dadosLogin.shortname,
                userId: dadosLogin.username
            };

            interpretadorComunicacao.interpretar(listarContasFactory.listarContas(requisicao))
                .sucesso(listarContasSucesso)
                .aviso(listarContasErro)
                .erro(listarContasErro);

            /**
            * @ngdoc overview
            * @name erroTransacaoConta
            * 
            * @memberOf extratoMovimentacaoController.js
            *
            * @description        
            * Método executado em caso de erro na consulta das contas do cliente
            **/
            function listarContasErro() {
                vm.conta.erroNaTransacao = true;
            }

            // var data = {"lista": [{"cnpj": "000382468","nome": "COLGATE PALMOLIVE C","contas": [{"agencia": "11500","conta": "0010107","tipoConta": "1"}]},{"cnpj": "001689775","nome": "CSRR COM DE VESTUAR","contas": [{"agencia": "00200","conta": "1684618","tipoConta": "1"}]},{"cnpj": "002428624","nome": "TRIP LINHAS AEREAS","contas": [{"agencia": "11500","conta": "0036611","tipoConta": "1"}]},{"cnpj": "003331223","nome": "CUSTO ZERO C I CONF","contas": [{"agencia": "00200","conta": "1683000","tipoConta": "1"}]},{"cnpj": "033200056","nome": "LOJAS RIACHUELO S A","contas": [{"agencia": "11500","conta": "0008358","tipoConta": "1"}]},{"cnpj": "041519042","nome": "LIGARE TELECOMUNICA","contas": [{"agencia": "00200","conta": "1670307","tipoConta": "1"}]},{"cnpj": "043086529","nome": "ELMO SERV AUX DE ED","contas": [{"agencia": "00200","conta": "1678405","tipoConta": "1"}]},{"cnpj": "048770051","nome": "MIRACATU AUTO POSTO","contas": [{"agencia": "09700","conta": "0082932","tipoConta": "1"}]},{"cnpj": "049372154","nome": "TAB CONST E EMP IMO","contas": [{"agencia": "09700","conta": "0166885","tipoConta": "1"}]},{"cnpj": "061522173","nome": "ROSSET CIA LTDA","contas": [{"agencia": "00200","conta": "2012834","tipoConta": "1"}]},{"cnpj": "061558037","nome": "CMR IND E COM LTDA","contas": [{"agencia": "00200","conta": "1636800","tipoConta": "1"}]},{"cnpj": "062340674","nome": "LILY OF THE VALLEY","contas": [{"agencia": "00200","conta": "1682992","tipoConta": "1"}]},{"cnpj": "071535520","nome": "SINDICATO METALURGI","contas": [{"agencia": "00200","conta": "1653003","tipoConta": "1"}]},{"cnpj": "072829807","nome": "MEDIAWORKS SIST INF","contas": [{"agencia": "00200","conta": "1655847","tipoConta": "1"}]}],"statusProcessamento": {"mensagem": {"codigo": "","descricao": "","severidade": "00"}} };

            //listarContasSucesso(data);

            /**
            * @ngdoc overview
            * @name sucessoTransacaoConta
            * 
            * @memberOf extratoMovimentacaoController.js
            *
            * @description        
            * Método executado em caso de sucesso na consulta das contas do cliente
            **/
            function listarContasSucesso(data) {
                vm.conta.lista = data.lista;
                vm.conta.exibir();
                vm.conta.erroNaTransacao = false;

                modal.abrirModal(undefined, undefined, "modalSelecaoConta", atualizarContaEmUso,
                    undefined, { "lista": vm.conta.lista, "contaSelecionada": vm.contaPreferencial },
                    "selecionarContaController", "scCtrl", "md");
            }
        }

        /**
        * @ngdoc overview
        * @ngdoc method
        * @name formatarDataAAAAMMDD
        *
        * @description
        * Método responsável pela formatação
        **/
        function formatarDataAAAAMMDD(data) {
            return data.toISOString()
                .replace(/-/g, "")
                .substring(0, 8);
        }

        /**
         * @description
         * Método para abertura e validação de senhas pelo modal.
         */
        function validarSenha() {

            modal.abrirModal(undefined, undefined, "modalConfirmacaoSenha",
                confirmarSenhaToken, cancelouSenhaToken, {},
                "confirmacaoSenhaController", "csCtrl", "senha", "md");
        }

        /**
        * @ngdoc method
        * @name confirmarSenhaToken
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por confirmar senha e token e acionar a operação de liberar/excluir as maquinas.
        **/
        function confirmarSenhaToken(data) {
            //TODO: Validação de senha arq
            vm.resultadoValidacaoSenha = data;

            switch (vm.tipoPagamento) {
                case "MODALIDADE":
                    transacaoAutorizarPagamentosPorModalidadeOuConta(obterDataSelecionada(vm.dtpickerInicioModalidade, vm.sliderInicioModalidade), data.senha);
                    break;
                case "CONTA":
                    transacaoAutorizarPagamentosPorModalidadeOuConta(obterDataSelecionada(vm.dtpickerInicioConta, vm.sliderInicioConta), data.senha);
                    break;
                case "PAGAMENTOS":
                    transacaoAutorizarPagamentosPorPagamento(data.senha);
                    break;
                default:
                    break;
            }
        }

        /**
         * @description Método responsável por obter a data selecionada no momento
         */
        function obterDataSelecionada(dtPicker, slider) {
            if (dtPicker != undefined && dtPicker != null && dtPicker != "") {
                return dtPicker;
            } else {
                return gerarFiltroSlider(slider);
            }
        }

        /**
        * @ngdoc method
        * @name cancelouSenhaToken
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por cancelar a digitação de senha token.
        **/
        function cancelouSenhaToken(data) {
            //TODO: Validação de senha arq
            vm.resultadoValidacaoSenha = data;
        }

        /**
        * @ngdoc method
        * @name mostrarAlerta
        *  
        * @description
        * Método responsável por exibir o alerta de acordo com o retorno da comunicação
        **/
        function mostrarAlerta(tipoAlerta, data) {

            switch (vm.tipoPagamento) {
                case "MODALIDADE":
                    vm.alertasModalidade.push({ tipo: tipoAlerta, data: data });
                    break;
                case "CONTA":
                    vm.alertasConta.push({ tipo: tipoAlerta, data: data });
                    break;
                case "PAGAMENTOS":
                    vm.alertasPagamento.push({ tipo: tipoAlerta, data: data });
                    break;
                default:
                    break;
            }
        }

        /**
         * @ngdoc method
         *  * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeFiltroDataModalidade(executaTran) {
            vm.alertasModalidade = [];
            vm.buscaCalendarioModalidade = false;

            vm.dtpickerInicioModalidade = "";

            if (executaTran) {
                transacaoListarPagamentosPorModalidade();
            }
        }

        /**
         * @ngdoc method
         *  * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeFiltroDataPagamento(executaTran) {
            vm.alertasPagamento = [];
            vm.buscaCalendarioPagamento = false;

            vm.dtpickerInicioPagamento = "";

            if (executaTran) {
                transacaoListarPagamentosPorPagamento();
            }
        }

        /**
         * @ngdoc method
         *  * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeFiltroDataConta(executaTran) {
            vm.alertasConta = [];
            vm.buscaCalendarioConta = false;

            vm.dtpickerInicioConta = "";

            if (executaTran) {
                transacaoListarPagamentosPorConta();
            }
        }

        /**
        * @ngdoc method
        * @name filtrarModalidade
        *
        * @description
        * Preencha a data de fim do filtro de data a partir da seleção do datepicker e realiza a consulta
        **/
        function filtrarModalidade() {
            vm.buscaCalendarioModalidade = true;

            vm.dtOptions.minDate = pickerDtMinimo;

            mostrarAlerta("info", $filter("date")(vm.dtpickerInicioModalidade, "dd/MM"));

            transacaoListarPagamentosPorModalidade();
        }

        /**
        * @ngdoc method
        * @name filtrarModalidade
        *
        * @description
        * Preencha a data de fim do filtro de data a partir da seleção do datepicker e realiza a consulta
        **/
        function filtrarPagamento() {
            vm.buscaCalendarioPagamento = true;

            vm.dtOptions.minDate = pickerDtMinimo;

            mostrarAlerta("info", $filter("date")(vm.dtpickerInicioPagamento, "dd/MM"));

            transacaoListarPagamentosPorPagamento();
        }

        /**
        * @ngdoc method
        * @name filtrarConta
        *
        * @description
        * Preencha a data de fim do filtro de data a partir da seleção do datepicker e realiza a consulta
        **/
        function filtrarConta() {
            vm.buscaCalendarioConta = true;

            vm.dtOptions.minDate = pickerDtMinimo;

            mostrarAlerta("info", $filter("date")(vm.dtpickerInicioConta, "dd/MM"));

            transacaoListarPagamentosPorConta();
        }

        /**
        * @ngdoc method
        * @name carregaDatePickerModalidade
        *
        * @description
        * Exibe o datepicker
        **/
        function carregaDatePickerModalidade() {
            removeFiltroDataModalidade(false);
            iniciaDatePicker();

            vm.dtpickerInicioModalidadeAberto = true;
        }

        /**
        * @ngdoc method
        * @name carregaDatePickerModalidade
        *
        * @description
        * Exibe o datepicker
        **/
        function carregaDatePickerPagamento() {
            removeFiltroDataPagamento(false);
            iniciaDatePicker();

            vm.dtpickerInicioPagamentoAberto = true;
        }

        /**
        * @ngdoc method
        * @name carregaDatePickerConta
        *
        * @description
        * Exibe o datepicker
        **/
        function carregaDatePickerConta() {
            removeFiltroDataConta(false);
            iniciaDatePicker();

            vm.dtpickerInicioContaAberto = true;
        }

        /**
        * @ngdoc method
        * @name iniciaDatePicker
        *
        * @description
        * Carrega os valores iniciais do datepicker
        **/
        function iniciaDatePicker() {
            pickerDtMaximo = new Date();
            pickerDtMinimo = new Date();

            pickerDtMinimo.setDate(pickerDtMinimo.getDate() + 7);

            vm.dtOptions = {
                minDate: pickerDtMaximo,
                maxDate: pickerDtMinimo,
                maxMode: "day",
                showWeeks: false
            };
        }

        /**
        * @ngdoc method
        * @name carregarSlider
        *
        * @description
        * Método responsável por preencher os valores default do slider
        **/
        function iniciarSlider() {
            vm.buscaCalendarioModalidade = false;
            vm.buscaCalendarioPagamento = false;
            vm.buscaCalendarioConta = false;
            inicializaDatas();
            preencheOpcoesSlider();

            vm.sliderInicioModalidade = retornaContagemDias(dtInicio);
            vm.sliderInicioPagamento = retornaContagemDias(dtInicio);
            vm.sliderInicioConta = retornaContagemDias(dtInicio);
        }

        /**
        * @ngdoc method
        * @name retornaContagemDias
        *
        * @param {Date} a data a ser subtraida da data atual
        *
        * @description
        * Retorna a diferença da data atual para a data recebida 
        **/
        function retornaContagemDias(data) {
            var dtAtual = new Date();
            dtAtual.setHours(0);
            dtAtual.setMinutes(0);
            dtAtual.setSeconds(0);
            dtAtual.setMilliseconds(0);

            data.setHours(0);
            data.setMinutes(0);
            data.setSeconds(0);
            data.setMilliseconds(0);

            var diferencaTempo = Math.abs(dtAtual.getTime() - data.getTime());
            var diferencaDias = (diferencaTempo / (1000 * 3600 * 24));
            return diferencaDias;
        }

        /**
        * @ngdoc method
        * @name inicializaDatas
        *
        * @description
        * Método responsável por iniciar as datas utilizadas para filtro de lançamentos
        **/
        function inicializaDatas() {
            dtInicio = new Date();
        }

        /**
        * @ngdoc method
        * @name preencheOpcoesSlider
        *
        * @description
        * Método responsável por preencher os dados de funcionamento do slider
        **/
        function preencheOpcoesSlider() {
            var passos = [0, 1, 2, 3, 4, 5, 6];

            preencheOpcoesSliderFiltroPag(100);

            vm.sliderOptions = {
                noSwitching: true,
                totalDias: "",
                showTicksValues: true,
                rightToLeft: false,
                stepsArray: passos.map(function (v) {
                    return v;
                }),
                onEnd: function () {

                    if (vm.tipoPagamento == "CONTA") {
                        transacaoListarPagamentosPorConta();
                    }
                    else if (vm.tipoPagamento == "MODALIDADE") {
                        transacaoListarPagamentosPorModalidade();
                    }
                    else if (vm.tipoPagamento == "PAGAMENTOS") {
                        transacaoListarPagamentosPorPagamento();
                    }

                },
                translate: function (value, sliderId, label) {
                    if (label == "high" && this.lowValue == this.highValue) {
                        return "";
                    } else if (label != "tick-value") {
                        var data = new Date();
                        if (value === 0) {
                            return "Hoje";
                        }
                        return $filter("date")(data.setDate(data.getDate() + value), "dd/MM");
                    } else {
                        return value;
                    }
                }
            };
        }

        /**
         * @description Método responsável por preencher as opçoes do slider de filtro selecionado pela tela. 
         */
        function preencheOpcoesSliderFiltroPag(valorMax) {
            vm.sliderOptionsFiltro = {
                floor: 0,
                ceil: valorMax,
                step: 1,
                translate: function () {
                    return "";
                }
            };
        }

        /**
         * @description Método responsável por gerar o filtro de slider
         */
        function gerarFiltroSlider(modelValue) {
            if (modelValue == undefined || modelValue == null || modelValue == "") {
                modelValue = 0;
            }

            var sliderDtFim = new Date();
            sliderDtFim.setHours(0);
            sliderDtFim.setMinutes(0);
            sliderDtFim.setSeconds(0);
            sliderDtFim.setMilliseconds(0);

            sliderDtFim.setDate(sliderDtFim.getDate() + modelValue);

            return sliderDtFim;
        }

        /**
        * limpa as listas de pagamentos
        */
        function limparVariaveis() {

            //Limpa todas as listas
            vm.listaPagamentosPorConta = {};

            vm.listaPagamentosPorModalidade = {};

            vm.listaPagamentosPorPagamento = {};

            vm.valorTotalPagamentoPorPagamentos = 0;

            vm.alertasDados = [];
        }

        /**
        * Preenche o alerta ao não encontrar dados ou der erro.
        */
        function preencherAlertaDados(type, data, location) {
            vm.alertasDados.push({
                tipo: type,
                texto: data,
                caminho: location
            });
        }

    }
})();