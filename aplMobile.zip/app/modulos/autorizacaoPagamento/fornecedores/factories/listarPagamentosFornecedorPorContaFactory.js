(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarPagamentosFornecedorPorContaFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:listarPagamentosFornecedorPorContaFactory
    *
    * @description
    * Factory de conexão com API listarPagamentosFornecedorPorContaFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoPagamento")
        .factory("listarPagamentosFornecedorPorContaFactory", listarPagamentosFornecedorPorContaFactory);

    listarPagamentosFornecedorPorContaFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarPagamentosFornecedorPorContaFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:listarPagamentosFornecedorPorContaFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarPagamentosFornecedorPorContaFactory(conectorAPI, appSettings, utilitarios) {

        return {
            listarPagamentos: listarPagamentos
        };

        /**
        * @ngdoc method
        * @name listarPagamentos
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento:listarPagamentos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarPagamentos(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "listar-pagamento-por-conta"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();