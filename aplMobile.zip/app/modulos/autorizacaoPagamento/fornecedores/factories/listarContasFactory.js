(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarContasFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:listarContasFactory
    *
    * @description
    * Factory de conexão com API listarContasFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoPagamento")
        .factory("listarContasPagamentosFactory", listarContasFactory);

    listarContasFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarContasFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:listarContasFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarContasFactory(conectorAPI, appSettings, utilitarios) {

        return {
            listarContas: listarContas
        };

        /**
        * @ngdoc method
        * @name listarContas
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento:listarContas
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarContas(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "listar-contas-pagamentos"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();