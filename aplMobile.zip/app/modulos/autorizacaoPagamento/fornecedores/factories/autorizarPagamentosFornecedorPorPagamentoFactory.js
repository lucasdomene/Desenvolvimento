(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name autorizarPagamentosFornecedorPorPagamentoFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:autorizarPagamentosFornecedorPorPagamentoFactory
    *
    * @description
    * Factory de conexão com API autorizarPagamentosFornecedorPorPagamentoFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoPagamento")
        .factory("autorizarPagamentosFornecedorPorPagamentoFactory", autorizarPagamentosFornecedorPorPagamentoFactory);

    autorizarPagamentosFornecedorPorPagamentoFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name autorizarPagamentosFornecedorPorPagamentoFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:autorizarPagamentosFornecedorPorPagamentoFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function autorizarPagamentosFornecedorPorPagamentoFactory(conectorAPI, appSettings, utilitarios) {

        return {
            autorizarPagamentos: autorizarPagamentos
        };

        /**
        * @ngdoc method
        * @name autorizarPagamentos
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento:autorizarPagamentos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function autorizarPagamentos(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "autorizar-pagamentos"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();