(function () {
    "use strict";

    /**
     * /**
     * @ngdoc constant
     * @name arq-spa-base.recursos.constants:app.config
     * @module arq-spa-base.recursos
     * 
     * @description
     * Constantes que armazenam as configurações da aplicação.
     */
    angular.module("arq-spa-base.recursos").constant("appSettings", {
        configuracao: {
            caminhoArquivoConfigContexto: "./app/assets/config/contexto.json",
            caminhoCatalogoDependencias: "./app/assets/config/dependencias.json",
            caminhoDefinicoesFiltros: "./app/assets/config/filtros.json",
            caminhoArquivosModulos: "./app/assets/js/",
            expressaoRegularCaracteresEspeciais: "^([a-zA-Z0-9 ])*$",
            memorizador: {
                prefixo: "sfrMobilePJ",
                expiracao: 0
            },
            codigoCanal: "IPJ",
            tratamentoExcecao: {
                servico: "tratarExcecao",
                funcao: "tratarErro"
            },
            criptografia: false,
            aplicacao: "MBJ",
            seguranca: {
                urlWhiteList: []
            },
            limparContextoTrabalhoLogoff: true
        },
        comunicacao: {
            urlLog: "https://api-ti.safra.com.br/log",
            urlBackend: "https://api-ti.safra.com.br/pj/",
            urlContainer: "http://localhost:8080/periferico"
        },
        navegacao: {
            fluxoInicial: "apl-mobile-pj-inicio"
        },
        tipoSpinner: {
            spinner: {
                elementHeight: "24px",
                elementWidth: "24px",
                top: "12px",
                left: "12px",
                position: "relative",
                zIndex: null,
                length: 4,
                width: 3,
                radius: 6,
                color: "#555"
            },
            loader: {
                color: "white"
            }
        }
    });
})();