/**
* @ngdoc overview
* @name apl-mobile-pj.areaAberta
* 
* @require apl-mobile-pj.comum
* 
* @description
* Módulo que define os fluxos de navegacao da area aberta.
**/
angular.module("apl-mobile-pj.areaAberta", [
    "ui.bootstrap",
    "ngAnimate",
    "ui.mask",
    "angular-progress-arc"
    ]).config(areaAbertaModulo)
    .run(["sfTradutor", function (tradutor) {
        tradutor.adicionarDicionarios(["app/modulos/areaAberta/login/internacionalizacao"]);
    }]);

areaAbertaModulo.$inject = ["sfNavegadorProvider"];

/**
* @ngdoc method
* @name apl-mobile-pj.areaAberta 
* 
* @param {provider} sfNavegadorProvider instancia do sfNavegadorProvider
* 
* @description
* metodo responsavel por inicar o modulo.
**/
function areaAbertaModulo(sfNavegadorProvider) {
    sfNavegadorProvider.adicionarFluxoNavegacao(
        sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-login")
            .adicionarEstado("login", {
                controller: "loginController as lCtrl",
                templateUrl: "./app/modulos/areaAberta/login/views/inicio.html",
                abstract: true
            })

            .adicionarEstado("login.login-inicio", {
                templateUrl: "./app/modulos/areaAberta/login/views/login.html",
                parent: "login"
            }, [
                {
                    acao: "senha-eletronica",
                    estadoDestino: "login.senha-eletronica"
                },
                {
                    acao: "ativar-token",
                    fluxo: "apl-mobile-pj-ativar-token"
                }
            ])

            .adicionarEstado("login.senha-eletronica", {
                templateUrl: "./app/modulos/areaAberta/login/views/senhaEletronica.html",
                parent: "login"
            }, [
                {
                    acao: "token",
                    estadoDestino: "login.token"
                },
                {
                    acao: "voltar",
                    estadoDestino: "login.login-inicio"
                },
                {
                    acao: "alterar-senha",
                    fluxo: "apl-mobile-pj-alterar-senha"
                },
                {
                    acao: "ativar-token",
                    fluxo: "apl-mobile-pj-ativar-token"
                }
            ])

            .adicionarEstado("login.token", {
                templateUrl: "./app/modulos/areaAberta/login/views/token.html",
                parent: "login"
            }, [
                {
                    acao: "areaPrincipal.home",
                    fluxo: "apl-mobile-pj-home"
                },
                {
                    acao: "voltar",
                    estadoDestino: "login.login-inicio"
                },
                {
                    acao: "cadastrar-maquina",
                    fluxo: "apl-mobile-pj-novo-dispositivo"
                },
                {
                    acao: "ativar-token",
                    fluxo: "apl-mobile-pj-ativar-token"
                }
            ])
            .definirEstadoInicial("login.login-inicio")
    );
    sfNavegadorProvider.adicionarFluxoNavegacao(
        sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-token")
            .adicionarEstado("login-token", {
                controller: "loginController as lCtrl",
                templateUrl: "./app/modulos/areaAberta/login/views/inicio.html",
                abstract: true
            })

            .adicionarEstado("login.token-direto", {
                templateUrl: "./app/modulos/areaAberta/login/views/token.html",
                parent: "login-token"
            }, [
                {
                    acao: "areaPrincipal.home",
                    fluxo: "apl-mobile-pj-home"
                },
                {
                    acao: "voltar",
                    fluxo: "apl-mobile-pj-login"
                }
            ])
            .definirEstadoInicial("login.token-direto")
    );
}
(function () {
    "use strict";

    /**
    * @ngdoc overview
    * @name apl-mobile-pj.home:loginController
    * 
    * @requires sfNavegador, contexto, listarCotacoesFactory, listarMoedasFactory, modal
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas na area login.
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .controller("loginController", loginController);

    loginController.$inject = [
        "sfNavegador",
        "sfContexto",
        // "listarCotacoesFactory",
        // "listarMoedasFactory",
        "modal",
        "sfMemorizador",
        "sfUtilitarios",
        "interpretadorComunicacao",
        "$location",
        "$anchorScroll",
        "obterNomeUsuarioFactory",
        //"autenticarUsuarioFactory",
        "validarTokenFactory",
        "validarIPFactory",
        "validarDNAFactory",
        "utilitariosAplicacaoFactory",
        "$interval",
        "sfToken",
        // ,
        // "listarSaldoFactory"
        "sfAutenticador",
        "sfDefensor"
    ];

    /**
    * @ngdoc method
    * @name loginController
    *
    * @methodOf apl-mobile-pj.areaAberta:loginController
    *  
    * @description
    * Contem as definições do controller.
    **/
    function loginController(
        sfNavegador,
        contexto,
        // listarCotacoesFactory,
        // listarMoedasFactory,
        modal,
        sfMemorizador,
        utilitarios,
        interpretadorComunicacao,
        $location,
        $anchorScroll,
        obterNomeUsuarioFactory,
        //autenticarUsuarioFactory,
        validarTokenFactory,
        validarIPFactory,
        validarDNAFactory,
        utilitariosAplicacaoFactory,
        $interval,
        sfToken,
        // ,
        // listarSaldoFactory
        sfAutenticador,
        sfDefensor
    ) {

        var vm = this;

        //vm.listarCotacoes = listarCotacoes;
        //vm.listarMoedas = listarMoedas;
        vm.exibeMoedas = exibeMoedas;
        vm.exibeCotacoes = exibeCotacoes;
        vm.carregarHomeLogada = carregarHomeLogada;
        vm.transacaoObterNomeCliente = transacaoObterNomeCliente;
        vm.nomeCliente = "";
        vm.confirmarSenha = confirmarSenha;
        vm.senhaEletronica = null;
        vm.voltar = voltar;
        vm.listaTokens = [];
        vm.confirmarToken = confirmarToken;
        vm.codigoToken = null;
        vm.NumeroSerial = null;
        vm.apenasNumeros = apenasNumeros;
        vm.limparToken = limparToken;
        vm.tokenValidado = false;
        vm.codigoNextToken = "";

        vm.delayMilissegundo = 100;

        vm.exibeToken = false;
        vm.token = {};
        vm.gerenciaToken = gerenciaToken;
        //var promessaIntervaloToken;

        // vm.token = {
        //     possui: true,
        //     sequencia: 12345678,
        //     serial: 234,
        //     vidaUtilMilissegundos: 20000,
        //     liberado: false
        // };

        vm.animarLogin = true;


        iniciar();

        /*Funções*/

        /**
         * @ngdoc method
         * @name carregarHomeLogada
         *
         * @methodOf apl-mobile-pj.areaAberta:loginController
         *  
         * @description
         * Método responsável por carregar a tela de Home Logada. 
         */
        function carregarHomeLogada() {

            var dadosShortnameUsernameMemorizados = {
                shortname: vm.shortname.valor,
                username: vm.username.valor
            };

            contexto.definirValorContextoTrabalho("dadosLogin", dadosShortnameUsernameMemorizados);

            if (vm.lembrarSelecionado) {
                sfMemorizador.definir("lembrarShortnameUsername", dadosShortnameUsernameMemorizados);
            }
            else {
                console.log("removeu Chave");
                sfMemorizador.removerChave("lembrarShortnameUsername");
            }

            vm.transacaoObterNomeCliente();

        }

        /**
        * @ngdoc method
        * @name iniciar
        *
        * @methodOf apl-mobile-pj.areaAberta:loginController
        *  
        * @description
        * Método responsável por carregar o estado inicial dos elementos da view.
        **/
        function iniciar() {

            vm.codigoNextToken = "";

            vm.lembrar = {
                desativado: true
            };
            vm.entrar = {
                desativado: true
            };
            vm.shortname = {
                valor: ""
            };
            vm.username = {
                valor: ""
            };
            vm.listaAcoes = {
                visivel: true
            };
            vm.listaMoedas = {
                visivel: false
            };

            var dadosShortnameUsernameRecuperados = sfMemorizador.obter("lembrarShortnameUsername");

            //Caso tenha sido prenchido informacoes no login com sucesso anterior recupera os dados e preenche
            if (dadosShortnameUsernameRecuperados) {
                vm.shortname.valor = dadosShortnameUsernameRecuperados.shortname;
                vm.username.valor = dadosShortnameUsernameRecuperados.username;
                vm.lembrar.desativado = false;
                vm.lembrarSelecionado = true;
            }

            vm.ordenacaoAcoesReverso = false;
            vm.ordenacaoAcoes = "";

            // vm.listarCotacoes();
            // vm.listarMoedas();

            var data = contexto.obterValorContextoTrabalho("permissionamento");
            if (data != null && data != undefined && data != "") {
                vm.nomeCliente = contexto.obterValorContextoTrabalho("nomeClienteUltimoAcesso");
                recuperarListaTokens(data);
            }
        }

        /**
        * @ngdoc method
        * @name listarCotacoes
        *
        * @methodOf apl-mobile-pj.areaAberta:loginController
        *  
        * @description
        * Método responsável por realizar a chamada de listarCotacoes
        **/
        // function listarCotacoes() {
        // interpretadorComunicacao.interpretar(listarCotacoesFactory.listarCotacoes())
        //         .sucesso(listarCotacoesSucesso)
        //         .aviso(listarCotacoesErro)
        //         .erro(listarCotacoesErro);

        //     /**
        //     * @ngdoc method
        //     * @name listarCotacoesSucesso
        //     * @param {JSON} retorno variavel contendo o retorno do serviço
        //     *
        //     * @methodOf apl-mobile-pj.areaAberta:loginController
        //     *  
        //     * @description
        //     * Método responsável por tratar o retorno da chamada de listarCotacoes em caso de sucesso
        //     **/
        //     function listarCotacoesSucesso(retorno) {
        //         var cotacoes = retorno;
        //         if ((cotacoes) && cotacoes.statusProcessamento.mensagem.codigo === 0 && cotacoes.items.length > 0) {
        //             vm.acoes = cotacoes.items;
        //             vm.dataCotacoes = cotacoes.items[0].data;
        //             vm.horaCotacoes = cotacoes.items[0].hora;
        //             vm.listaAcoes.erroConsulta = false;
        //         } else {
        //             listarCotacoesErro(cotacoes);
        //         }
        //     }

        //     /**
        //     * @ngdoc method
        //     * @name listarCotacoesErro
        //     * @param {JSON} retorno variavel contendo o retorno do serviço
        //     *
        //     * @methodOf apl-mobile-pj.areaAberta:loginController
        //     *  
        //     * @description
        //     * Método responsável por tratar o retorno da chamada de listarCotacoes em caso de erro
        //     **/
        //     function listarCotacoesErro(retorno) {
        //         console.log("Erro ao listar cotacoes:" + JSON.stringify(retorno));
        //         vm.listaAcoes.erroConsulta = true;
        //     }
        // }

        /**
        * @ngdoc method
        * @name exibeMoedas
        *
        * @methodOf apl-mobile-pj.areaAberta:loginController
        *
        * @description
        * Exibe a aba de moedas ou retorna para o topo em caso de ja estar visivel
        **/
        function exibeMoedas() {
            if (vm.listaMoedas.visivel) {
                $location.hash("topoMoedas");
                $anchorScroll();
            } else {
                vm.listaMoedas.visivel = true;
                vm.listaAcoes.visivel = false;
            }
        }
        /**
        * @ngdoc method
        * @name exibeCotacoes
        *
        * @methodOf apl-mobile-pj.areaAberta:loginController
        *
        * @description
        * Exibe a aba de acoes ou retorna para o topo em caso de ja estar visivel
        **/
        function exibeCotacoes() {
            if (vm.listaAcoes.visivel) {
                $location.hash("topoCotacoes");
                $anchorScroll();
            } else {
                vm.listaAcoes.visivel = true;
                vm.listaMoedas.visivel = false;
            }
        }

        /**
        * @ngdoc method
        * @name listarMoedas        
        * @methodOf apl-mobile-pj.areaAberta:loginController
        *  
        * @description
        * Método responsável por realizar a chamada de listarMoedas
        **/
        // function listarMoedas() {
        //     interpretadorComunicacao.interpretar(listarMoedasFactory.listarMoedas())
        //         .sucesso(listarMoedasSucesso)
        //         .aviso(listarMoedasErro)
        //         .erro(listarMoedasErro);

        //     /**
        //     * @ngdoc method
        //     * @name listarMoedasSucesso
        //     * @param {JSON} retorno variavel contendo o retorno do serviço
        //     *
        //     * @methodOf apl-mobile-pj.areaAberta:loginController
        //     *  
        //     * @description
        //     * Método responsável por tratar o retorno da chamada de listarMoedas em caso de sucesso
        //     **/
        //     function listarMoedasSucesso(retorno) {
        //         var moedas = retorno;
        //         if ((moedas.items) && moedas.statusProcessamento.mensagem.codigo === 0 && moedas.items.length > 0) {
        //             vm.moedas = moedas.items;
        //             vm.dataMoedas = moedas.items[0].data;
        //             vm.horaMoedas = moedas.items[0].hora;
        //             vm.listaMoedas.erroConsulta = false;
        //         } else {
        //             listarMoedasErro(moedas);
        //         }
        //     }

        //     /**
        //     * @ngdoc method
        //     * @name listarMoedasErro
        //     * @param {JSON} retorno variavel contendo o retorno do serviço
        //     *
        //     * @methodOf apl-mobile-pj.areaAberta:loginController
        //     *  
        //     * @description
        //     * Método responsável por tratar o retorno da chamada de listarMoedas em caso de erro
        //     **/
        //     function listarMoedasErro(retorno) {
        //         vm.listaMoedas.erroConsulta = true;
        //         console.log("Erro ao listar moedas:" + JSON.stringify(retorno));
        //     }
        // }

        /**
        * @ngdoc method
        * @name transacaoObterNomeCliente
        * 
        * @memberOf loginController.js
        *
        * @description        
        * Método que realiza a consulta de nome do cliente
        **/
        function transacaoObterNomeCliente() {
            interpretadorComunicacao.interpretar(obterNomeUsuarioFactory
                .obterNomeUsuario())
                .sucesso(sucesso)
                .aviso(obtemNomeClienteErro)
                .erro(obtemNomeClienteErro);

            //sucesso({ "ADSE_EV_STATUS": "", "ADSE_EV_NOM_USR": "ANDRE BIZARRI", "statusProcessamento": { "mensagem": { "codigo": "4913", "descricao": "USUARIO IDENTIFICADO COM SUCESSO (NOME OBTIDO)", "severidade": "00" } } });

            /**
            * @ngdoc method
            * @name sucesso
            * 
            * @memberOf loginController.js
            *
            * @description        
            * Método executado em caso de sucesso na consulta de nome do cliente
            **/
            function sucesso(data) {
                contexto.definirValorContextoTrabalho("nomeClienteUltimoAcesso",
                    data.ADSE_EV_NOM_USR);

                vm.nomeCliente = data.ADSE_EV_NOM_USR;
                contexto.definirValorContextoTrabalho("lembrarShortname", vm.shortname.valor);

                removeAlerta();

                // sfToken.obterSequencia(false)
                //  .then(sucessoObterToken)
                //  .catch(erroObterToken);

                sfNavegador.navegar("senha-eletronica");
            
                
            } 

            // /**
            // * @ngdoc method
            // * @name sucessoObterToken
            // * 
            // * @memberOf loginController.js
            // *
            // * @description        
            // * Método executado em caso de sucesso na obtenção do Token
            // * sucesso = true (ativo) 
            // **/
            // function sucessoObterToken(retorno) {
            //     vm.token = retorno.data;

            //     if(vm.token.sucesso) {
            //         contexto.definirValorContextoTrabalho("tokenSerial", vm.token.serial);
            //         sfNavegador.navegar("senha-eletronica");
            //     } else {
            //         sfNavegador.navegar("ativar-token");
            //     }
            // }

            // /**
            // * @ngdoc method
            // * @name sucessoObterToken
            // * 
            // * @memberOf loginController.js
            // *
            // * @description        
            // * Método executado em caso de sucesso na obtenção do Token
            // * sucesso = true (ativo) 
            // **/
            // function erroObterToken(data) {
            //     removeAlerta();
            //     mostrarAlerta("danger", data.statusProcessamento.message);
            // }

            /**           
           * @ngdoc method
           * @name erro
           * 
           * @memberOf loginController.js
           *
           * @description
           * Método executado em caso de erro na consulta de nome do cliente
           **/
            function obtemNomeClienteErro(data) {
                if (data == null || data == undefined) {
                    removeAlerta();
                    modal.abrirModal(undefined,
                        "Erro ao obter nome do cliente.",
                        "",
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        "md");

                    return;
                }

                if (data.ADSE_EV_STATUS == "E") {
                    removeAlerta();
                    sfNavegador.navegar("alterar-senha");
                }
                else {
                    removeAlerta();
                    modal.abrirModal(undefined,
                        data.statusProcessamento.message,
                        "",
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        "md");
                }
            }
        }

        /**
         * description click para confirmar senha
         */
        function confirmarSenha() {
            if (vm.senhaEletronica != null) {

                var param = {
                    idEstrategia: "usuario/senha",
                    credenciais: {
                        "shortname": vm.shortname.valor,
                        "userId": vm.username.valor,
                        "ADSE_RC_SENHA_ATU": vm.senhaEletronica,
                        "ADSE_RC_SENHA_ALT": "",
                        "ADSE_RC_IC_PERFIL": "S",
                        "ADSE_RC_TP_OPER": "L",
                        "ADSE_RC_SENHA_BLW": "",
                        "ADSE_RC_ALT_MSG": "",
                        "ADSE_RC_ATIVACAO": "",
                        "ADSE_RC_BROWSER": "",
                        "ADSE_RC_COD_MAQUINA": "",
                        "ADSE_RC_VERSAO": "",
                        "ADSE_RC_TIPO": ""
                    }
                };

                interpretadorComunicacao.interpretar(sfAutenticador.autenticar(param))
                    .sucesso(sucesso)
                    .aviso(erro)
                    .erro(erro);
            }
            /**
             * @description sucesso da autenticacao Usuario
             */
            function sucesso(data) {
                //TODO XASAN Ver o pq do status == B
                if (data.propriedades.ADSE_EV_STATUS == "B" || data.propriedades.ADSE_EV_STATUS == "E") {
                    removeAlerta();
                    modal.abrirModal(undefined,
                        data.statusProcessamento.message,
                        "modalErro",
                        alterarSenhaExpirada,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        "md");
                } else {
                    vm.nomeCliente = data.propriedades.ADSE_EV_NOM_USR;
                    montarPermissionamento(data.propriedades);
                    removeAlerta();
                    sfNavegador.navegar("token");
                }
            }

            /**
            * @description Método responsável por iniciar fluxo alterar Senha
            */
            function alterarSenhaExpirada() {
                removeAlerta();
                sfNavegador.navegar("alterar-senha");
            }

            /**
             * @description erro da autenticacao Usuario
             */
            function erro(retorno) {

                if (retorno.propriedades.ADSE_EV_STATUS == "E") {
                    removeAlerta();
                    modal.abrirModal(undefined,
                        retorno.statusProcessamento.message,
                        "modalErro",
                        alterarSenhaExpirada,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        "md");
                }
                else {
                    removeAlerta();
                    mostrarAlerta("danger", retorno.statusProcessamento.message);
                }
            }

        }

        /**
         * @description validar DNA
         */
        function validarDNA() {
            var agencia = "IPJ",
                conta = vm.shortname.valor,
                usuario = vm.username.valor,
                tipoLogin = "PJ 1",
                applicationLayerVersion = "",
                customFields = [];


            interpretadorComunicacao.interpretar(sfDefensor.obterDNA(agencia, conta, usuario, tipoLogin, applicationLayerVersion, customFields))
                .sucesso(sucessoObterDNA)
                .aviso(erroObterDNA)
                .erro(erroObterDNA);

            /**
             * @description Método de sucesso na obtenção de DNA
             */
            function sucessoObterDNA(data) {
                validarDNADefensor(data);
            }

            /**
             * @description Método de erro na obtenção de DNA
             */
            function erroObterDNA(data) {
                removeAlerta();
                mostrarAlerta("danger", data.statusProcessamento.message);
            }
        }

        /**
         * @description Método responsável por efetuar a validação do DNA obtido dentro do Defensor
         */
        function validarDNADefensor(paramDNA) {
            var param = {
                "idEstrategia": "defensor",
                "credenciais": {
                    "cipheredId": paramDNA.id,
                    "cipheredKey": paramDNA.key,
                    "salt": paramDNA.senha,
                    "statusPlugin": "001",
                    "pulaSMS": "S",
                    "instalacao": "GBB", //TODO XASAN Ver qual a configuração de instalação do defensor onde para desktop é GBB (ver o de mobile)
                    "shortname": vm.shortname.valor,
                    "userId": vm.username.valor
                }
            };

            interpretadorComunicacao.interpretar(sfAutenticador.autenticar(param))
                .sucesso(validaDNADefensorSucesso)
                .aviso(erro)
                .erro(erro);

            // var param = {
            //     "PLVM_RC_CDMAQ": "D9A5E72FE9D9F976",
            //     "PLVM_RC_STAPLUG": "001",
            //     "PLVM_RC_IP": "172.16.34.163                           ",
            //     "PLVM_RC_VERPLUG": "1.12.3.5                      ",
            //     "PLVM_RC_PULASMS": "N",
            //     "PLVM_RC_INST": "WSW"
            // };

            // interpretadorComunicacao.interpretar(validarDNAFactory.validarDNA(param))
            //     .sucesso(sucesso)
            //     .aviso(erro)
            //     .erro(erro);

            // var mockerro = {
            //     "PLVM_EV_FLOBPL": "S",
            //     "PLVM_EV_FLOBMA": "S",
            //     "PLVM_EV_FLOBLI": "S",
            //     "PLVM_EV_FLCADMAQ": "S",
            //     "PLVM_EV_STAMAQ": "B",
            //     "PLVM_EV_FLSMS_LIB": "N",
            //     "PLVM_EV_FLSMS_NOV": "N",
            //     "PLVM_EV_DTOBPL": "20121019",
            //     "PLVM_EV_DTOBMA": "20121019",
            //     "PLVM_EV_DTOBLI": "20121019",
            //     "PLVM_EV_INPORSH": "N",
            //     "PLVM_EV_INIPLIB": "N",
            //     "PLVM_EV_FLOBVE": "N",
            //     "PLVM_EV_DTOBVE": "00010101",
            //     "statusProcessamento": {
            //         "mensagem": {
            //             "codigo": "0000",
            //             "descricao": "",
            //             "severidade": "00"
            //         }
            //     }
            // };

            //erro(mockerro);

            /**
             * @description sucesso validar DNA
             */
            function validaDNADefensorSucesso() {
                removeAlerta();
                sfNavegador.navegar("areaPrincipal.home");
            }

            /**
             * @description erro validar DNA
             */
            function erro(retorno) {
                //TODO XASAN Ajustar o retorno do De-Para de mensagem para cada situação abaixo:
                /*
                461, "Dispositivo pendente de liberação."); //Direcionar a aplicação para liberação quando master???
           OK - 460, "Dispositivo não cadastrado.");
                403, "Acesso bloqueado.");
                400, "Dispositivo inválido.");
                550, "Erro na execução do serviço de validação de dispositivo.");
                 */

                if (retorno.httpStatusCode === 460) {
                    removeAlerta();
                    contexto.definirValorContextoTrabalho("cadastrarMaquinaLogin", "S");
                    sfNavegador.navegar("cadastrar-maquina");
                } else {
                    removeAlerta();
                    mostrarAlerta("danger", retorno.statusProcessamento.message);
                }
            }
        }

        /**
         * @description limpar token
         */
        function limparToken(token) {
            vm.codigoToken = null;
            vm.NumeroSerial = token.numero;
        }

        /**
         * @description recupera a lista de tokens
         */
        function recuperarListaTokens(data) {
            vm.listaTokens = [];

            var tokenFisico = data.MENSAGEM;
            var tokenCelular = data.TOKEN;

            if (tokenFisico != null && tokenFisico.ADLG_TS_NUM_TOKEN != undefined) {
                vm.NumeroSerial = tokenFisico.ADLG_TS_NUM_TOKEN;
            }
            else {
                vm.NumeroSerial = tokenCelular.ADLG_TS_NRTOK_M;
            }

            if (tokenFisico != null) {
                tokenFisico.nome = "Token físico";
                tokenFisico.numero = tokenFisico.ADLG_TS_NUM_TOKEN;
                vm.listaTokens.push(tokenFisico);
            }

            if (tokenCelular != null) {
                tokenCelular.nome = "Token celular";
                tokenCelular.numero = tokenCelular.ADLG_TS_NRTOK_M;
                vm.listaTokens.push(tokenCelular);
            }
        }

        /**
       * @ngdoc method
       * @name mostrarAlerta
       *  
       * @description
       * Método responsável por exibir o alerta de acordo com o retorno da comunicação
       **/
        function mostrarAlerta(tipoAlerta, textoAlerta) {
            var caminho = "";

            if (tipoAlerta == "warning") {

                caminho = "./app/assets/img/Pendencias_60x60pt_Ocre.png";
            }
            else if (tipoAlerta == "danger") {
                caminho = "./app/assets/img/icone_atencao_erro.png";
            }
            else {
                caminho = "./app/assets/img/icone_Mensagem_SUCESSO_60x60pt.png";
            }

            vm.alertas.push({ tipo: tipoAlerta, texto: textoAlerta, caminho: caminho });
        }

        /**
         * @ngdoc method
         *  * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeAlerta() {
            vm.alertas = [];
        }


        /**
         * description voltar
         */
        function voltar() {
            vm.codigoToken = null;
            vm.NumeroSerial = null;
            vm.nomeCliente = "";
            vm.senhaEletronica = null;
            vm.listaTokens = [];
            removeAlerta();
            sfNavegador.navegar("voltar");
        }

        /**
         * description click no botão que confirma o token
         */
        function confirmarToken() {
            if (vm.codigoToken != null && !vm.tokenValidado) {

                var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

                var param = {
                    idEstrategia: "rsa",
                    credenciais: {
                        "passcode": vm.codigoToken,
                        "codigoNextToken": vm.codigoNextToken,
                        "serialNumber": vm.NumeroSerial,
                        "identificadorPessoa": dadosLogin.shortname,
                        "tipoPessoa": "PJ",
                        "shortname": dadosLogin.shortname,
                        "userId": dadosLogin.username,
                        "codGravacaoSenhaToken": "0001"
                    }
                };

                interpretadorComunicacao.interpretar(sfAutenticador.autenticar(param))
                    .sucesso(sucesso)
                    .aviso(erro)
                    .erro(erro);

            } else if (vm.tokenValidado) {
                validarDNA();
            }

            /**
             * description sucesso da validação de token
             */
            function sucesso() {
                vm.tokenValidado = true;
                validarDNA();
            }

            /**
             * @description erro da validação de token
             */
            function erro(retorno) {
                if (retorno.httpStatusCode === 472) {
                    vm.codigoNextToken = retorno.propriedades.authenticationToken[0];
                    vm.tokenValidado = false;
                }

                removeAlerta();
                mostrarAlerta("danger", retorno.statusProcessamento.message);
            }
        }

        /**
        * @ngdoc method
        * @name iniciar
        *
        * @methodOf apl-mobile-pj.areaAberta:loginController
        *  
        * @description
        * Método responsável por permitir digitacao apenas de valores númericos.
        **/
        function apenasNumeros(event) {
            if (event.code != "Enter") {
                var regex = new RegExp("^([0-9])*$");
                var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);

                if (!regex.test(key)) {
                    event.preventDefault();
                }
            }
        }

        /**
        * @ngdoc overview
        * @name montarPermissionamento
        * 
        * @memberOf loginController.js
        *
        * @description
        * Método executado para montar as permissões
        **/
        function montarPermissionamento(data) {
            var permissionamento = {};
            permissionamento.CONTAS = data.ADLG_EV_ITENS;
            permissionamento.GRUPO_SERVICOS = data.ADLG_EV_GRUPOS;
            permissionamento.CONTAS_POR_SERVICO = data.ADLG_EV_SERVICO;
            permissionamento.USUARIO_CPF = data.ADLG_EV_USUARIOCPF;
            permissionamento.USUARIO_DADOS = data.ADLG_EV_USUARIOCPF;
            permissionamento.MENSAGEM = data.ADLG_EV_MENSAGEM;
            permissionamento.TOKEN = data.ADLG_EV_TOKEN;

            contexto.definirValorContextoTrabalho("permissionamento", permissionamento);
            contexto.definirValorContextoTrabalho("dataUltimoAcesso", permissionamento.TOKEN.ADLG_TS_DTULAC);

            console.log(contexto.obterValorContextoTrabalho("permissionamento"));

            recuperarListaTokens(permissionamento);
        }



        //#region token ============================================================================================

        /**
        * @ngdoc method
        * @name gerenciaToken
        *
        * @methodOf apl-mobile-pj.areaAberta:loginController
        *
        * @description
        * Responsável por gerenciar a exibição do token e sua chamada
        **/
        function gerenciaToken() {
            if (!vm.exibeToken) {
                obtemSequenciaToken();
            } else {

                vm.exibeToken = false;
            }
        }

        /**
        * @ngdoc method
        * @name obtemSequenciaToken
        *
        * @methodOf apl-mobile-pj.areaAberta:loginController
        *
        * @description
        * Função responsável por chamar o metodo obter sequencia do token
        **/
        function obtemSequenciaToken() {

            sfToken.obterSequencia(false)
                 .then(sucessoObterSequencia)
                 .catch(erroObterSequencia);
        }

        /**
        * @ngdoc method
        * @name sucessoObterSequencia
        *
        * @methodOf apl-mobile-pj.areaAberta:loginController
        *
        * @description
        * DescricaoComentario
        **/
        function sucessoObterSequencia(retornoSucesso) {

            vm.token = retornoSucesso.data;

            //TODO VERIFICAR
            vm.token.vidaUtilMilissegundos = 20000;
           
            if (vm.token.sucesso) {
                contexto.definirValorContextoTrabalho("tokenSerial",vm.token.serial);
                if (vm.token.vidaUtilMilissegundos > 0) {
                    vm.exibeToken = true;
                    vm.progressoBarraCircular = 0;
                    $interval(atualizaToken, vm.delayMilissegundo, Math.ceil(vm.token.vidaUtilMilissegundos / vm.delayMilissegundo))
                        .then(obtemSequenciaToken);
                } else {
                    vm.exibeToken = false;
                }
            }
            else {
                //sfNavegador.navegar("ativar-token");
            } 
        }

        /**
        * @ngdoc method
        * @name erroObterSequencia
        *
        * @methodOf apl-mobile-pj.areaAberta:loginController
        *
        * @description
        * Função responsável por tratar o erro
        **/
        function erroObterSequencia() {
            vm.exibeToken = false;
        }

        /**
        * @ngdoc method
        * @name atualizaToken
        *
        * @methodOf apl-mobile-pj.areaAberta:loginController
        *
        * @description
        * Responsável por atualizar o tempo da barra de progresso circular
        **/
        function atualizaToken() {

            vm.progressoBarraCircular = vm.progressoBarraCircular + vm.delayMilissegundo / vm.token.vidaUtilMilissegundos;

            if (vm.progressoBarraCircular > 1) {
                vm.progressoBarraCircular = 1;
            }
        }


        //#endregion token =========================================================================================



    }
})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name autenticarUsuarioFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:autenticarUsuarioFactory
    *
    * @description
    * Factory de conexão com API autenticarUsuarioFactory
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .factory("autenticarUsuarioFactory", autenticarUsuarioFactory);

    autenticarUsuarioFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name autenticarUsuario
    *
    * @methodOf apl-mobile-pj.extrato:autenticarUsuarioFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function autenticarUsuarioFactory(conectorAPI, appSettings, utilitarios) {

        return {
            autenticarUsuario: autenticarUsuario
        };

        /**
        * @ngdoc method
        * @name autenticarUsuario
        *
        * @methodOf apl-mobile-pj.extrato:autenticarUsuario
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function autenticarUsuario(requisicao) {

            var param = requisicao;
                
                // "ADSE_RC_SENHA_ALT" : requisicao.ADSE_RC_SENHA_ALT,
                // "ADSE_RC_IC_PERFIL" : requisicao.ADSE_RC_IC_PERFIL,
                // "ADSE_RC_TP_OPER" : requisicao.ADSE_RC_TP_OPER,
                // "ADSE_RC_SENHA_BLW" : requisicao.ADSE_RC_SENHA_BLW,
                // "ADSE_RC_ALT_MSG" : requisicao.ADSE_RC_ALT_MSG,
                // "ADSE_RC_BROWSER" : requisicao.ADSE_RC_BROWSER,
                // "ADSE_RC_COD_MAQUINA" :requisicao.ADSE_RC_COD_MAQUINA,
                // "ADSE_RC_VERSAO" : requisicao.ADSE_RC_VERSAO,
                // "ADSE_RC_TIPO" : requisicao.ADSE_RC_TIPO


            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "autenticar-usuario-pj"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarCotacoesFactoryFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:listarCotacoesFactoryFactory
    *
    * @description
    * Factory de conexão com API listarCotacoesFactory
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .factory("listarCotacoesFactory", listarCotacoesFactory);

    listarCotacoesFactory.$inject = ["sfConectorAPI"];

    /**
    * @ngdoc method
    * @name  listarCotacoesFactory
    *
    * @methodOf apl-mobile-pj.areaAberta: listarCotacoesFactoryFactory
    *
    * @description
    * Contem as definições da factory.
    **/
    function listarCotacoesFactory(conectorAPI) {
        return {
            listarCotacoes: listarCotacoes
        };

        /*Funções*/

        /**
        * @ngdoc method
        * @name listarCotacoesService
        *
        * @methodOf apl-mobile-pj.nomeModulo:listarCotacoesFactory
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarCotacoes() {

            var req = {
                method: "POST",
                url: "listar-cotacoes",
                dataType: "json"
            };
            return conectorAPI.executar(req, false);
        }
    }

})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarMoedasFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:listarMoedasFactory
    *
    * @description
    * Factory de conexão com API listarMoedas
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .factory("listarMoedasFactory", listarMoedasFactory);

    listarMoedasFactory.$inject = ["sfConectorAPI"];

    /**
    * @ngdoc method
    * @name  listarMoedas
    *
    * @methodOf apl-mobile-pj.areaAberta: listarMoedasFactory
    *
    * @description
    * Contem as definições da factory.
    **/
    function listarMoedasFactory(conectorAPI) {
        return {
            listarMoedas: listarMoedas
        };

        /*Funções*/

        /**
        * @ngdoc method
        * @name listarCotacoesService
        *
        * @methodOf apl-mobile-pj.areaAberta:listarMoedas
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarMoedas() {

            var req = {
                method: "POST",
                url: "listar-moedas",
                dataType: "json"
            };
            return conectorAPI.executar(req, false);
        }
    }

})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name obterNomeUsuarioFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:obterNomeUsuarioFactory
    *
    * @description
    * Factory de conexão com API obterNomeUsuarioFactory
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .factory("obterNomeUsuarioFactory", obterNomeUsuarioFactory);

    obterNomeUsuarioFactory.$inject = ["sfConectorAPI", "sfContexto"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name obterNomeUsuario
    *
    * @methodOf apl-mobile-pj.extrato:obterNomeUsuarioFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function obterNomeUsuarioFactory(conectorAPI, sfContexto) {

        return {
            obterNomeUsuario: obterNomeUsuario
        };

        /**
        * @ngdoc method
        * @name obterNomeUsuario
        *
        * @methodOf apl-mobile-pj.extrato:obterNomeUsuario
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function obterNomeUsuario() {

            var dadosShortnameUsername = sfContexto.obterValorContextoTrabalho("dadosLogin");

            var req = {
                method: "POST",
                url: "obter-nome-usuario",
                data: {
                    "shortname": dadosShortnameUsername.shortname,
                    "userId": dadosShortnameUsername.username
                },
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name validarDNAFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:validarDNAFactory
    *
    * @description
    * Factory de conexão com API validarDNAFactory
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .factory("validarDNAFactory", validarDNAFactory);

    validarDNAFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name validarDNA
    *
    * @methodOf apl-mobile-pj.extrato:validarDNAFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function validarDNAFactory(conectorAPI, appSettings, utilitarios) {

        return {
            validarDNA: validarDNA
        };

        /**
        * @ngdoc method
        * @name validarDNA
        *
        * @methodOf apl-mobile-pj.extrato:validarDNA
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function validarDNA(requisicao) {

            var param = requisicao;

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "validar-dna-maquina"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name validarIPFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:validarIPFactory
    *
    * @description
    * Factory de conexão com API validarIPFactory
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .factory("validarIPFactory", validarIPFactory);

    validarIPFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name validarIP
    *
    * @methodOf apl-mobile-pj.extrato:validarIPFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function validarIPFactory(conectorAPI, appSettings, utilitarios) {

        return {
            validarIP: validarIP
        };

        /**
        * @ngdoc method
        * @name validarIP
        *
        * @methodOf apl-mobile-pj.extrato:validarIP
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function validarIP(requisicao) {

            var param = requisicao;

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "validar-ip"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name validarTokenFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:validarTokenFactory
    *
    * @description
    * Factory de conexão com API validarTokenFactory
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .factory("validarTokenFactory", validarTokenFactory);

    validarTokenFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name validarToken
    *
    * @methodOf apl-mobile-pj.extrato:validarTokenFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function validarTokenFactory(conectorAPI, appSettings, utilitarios) {

        return {
            validarToken: validarToken
        };

        /**
        * @ngdoc method
        * @name validarToken
        *
        * @methodOf apl-mobile-pj.extrato:validarToken
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function validarToken(requisicao) {

            var param = requisicao;

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "validar-token"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();