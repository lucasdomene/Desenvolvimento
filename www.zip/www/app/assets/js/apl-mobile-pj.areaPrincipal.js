/**
 * @ngdoc overview
 * @name apl-mobile-pj.areaPrincipal
 * 
 * @require apl-mobile-pj.comum
 * 
 * @description
 * Módulo que define os fluxos de navegacao da area Logada.
 **/

angular.module("apl-mobile-pj.areaPrincipal",
    ["ui.bootstrap",
        "ngAnimate"])
    .config(areaPrincipalModule)
    .run(["sfTradutor", function (tradutor) {
        tradutor.adicionarDicionarios(["app/modulos/areaPrincipal/home/internacionalizacao"]);
    }]);


areaPrincipalModule.$inject = ["sfNavegadorProvider"];

/**
* @ngdoc method
* @name apl-mobile-pj.areaPrincipal 
* 
* @param {provider} sfNavegadorProvider instancia do sfNavegadorProvider
* 
* @description
* metodo responsavel por inicar o modulo.
**/
function areaPrincipalModule(sfNavegadorProvider) {
    sfNavegadorProvider.adicionarFluxoNavegacao(
        sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-home")
            .adicionarEstado("home", {
                templateUrl: "./app/modulos/areaPrincipal/home/views/home.html",
                controller: "homeController as hCtrl"
            }, [
                {
                    acao: "gestao-maquinas",
                    fluxo: "apl-mobile-pj-orquestrador-seguranca"
                },
                {
                    acao: "cadastrar-maquinas",
                    fluxo: "apl-mobile-pj-novo-dispositivo"
                },
                {
                    acao: "encerrar-sessao",
                    fluxo: "apl-mobile-pj-login"
                },
                {
                    acao: "autorizar-pagamentos",
                    fluxo: "apl-mobile-pj-autorizacaoPagamento"
                },
                {
                    acao: "extrato",
                    fluxo: "apl-mobile-pj-extrato"
                },
                {
                    acao: "investimentos",
                    fluxo: "apl-mobile-pj-investimentos"
                },
                {
                    acao: "ativar-token",
                    fluxo: "apl-mobile-pj-ativar-token"
                }

            ], {
                cabecalho: {
                    mostrarlogo: true,
                    mostrarmenu: true
                }
            })
            .definirEstadoInicial("home")
    );
}
(function () {
    "use strict";

    /**
    * @ngdoc overview
    * @name apl-mobile-pj.areaPrincipal.homeController
    * 
    * @requires sfNavegador
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas na view da home logada.
    **/
    angular.module("apl-mobile-pj.areaPrincipal")
        .controller("homeController", homeController);

    homeController.$inject = [
        "$filter",
        "sfContexto",
        "sfNavegador",
        "sfMemorizador",
        "sfUtilitarios",
        "interpretadorComunicacao",
        "listarMaquinasPendentesFactory",
        "listarContasFactory",
        "listarSaldoFactory",
        "validapermissionamento",
        "sfAutenticador"
    ];


    /**
    * @ngdoc 
    * @name homeController
    *
    * @methodOf apl-mobile-pj.areaPrincipal.home
    *  
    * @description
    * Controller responsável por manipular a tela home da área logada.
    **/
    function homeController($filter,
        sfContexto,
        sfNavegador,
        sfMemorizador,
        utilitarios,
        interpretadorComunicacao,
        listarMaquinasPendentesFactory,
        listarContasFactory,
        listarSaldoFactory,
        validapermissionamento,
        sfAutenticador
    ) {
        var vm = this;

        vm.Atalhos = [];

        vm.mostrarAtalhos = true;
        vm.nomeClienteUltimoAcesso = null;
        vm.iniciar = iniciar;
        vm.maquinasPendentes = 0;
        vm.contaPreferencial = null;

        // vm.Atalhos = [
        //     {
        //         atalhoColorido: true,
        //         srcImg: "./app/assets/img/home/00_b_extrato-01.png",
        //         atalhoRodapeDesc: "AGENCIA <br/>E SALDO",
        //         atalhoTexto: "extrato",                
        //         tela: "",//"extrato"
        //         acao: navegarPara,
        //         textoFixo: "AGENCIA <br/>E SALDO",
        //         exibirRodape: true,
        //         rodapeDetalheDuplo: true,
        //         linhaSuperior: null,
        //         linhaInferior: "R$ SALDO",
        //         linhaInferiorTipo: "moeda",
        //         permissaogrupo: "POS",
        //         permissaoservico: "004",
        //         permissaonivel: ""
        //     },
        //     {
        //         atalhoColorido: false,
        //         srcImg: "./app/assets/img/home/00_b_autorizacao-01.png",
        //         atalhoRodapeDesc: "",
        //         atalhoTexto: "autorização de pagamentos",
        //         tela: "",//"autorizar-pagamentos"
        //         acao: navegarPara,
        //         textoFixo: "",
        //         exibirRodape: false,
        //         permissaogrupo: "PAG",
        //         permissaoservico: "001",
        //         permissaonivel: ""
        //     },
        //     {
        //         atalhoColorido: false,
        //         srcImg: "./app/assets/img/home/00_b_recebiveis-01.png",
        //         atalhoRodapeDesc: "",
        //         atalhoTexto: "recebimentos",
        //         tela: "",
        //         acao: navegarPara,
        //         textoFixo: "",
        //         exibirRodape: false,
        //         permissaogrupo: "",
        //         permissaoservico: "",
        //         permissaonivel: ""
        //     },
        //     {
        //         atalhoColorido: false,
        //         srcImg: "./app/assets/img/home/00_b_investimentos-01.png",
        //         atalhoRodapeDesc: "",
        //         atalhoTexto: "investimentos",
        //         tela: "",//"investimentos"
        //         acao: navegarPara,
        //         textoFixo: "Não há pendências",
        //         exibirRodape: false,
        //         permissaogrupo: "POS",
        //         permissaoservico: "001",
        //         permissaonivel: ""
        //     },
        //     {
        //         atalhoColorido: true,
        //         srcImg: "./app/assets/img/home/00_b_seguranca-01.png",
        //         atalhoRodapeDesc: "",
        //         atalhoTexto: "seguranca",
        //         tela: "gestao-maquinas",
        //         acao: navegarPara,
        //         textoFixo: "sem pendências",
        //         exibirRodape: true,
        //         permissaogrupo: "",
        //         permissaoservico: "",
        //         permissaonivel: ""
        //     },
        //     {
        //         atalhoColorido: false,
        //         srcImg: "./app/assets/img/home/00_b_agencia-01.png",
        //         atalhoRodapeDesc: "",
        //         atalhoTexto: "localize uma agencia",
        //         tela: "",
        //         acao: navegarPara,
        //         textoFixo: "",
        //         exibirRodape: false,
        //         permissaogrupo: "",
        //         permissaoservico: "",
        //         permissaonivel: ""
        //     },
        //     {
        //         atalhoColorido: false,
        //         srcImg: "./app/assets/img/home/00_b_chat-01.png",
        //         atalhoRodapeDesc: "",
        //         atalhoTexto: "fale conosco",
        //         tela: "",
        //         acao: navegarPara,
        //         textoFixo: "",
        //         exibirRodape: false,
        //         permissaogrupo: "",
        //         permissaoservico: "",
        //         permissaonivel: ""
        //     },
        //     {
        //         atalhoColorido: false,
        //         srcImg: "./app/assets/img/home/00_b_sair-01.png",
        //         atalhoRodapeDesc: "",
        //         atalhoTexto: "cadastrar maquinas",
        //         tela: "cadastrar-maquinas",
        //         acao: navegarPara,
        //         textoFixo: "Não há pendências",
        //         exibirRodape: false,
        //         permissaogrupo: "",
        //         permissaoservico: "",
        //         permissaonivel: "MASTER"
        //     },
        //     {
        //         atalhoColorido: false,
        //         srcImg: "./app/assets/img/home/00_b_sair-01.png",
        //         atalhoRodapeDesc: "",
        //         atalhoTexto: "sair",
        //         tela: "encerrar-sessao",
        //         acao: navegarPara,
        //         textoFixo: "Não há pendências",
        //         exibirRodape: false,
        //         permissaogrupo: "",
        //         permissaoservico: "",
        //         permissaonivel: ""
        //     }

        // ];


        iniciar();

        /*Funções*/

        /**
        * @ngdoc method
        * @name navegarPara
        *
        * @methodOf apl-mobile-pj.areaPrincipal.home
        *  
        * @description
        * Método responsável por navegar para a tela informada.
        **/
        function navegarPara(tela) {
            if (tela != "") {
                sfNavegador.navegar(tela);
            }
        }

        /**
         * @description Método responsável por efetuar a saida da aplicação.
         */
        function sair() {
            sfAutenticador.logoff().then(sucesso).catch(sucesso);

            /**
             * @description Método de sucesso para a saida da aplicação
             */
            function sucesso() {
                sfNavegador.iniciarFluxo("apl-mobile-pj-login");
            }
        }

        /**
        * @ngdoc method
        * @name iniciar
        *
        * @methodOf apl-mobile-pj.areaPrincipal.home
        *  
        * @description
        * Método responsável por carregar o estado inicial dos elementos da view.
        **/
        function iniciar() {
            vm.operacoesPendentes = false;
            recuperarContexto();
            iniciarAtalhos();
            recuperarContaPreferencial();
            listarMaquinasPendentes();
        }

        /**
        * @ngdoc method
        * @name recuperarContexto
        *
        * @methodOf apl-mobile-pj.areaPrincipal.home
        *  
        * @description
        * Método responsável recuperar os dados do contexto armazenados apos a transacao de autenticacao
        **/
        function recuperarContexto() {
            vm.nomeClienteUlimoAcesso = sfContexto.obterValorContextoTrabalho("nomeClienteUltimoAcesso");
            vm.dataUltimoAcesso = sfContexto.obterValorContextoTrabalho("dataUltimoAcesso");
        }

        /**
        * @ngdoc method
        * @name iniciarAtalhos
        *
        * @methodOf apl-mobile-pj.areaPrincipal.home
        *  
        * @description
        * Método responsável preencher o objeto dos atalhos exibidos
        **/
        function iniciarAtalhos() {

            vm.Atalhos = [
                {
                    atalhoColorido: true,
                    srcImg: "./app/assets/img/home/00_b_extrato-01.png",
                    atalhoRodapeDesc: "AGENCIA <br/>E SALDO",
                    atalhoTexto: "extrato",
                    tela: "",//extrato
                    acao: navegarPara,
                    textoFixo: "AGENCIA <br/>E SALDO",
                    exibirRodape: true,
                    rodapeDetalheDuplo: true,
                    linhaSuperior: null,
                    linhaInferior: "R$ SALDO",
                    linhaInferiorTipo: "moeda",
                    permissaogrupo: "POS",
                    permissaoservico: "001",
                    permissaonivel: ""
                },
                {
                    atalhoColorido: false,
                    srcImg: "./app/assets/img/home/00_b_autorizacao-01.png",
                    atalhoRodapeDesc: "",
                    atalhoTexto: "autorização de pagamentos",
                    tela: "",//autorizar-pagamentos
                    acao: navegarPara,
                    textoFixo: "",
                    exibirRodape: false,
                    permissaogrupo: "PAG",
                    permissaoservico: "001",
                    permissaonivel: ""
                },
                {
                    atalhoColorido: false,
                    srcImg: "./app/assets/img/home/00_b_recebiveis-01.png",
                    atalhoRodapeDesc: "",
                    atalhoTexto: "recebimentos",
                    tela: "",
                    acao: navegarPara,
                    textoFixo: "",
                    exibirRodape: false,
                    permissaogrupo: "",
                    permissaoservico: "",
                    permissaonivel: ""
                },
                {
                    atalhoColorido: false,
                    srcImg: "./app/assets/img/home/00_b_investimentos-01.png",
                    atalhoRodapeDesc: "",
                    atalhoTexto: "investimentos",
                    tela: "",//investimentos
                    acao: navegarPara,
                    textoFixo: "Não há pendências",
                    exibirRodape: false,
                    permissaogrupo: "POS",
                    permissaoservico: "001",
                    permissaonivel: ""
                },
                {
                    atalhoColorido: true,
                    srcImg: "./app/assets/img/home/00_b_seguranca-01.png",
                    atalhoRodapeDesc: "",
                    atalhoTexto: "seguranca",
                    tela: "gestao-maquinas",
                    acao: navegarPara,
                    textoFixo: "sem pendências",
                    exibirRodape: true,
                    permissaogrupo: "",
                    permissaoservico: "",
                    permissaonivel: ""
                },
                {
                    atalhoColorido: false,
                    srcImg: "./app/assets/img/home/00_b_agencia-01.png",
                    atalhoRodapeDesc: "",
                    atalhoTexto: "localize uma agencia",
                    tela: "",
                    acao: navegarPara,
                    textoFixo: "",
                    exibirRodape: false,
                    permissaogrupo: "",
                    permissaoservico: "",
                    permissaonivel: ""
                },
                {
                    atalhoColorido: false,
                    srcImg: "./app/assets/img/home/00_b_chat-01.png",
                    atalhoRodapeDesc: "",
                    atalhoTexto: "fale conosco",
                    tela: "",
                    acao: navegarPara,
                    textoFixo: "",
                    exibirRodape: false,
                    permissaogrupo: "",
                    permissaoservico: "",
                    permissaonivel: ""
                },
                {
                    atalhoColorido: false,
                    srcImg: "./app/assets/img/home/00_b_sair-01.png",
                    atalhoRodapeDesc: "",
                    atalhoTexto: "sair",
                    tela: "",
                    acao: sair,
                    textoFixo: "Não há pendências",
                    exibirRodape: false,
                    permissaogrupo: "",
                    permissaoservico: "",
                    permissaonivel: ""
                }

            ];

            angular.forEach(vm.Atalhos, function (atalho) {
                var permitido = validapermissionamento.validacao(atalho.permissaogrupo, atalho.permissaoservico, atalho.permissaonivel);
                atalho.permissao = permitido;
            });
        }


        /**
        * @ngdoc method
        * @name listarMaquinasPendentes
        *  
        * @description
        * Método responsável por chamar o serviço que consulta as maquinas Pendentes
        **/
        function listarMaquinasPendentes() {
            var shortname = sfContexto.obterValorContextoTrabalho("lembrarShortname");

            interpretadorComunicacao.interpretar(listarMaquinasPendentesFactory
                .listarMaquinasPendentes(shortname))
                .sucesso(sucesso)
                .aviso(erro)
                .erro(erro);

            //     // sucesso({ "PLLM_EV_INESTOU": 5, "PLLM_EV_DTOBPL": "20121204", "PLLM_EV_DTOBMA": "20121204", "PLLM_EV_DTOBLI": "20121204", "PLLM_EV_INPORSH": "N", "PLLM_EV_OCOR": [{ "PLLM_EV_DTINC": "20160802", "PLLM_EV_HRINC": "1030", "PLLM_EV_CHCLI": "VALISERE       TESTE", "PLLM_EV_CHMAQ": "0de36e7d1d43e08e", "PLLM_EV_APMAQ": "teste3", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "0701efc7-3355-46c3-843d-9f01bd5ae0c9" }, { "PLLM_EV_DTINC": "20160802", "PLLM_EV_HRINC": "1030", "PLLM_EV_CHCLI": "VALISERE       TESTE", "PLLM_EV_CHMAQ": "06badc575bcef39c", "PLLM_EV_APMAQ": "teste3", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "42dd505a-a910-067b-bbd7-24a39950c01b" }, { "PLLM_EV_DTINC": "20160729", "PLLM_EV_HRINC": "1655", "PLLM_EV_CHCLI": "VALISERE       TESTE", "PLLM_EV_CHMAQ": "8ceb147bab5201e7", "PLLM_EV_APMAQ": "j", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "8898f20f-0e35-97c0-c16e-738347af36a0" }, { "PLLM_EV_DTINC": "20160729", "PLLM_EV_HRINC": "1553", "PLLM_EV_CHCLI": "VALISERE       TESTE", "PLLM_EV_CHMAQ": "ff9cd6b61d9b6fe3", "PLLM_EV_APMAQ": "mobile", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "8591b7cb-d7eb-6b60-58e0-4e28cedac59a" }, { "PLLM_EV_DTINC": "20160718", "PLLM_EV_HRINC": "2039", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "0edbc43525618c3e", "PLLM_EV_APMAQ": "Teste 180720162038", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "c4f186fa-268e-6f92-fe6d-c75fcd2ebbc3" }, { "PLLM_EV_DTINC": "20160718", "PLLM_EV_HRINC": "1834", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "7a121522a6c6c6bb", "PLLM_EV_APMAQ": "Teste 180720161834", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "b8a06c9e-6deb-6a69-579c-97678ba270dc" }, { "PLLM_EV_DTINC": "20160718", "PLLM_EV_HRINC": "1824", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "3eb4f815c63e408a", "PLLM_EV_APMAQ": "Teste 180720161823", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "d44c2799-8372-b37c-70e3-a15c6c7d2185" }, { "PLLM_EV_DTINC": "20160718", "PLLM_EV_HRINC": "1758", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "670dccddd573cb29", "PLLM_EV_APMAQ": "Teste 180720161758", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "5e1be995-e441-01b6-c155-eed5ea0034cb" }, { "PLLM_EV_DTINC": "20160718", "PLLM_EV_HRINC": "1751", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "7c35cdb50a0a8458", "PLLM_EV_APMAQ": "Teste 180720161751", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "234bef32-046c-56cf-5a3c-fdc94511a969" }, { "PLLM_EV_DTINC": "20160718", "PLLM_EV_HRINC": "1749", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "e9b8a08080aa6479", "PLLM_EV_APMAQ": "Teste 180720161748", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "3eb3217c-6293-b687-56d7-0acdb89f9c2e" }, { "PLLM_EV_DTINC": "20160718", "PLLM_EV_HRINC": "1746", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "6bdf2bbfbebaa204", "PLLM_EV_APMAQ": "Teste 180720161746", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "f548d21c-8ce8-6658-8808-28c7d52fbbba" }, { "PLLM_EV_DTINC": "20160718", "PLLM_EV_HRINC": "1736", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "a4d6b50c22b923b4", "PLLM_EV_APMAQ": "Teste 180720161736", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "b152b48c-32b4-3187-c679-a0c7624ee0f4" }, { "PLLM_EV_DTINC": "20160718", "PLLM_EV_HRINC": "1731", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "908354aed4e02a45", "PLLM_EV_APMAQ": "Teste 180720161731", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "e69f0afe-7ab6-4651-2c27-5ce0157dd17f" }, { "PLLM_EV_DTINC": "20160718", "PLLM_EV_HRINC": "1600", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "20cf7502669096e3", "PLLM_EV_APMAQ": "Teste 180720161600", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "c0eb8049-d84b-3c2f-3599-d6b7d4ca6669" }, { "PLLM_EV_DTINC": "20160713", "PLLM_EV_HRINC": "1446", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "35cf3b0c51fdd105", "PLLM_EV_APMAQ": "Teste 130720161446", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "67128ae0-cc88-e0c5-112d-17cc56b15a4c" }, { "PLLM_EV_DTINC": "20160713", "PLLM_EV_HRINC": "1105", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "7b117f974f275ccf", "PLLM_EV_APMAQ": "Teste 130720161105", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "fb0c05ef-3163-c6c6-cd40-ca591bbb8cca" }, { "PLLM_EV_DTINC": "20160712", "PLLM_EV_HRINC": "1304", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "93b7a93b721725c6", "PLLM_EV_APMAQ": "asdf", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "922573c1-3aa2-9c2d-3f3c-d85fb76e6b90" }, { "PLLM_EV_DTINC": "20160705", "PLLM_EV_HRINC": "1848", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "AS8J847EHKSL666I", "PLLM_EV_APMAQ": "ABC 321", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "99990101", "selecionado": false, "guid": "bf10a69d-2b97-be36-db42-b80db7ff2bee" }, { "PLLM_EV_DTINC": "20160624", "PLLM_EV_HRINC": "1007", "PLLM_EV_CHCLI": "VALISERE       VALISERE", "PLLM_EV_CHMAQ": "21A", "PLLM_EV_APMAQ": "K120", "PLLM_EV_STA": "P", "PLLM_EV_DTLIB": "00010101", "PLLM_EV_USLIB": "", "PLLM_EV_MAQLIB": "", "PLLM_EV_DTALT": "00010101", "PLLM_EV_USALT": "", "PLLM_EV_DTVAL": "20160624", "selecionado": false, "guid": "72bf7c35-b9ca-242b-f95f-1e2f2590ccb1" }], "statusProcessamento": { "mensagem": { "codigo": "0000", "descricao": "", "severidade": "00" } } });

            /**
            * @ngdoc method
            * @name sucesso
            *   
            * @description
            * Método de sucesso do retorno da consulta as maquinas Pendentes
            **/
            function sucesso(data) {
                var atalho = vm.Atalhos.filter(function (e) {
                    return e.tela == "gestao-maquinas";
                });

                if (atalho.length == 1
                    && angular.isDefined(data.PLLM_EV_OCOR)) {

                    var pendencias = data.PLLM_EV_OCOR.length;
                    //TODO internacionalizar mensagem de retorno
                    if (pendencias == 0) {
                        atalho[0].atalhoRodapeDesc = "sem pendências";
                    } else {
                        atalho[0].atalhoRodapeDesc = pendencias + " pendencias";
                    }
                }
            }

            /**
           * @ngdoc method
           * @name erro
           *  
           * @description
           * Método de erro do retorno da consulta as maquinas Pendentes
           **/
            function erro() {
            }
        }


        /**
         * @ngdoc method
         * @name obterSaldo
         * 
         * @memberOf homeController.js
         *
         * @description        
         * Método que realiza a consulta de saldo
         **/
        function obterSaldo() {

            interpretadorComunicacao.interpretar(listarSaldoFactory
                .listarSaldo(utilitarios.zerosAEsquerda(vm.contaPreferencial.agencia, 5), vm.contaPreferencial.numero, utilitarios.zerosAEsquerda(vm.contaPreferencial.cnpj, 9)))
                .sucesso(sucesso)
                .aviso(erro)
                .erro(erro);

            // sucesso({"SLDG_EV_SIBLO": "+","SLDG_EV_SBLO": 0,"SLDG_EV_SIPAR": "+","SLDG_EV_SPAR": 11526072,"SLDG_EV_SIREA": "+","SLDG_EV_SREA": 0,"SLDG_EV_SILIM": "+","SLDG_EV_SLIM": 30750000,"SLDG_EV_SILSQ": "+","SLDG_EV_SLSQ": 0,
            // "SLDG_EV_SIMDIA": "+","SLDG_EV_MDIA": 11598253,"SLDG_EV_CDAT": 20110803,"SLDG_EV_FLB0": 0,"SLDG_EV_SCOB0": "+","SLDG_EV_COB0": "00000000000000000","SLDG_EV_FLB1": 0,"SLDG_EV_SICOB1": "+","SLDG_EV_COB1": "00000000000000000",
            // "SLDG_EV_MENS": "","SLDG_EV_DTLCH": "","SLDG_EV_SIVLLES": "","SLDG_EV_VLLES": "00000000000000000","SLDG_EV_DTLES": "","SLDG_EV_SIVLLFL": "","SLDG_EV_VLLFL": "00000000000000000","SLDG_EV_DTLFL": "","SLDG_EV_ERR_AGE": "",
            // "SLDG_EV_SIVLAGE": "","SLDG_EV_VLAGE": "","SLDG_EV_ERR_DEB": "","SLDG_EV_SIVLDEB": "","SLDG_EV_VLDEB": "","SLDG_EV_SIVLPARC": "","SLDG_EV_VLPARC": "","SLDG_EV_DTPARC": "","SLDG_EV_ERR_LIM": "","SLDG_EV_SINCI": "+",
            // "SLDG_EV_SLCI": "00000000000000000","SLDG_EV_NMCI": "009101506","SLDG_EV_OCOR": [{"SLDG_EV_OC_PROD": "ALE","SLDG_EV_OC_MODA": "GALILEO MM","SLDG_EV_OC_TSPO": "","SLDG_EV_OC_SIPRO": "+","SLDG_EV_OC_SPRO": "00000000108763560",
            // "SLDG_EV_OC_TPRO": "01","SLDG_EV_OC_FLAP": "0","SLDG_EV_OC_FEXT": "S","SLDG_EV_OC_FCLI": "N"},{"SLDG_EV_OC_PROD": "EXE","SLDG_EV_OC_MODA": "EXECUTIVE RF","SLDG_EV_OC_TSPO": "","SLDG_EV_OC_SIPRO": "+","SLDG_EV_OC_SPRO": "00000000025076925",
            // "SLDG_EV_OC_TPRO": "01","SLDG_EV_OC_FLAP": "0","SLDG_EV_OC_FEXT": "S","SLDG_EV_OC_FCLI": "N"},{"SLDG_EV_OC_PROD": "SSP","SLDG_EV_OC_MODA": "S&P MM","SLDG_EV_OC_TSPO": "","SLDG_EV_OC_SIPRO": "+","SLDG_EV_OC_SPRO": "00000000076306461",
            // "SLDG_EV_OC_TPRO": "01","SLDG_EV_OC_FLAP": "0","SLDG_EV_OC_FEXT": "S","SLDG_EV_OC_FCLI": "N"},{"SLDG_EV_OC_PROD": "","SLDG_EV_OC_MODA": "TOTAL","SLDG_EV_OC_TSPO": "","SLDG_EV_OC_SIPRO": "+","SLDG_EV_OC_SPRO": "00000000210146946",
            // "SLDG_EV_OC_TPRO": "00","SLDG_EV_OC_FLAP": "0","SLDG_EV_OC_FEXT": "N","SLDG_EV_OC_FCLI": ""}],"statusProcessamento": {"mensagem": {"codigo": "0000","descricao": "","severidade": "00"}}});

            /**
            * @ngdoc method
            * @name sucesso
            * 
            * @memberOf homeController.js
            *
            * @description        
            * Método executado em caso de sucesso na consulta de nome do cliente
            **/
            function sucesso(data) {

                var saldo = data.SLDG_EV_SPAR;

                var atalho = vm.Atalhos.filter(function (e) {
                    return e.tela == "extrato";
                });

                if (atalho.length == 1) {
                    atalho[0].linhaInferior = saldo;
                }

            }

            /**
             * @description Método de erro.
             */
            function erro() {

            }
        }


        /**
        * @ngdoc method
        * @name obterConta
        *  
        * @description
        * Método responsável por chamar o serviço que obtem a conta do cliente
        **/
        function obterConta() {
            console.log(listarContasFactory);
        //     interpretadorComunicacao.interpretar(listarContasFactory
        //         .listarContas())
        //         .sucesso(sucesso)
        //         .aviso(erro)
        //         .erro(erro);

        //     //  var data = {"data": [{"cnpj": "000382468","nome": "WLOTZGV KZONLOREV RMX V WLN OG","tipoPessoa": "J","contas": [{"agencia": "11500","conta": "000010107","tipoConta": "01","contaInvestimento": "009201410"}]},{"cnpj": "000690786","nome": "UVIMZMXL WLFGL NZIJFVH ORHYLZ","tipoPessoa": "F","contas": [{"agencia": "00200","conta": "001674043","tipoConta": "01","contaInvestimento": "009107181"}]},{"cnpj": "001521585","nome": "ILWSZ E SZMMZ GIZYZOSL G OGXZ","tipoPessoa": "J","contas": [{"agencia": "00200","conta": "001675996","tipoConta": "01","contaInvestimento": "009108209"}]},{"cnpj":"003281663","nome": "YIRTSGLM VNKIVVMX V KZIG OGXZ","tipoPessoa": "J","contas": [{"agencia": "09700","conta": "000156626","tipoConta": "01","contaInvestimento": "009131171"}]},{"cnpj": "006599918","nome": "OLGZIRL SVROYIFMM PIZFHV","tipoPessoa": "F","contas": [{"agencia": "11500","conta": "000027638","tipoConta": "01","contaInvestimento": "009207591"}]},{"cnpj": "012163378","nome": "QZIRY YIRHLOZ XFZIGV ULTZWZ","tipoPessoa": "F","contas": [{"agencia": "11500","conta": "000051172","tipoConta": "01","contaInvestimento": "009220767"}]},{"cnpj": "033200056","nome": "OLQZH IRZWSFVOL H Z","tipoPessoa": "J","contas": [{"agencia": "11500","conta": "000008358","tipoConta": "01","contaInvestimento": "009201088"}]},{"cnpj": "048112171","nome": "WLN OFHGIVH HKLG WVMGVI OGXZ","tipoPessoa": "J","contas": [{"agencia": "00200","conta": "001661464","tipoConta": "01","contaInvestimento":"009103461"}]},{"cnpj": "048271128","nome": "MVOHLM ZHWSVI","tipoPessoa": "F","contas": [{"agencia": "00200","conta": "001670234","tipoConta": "01","contaInvestimento": "009105587"}]},{"cnpj": "048435747","nome": "R K O RMWLIK KZFORHGZ OGXZ","tipoPessoa": "J","contas": [{"agencia": "09700","conta": "000118856","tipoConta": "01","contaInvestimento": "009116406"}]},{"cnpj": "048770051","nome": "NRIZWZGF ZFGL KLHGL OGXZ","tipoPessoa": "J","contas": [{"agencia": "09700","conta": "000082932","tipoConta": "01","contaInvestimento": "009109388"}]},{"cnpj": "049372154","nome": "GZY WLMHG V VNK RNLY OGXZ","tipoPessoa": "J","contas": [{"agencia": "09700","conta": "000166885","tipoConta": "01","contaInvestimento": "009137438"}]},{"cnpj": "057484768","nome": "EZORHVIV RMX V WLN OGXZ","tipoPessoa": "J","contas": [{"agencia": "00200","conta": "005005740","tipoConta":"02","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005232207","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005237381","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005242695","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005246704","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005247913","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005264532","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005270788","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005282301","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005292536","tipoConta": "03","contaInvestimento": "000000000"}]},{"cnpj": "061100145","nome": "RMXRZMZ HVTFILH H/Z","tipoPessoa": "J","contas": [{"agencia": "00200","conta": "001672849","tipoConta": "01","contaInvestimento": "009106605"}]},{"cnpj": "061558037","nome": "OLIVIO GARANTIAS COMITE","tipoPessoa": "J","contas": [{"agencia": "00200","conta": "001636800","tipoConta": "01","contaInvestimento": "009101476"},{"agencia": "00200","conta": "005028413","tipoConta": "02","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005031287","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005186931","tipoConta": "02","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005227521","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005231286","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005237021","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005247514","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005247611","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005262645","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005266993","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005269771","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005273884","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005278711","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005281372","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005289730","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "00200","conta": "005301331","tipoConta": "03","contaInvestimento": "000000000"},{"agencia": "09700","conta": "005030230","tipoConta": "02","contaInvestimento": "000000000"}]},{"cnpj": "087122696","nome": "ILMZOXL WLIIVZ NZIGRMH","tipoPessoa": "F","contas": [{"agencia": "00200","conta": "001654344","tipoConta": "01","contaInvestimento": "009102499"}]},{"cnpj": "116832728","nome": "XZERX YFMWV","tipoPessoa": "F","contas": [{"agencia": "11500","conta": "000051083","tipoConta": "01","contaInvestimento": "009220678"}]},{"cnpj": "298152378","nome": "ZXIRZMZ TRHVOV SVIGALT H OVNV","tipoPessoa": "F","contas": [{"agencia": "11500","conta": "000050621","tipoConta": "01","contaInvestimento": "009220384"}]},{"cnpj": "302723788","nome": "EZMRZ OFWWRZ HVWWL NVIGA","tipoPessoa": "F","contas": [{"agencia": "00200","conta": "001653925","tipoConta": "01","contaInvestimento": "009102383"}]},{"cnpj": "367361128","nome": "HVITRL IZNKRN","tipoPessoa": "F","contas": [{"agencia": "00200","conta": "001667241","tipoConta": "01","contaInvestimento": "009104785"}]},{"cnpj": "761434738","nome": "QLZL ZOEVH XV WZIEZOSL","tipoPessoa": "F","contas": [{"agencia": "00200","conta": "001636389","tipoConta": "01","contaInvestimento": "009101441"}]}] };

        //     // sucesso(data);

        //     /**
        //     * @ngdoc method
        //     * @name sucesso
        //     *   
        //     * @description
        //     * Método de sucesso do retorno da listagem de contas
        //     **/
        //     function sucesso(data) {

        //         if (angular.isDefined(data)
        //             && angular.isDefined(data.lista)
        //             && angular.isDefined(data.lista[0])
        //             && angular.isDefined(data.lista[0].cnpj)
        //             && angular.isDefined(data.lista[0].contas[0])
        //             && angular.isDefined(data.lista[0].contas[0].agencia)
        //             && angular.isDefined(data.lista[0].contas[0].conta)) {

        //             var agencia = parseInt(data.lista[0].contas[0].agencia);
        //             var conta = parseInt(data.lista[0].contas[0].conta);
        //             var cnpj = parseInt(data.lista[0].cnpj);

        //             vm.contaPreferencial = {
        //                 agencia: agencia,
        //                 numero: conta,
        //                 cnpj: cnpj
        //             };

        //             //sfMemorizador.definir("extrato.contaPreferencial", vm.contaPreferencial);

        //             atualizarContaEmUso();
        //             obterSaldo();
        //         }
        //     }

        //     /**
        //    * @ngdoc method
        //    * @name erro
        //    *  
        //    * @description
        //    * Método de erro do retorno da consulta da listagem de contas
        //    **/
        //     function erro(erro) {
        //         console.log("Erro ao listar contas:" + JSON.stringify(erro));
        //     }
        }

        /**
        * @ngdoc overview
        * @ngdoc method
        * @name recuperarContaPreferencial
        *
        * @description
        * Método responsável recuperar agência e conta preferencial
        **/
        function recuperarContaPreferencial() {
            var contaPreferencial = sfMemorizador.obter("extrato.contaPreferencial");
            if (contaPreferencial != null) {
                vm.contaPreferencial = contaPreferencial;
                atualizarContaEmUso();
                obterSaldo();
            } else {
                obterConta();
            }

        }

        vm.askjd = obterConta;


        /**
        * @ngdoc overview
        * @ngdoc method
        * @name atualizarContaEmUso
        *
        * @description
        * Método responsável por atualizar a conta exibida nos cards
        **/
        function atualizarContaEmUso() {
            var atalho = vm.Atalhos.filter(function (e) {
                return e.tela == "extrato";
            });

            if (atalho.length == 1) {
                atalho[0].linhaSuperior = ""
                    + vm.contaPreferencial.agencia
                    + " / "
                    + vm.contaPreferencial.numero;
            }

            obterSaldo();
        }
    }
})();