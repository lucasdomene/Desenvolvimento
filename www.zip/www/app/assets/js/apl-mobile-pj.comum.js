(function () {
    /**
     * @ngdoc overview
     * @name apl-mobile-pj.comum
     * 
     * @require ui.bootstrap, ngAnimate
     * 
     * @description
     * Módulo que define os fluxos de navegacao pelos controles da comum, utilizado por toda aplicação.
     **/
    angular.module("apl-mobile-pj.comum", ["ngAnimate","ui.bootstrap"])
        .config(comumModule)
        .run(["sfTradutor", function (tradutor) {
            tradutor.adicionarDicionarios(
                [
                    "app/modulos/comum/internacionalizacao/"
                ]
            );
        }]);

    comumModule.$inject = ["sfNavegadorProvider"];

    /**
    * @ngdoc overview
    * @name comumModule
    * 
    * @description
    * Navegação do módulo comum.
    **/
    function comumModule(sfNavegadorProvider) {
        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-detalhes-pagamento")
                .adicionarEstado("comum", {
                    templateUrl: "./app/modulos/comum/views/detalhespagamento/autorizacao.html",
                    controller: "situacaoPagamentoController as sitpagCtrl",
                    abstract: true
                })
                .adicionarEstado("comum.detalhes-do-pagamento", {
                    templateUrl: "./app/modulos/comum/views/detalhespagamento/sumarizador.html",
                    parent: "comum"
                },
                [
                    {
                        acao: "exibir-pagamentos-por-situacao",
                        estadoDestino: "comum.pagamentos-por-situacao"
                    }
                ])
                .adicionarEstado("comum.pagamentos-por-situacao", {
                    templateUrl: "./app/modulos/comum/views/detalhespagamento/pagamentos.html",
                    parent: "comum"
                },
                [
                    {
                        acao: "exibir-comprovante-fornecedor",
                        fluxo:"apl-mobile-pj-comprovante-fornecedor"
                    }
                ]
                )
                .definirEstadoInicial("comum.detalhes-do-pagamento")
        );
    }
    // angular.module("apl-mobile-pj.comum").directive("setClassWhenAtTop", setTopTest);

    // setTopTest.$inject = ["$window", "$document"];

    // /**
    //  * @description Teste
    //  */
    // function setTopTest($window, $document) {

    //     return {
    //         restrict: "A",
    //         link: function (scope, element, attrs) {


    //             var topClass = attrs.setClassWhenAtTop, offsetTop = 50;

    //             $document.on("scroll", function (e) {
    //                 if ($window.pageYOffset >= offsetTop) {
    //                     element.addClass(topClass);
    //                 } else {
    //                     element.removeClass(topClass);
    //                 }

    //                 console.log(e);
    //             });

    //         }
    //     };
    // }
})(); 
(function () {
    "use strict";

    var utilitarios = {
        getTemplate: function (elem, attrs) {
            return (attrs.template ? "./app/modulos/comum/views/" + this.name + "/" + attrs.template + ".html" : "./app/modulos/comum/views/" + this.name + "/default.html");
        }
    };

    angular.module("apl-mobile-pj.comum").constant("utilitariosMobile", utilitarios);
})();
(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("botao", botaoDirective);
    
    botaoDirective.$inject = ["utilitariosMobile"];
    
    /**
    * @ngdoc directive
    * @name botaoDirective
    *
    * @description
    * Diretiva responsável por controlar o componente de botão
    **/
    function botaoDirective(utilitariosMobile) {
        return {
            restrict: "E",
            scope: {
                texto: "@",
                acao: "&"
            },
            templateUrl: utilitariosMobile.getTemplate
        };
    }

})();
(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("cabecalho", cabecalhoDirective);

    cabecalhoDirective.$inject = ["utilitariosMobile"];

    /**
    * @ngdoc directive
    * @name cabecalhoDirective
    *
    * @description
    * Diretiva responsável por controlar o componente de cabeçalho
    **/
    function cabecalhoDirective(utilitariosMobile) {
        return {
            restrict: "E",
            scope: {
                acaovoltar: "&",
                acaopesquisar: "&",
                acaomenu: "&",

                titulo: "@",

                mostrarvoltar: "@",
                mostrarmenu: "@",
                mostrarlogo: "@",
                mostrarlupa: "@"
            },
            templateUrl: utilitariosMobile.getTemplate
        };
    }

})();
(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("cabecalhoconfirmacaosucesso", cabecalhoconfirmacaosucessoDirective);

    cabecalhoconfirmacaosucessoDirective.$inject = ["utilitariosMobile"];

    /**
    * @ngdoc directive
    * @name cabecalhoconfirmacaosucessoDirective
    *
    * @description
    * Diretiva responsável por controlar o componente de cabeçalho confirmação de sucesso
    **/
    function cabecalhoconfirmacaosucessoDirective(utilitariosMobile) {
        return {
            restrict: "E",
            scope: {
                ponto: "@"
            },
            link: executaAcao,
            templateUrl: utilitariosMobile.getTemplate
        };

        /**
        * @ngdoc function
        * @name executaAcao
        *
        * @description
        * Função responsável por controlar a chamada de ação do componente de cabeçalho de confirmação de sucesso
        **/
        function executaAcao(scope, element, attr) {
            var passoAtual = element[0].querySelector("#" + attr.ponto);
            angular.element(passoAtual).addClass("passo-ativo");

            var descpassoAtual = element[0].querySelector("#desc" + attr.ponto);
            angular.element(descpassoAtual).addClass("desc-passo-ativo");
        }
    }
})();

(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("cabecalhopassos", cabecalhoPassosDirective);
    
    cabecalhoPassosDirective.$inject = ["utilitariosMobile"];
    
    /**
    * @ngdoc directive
    * @name cabecalhoPassosDirective
    *
    * @description
    * Diretiva responsável por controlar o componente de cabeçalho de passo a passo
    **/
    function cabecalhoPassosDirective(utilitariosMobile) {
        return {
            restrict: "E",
            scope: {
                ponto: "@"
            },
            link: executaAcao,
            templateUrl: utilitariosMobile.getTemplate
        };
        
        /**
        * @ngdoc function
        * @name executaAcao
        *
        * @description
        * Função responsável por controlar a chamada de ação do componente de cabeçalho de passo a passo
        **/
        function executaAcao(scope, element, attr) {
            var passoAtual = element[0].querySelector("#" + attr.ponto);
            angular.element(passoAtual).addClass("passo-ativo");
            
            var descpassoAtual = element[0].querySelector("#desc" + attr.ponto);
            angular.element(descpassoAtual).addClass("desc-passo-ativo");
        }
    }
})();

(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("cabecalhotoken", cabecalhotoken);
    
    cabecalhotoken.$inject = ["utilitariosMobile"];
    
    /**
    * @ngdoc directive
    * @name cabecalhotoken
    *
    * @description
    * Diretiva responsável por controlar o componente de cabeçalho de passo a passo
    **/
    function cabecalhotoken(utilitariosMobile) {
        return {
            restrict: "E",
            scope: {
                ponto: "@"
            },
            link: executaAcao,
            templateUrl: utilitariosMobile.getTemplate
        };
        
        /**
        * @ngdoc function
        * @name executaAcao
        *
        * @description
        * Função responsável por controlar a chamada de ação do componente de cabeçalho de passo a passo
        **/
        function executaAcao(scope, element, attr) {
            var passoAtual = element[0].querySelector("#" + attr.ponto);
            angular.element(passoAtual).addClass("passo-ativo");
            
            var descpassoAtual = element[0].querySelector("#desc" + attr.ponto);
            angular.element(descpassoAtual).addClass("desc-passo-ativo");
        }
    }
})();

(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("confirmarsenhatoken", confirmarsenhatokenDirective);

    confirmarsenhatokenDirective.$inject = ["utilitariosMobile"]; 

    /**
    * @ngdoc directive
    * @name confirmarsenhatokenDirective
    *
    * @description
    * Diretiva responsável por controlar o componente de confirmar senha e token
    **/
    function confirmarsenhatokenDirective(utilitariosMobile) { 
        return {
            restrict: "E",
            scope: {
                acaoconfirmar: "&",
                acaocancelar: "&",
                senha: "=senha",
                token: "=token",
                exibeToken: "=exibeToken"
            },
            templateUrl: utilitariosMobile.getTemplate,
            link: link
        };
    }

    /**
    * @ngdoc method
    * @name link
    *
    * @methodOf confirmarSenhaToken.js
    *  
    * @description
    * Método responsável por adicionar novo método ao scope.
    **/
    function link(scope) {
        scope.apenasNumeros = apenasNumeros;

        /**
        * @ngdoc method
        * @name iniciar
        *
        * @methodOf confirmarSenhaToken.js
        *  
        * @description
        * Método responsável por permitir apenas digitacao de valores númericos.
        **/
        function apenasNumeros(event) {
            if (event.code != "Enter") {
                var regex = new RegExp("^([0-9])*$");
                var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);

                if (!regex.test(key)) {
                    event.preventDefault();
                }
            }
        }
    }
})();
(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("fixaCabecalhoTabelaComScroll", fixaCabecalhoTabelaComScroll);

    fixaCabecalhoTabelaComScroll.$inject = ["$window", "$document"];

    /**
     * @description Diretiva criada para gerenciar o momento para fixar o cabeçalho de uma tabela ao topo da aplicação 
     */
    function fixaCabecalhoTabelaComScroll($window, $document) {
        return {
            restrict: "A",
            link: executaAcao
        };

        /**
         * @description Ação que será executada na criação da Diretiva.
         */
        function executaAcao(scope, element, attrs) {
            var divScroll = angular.element($document[0].querySelector("#" + attrs.divscrollconteudo));

            var topClass = attrs.fixaCabecalhoTabelaComScroll;
            var offsetTop = attrs.posicaofixa;

            divScroll.bind("scroll", function () {
                if (this.scrollTop >= offsetTop) {
                    element.addClass(topClass);
                } else {
                    element.removeClass(topClass);
                }
            });
        }
    }
})(); 
//IMPLEMENTATION

(function () {
    "use strict";

    //TODO: REMOVER
    var mockitensMenu = [
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_extrato-01.png",
            fluxoDestino: "",
            // fluxoDestino: "apl-mobile-pj-extrato",
            texto: "Extrato de Movimentação",
            destaque: false,
            permissaogrupo: "POS",
            permissaoservico: "004",
            permissaonivel: ""
        },
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_autorizacao-01.png",
            fluxoDestino: "",
            // fluxoDestino: "apl-mobile-pj-autorizacaoPagamento",
            texto: "Autorização de Pagamentos",
            destaque: false,
            permissaogrupo: "PAG",
            permissaoservico: "001",
            permissaonivel: ""
        },
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_recebiveis-01.png",
            fluxoDestino: "",
            texto: "Recebimentos",
            destaque: false,
            permissaogrupo: "",
            permissaoservico: "",
            permissaonivel: ""
        },
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_investimentos-01.png",
            fluxoDestino: "",
            // fluxoDestino: "apl-mobile-pj-investimentos",
            texto: "Investimentos",
            destaque: false,
            permissaogrupo: "POS",
            permissaoservico: "001",
            permissaonivel: ""
        }
    ];

    var itensMenuFixo = [
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_home.png",
            texto: "Início",
            fluxoDestino: "apl-mobile-pj-home",
            exibido: true,
            destaque: true,
            permissaogrupo: "",
            permissaoservico: "",
            nivel: "",
            delimitadorTopo: true,
            delimitadorRodape: true
        },
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_seguranca-01.png",
            fluxoDestino: "apl-mobile-pj-orquestrador-seguranca",
            texto: "Segurança",
            destaque: false,
            permissaogrupo: "",
            permissaoservico: "",
            permissaonivel: "",
            delimitadorTopo: true
        },
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_chat-01.png",
            fluxoDestino: "",
            texto: "Fale conosco",
            destaque: false,
            permissaogrupo: "",
            permissaoservico: "",
            permissaonivel: ""
        },
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_agencia-01.png",
            fluxoDestino: "",
            texto: "Localize uma Agência",
            destaque: false,
            permissaogrupo: "",
            permissaoservico: "",
            permissaonivel: ""
        }
    ];

    /**
    * @ngdoc overview
    * @name apl-mobile-pj.areaPrincipal.menuDirective
    * 
    * @requires sfNavegador
    * 
    * @description
    * Directive responsável pela tratativa das ações a serem realizadas na view da menu logada.
    **/
    angular.module("apl-mobile-pj.comum").directive("menupj", menuDirective);

    menuDirective.$inject = [
        "sfNavegador",
        "utilitariosMobile",
        "sfContexto",
        "sfAutenticador"
    ];

    /**
    * @ngdoc 
    * @name menuDirective
    *
    * @methodOf apl-mobile-pj.areaPrincipal.menu
    *  
    * @description
    * Directive responsável por manipular a tela menu da área logada.
    **/
    function menuDirective(sfNavegador, utilitariosMobile, contexto, sfAutenticador) {
        return {
            restrict: "E",
            scope: {
                itemdestacado: "@",
                itensMenu: "@",
                nomeUsuario: "@",
                shortName: "@"
            },
            link: executarAcaoMenuPJ,
            templateUrl: utilitariosMobile.getTemplate
        };
        
        /**
         * @description Comment
         */
        function executarAcaoMenuPJ(scope) {      
            
            scope.sair = function () {
                sfAutenticador.logoff().then(sucesso).catch(sucesso);

                /**
                * @description Método de sucesso para a saida da aplicação
                */
                function sucesso(){
                    sfNavegador.iniciarFluxo("apl-mobile-pj-login");
                }
            };

            scope.itensMenu = [];
                 
            //adiciona o item do Inicio 
            scope.itensMenu[0] = itensMenuFixo[0];
            
            //percorro o mock e adiciono no scope os itens dinamicos
            for(var iContador = 0; iContador < mockitensMenu.length; iContador++)
            {
                //adiciono no array do menu os itens dinamicos
                 scope.itensMenu.push(mockitensMenu[iContador]);
            }
            
            //Adiciobno os ultimos itens fixos
            scope.itensMenu.push(itensMenuFixo[1]);
            scope.itensMenu.push(itensMenuFixo[2]);
            scope.itensMenu.push(itensMenuFixo[3]);

            angular.forEach(scope.itensMenu, function (item) {
                if (item.texto == scope.itemdestacado) {
                    item.destaque = true;
                }
                else {
                    item.destaque = false;
                }
            });

            scope.nomeUsuario = contexto.obterValorContextoTrabalho("nomeClienteUltimoAcesso");
            scope.shortName = contexto.obterValorContextoTrabalho("lembrarShortname");
        }
    }



})();





(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("permissionamento", permissionamento);

    permissionamento.$inject = ["$window", "$document", "validapermissionamento"];

    /**
     * @description Diretiva criada para aplicar a validação do permissionamento 
     */
    function permissionamento($window, $document, validapermissionamento) {
        return {
            restrict: "A",
            replace: false,
            transclude: false,
            link: validaPermissao
        };

        /**
         * @description Ação que valida Permissao.
         */
        function validaPermissao(scope, element, attrs) {
            var grupo = attrs.permissaogrupo;
            var servico = attrs.permissaoservico;
            var nivel = attrs.permissaonivel;

            var permitido = validapermissionamento.validacao(grupo, servico, nivel);

            if (!permitido)
            {
                element.html("");
            }
        }
    }
})(); 
/*! angularjs-slider - v5.4.0 - 
 (c) Rafal Zajac <rzajac@gmail.com>, Valentin Hervieu <valentin@hervieu.me>, Jussi Saarivirta <jusasi@gmail.com>, Angelin Sirbu <angelin.sirbu@gmail.com> - 
 https://github.com/angular-slider/angularjs-slider - 
 2016-07-13 */
/*jslint unparam: true */
/*global angular: false, console: false, define, module */
(function (root, factory) {
  "use strict";
  /* istanbul ignore next */
  if (typeof define === "function" && define.amd) {
    // AMD. Register as an anonymous module.
    define(["angular"], factory);
  } else if (typeof module === "object" && module.exports) {
    // Node. Does not work with strict CommonJS, but
    // only CommonJS-like environments that support module.exports,
    // like Node.
    // to support bundler like browserify
    module.exports = factory(require("angular"));
  } else {
    // Browser globals (root is window)
    factory(root.angular);
  }

} (this, function (angular) {
  "use strict";
  var module = angular.module("rzModule", [])

    .factory("RzSliderOptions", function () {
      var defaultOptions = {
        floor: 0,
        ceil: null, //defaults to rz-slider-model
        step: 1,
        precision: 0,
        minRange: null,
        maxRange: null,
        pushRange: false,
        minLimit: null,
        maxLimit: null,
        id: null,
        translate: null,
        getLegend: null,
        stepsArray: null,
        bindIndexForStepsArray: false,
        draggableRange: false,
        draggableRangeOnly: false,
        showSelectionBar: false,
        showSelectionBarEnd: false,
        showSelectionBarFromValue: null,
        hidePointerLabels: false,
        hideLimitLabels: false,
        readOnly: false,
        disabled: false,
        interval: 350,
        showTicks: false,
        showTicksValues: false,
        ticksTooltip: null,
        ticksValuesTooltip: null,
        vertical: false,
        getSelectionBarColor: null,
        getTickColor: null,
        getPointerColor: null,
        keyboardSupport: true,
        scale: 1,
        enforceStep: true,
        enforceRange: false,
        noSwitching: false,
        onlyBindHandles: false,
        onStart: null,
        onChange: null,
        onEnd: null,
        rightToLeft: false,
        boundPointerLabels: true,
        mergeRangeLabelsIfSame: false,
        customTemplateScope: null
      };
      var globalOptions = {};

      var factory = {};
      /**
       * `options({})` allows global configuration of all sliders in the
       * application.
       *
       *   var app = angular.module( 'App', ['rzModule'], function( RzSliderOptions ) {
       *     // show ticks for all sliders
       *     RzSliderOptions.options( { showTicks: true } );
       *   });
       */
      factory.options = function (value) {
        angular.extend(globalOptions, value);
      };

      factory.getOptions = function (options) {
        return angular.extend({}, defaultOptions, globalOptions, options);
      };

      return factory;
    })

    .factory("rzThrottle", ["$timeout", function ($timeout) {
      /**
       * rzThrottle
       *
       * Taken from underscore project
       *
       * @param {Function} func
       * @param {number} wait
       * @param {ThrottleOptions} options
       * @returns {Function}
       */
      return function (func, wait, options) {
        "use strict";
        /* istanbul ignore next */
        var getTime = (Date.now || function () {
          return new Date().getTime();
        });
        var context, args, result;
        var timeout = null;
        var previous = 0;
        options = options || {};
        var later = function () {
          previous = getTime();
          timeout = null;
          result = func.apply(context, args);
          context = args = null;
        };
        return function () {
          var now = getTime();
          var remaining = wait - (now - previous);
          context = this;
          args = arguments;
          if (remaining <= 0) {
            $timeout.cancel(timeout);
            timeout = null;
            previous = now;
            result = func.apply(context, args);
            context = args = null;
          } else if (!timeout && options.trailing !== false) {
            timeout = $timeout(later, remaining);
          }
          return result;
        };
      };
    }])

    .factory("RzSlider", ["$timeout", "$document", "$window", "$compile", "RzSliderOptions", "rzThrottle", function ($timeout, $document, $window, $compile, RzSliderOptions, rzThrottle) {
      "use strict";

      /**
       * Slider
       *
       * @param {ngScope} scope            The AngularJS scope
       * @param {Element} sliderElem The slider directive element wrapped in jqLite
       * @constructor
       */
      var Slider = function (scope, sliderElem) {
        /**
         * The slider's scope
         *
         * @type {ngScope}
         */
        this.scope = scope;

        /**
         * The slider inner low value (linked to rzSliderModel)
         * @type {number}
         */
        this.lowValue = 0;

        /**
         * The slider inner high value (linked to rzSliderHigh)
         * @type {number}
         */
        this.highValue = 0;

        /**
         * Slider element wrapped in jqLite
         *
         * @type {jqLite}
         */
        this.sliderElem = sliderElem;

        /**
         * Slider type
         *
         * @type {boolean} Set to true for range slider
         */
        this.range = this.scope.rzSliderModel !== undefined && this.scope.rzSliderHigh !== undefined;

        /**
         * Values recorded when first dragging the bar
         *
         * @type {Object}
         */
        this.dragging = {
          active: false,
          value: 0,
          difference: 0,
          offset: 0,
          lowLimit: 0,
          highLimit: 0
        };

        /**
         * property that handle position (defaults to left for horizontal)
         * @type {string}
         */
        this.positionProperty = "left";

        /**
         * property that handle dimension (defaults to width for horizontal)
         * @type {string}
         */
        this.dimensionProperty = "width";

        /**
         * Half of the width or height of the slider handles
         *
         * @type {number}
         */
        this.handleHalfDim = 0;

        /**
         * Maximum position the slider handle can have
         *
         * @type {number}
         */
        this.maxPos = 0;

        /**
         * Precision
         *
         * @type {number}
         */
        this.precision = 0;

        /**
         * Step
         *
         * @type {number}
         */
        this.step = 1;

        /**
         * The name of the handle we are currently tracking
         *
         * @type {string}
         */
        this.tracking = "";

        /**
         * Minimum value (floor) of the model
         *
         * @type {number}
         */
        this.minValue = 0;

        /**
         * Maximum value (ceiling) of the model
         *
         * @type {number}
         */
        this.maxValue = 0;


        /**
         * The delta between min and max value
         *
         * @type {number}
         */
        this.valueRange = 0;


        /**
         * If showTicks/showTicksValues options are number.
         * In this case, ticks values should be displayed below the slider.
         * @type {boolean}
         */
        this.intermediateTicks = false;

        /**
         * Set to true if init method already executed
         *
         * @type {boolean}
         */
        this.initHasRun = false;

        /**
         * Used to call onStart on the first keydown event
         *
         * @type {boolean}
         */
        this.firstKeyDown = false;

        /**
         * Internal flag to prevent watchers to be called when the sliders value are modified internally.
         * @type {boolean}
         */
        this.internalChange = false;

        /**
         * Internal flag to keep track of the visibility of combo label
         * @type {boolean}
         */
        this.cmbLabelShown = false;

        // Slider DOM elements wrapped in jqLite
        this.fullBar = null; // The whole slider bar
        this.selBar = null; // Highlight between two handles
        this.minH = null; // Left slider handle
        this.maxH = null; // Right slider handle
        this.flrLab = null; // Floor label
        this.ceilLab = null; // Ceiling label
        this.minLab = null; // Label above the low value
        this.maxLab = null; // Label above the high value
        this.cmbLab = null; // Combined label
        this.ticks = null; // The ticks

        // Initialize slider
        this.init();
      };

      // Add instance methods
      Slider.prototype = {

        /**
         * Initialize slider
         *
         * @returns {undefined}
         */
        init: function () {
          var thrLow, thrHigh,
            self = this;

          var calcDimFn = function () {
            self.calcViewDimensions();
          };

          this.applyOptions();
          this.syncLowValue();
          if (this.range) {
            this.syncHighValue();
          }
          this.initElemHandles();
          this.manageElementsStyle();
          this.setDisabledState();
          this.calcViewDimensions();
          this.setMinAndMax();
          this.addAccessibility();
          this.updateCeilLab();
          this.updateFloorLab();
          this.initHandles();
          this.manageEventsBindings();

          // Recalculate slider view dimensions
          this.scope.$on("reCalcViewDimensions", calcDimFn);

          // Recalculate stuff if view port dimensions have changed
          angular.element($window).on("resize", calcDimFn);

          this.initHasRun = true;

          // Watch for changes to the model
          thrLow = rzThrottle(function () {
            self.onLowHandleChange();
          }, self.options.interval);

          thrHigh = rzThrottle(function () {
            self.onHighHandleChange();
          }, self.options.interval);

          this.scope.$on("rzSliderForceRender", function () {
            self.resetLabelsValue();
            thrLow();
            if (self.range) {
              thrHigh();
            }
            self.resetSlider();
          });

          // Watchers (order is important because in case of simultaneous change,
          // watchers will be called in the same order)
          this.scope.$watch("rzSliderOptions()", function (newValue, oldValue) {
            if (newValue === oldValue) {
              return;
            }
            self.applyOptions(); // need to be called before synchronizing the values
            self.syncLowValue();
            if (self.range) {
              self.syncHighValue();
            }
            self.resetSlider();
          }, true);

          this.scope.$watch("rzSliderModel", function (newValue, oldValue) {
            if (self.internalChange) {
              return;
            }
            if (newValue === oldValue) {
              return;
            }
            thrLow();
          });

          this.scope.$watch("rzSliderHigh", function (newValue, oldValue) {
            if (self.internalChange) {
              return;
            }
            if (newValue === oldValue) {
              return;
            }
            if (newValue != null) {
              thrHigh();
            }
            if (self.range && newValue == null || !self.range && newValue != null) {
              self.applyOptions();
              self.resetSlider();
            }
          });

          this.scope.$on("$destroy", function () {
            self.unbindEvents();
            angular.element($window).off("resize", calcDimFn);
          });
        },

        findStepIndex: function (modelValue) {
          var index = 0;
          for (var i = 0; i < this.options.stepsArray.length; i++) {
            var step = this.options.stepsArray[i];
            if (step === modelValue) {
              index = i;
              break;
            }
            else if (angular.isObject(step) && step.value === modelValue) {
              index = i;
              break;
            }
          }
          return index;
        },

        syncLowValue: function () {
          if (this.options.stepsArray) {
            if (!this.options.bindIndexForStepsArray) {
              this.lowValue = this.findStepIndex(this.scope.rzSliderModel);
            }
            else {
              this.lowValue = this.scope.rzSliderModel;
            }
          }
          else {
            this.lowValue = this.scope.rzSliderModel;
          }
        },

        syncHighValue: function () {
          if (this.options.stepsArray) {
            if (!this.options.bindIndexForStepsArray) {
              this.highValue = this.findStepIndex(this.scope.rzSliderHigh);
            }
            else {
              this.highValue = this.scope.rzSliderHigh;
            }
          }
          else {
            this.highValue = this.scope.rzSliderHigh;
          }
        },

        getStepValue: function (sliderValue) {
          var step = this.options.stepsArray[sliderValue];
          if (angular.isObject(step)) {
            return step.value;
          }
          return step;
        },

        applyLowValue: function () {
          if (this.options.stepsArray) {
            if (!this.options.bindIndexForStepsArray) {
              this.scope.rzSliderModel = this.getStepValue(this.lowValue);
            }
            else {
              this.scope.rzSliderModel = this.lowValue;
            }
          }
          else {
            this.scope.rzSliderModel = this.lowValue;
          }
        },

        applyHighValue: function () {
          if (this.options.stepsArray) {
            if (!this.options.bindIndexForStepsArray) {
              this.scope.rzSliderHigh = this.getStepValue(this.highValue);
            }
            else {
              this.scope.rzSliderHigh = this.highValue;
            }
          }
          else {
            this.scope.rzSliderHigh = this.highValue;
          }
        },

        /*
         * Reflow the slider when the low handle changes (called with throttle)
         */
        onLowHandleChange: function () {
          this.syncLowValue();
          if (this.range) {
            this.syncHighValue();
          }
          this.setMinAndMax();
          this.updateLowHandle(this.valueToOffset(this.lowValue));
          this.updateSelectionBar();
          this.updateTicksScale();
          this.updateAriaAttributes();
          if (this.range) {
            this.updateCmbLabel();
          }
        },

        /*
         * Reflow the slider when the high handle changes (called with throttle)
         */
        onHighHandleChange: function () {
          this.syncLowValue();
          this.syncHighValue();
          this.setMinAndMax();
          this.updateHighHandle(this.valueToOffset(this.highValue));
          this.updateSelectionBar();
          this.updateTicksScale();
          this.updateCmbLabel();
          this.updateAriaAttributes();
        },

        /**
         * Read the user options and apply them to the slider model
         */
        applyOptions: function () {
          var sliderOptions;
          if (this.scope.rzSliderOptions) {
            sliderOptions = this.scope.rzSliderOptions();
          }
          else {
            sliderOptions = {};
          }

          this.options = RzSliderOptions.getOptions(sliderOptions);

          if (this.options.step <= 0) {
            this.options.step = 1;
          }

          this.range = this.scope.rzSliderModel !== undefined && this.scope.rzSliderHigh !== undefined;
          this.options.draggableRange = this.range && this.options.draggableRange;
          this.options.draggableRangeOnly = this.range && this.options.draggableRangeOnly;
          if (this.options.draggableRangeOnly) {
            this.options.draggableRange = true;
          }

          this.options.showTicks = this.options.showTicks || this.options.showTicksValues;
          this.scope.showTicks = this.options.showTicks; //scope is used in the template
          if (angular.isNumber(this.options.showTicks)) {
            this.intermediateTicks = true;
          }

          this.options.showSelectionBar = this.options.showSelectionBar || this.options.showSelectionBarEnd
            || this.options.showSelectionBarFromValue !== null;

          if (this.options.stepsArray) {
            this.parseStepsArray();
          } else {
            if (this.options.translate) {
              this.customTrFn = this.options.translate;
            }
            else {
              this.customTrFn = function (value) {
                return String(value);
              };
            }

            this.getLegend = this.options.getLegend;
          }

          if (this.options.vertical) {
            this.positionProperty = "bottom";
            this.dimensionProperty = "height";
          }

          if (this.options.customTemplateScope) {
            this.scope.custom = this.options.customTemplateScope;
          }
        },

        parseStepsArray: function () {
          this.options.floor = 0;
          this.options.ceil = this.options.stepsArray.length - 1;
          this.options.step = 1;

          if (this.options.translate) {
            this.customTrFn = this.options.translate;
          }
          else {
            this.customTrFn = function (modelValue) {
              if (this.options.bindIndexForStepsArray) {
                return this.getStepValue(modelValue);
              }
              return modelValue;
            };
          }

          this.getLegend = function (index) {
            var step = this.options.stepsArray[index];
            if (angular.isObject(step)) {
              return step.legend;
            }
            return null;
          };
        },

        /**
         * Resets slider
         *
         * @returns {undefined}
         */
        resetSlider: function () {
          this.manageElementsStyle();
          this.addAccessibility();
          this.setMinAndMax();
          this.updateCeilLab();
          this.updateFloorLab();
          this.unbindEvents();
          this.manageEventsBindings();
          this.setDisabledState();
          this.calcViewDimensions();
        },

        /**
         * Set the slider children to variables for easy access
         *
         * Run only once during initialization
         *
         * @returns {undefined}
         */
        initElemHandles: function () {
          // Assign all slider elements to object properties for easy access
          angular.forEach(this.sliderElem.children(), function (elem, index) {
            var jElem = angular.element(elem);

            switch (index) {
              case 0:
                this.fullBar = jElem;
                break;
              case 1:
                this.selBar = jElem;
                break;
              case 2:
                this.minH = jElem;
                break;
              case 3:
                this.maxH = jElem;
                break;
              case 4:
                this.flrLab = jElem;
                break;
              case 5:
                this.ceilLab = jElem;
                break;
              case 6:
                this.minLab = jElem;
                break;
              case 7:
                this.maxLab = jElem;
                break;
              case 8:
                this.cmbLab = jElem;
                break;
              case 9:
                this.ticks = jElem;
                break;
              default:
                break;
            }

          }, this);

          // Initialize offset cache properties
          this.selBar.rzsp = 0;
          this.minH.rzsp = 0;
          this.maxH.rzsp = 0;
          this.flrLab.rzsp = 0;
          this.ceilLab.rzsp = 0;
          this.minLab.rzsp = 0;
          this.maxLab.rzsp = 0;
          this.cmbLab.rzsp = 0;
        },

        /**
         * Update each elements style based on options
         */
        manageElementsStyle: function () {

          if (!this.range) {
            this.maxH.css("display", "none");
          }
          else {
            this.maxH.css("display", "");
          }


          this.alwaysHide(this.flrLab, this.options.showTicksValues || this.options.hideLimitLabels);
          this.alwaysHide(this.ceilLab, this.options.showTicksValues || this.options.hideLimitLabels);

          var hideLabelsForTicks = this.options.showTicksValues && !this.intermediateTicks;
          //this.alwaysHide(this.minLab, hideLabelsForTicks || this.options.hidePointerLabels);
          //this.alwaysHide(this.maxLab, hideLabelsForTicks || !this.range || this.options.hidePointerLabels);
          this.alwaysHide(this.cmbLab, hideLabelsForTicks || !this.range || this.options.hidePointerLabels);
          this.alwaysHide(this.selBar, !this.range && !this.options.showSelectionBar);

          if (this.options.vertical) {
            this.sliderElem.addClass("rz-vertical");
          }

          if (this.options.draggableRange) {
            this.selBar.addClass("rz-draggable");
          }
          else {
            this.selBar.removeClass("rz-draggable");
          }

          if (this.intermediateTicks && this.options.showTicksValues) {
            this.ticks.addClass("rz-ticks-values-under");
          }
        },

        alwaysHide: function (el, hide) {
          el.rzAlwaysHide = hide;
          if (hide) {
            this.hideEl(el);
          }
          else {
            this.showEl(el);
          }
        },

        /**
         * Manage the events bindings based on readOnly and disabled options
         *
         * @returns {undefined}
         */
        manageEventsBindings: function () {
          if (this.options.disabled || this.options.readOnly) {
            this.unbindEvents();
          }
          else {
            this.bindEvents();
          }
        },

        /**
         * Set the disabled state based on rzSliderDisabled
         *
         * @returns {undefined}
         */
        setDisabledState: function () {
          if (this.options.disabled) {
            this.sliderElem.attr("disabled", "disabled");
          } else {
            this.sliderElem.attr("disabled", null);
          }
        },

        /**
         * Reset label values
         *
         * @return {undefined}
         */
        resetLabelsValue: function () {
          this.minLab.rzsv = undefined;
          this.maxLab.rzsv = undefined;
        },

        /**
         * Initialize slider handles positions and labels
         *
         * Run only once during initialization and every time view port changes size
         *
         * @returns {undefined}
         */
        initHandles: function () {
          this.updateLowHandle(this.valueToOffset(this.lowValue));

          /*
           the order here is important since the selection bar should be
           updated after the high handle but before the combined label
           */
          if (this.range) {
            this.updateHighHandle(this.valueToOffset(this.highValue));
          }
          this.updateSelectionBar();
          if (this.range) {
            this.updateCmbLabel();
          }

          this.updateTicksScale();
        },

        /**
         * Translate value to human readable format
         *
         * @param {number|string} value
         * @param {jqLite} label
         * @param {String} which
         * @param {boolean} [useCustomTr]
         * @returns {undefined}
         */
        translateFn: function (value, label, which, useCustomTr) {
          useCustomTr = useCustomTr === undefined ? true : useCustomTr;

          var valStr = "",
            getDimension = false,
            noLabelInjection = label.hasClass("no-label-injection");

          if (useCustomTr) {
            if (this.options.stepsArray && !this.options.bindIndexForStepsArray) {
              value = this.getStepValue(value);
            }
            valStr = String(this.customTrFn(value, this.options.id, which));
          }
          else {
            valStr = String(value);
          }

          if (label.rzsv === undefined || label.rzsv.length !== valStr.length || (label.rzsv.length > 0 && label.rzsd === 0)) {
            getDimension = true;
            label.rzsv = valStr;
          }

          if (!noLabelInjection) { label.html(valStr); }

          this.scope[which + "Label"] = valStr;

          // Update width only when length of the label have changed
          if (getDimension) {
            this.getDimension(label);
          }
        },

        /**
         * Set maximum and minimum values for the slider and ensure the model and high
         * value match these limits
         * @returns {undefined}
         */
        setMinAndMax: function () {

          this.step = +this.options.step;
          this.precision = +this.options.precision;

          this.minValue = this.options.floor;

          if (this.options.enforceStep) {
            this.lowValue = this.roundStep(this.lowValue);
            if (this.range) {
              this.highValue = this.roundStep(this.highValue);
            }
          }

          if (this.options.ceil != null) {
            this.maxValue = this.options.ceil;
          }
          else {
            this.maxValue = this.options.ceil = this.range ? this.highValue : this.lowValue;
          }

          if (this.options.enforceRange) {
            this.lowValue = this.sanitizeValue(this.lowValue);
            if (this.range) {
              this.highValue = this.sanitizeValue(this.highValue);
            }
          }

          this.applyLowValue();
          if (this.range) {
            this.applyHighValue();
          }

          this.valueRange = this.maxValue - this.minValue;
        },

        /**
         * Adds accessibility attributes
         *
         * Run only once during initialization
         *
         * @returns {undefined}
         */
        addAccessibility: function () {
          this.minH.attr("role", "slider");
          this.updateAriaAttributes();
          if (this.options.keyboardSupport && !(this.options.readOnly || this.options.disabled)) {
            this.minH.attr("tabindex", "0");
          }
          else {
            this.minH.attr("tabindex", "");
          }
          if (this.options.vertical) {
            this.minH.attr("aria-orientation", "vertical");
          }

          if (this.range) {
            this.maxH.attr("role", "slider");
            if (this.options.keyboardSupport && !(this.options.readOnly || this.options.disabled)) {
              this.maxH.attr("tabindex", "0");
            }
            else {
              this.maxH.attr("tabindex", "");
            }
            if (this.options.vertical) {
              this.maxH.attr("aria-orientation", "vertical");
            }
          }
        },

        /**
         * Updates aria attributes according to current values
         */
        updateAriaAttributes: function () {
          this.minH.attr({
            "aria-valuenow": this.scope.rzSliderModel,
            "aria-valuetext": this.customTrFn(this.scope.rzSliderModel, this.options.id, "model"),
            "aria-valuemin": this.minValue,
            "aria-valuemax": this.maxValue
          });
          if (this.range) {
            this.maxH.attr({
              "aria-valuenow": this.scope.rzSliderHigh,
              "aria-valuetext": this.customTrFn(this.scope.rzSliderHigh, this.options.id, "high"),
              "aria-valuemin": this.minValue,
              "aria-valuemax": this.maxValue
            });
          }
        },

        /**
         * Calculate dimensions that are dependent on view port size
         *
         * Run once during initialization and every time view port changes size.
         *
         * @returns {undefined}
         */
        calcViewDimensions: function () {
          var handleWidth = this.getDimension(this.minH);

          this.handleHalfDim = handleWidth / 2;
          this.barDimension = this.getDimension(this.fullBar);

          this.maxPos = this.barDimension - handleWidth;

          this.getDimension(this.sliderElem);
          this.sliderElem.rzsp = this.sliderElem[0].getBoundingClientRect()[this.positionProperty];

          if (this.initHasRun) {
            this.updateFloorLab();
            this.updateCeilLab();
            this.initHandles();
          }
        },

        /**
         * Update the ticks position
         *
         * @returns {undefined}
         */
        updateTicksScale: function () {
          if (!this.options.showTicks) { return; }
          var step = this.step;
          if (this.intermediateTicks) {
            step = this.options.showTicks;
          }
          var ticksCount = Math.round((this.maxValue - this.minValue) / step) + 1;
          this.scope.ticks = [];
          for (var i = 0; i < ticksCount; i++) {
            var value = this.roundStep(this.minValue + i * step);
            var tick = {
              selected: this.isTickSelected(value)
            };
            if (tick.selected && this.options.getSelectionBarColor) {
              tick.style = {
                "background-color": this.getSelectionBarColor()
              };
            }
            if (!tick.selected && this.options.getTickColor) {
              tick.style = {
                "background-color": this.getTickColor(value)
              };
            }
            if (this.options.ticksTooltip) {
              tick.tooltip = this.options.ticksTooltip(value);
              tick.tooltipPlacement = this.options.vertical ? "right" : "top";
            }
            if (this.options.showTicksValues) {
              tick.value = this.getDisplayValue(value, "tick-value");
              if (this.options.ticksValuesTooltip) {
                tick.valueTooltip = this.options.ticksValuesTooltip(value);
                tick.valueTooltipPlacement = this.options.vertical ? "right" : "top";
              }
            }
            if (this.getLegend) {
              var legend = this.getLegend(value, this.options.id);
              if (legend) {
                tick.legend = legend;
              }
            }
            if (!this.options.rightToLeft) {
              this.scope.ticks.push(tick);
            } else {
              this.scope.ticks.unshift(tick);
            }
          }
        },

        isTickSelected: function (value) {
          if (!this.range) {
            if (this.options.showSelectionBarFromValue !== null) {
              var center = this.options.showSelectionBarFromValue;
              if (this.lowValue > center && value >= center && value <= this.lowValue) {
                return true;
              }
              else if (this.lowValue < center && value <= center && value >= this.lowValue) {
                return true;
              }
            }
            else if (this.options.showSelectionBarEnd) {
              if (value >= this.lowValue) {
                return true;
              }
            }
            else if (this.options.showSelectionBar && value <= this.lowValue) {
              return true;
            }
          }
          if (this.range && value >= this.lowValue && value <= this.highValue) {
            return true;
          }
          return false;
        },

        /**
         * Update position of the floor label
         *
         * @returns {undefined}
         */
        updateFloorLab: function () {
          this.translateFn(this.minValue, this.flrLab, "floor");
          this.getDimension(this.flrLab);
          var position = this.options.rightToLeft ? this.barDimension - this.flrLab.rzsd : 0;
          this.setPosition(this.flrLab, position);
        },

        /**
         * Update position of the ceiling label
         *
         * @returns {undefined}
         */
        updateCeilLab: function () {
          this.translateFn(this.maxValue, this.ceilLab, "ceil");
          this.getDimension(this.ceilLab);
          var position = this.options.rightToLeft ? 0 : this.barDimension - this.ceilLab.rzsd;
          this.setPosition(this.ceilLab, position);
        },

        /**
         * Update slider handles and label positions
         *
         * @param {string} which
         * @param {number} newOffset
         */
        updateHandles: function (which, newOffset) {
          if (which === "lowValue") {
            this.updateLowHandle(newOffset);
          }
          else {
            this.updateHighHandle(newOffset);
          }

          this.updateSelectionBar();
          this.updateTicksScale();
          if (this.range) {
            this.updateCmbLabel();
          }
        },

        /**
         * Helper function to work out the position for handle labels depending on RTL or not
         *
         * @param {string} labelName maxLab or minLab
         * @param newOffset
         *
         * @returns {number}
         */
        getHandleLabelPos: function (labelName, newOffset) {
          var labelRzsd = this[labelName].rzsd,
            nearHandlePos = newOffset - labelRzsd / 2 + this.handleHalfDim,
            endOfBarPos = this.barDimension - labelRzsd;

          if (!this.options.boundPointerLabels) {
            return nearHandlePos;
          }

          if (this.options.rightToLeft && labelName === "minLab" || !this.options.rightToLeft && labelName === "maxLab") {
            return Math.min(nearHandlePos, endOfBarPos);
          } else {
            return Math.min(Math.max(nearHandlePos, 0), endOfBarPos);
          }
        },

        /**
         * Update low slider handle position and label
         *
         * @param {number} newOffset
         * @returns {undefined}
         */
        updateLowHandle: function (newOffset) {
          this.setPosition(this.minH, newOffset);
          this.translateFn(this.lowValue, this.minLab, "model");
          this.setPosition(this.minLab, this.getHandleLabelPos("minLab", newOffset));

          if (this.options.getPointerColor) {
            var pointercolor = this.getPointerColor("min");
            this.scope.minPointerStyle = {
              backgroundColor: pointercolor
            };
          }

          this.shFloorCeil();
        },

        /**
         * Update high slider handle position and label
         *
         * @param {number} newOffset
         * @returns {undefined}
         */
        updateHighHandle: function (newOffset) {
          this.setPosition(this.maxH, newOffset);
          this.translateFn(this.highValue, this.maxLab, "high");
          this.setPosition(this.maxLab, this.getHandleLabelPos("maxLab", newOffset));

          if (this.options.getPointerColor) {
            var pointercolor = this.getPointerColor("max");
            this.scope.maxPointerStyle = {
              backgroundColor: pointercolor
            };
          }

          this.shFloorCeil();
        },

        /**
         * Show/hide floor/ceiling label
         *
         * @returns {undefined}
         */
        shFloorCeil: function () {
          var flHidden = false,
            clHidden = false,
            isRTL = this.options.rightToLeft,
            flrLabPos = this.flrLab.rzsp,
            flrLabDim = this.flrLab.rzsd,
            minLabPos = this.minLab.rzsp,
            minLabDim = this.minLab.rzsd,
            maxLabPos = this.maxLab.rzsp,
            maxLabDim = this.maxLab.rzsd,
            cmbLabPos = this.cmbLab.rzsp,
            cmbLabDim = this.cmbLab.rzsd,
            ceilLabPos = this.ceilLab.rzsp,
            halfHandle = this.handleHalfDim,
            isMinLabAtFloor = isRTL ? minLabPos + minLabDim >= flrLabPos - flrLabDim - 5 : minLabPos <= flrLabPos + flrLabDim + 5,
            isMinLabAtCeil = isRTL ? minLabPos - minLabDim <= ceilLabPos + halfHandle + 10 : minLabPos + minLabDim >= ceilLabPos - halfHandle - 10,
            //isMaxLabAtFloor = isRTL ? maxLabPos >= flrLabPos - flrLabDim - halfHandle : maxLabPos <= flrLabPos + flrLabDim + halfHandle,
            isMaxLabAtCeil = isRTL ? maxLabPos - maxLabDim <= ceilLabPos + 10 : maxLabPos + maxLabDim >= ceilLabPos - 10,
            isCmbLabAtFloor = isRTL ? cmbLabPos >= flrLabPos - flrLabDim - halfHandle : cmbLabPos <= flrLabPos + flrLabDim + halfHandle,
            isCmbLabAtCeil = isRTL ? cmbLabPos - cmbLabDim <= ceilLabPos + 10 : cmbLabPos + cmbLabDim >= ceilLabPos - 10;


          if (isMinLabAtFloor) {
            flHidden = true;
            this.hideEl(this.flrLab);
          } else {
            flHidden = false;
            this.showEl(this.flrLab);
          }

          if (isMinLabAtCeil) {
            clHidden = true;
            this.hideEl(this.ceilLab);
          } else {
            clHidden = false;
            this.showEl(this.ceilLab);
          }

          if (this.range) {
            var hideCeil = this.cmbLabelShown ? isCmbLabAtCeil : isMaxLabAtCeil;
            var hideFloor = this.cmbLabelShown ? isCmbLabAtFloor : isMinLabAtFloor;

            if (hideCeil) {
              this.hideEl(this.ceilLab);
            } else if (!clHidden) {
              this.showEl(this.ceilLab);
            }

            // Hide or show floor label
            if (hideFloor) {
              this.hideEl(this.flrLab);
            } else if (!flHidden) {
              this.showEl(this.flrLab);
            }
          }
        },

        /**
         * Update slider selection bar, combined label and range label
         *
         * @returns {undefined}
         */
        updateSelectionBar: function () {
          var position = 0,
            dimension = 0,
            isSelectionBarFromRight = this.options.rightToLeft ? !this.options.showSelectionBarEnd : this.options.showSelectionBarEnd,
            positionForRange = this.options.rightToLeft ? this.maxH.rzsp + this.handleHalfDim : this.minH.rzsp + this.handleHalfDim;

          if (this.range) {
            dimension = Math.abs(this.maxH.rzsp - this.minH.rzsp);
            position = positionForRange;
          }
          else if (this.options.showSelectionBarFromValue !== null) {
            var center = this.options.showSelectionBarFromValue,
              centerPosition = this.valueToOffset(center),
              isModelGreaterThanCenter = this.options.rightToLeft ? this.lowValue <= center : this.lowValue > center;
            if (isModelGreaterThanCenter) {
              dimension = this.minH.rzsp - centerPosition;
              position = centerPosition + this.handleHalfDim;
            }
            else {
              dimension = centerPosition - this.minH.rzsp;
              position = this.minH.rzsp + this.handleHalfDim;
            }
          }
          else if (isSelectionBarFromRight) {
            dimension = Math.abs(this.maxPos - this.minH.rzsp) + this.handleHalfDim;
            position = this.minH.rzsp + this.handleHalfDim;
          } else {
            dimension = Math.abs(this.maxH.rzsp - this.minH.rzsp) + this.handleHalfDim;
            position = 0;
          }

          this.setDimension(this.selBar, dimension);
          this.setPosition(this.selBar, position);
          if (this.options.getSelectionBarColor) {
            var color = this.getSelectionBarColor();
            this.scope.barStyle = {
              backgroundColor: color
            };
          }
        },

        /**
         * Wrapper around the getSelectionBarColor of the user to pass to
         * correct parameters
         */
        getSelectionBarColor: function () {
          if (this.range) {
            return this.options.getSelectionBarColor(this.scope.rzSliderModel, this.scope.rzSliderHigh);
          }
          return this.options.getSelectionBarColor(this.scope.rzSliderModel);
        },

        /**
         * Wrapper around the getPointerColor of the user to pass to
         * correct parameters
         */
        getPointerColor: function (pointerType) {
          if (pointerType === "max") {
            return this.options.getPointerColor(this.scope.rzSliderHigh, pointerType);
          }
          return this.options.getPointerColor(this.scope.rzSliderModel, pointerType);
        },

        /**
         * Wrapper around the getTickColor of the user to pass to
         * correct parameters
         */
        getTickColor: function (value) {
          return this.options.getTickColor(value);
        },

        /**
         * Update combined label position and value
         *
         * @returns {undefined}
         */
        updateCmbLabel: function () {
          var isLabelOverlap = null;
          if (this.options.rightToLeft) {
            isLabelOverlap = this.minLab.rzsp - this.minLab.rzsd - 10 <= this.maxLab.rzsp;
          } else {
            isLabelOverlap = this.minLab.rzsp + this.minLab.rzsd + 10 >= this.maxLab.rzsp;
          }

          if (isLabelOverlap) {
            var lowTr = this.getDisplayValue(this.lowValue, "model"),
              highTr = this.getDisplayValue(this.highValue, "high"),
              labelVal = "";
            if (this.options.mergeRangeLabelsIfSame && lowTr === highTr) {
              labelVal = lowTr;
            }
            //  else if (this.lowValue != this.highValue) {
            //   labelVal = this.options.rightToLeft ? highTr + " - " + lowTr : lowTr + " - " + highTr;
            // }

            this.translateFn(labelVal, this.cmbLab, "cmb", false);
            var pos = this.options.boundPointerLabels ? Math.min(
              Math.max(
                this.selBar.rzsp + this.selBar.rzsd / 2 - this.cmbLab.rzsd / 2,
                0
              ),
              this.barDimension - this.cmbLab.rzsd
            ) : this.selBar.rzsp + this.selBar.rzsd / 2 - this.cmbLab.rzsd / 2;

            this.setPosition(this.cmbLab, pos);
            this.cmbLabelShown = true;
            //this.hideEl(this.minLab);
            //this.hideEl(this.maxLab);
            this.showEl(this.cmbLab);
          } else {
            this.cmbLabelShown = false;
            this.showEl(this.maxLab);
            this.showEl(this.minLab);
            this.hideEl(this.cmbLab);
          }
        },

        /**
         * Return the translated value if a translate function is provided else the original value
         * @param value
         * @param which if it's min or max handle
         * @returns {*}
         */
        getDisplayValue: function (value, which) {
          if (this.options.stepsArray && !this.options.bindIndexForStepsArray) {
            value = this.getStepValue(value);
          }
          return this.customTrFn(value, this.options.id, which);
        },

        /**
         * Round value to step and precision based on minValue
         *
         * @param {number} value
         * @param {number} customStep a custom step to override the defined step
         * @returns {number}
         */
        roundStep: function (value, customStep) {
          var step = customStep ? customStep : this.step,
            steppedDifference = parseFloat((value - this.minValue) / step).toPrecision(12);
          steppedDifference = Math.round(+steppedDifference) * step;
          var newValue = (this.minValue + steppedDifference).toFixed(this.precision);
          return +newValue;
        },

        /**
         * Hide element
         *
         * @param element
         * @returns {jqLite} The jqLite wrapped DOM element
         */
        hideEl: function (element) {
          return element.css({
            visibility: "hidden"
          });
        },

        /**
         * Show element
         *
         * @param element The jqLite wrapped DOM element
         * @returns {jqLite} The jqLite
         */
        showEl: function (element) {
          if (!element.rzAlwaysHide) {
            return element;
          }

          return element.css({
            visibility: "visible"
          });
        },

        /**
         * Set element left/top offset depending on whether slider is horizontal or vertical
         *
         * @param {jqLite} elem The jqLite wrapped DOM element
         * @param {number} pos
         * @returns {number}
         */
        setPosition: function (elem, pos) {
          elem.rzsp = pos;
          var css = {};
          css[this.positionProperty] = pos + "px";
          elem.css(css);
          return pos;
        },

        /**
         * Get element width/height depending on whether slider is horizontal or vertical
         *
         * @param {jqLite} elem The jqLite wrapped DOM element
         * @returns {number}
         */
        getDimension: function (elem) {
          var val = elem[0].getBoundingClientRect();
          if (this.options.vertical) {
            elem.rzsd = (val.bottom - val.top) * this.options.scale;
          }
          else {
            elem.rzsd = (val.right - val.left) * this.options.scale;
          }
          return elem.rzsd;
        },

        /**
         * Set element width/height depending on whether slider is horizontal or vertical
         *
         * @param {jqLite} elem  The jqLite wrapped DOM element
         * @param {number} dim
         * @returns {number}
         */
        setDimension: function (elem, dim) {
          elem.rzsd = dim;
          var css = {};
          css[this.dimensionProperty] = dim + "px";
          elem.css(css);
          return dim;
        },

        /**
         * Translate value to pixel offset
         *
         * @param {number} val
         * @returns {number}
         */
        valueToOffset: function (val) {
          if (this.options.rightToLeft) {
            return (this.maxValue - this.sanitizeValue(val)) * this.maxPos / this.valueRange || 0;
          }
          return (this.sanitizeValue(val) - this.minValue) * this.maxPos / this.valueRange || 0;
        },

        /**
         * Returns a value that is within slider range
         *
         * @param {number} val
         * @returns {number}
         */
        sanitizeValue: function (val) {
          return Math.min(Math.max(val, this.minValue), this.maxValue);
        },

        /**
         * Translate offset to model value
         *
         * @param {number} offset
         * @returns {number}
         */
        offsetToValue: function (offset) {
          if (this.options.rightToLeft) {
            return (1 - (offset / this.maxPos)) * this.valueRange + this.minValue;
          }
          return (offset / this.maxPos) * this.valueRange + this.minValue;
        },

        // Events

        /**
         * Get the X-coordinate or Y-coordinate of an event
         *
         * @param {Object} event  The event
         * @returns {number}
         */
        getEventXY: function (event) {
          /* http://stackoverflow.com/a/12336075/282882 */
          //noinspection JSLint
          var clientXY = this.options.vertical ? "clientY" : "clientX";
          if (event[clientXY] !== undefined) {
            return event[clientXY];
          }

          return event.originalEvent === undefined ?
            event.touches[0][clientXY] : event.originalEvent.touches[0][clientXY];
        },

        /**
         * Compute the event position depending on whether the slider is horizontal or vertical
         * @param event
         * @returns {number}
         */
        getEventPosition: function (event) {
          var sliderPos = this.sliderElem.rzsp,
            eventPos = 0;
          if (this.options.vertical) {
            eventPos = -this.getEventXY(event) + sliderPos;
          }
          else {
            eventPos = this.getEventXY(event) - sliderPos;
          }
          return (eventPos - this.handleHalfDim) * this.options.scale;
        },

        /**
         * Get event names for move and event end
         *
         * @param {Event}    event    The event
         *
         * @return {{moveEvent: string, endEvent: string}}
         */
        getEventNames: function (event) {
          var eventNames = {
            moveEvent: "",
            endEvent: ""
          };

          if (event.touches || (event.originalEvent !== undefined && event.originalEvent.touches)) {
            eventNames.moveEvent = "touchmove";
            eventNames.endEvent = "touchend";
          } else {
            eventNames.moveEvent = "mousemove";
            eventNames.endEvent = "mouseup";
          }

          return eventNames;
        },

        /**
         * Get the handle closest to an event.
         *
         * @param event {Event} The event
         * @returns {jqLite} The handle closest to the event.
         */
        getNearestHandle: function (event) {
          if (!this.range) {
            return this.minH;
          }
          var offset = this.getEventPosition(event),
            distanceMin = Math.abs(offset - this.minH.rzsp),
            distanceMax = Math.abs(offset - this.maxH.rzsp);
          if (distanceMin < distanceMax) {
            return this.minH;
          }
          else if (distanceMin > distanceMax) {
            return this.maxH;
          }
          else if (!this.options.rightToLeft) {
            //if event is at the same distance from min/max then if it's at left of minH, we return minH else maxH
            return offset < this.minH.rzsp ? this.minH : this.maxH;
          }
          else {
            //reverse in rtl
            return offset > this.minH.rzsp ? this.minH : this.maxH;
          }
        },

        /**
         * Wrapper function to focus an angular element
         *
         * @param el {AngularElement} the element to focus
         */
        focusElement: function (el) {
          var DOM_ELEMENT = 0;
          el[DOM_ELEMENT].focus();
        },

        /**
         * Bind mouse and touch events to slider handles
         *
         * @returns {undefined}
         */
        bindEvents: function () {
          var barTracking, barStart, barMove;

          if (this.options.draggableRange) {
            barTracking = "rzSliderDrag";
            barStart = this.onDragStart;
            barMove = this.onDragMove;
          } else {
            barTracking = "lowValue";
            barStart = this.onStart;
            barMove = this.onMove;
          }

          if (!this.options.onlyBindHandles) {
            this.selBar.on("mousedown", angular.bind(this, barStart, null, barTracking));
            this.selBar.on("mousedown", angular.bind(this, barMove, this.selBar));
          }

          if (this.options.draggableRangeOnly) {
            this.minH.on("mousedown", angular.bind(this, barStart, null, barTracking));
            this.maxH.on("mousedown", angular.bind(this, barStart, null, barTracking));
          } else {
            this.minH.on("mousedown", angular.bind(this, this.onStart, this.minH, "lowValue"));
            if (this.range) {
              this.maxH.on("mousedown", angular.bind(this, this.onStart, this.maxH, "highValue"));
            }
            if (!this.options.onlyBindHandles) {
              this.fullBar.on("mousedown", angular.bind(this, this.onStart, null, null));
              this.fullBar.on("mousedown", angular.bind(this, this.onMove, this.fullBar));
              this.ticks.on("mousedown", angular.bind(this, this.onStart, null, null));
              this.ticks.on("mousedown", angular.bind(this, this.onTickClick, this.ticks));
            }
          }

          if (!this.options.onlyBindHandles) {
            this.selBar.on("touchstart", angular.bind(this, barStart, null, barTracking));
            this.selBar.on("touchstart", angular.bind(this, barMove, this.selBar));
          }
          if (this.options.draggableRangeOnly) {
            this.minH.on("touchstart", angular.bind(this, barStart, null, barTracking));
            this.maxH.on("touchstart", angular.bind(this, barStart, null, barTracking));
          } else {
            this.minH.on("touchstart", angular.bind(this, this.onStart, this.minH, "lowValue"));
            if (this.range) {
              this.maxH.on("touchstart", angular.bind(this, this.onStart, this.maxH, "highValue"));
            }
            if (!this.options.onlyBindHandles) {
              this.fullBar.on("touchstart", angular.bind(this, this.onStart, null, null));
              this.fullBar.on("touchstart", angular.bind(this, this.onMove, this.fullBar));
              this.ticks.on("touchstart", angular.bind(this, this.onStart, null, null));
              this.ticks.on("touchstart", angular.bind(this, this.onTickClick, this.ticks));
            }
          }

          if (this.options.keyboardSupport) {
            this.minH.on("focus", angular.bind(this, this.onPointerFocus, this.minH, "lowValue"));
            if (this.range) {
              this.maxH.on("focus", angular.bind(this, this.onPointerFocus, this.maxH, "highValue"));
            }
          }
        },

        /**
         * Unbind mouse and touch events to slider handles
         *
         * @returns {undefined}
         */
        unbindEvents: function () {
          this.minH.off();
          this.maxH.off();
          this.fullBar.off();
          this.selBar.off();
          this.ticks.off();
        },

        /**
         * onStart event handler
         *
         * @param {?Object} pointer The jqLite wrapped DOM element; if null, the closest handle is used
         * @param {?string} ref     The name of the handle being changed; if null, the closest handle's value is modified
         * @param {Event}   event   The event
         * @returns {undefined}
         */
        onStart: function (pointer, ref, event) {
          var ehMove, ehEnd,
            eventNames = this.getEventNames(event);

          event.stopPropagation();
          event.preventDefault();

          // We have to do this in case the HTML where the sliders are on
          // have been animated into view.
          this.calcViewDimensions();

          if (pointer) {
            this.tracking = ref;
          } else {
            pointer = this.getNearestHandle(event);
            this.tracking = pointer === this.minH ? "lowValue" : "highValue";
          }

          pointer.addClass("rz-active");

          if (this.options.keyboardSupport) {
            this.focusElement(pointer);
          }

          ehMove = angular.bind(this, this.dragging.active ? this.onDragMove : this.onMove, pointer);
          ehEnd = angular.bind(this, this.onEnd, ehMove);

          $document.on(eventNames.moveEvent, ehMove);
          $document.one(eventNames.endEvent, ehEnd);
          this.callOnStart();
        },

        /**
         * onMove event handler
         *
         * @param {jqLite} pointer
         * @param {Event}  event The event
         * @param {boolean}  fromTick if the event occured on a tick or not
         * @returns {undefined}
         */
        onMove: function (pointer, event, fromTick) {
          var newOffset = this.getEventPosition(event),
            newValue,
            ceilValue = this.options.rightToLeft ? this.minValue : this.maxValue,
            flrValue = this.options.rightToLeft ? this.maxValue : this.minValue;

          if (newOffset <= 0) {
            newValue = flrValue;
          } else if (newOffset >= this.maxPos) {
            newValue = ceilValue;
          } else {
            newValue = this.offsetToValue(newOffset);
            if (fromTick && angular.isNumber(this.options.showTicks)) {
              newValue = this.roundStep(newValue, this.options.showTicks);
            }
            else {
              newValue = this.roundStep(newValue);
            }
          }
          this.positionTrackingHandle(newValue);
        },

        /**
         * onEnd event handler
         *
         * @param {Event}    event    The event
         * @param {Function} ehMove   The the bound move event handler
         * @returns {undefined}
         */
        onEnd: function (ehMove, event) {
          var moveEventName = this.getEventNames(event).moveEvent;

          if (!this.options.keyboardSupport) {
            this.minH.removeClass("rz-active");
            this.maxH.removeClass("rz-active");
            this.tracking = "";
          }
          this.dragging.active = false;

          $document.off(moveEventName, ehMove);
          this.callOnEnd();
        },

        onTickClick: function (pointer, event) {
          this.onMove(pointer, event, true);
        },

        onPointerFocus: function (pointer, ref) {
          this.tracking = ref;
          pointer.one("blur", angular.bind(this, this.onPointerBlur, pointer));
          pointer.on("keydown", angular.bind(this, this.onKeyboardEvent));
          pointer.on("keyup", angular.bind(this, this.onKeyUp));
          this.firstKeyDown = true;
          pointer.addClass("rz-active");
        },

        onKeyUp: function () {
          this.firstKeyDown = true;
          this.callOnEnd();
        },

        onPointerBlur: function (pointer) {
          pointer.off("keydown");
          pointer.off("keyup");
          this.tracking = "";
          pointer.removeClass("rz-active");
        },

        /**
         * Key actions helper function
         *
         * @param {number} currentValue value of the slider
         *
         * @returns {?Object} action value mappings
         */
        getKeyActions: function (currentValue) {
          var increaseStep = currentValue + this.step,
            decreaseStep = currentValue - this.step,
            increasePage = currentValue + this.valueRange / 10,
            decreasePage = currentValue - this.valueRange / 10;

          //Left to right default actions
          var actions = {
            "UP": increaseStep,
            "DOWN": decreaseStep,
            "LEFT": decreaseStep,
            "RIGHT": increaseStep,
            "PAGEUP": increasePage,
            "PAGEDOWN": decreasePage,
            "HOME": this.minValue,
            "END": this.maxValue
          };
          //right to left means swapping right and left arrows
          if (this.options.rightToLeft) {
            actions.LEFT = increaseStep;
            actions.RIGHT = decreaseStep;
            // right to left and vertical means we also swap up and down
            if (this.options.vertical) {
              actions.UP = decreaseStep;
              actions.DOWN = increaseStep;
            }
          }
          return actions;
        },

        onKeyboardEvent: function (event) {
          var currentValue = this[this.tracking],
            keyCode = event.keyCode || event.which,
            keys = {
              38: "UP",
              40: "DOWN",
              37: "LEFT",
              39: "RIGHT",
              33: "PAGEUP",
              34: "PAGEDOWN",
              36: "HOME",
              35: "END"
            },
            actions = this.getKeyActions(currentValue),
            key = keys[keyCode],
            action = actions[key];
          if (action == null || this.tracking === "") { return; }
          event.preventDefault();

          if (this.firstKeyDown) {
            this.firstKeyDown = false;
            this.callOnStart();
          }

          var self = this;
          $timeout(function () {
            var newValue = self.roundStep(self.sanitizeValue(action));
            if (!self.options.draggableRangeOnly) {
              self.positionTrackingHandle(newValue);
            }
            else {
              var difference = self.highValue - self.lowValue,
                newMinValue, newMaxValue;
              if (self.tracking === "lowValue") {
                newMinValue = newValue;
                newMaxValue = newValue + difference;
                if (newMaxValue > self.maxValue) {
                  newMaxValue = self.maxValue;
                  newMinValue = newMaxValue - difference;
                }
              } else {
                newMaxValue = newValue;
                newMinValue = newValue - difference;
                if (newMinValue < self.minValue) {
                  newMinValue = self.minValue;
                  newMaxValue = newMinValue + difference;
                }
              }
              self.positionTrackingBar(newMinValue, newMaxValue);
            }
          });
        },

        /**
         * onDragStart event handler
         *
         * Handles dragging of the middle bar.
         *
         * @param {Object} pointer The jqLite wrapped DOM element
         * @param {string} ref     One of the refLow, refHigh values
         * @param {Event}  event   The event
         * @returns {undefined}
         */
        onDragStart: function (pointer, ref, event) {
          var offset = this.getEventPosition(event);
          this.dragging = {
            active: true,
            value: this.offsetToValue(offset),
            difference: this.highValue - this.lowValue,
            lowLimit: this.options.rightToLeft ? this.minH.rzsp - offset : offset - this.minH.rzsp,
            highLimit: this.options.rightToLeft ? offset - this.maxH.rzsp : this.maxH.rzsp - offset
          };

          this.onStart(pointer, ref, event);
        },

        /**
         * getValue helper function
         *
         * gets max or min value depending on whether the newOffset is outOfBounds above or below the bar and rightToLeft
         *
         * @param {string} type 'max' || 'min' The value we are calculating
         * @param {number} newOffset  The new offset
         * @param {boolean} outOfBounds Is the new offset above or below the max/min?
         * @param {boolean} isAbove Is the new offset above the bar if out of bounds?
         *
         * @returns {number}
         */
        getValue: function (type, newOffset, outOfBounds, isAbove) {
          var isRTL = this.options.rightToLeft,
            value = null;

          if (type === "min") {
            if (outOfBounds) {
              if (isAbove) {
                value = isRTL ? this.minValue : this.maxValue - this.dragging.difference;
              } else {
                value = isRTL ? this.maxValue - this.dragging.difference : this.minValue;
              }
            } else {
              value = isRTL ? this.offsetToValue(newOffset + this.dragging.lowLimit) : this.offsetToValue(newOffset - this.dragging.lowLimit);
            }
          } else if (outOfBounds) {
            if (isAbove) {
              value = isRTL ? this.minValue + this.dragging.difference : this.maxValue;
            } else {
              value = isRTL ? this.maxValue : this.minValue + this.dragging.difference;
            }
          } else
            if (isRTL) {
              value = this.offsetToValue(newOffset + this.dragging.lowLimit) + this.dragging.difference;
            } else {
              value = this.offsetToValue(newOffset - this.dragging.lowLimit) + this.dragging.difference;
            }
          return this.roundStep(value);
        },

        /**
         * onDragMove event handler
         *
         * Handles dragging of the middle bar.
         *
         * @param {jqLite} pointer
         * @param {Event}  event The event
         * @returns {undefined}
         */
        onDragMove: function (pointer, event) {
          var newOffset = this.getEventPosition(event),
            newMinValue, newMaxValue,
            ceilLimit, flrLimit,
            isUnderFlrLimit, isOverCeilLimit,
            flrH, ceilH;

          if (this.options.rightToLeft) {
            ceilLimit = this.dragging.lowLimit;
            flrLimit = this.dragging.highLimit;
            flrH = this.maxH;
            ceilH = this.minH;
          } else {
            ceilLimit = this.dragging.highLimit;
            flrLimit = this.dragging.lowLimit;
            flrH = this.minH;
            ceilH = this.maxH;
          }
          isUnderFlrLimit = newOffset <= flrLimit;
          isOverCeilLimit = newOffset >= this.maxPos - ceilLimit;

          if (isUnderFlrLimit) {
            if (flrH.rzsp === 0) {
              return;
            }
            newMinValue = this.getValue("min", newOffset, true, false);
            newMaxValue = this.getValue("max", newOffset, true, false);
          } else if (isOverCeilLimit) {
            if (ceilH.rzsp === this.maxPos) {
              return;
            }
            newMaxValue = this.getValue("max", newOffset, true, true);
            newMinValue = this.getValue("min", newOffset, true, true);
          } else {
            newMinValue = this.getValue("min", newOffset, false);
            newMaxValue = this.getValue("max", newOffset, false);
          }
          this.positionTrackingBar(newMinValue, newMaxValue);
        },

        /**
         * Set the new value and offset for the entire bar
         *
         * @param {number} newMinValue   the new minimum value
         * @param {number} newMaxValue   the new maximum value
         */
        positionTrackingBar: function (newMinValue, newMaxValue) {
          this.lowValue = newMinValue;
          this.highValue = newMaxValue;
          this.applyLowValue();
          if (this.range) {
            this.applyHighValue();
          }
          this.applyModel();
          this.updateHandles("lowValue", this.valueToOffset(newMinValue));
          this.updateHandles("highValue", this.valueToOffset(newMaxValue));
        },

        /**
         * Set the new value and offset to the current tracking handle
         *
         * @param {number} newValue new model value
         */
        positionTrackingHandle: function (newValue) {
          var valueChanged = false;

          newValue = this.applyMinMaxLimit(newValue);
          if (this.range) {
            if (this.options.pushRange) {
              newValue = this.applyPushRange(newValue);
              valueChanged = true;
            }
            else {
              newValue = this.applyMinMaxRange(newValue);
              /* This is to check if we need to switch the min and max handles */
              if (this.tracking === "lowValue" && newValue > this.highValue) {
                if (this.options.noSwitching && this.highValue !== this.minValue) {
                  newValue = this.applyMinMaxRange(this.highValue);
                }
                else {
                  this.lowValue = this.highValue;
                  this.applyLowValue();
                  this.updateHandles(this.tracking, this.maxH.rzsp);
                  this.updateAriaAttributes();
                  this.tracking = "highValue";
                  this.minH.removeClass("rz-active");
                  this.maxH.addClass("rz-active");
                  if (this.options.keyboardSupport) {
                    this.focusElement(this.maxH);
                  }
                }
                valueChanged = true;
              }
              else if (this.tracking === "highValue" && newValue < this.lowValue) {
                if (this.options.noSwitching && this.lowValue !== this.maxValue) {
                  newValue = this.applyMinMaxRange(this.lowValue);
                }
                else {
                  this.highValue = this.lowValue;
                  this.applyHighValue();
                  this.updateHandles(this.tracking, this.minH.rzsp);
                  this.updateAriaAttributes();
                  this.tracking = "lowValue";
                  this.maxH.removeClass("rz-active");
                  this.minH.addClass("rz-active");
                  if (this.options.keyboardSupport) {
                    this.focusElement(this.minH);
                  }
                }
                valueChanged = true;
              }
            }
          }

          if (this[this.tracking] !== newValue) {
            this[this.tracking] = newValue;
            if (this.tracking === "lowValue") {
              this.applyLowValue();
            }
            else {
              this.applyHighValue();
            }
            this.updateHandles(this.tracking, this.valueToOffset(newValue));
            this.updateAriaAttributes();
            valueChanged = true;
          }

          if (valueChanged) {
            this.applyModel();
          }
        },

        applyMinMaxLimit: function (newValue) {
          if (this.options.minLimit != null && newValue < this.options.minLimit) {
            return this.options.minLimit;
          }
          if (this.options.maxLimit != null && newValue > this.options.maxLimit) {
            return this.options.maxLimit;
          }
          return newValue;
        },

        applyMinMaxRange: function (newValue) {
          var oppositeValue = this.tracking === "lowValue" ? this.highValue : this.lowValue,
            difference = Math.abs(newValue - oppositeValue);
          if (this.options.minRange != null) {
            if (difference < this.options.minRange) {
              if (this.tracking === "lowValue") {
                return this.highValue - this.options.minRange;
              }
              else {
                return this.lowValue + this.options.minRange;
              }
            }
          }
          if (this.options.maxRange != null) {
            if (difference > this.options.maxRange) {
              if (this.tracking === "lowValue") {
                return this.highValue - this.options.maxRange;
              }
              else {
                return this.lowValue + this.options.maxRange;
              }
            }
          }
          return newValue;
        },

        applyPushRange: function (newValue) {
          var difference = this.tracking === "lowValue" ? this.highValue - newValue : newValue - this.lowValue,
            range = this.options.minRange !== null ? this.options.minRange : this.options.step;
          if (difference < range) {
            if (this.tracking === "lowValue") {
              this.highValue = Math.min(newValue + range, this.maxValue);
              newValue = this.highValue - range;
              this.applyHighValue();
              this.updateHandles("highValue", this.valueToOffset(this.highValue));
            }
            else {
              this.lowValue = Math.max(newValue - range, this.minValue);
              newValue = this.lowValue + range;
              this.applyLowValue();
              this.updateHandles("lowValue", this.valueToOffset(this.lowValue));
            }
            this.updateAriaAttributes();
          }
          return newValue;
        },

        /**
         * Apply the model values using scope.$apply.
         * We wrap it with the internalChange flag to avoid the watchers to be called
         */
        applyModel: function () {
          this.internalChange = true;
          this.scope.$apply();
          this.callOnChange();
          this.internalChange = false;
        },

        /**
         * Call the onStart callback if defined
         * The callback call is wrapped in a $evalAsync to ensure that its result will be applied to the scope.
         *
         * @returns {undefined}
         */
        callOnStart: function () {
          if (this.options.onStart) {
            var self = this,
              pointerType = this.tracking === "lowValue" ? "min" : "max";
            this.scope.$evalAsync(function () {
              self.options.onStart(self.options.id, self.scope.rzSliderModel, self.scope.rzSliderHigh, pointerType);
            });
          }
        },

        /**
         * Call the onChange callback if defined
         * The callback call is wrapped in a $evalAsync to ensure that its result will be applied to the scope.
         *
         * @returns {undefined}
         */
        callOnChange: function () {
          if (this.options.onChange) {
            var self = this,
              pointerType = this.tracking === "lowValue" ? "min" : "max";
            this.scope.$evalAsync(function () {
              self.options.onChange(self.options.id, self.scope.rzSliderModel, self.scope.rzSliderHigh, pointerType);
            });
          }
        },

        /**
         * Call the onEnd callback if defined
         * The callback call is wrapped in a $evalAsync to ensure that its result will be applied to the scope.
         *
         * @returns {undefined}
         */
        callOnEnd: function () {
          if (this.options.onEnd) {
            var self = this,
              pointerType = this.tracking === "lowValue" ? "min" : "max";
            this.scope.$evalAsync(function () {
              self.options.onEnd(self.options.id, self.scope.rzSliderModel, self.scope.rzSliderHigh, pointerType);
            });
          }
          this.scope.$emit("slideEnded");
        }
      };

      return Slider;
    }])

    .directive("rzslider", ["RzSlider", function (RzSlider) {
      "use strict";

      return {
        restrict: "AE",
        replace: true,
        scope: {
          rzSliderModel: "=?",
          rzSliderHigh: "=?",
          rzSliderOptions: "&?",
          rzSliderTplUrl: "@"
        },

        /**
         * Return template URL
         *
         * @param {jqLite} elem
         * @param {Object} attrs
         * @return {string}
         */
        templateUrl: function (elem, attrs) {
          //noinspection JSUnresolvedVariable
          return attrs.rzSliderTplUrl || "rzSliderTpl.html";
        },

        link: function (scope, elem) {
          scope.slider = new RzSlider(scope, elem); //attach on scope so we can test it
        }
      };
    }]);

  // IDE assist

  /**
   * @name ngScope
   *
   * @property {number} rzSliderModel
   * @property {number} rzSliderHigh
   * @property {Object} rzSliderOptions
   */

  /**
   * @name jqLite
   *
   * @property {number|undefined} rzsp rzslider label position offset
   * @property {number|undefined} rzsd rzslider element dimension
   * @property {string|undefined} rzsv rzslider label value/text
   * @property {Function} css
   * @property {Function} text
   */

  /**
   * @name Event
   * @property {Array} touches
   * @property {Event} originalEvent
   */

  /**
   * @name ThrottleOptions
   *
   * @property {boolean} leading
   * @property {boolean} trailing
   */

  module.run(["$templateCache", function ($templateCache) {
    "use strict";

    $templateCache.put("rzSliderTpl.html",
      "<div class=rzslider><span class=rz-bar-wrapper><span class=rz-bar></span></span> <span class=rz-bar-wrapper><span class=\"rz-bar rz-selection\" ng-style=barStyle></span></span> <span class=\"rz-pointer rz-pointer-min\" ng-style=minPointerStyle></span> <span class=\"rz-pointer rz-pointer-max\" ng-style=maxPointerStyle></span> <span class=\"rz-bubble rz-limit rz-floor\"></span> <span class=\"rz-bubble rz-limit rz-ceil\"></span> <span class=rz-bubble></span> <span class=rz-bubble></span> <span class=rz-bubble></span><ul ng-show=showTicks class=rz-ticks><li ng-repeat=\"t in ticks track by $index\" class=rz-tick ng-class=\"{'rz-selected': t.selected}\" ng-style=t.style ng-attr-uib-tooltip=\"{{ t.tooltip }}\" ng-attr-tooltip-placement={{t.tooltipPlacement}} ng-attr-tooltip-append-to-body=\"{{ t.tooltip ? true : undefined}}\"><span ng-if=\"t.value != null\" class=rz-tick-value ng-attr-uib-tooltip=\"{{ t.valueTooltip }}\" ng-attr-tooltip-placement={{t.valueTooltipPlacement}}>{{ t.value }}</span> <span ng-if=\"t.legend != null\" class=rz-tick-legend>{{ t.legend }}</span></li></ul></div>"
    );

  }]);

  return module.name;
}));

(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("sfCaracteresEspeciaisEspaco", validarCaracteresEspeciais);

    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: validarCaracteresEspeciais
     * @module arq-spa-base.validacoes
     *  
     * @description
     * Método responsável por verificar se o e-mail informado é valido.
     */
    function validarCaracteresEspeciais() {
        return {
            restrict: "A",
            link: link
        };

        /**
        * @ngdoc object
        * @name link
        * 
        * @description
        * Método responsável por verificar se o campo de confirmação é igual o campo informado anteriormente.
        */
        function link(scope, element) {
            var regex = new RegExp("^([a-zA-Z0-9])*$");
            element.bind("keypress paste", bloquearCaracteres);

            /**
             * @ngdoc object
             * @name bloquearCaracteres
             * 
             * @description
             * Método contendo a lógica para bloquear os caracteres especiais informados no HTML do código.
             */
            function bloquearCaracteres(event) {
                if (event.code != "Enter") {
                    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);

                    if (!regex.test(key)) {
                        event.preventDefault();
                    }
                }
            }
        }
    }
})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name exibicaoComprovanteFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:exibicaoComprovanteFactory
    *
    * @description
    * Factory de conexão com API exibicaoComprovanteFactory
    **/
    angular.module("apl-mobile-pj.comum")
        .factory("exibicaoComprovanteFactory", exibicaoComprovanteFactory);

    exibicaoComprovanteFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name exibicaoComprovanteFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:exibicaoComprovanteFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function exibicaoComprovanteFactory(conectorAPI, appSettings, utilitarios) {

        return {
            exibirComprovante: exibirComprovante
        };

        /**
        * @ngdoc method
        * @name exibirComprovante
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento:exibirComprovante
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function exibirComprovante(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "exibicao-comprovante"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name identificarComprovanteCompartilhadoFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:identificarComprovanteCompartilhadoFactory
    *
    * @description
    * Factory de conexão com API identificarComprovanteCompartilhadoFactory
    **/
    angular.module("apl-mobile-pj.comum")
        .factory("identificarComprovanteCompartilhadoFactory", identificarComprovanteCompartilhadoFactory);

    identificarComprovanteCompartilhadoFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name identificarComprovanteCompartilhadoFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:identificarComprovanteCompartilhadoFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function identificarComprovanteCompartilhadoFactory(conectorAPI, appSettings, utilitarios) {

        return {
            identificarComprovanteCompartilhado: identificarComprovanteCompartilhado
        };

        /**
        * @ngdoc method
        * @name identificarComprovanteCompartilhado
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento:identificarComprovanteCompartilhado
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function identificarComprovanteCompartilhado(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "marcar-comprovante-compartilhado"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();
(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum")
        .factory("interpretadorComunicacao", interpretadorComunicacao);

    interpretadorComunicacao.$inject = ["sfNavegador", "modal", "sfAutenticador"];

    /**
    * @ngdoc method
    * @name interpretadorComunicacao
    *
    * @methodOf apl-mobile-pj.comum:interpretadorComunicacao
    *  
    * @description
    * Método responsavel por interpretar e processar as transacoes recebidas pelo controlador
    **/
    function interpretadorComunicacao(sfNavegador, modal, sfAutenticador) {

        return {
            interpretar: interpretar
        };

        /**
        * @ngdoc method
        * @name interpretar
        *
        * @methodOf apl-mobile-pj.comum:interpretadorComunicacao
        *  
        * @description
        * Método responsavel por inicializar a promisse que será retornada
        **/
        function interpretar(promise) {
            return new InterpretadorPromise(promise);
        }

        /**
        * @ngdoc method
        * @name InterpretadorPromise
        *
        * @methodOf apl-mobile-pj.comum:interpretadorComunicacao
        *  
        * @description
        * Método que recebe a promisse como parâmetro e executa os callbacks de acordo com o resultado
        **/
        function InterpretadorPromise(_promise) {
            this.promise = _promise;

            this.sucesso = callbackSucesso;
            this.aviso = callbackAviso;
            this.erro = callbackErro;

            /**
            * @ngdoc method
            * @name callbackSucesso
            *
            * @methodOf apl-mobile-pj.comum:interpretadorComunicacao
            *  
            * @description
            * Método que executa o call back de sucesso caso a comunicação tenha sido realizada com sucesso
            **/
            function callbackSucesso(callback) {
                this.promise.then(callbackPromise);

                /**
                * @ngdoc method
                * @name callbackPromise
                *
                * @methodOf apl-mobile-pj.comum:interpretadorComunicacao
                *  
                * @description
                * Método que re-chama a promisse de acordo com o resultado passando os dados retornados como parametro
                **/
                function callbackPromise(resultado) {
                    if (resultado.status === 200) {
                        resultado.data.httpStatusCode = resultado.status;

                        callback(resultado.data);
                    }
                }

                return this;
            }

            /**
            * @ngdoc method
            * @name callbackAviso
            *
            * @methodOf apl-mobile-pj.comum:interpretadorComunicacao
            *
            * @description
            * Método que executa o call back de aviso caso a comunicação tenha retornado um aviso
            **/
            function callbackAviso(callback) {
                this.promise.then(callbackPromise);

                /**
                * @ngdoc method
                * @name callbackPromise
                *
                * @methodOf apl-mobile-pj.comum:interpretadorComunicacao
                *  
                * @description
                * Método que re-chama a promisse de acordo com o resultado passando os dados retornados como parametro
                **/
                function callbackPromise(resultado) {
                    if (resultado.status === 250) {
                        resultado.data.httpStatusCode = resultado.status;

                        callback(resultado.data);
                    }
                }

                return this;
            }

            /**
            * @ngdoc method
            * @name callbackErro
            *
            * @methodOf apl-mobile-pj.comum:interpretadorComunicacao
            *
            * @description
            * Método que executa o call back de erro caso a comunicação tenha retornado um erro
            **/
            function callbackErro(callback) {
                this.promise.then(callbackPromiseSucesso).catch(callbackPromiseErro);

                /**
                * @ngdoc method
                * @name callbackPromiseSucesso
                *
                * @methodOf apl-mobile-pj.comum:interpretadorComunicacao
                *  
                * @description
                * Método que re-chama a promisse de acordo com o resultado passando os dados retornados como parametro
                **/
                function callbackPromiseSucesso(erro) {
                    if (validarRangeErros(erro.status)) {
                        erro.data.httpStatusCode = erro.status;

                        callback(erro.data);
                    }
                }

                /**
                * @ngdoc method
                * @name callbackPromiseErro
                *
                * @methodOf apl-mobile-pj.comum:interpretadorComunicacao
                *  
                * @description
                * Método que re-chama a promisse de acordo com o resultado passando os dados retornados como parametro
                **/
                function callbackPromiseErro(erro) {
                    if (validarRangeErros(erro.status)) {
                        erro.data.httpStatusCode = erro.status;

                        callback(erro.data);
                    } else {
                        modal.abrirModal(
                            "Segurança",
                            erro.data.statusProcessamento.message,
                            "", encerrarSessao);
                    }

                    /**
                     * @description Método de sucesso para a saida da aplicação
                     */
                    function encerrarSessao() {
                        sfAutenticador.logoff().then(sucesso).catch(sucesso);

                        /**
                         * @description Método de sucesso para a saida da aplicação
                        */
                        function sucesso() {
                            sfNavegador.iniciarFluxo("apl-mobile-pj-login");
                        }
                    }
                }

                /**
                 * @description Método responsavel por validar se o httpStatusCode está num range aceitavel pela aplicação.
                 */
                function validarRangeErros(httpStatusCode) {
                    return (httpStatusCode >= 460 && httpStatusCode <= 499) || (httpStatusCode === 550);
                }

                return this;
            }
        }
    }
})();
(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").factory("modal", modal);

    modal.$inject = [
        "$uibModal"
    ];

    /**
     * @description Implementação padrão do modal de exibição nas telas.
     */
    function modal($uibModal) {

        return {
            abrirModal: abrirModal
        };

        /**
         * @description Método responsável pela abertura do modal padrão.
         */
        function abrirModal(titulo,
            mensagem,
            nomeTemplate,
            acaoOK,
            acaoCancelar,
            dados,
            controller,
            controllerAs,
            size) {

            if (angular.isUndefined(nomeTemplate)
                || nomeTemplate == null || nomeTemplate == "") {
                nomeTemplate = "modalMensagem";

            }

            if (angular.isUndefined(controller)) {
                controller = "modalController";
            }

            if (angular.isUndefined(controllerAs)) {
                controllerAs = "ctrlModal";
            }

            if (angular.isUndefined(dados)) {
                dados = [];
            }

            if (titulo != undefined && titulo != null && titulo != "") {
                dados.titulo = titulo;
            }

            if (mensagem != undefined && mensagem != null && mensagem != "") {
                dados.mensagem = mensagem;
            }

            if (size == undefined || size == null || size == ""){
                size = "sm";
            }

            var instanciaModal = $uibModal.open({
                animation: true,
                templateUrl: "./app/modulos/comum/templates/modal/" + nomeTemplate + ".html",
                controller: controller,
                controllerAs: controllerAs,
                backdrop: "static",
                size: size,
                resolve: {
                    dados: function () {
                        return dados;
                    }
                }
            });

            instanciaModal.result.then(function (dadosRetornoModalOK) {
                if (acaoOK) {
                    acaoOK(dadosRetornoModalOK);
                }
            }, function (dadosRetornoModalCancelar) {
                if (acaoCancelar) {
                    acaoCancelar(dadosRetornoModalCancelar);
                }
            });

            return instanciaModal;

        }
    }

    angular.module("apl-mobile-pj.comum").controller("modalController", modalController);

    modalController.$inject = [
        "$uibModalInstance",
        "dados"
    ];

    /**
     * @description Controller base da modal de exibição para as telas.
     */
    function modalController($uibModalInstance, dados) {

        var vm = this;

        vm.dados = dados;
        vm.titulo = dados.titulo;
        vm.mensagem = dados.mensagem;

        vm.acaoOK = function (dadosOK) {
            $uibModalInstance.close(dadosOK);
        };

        vm.acaoCancelar = function (dadosCancelar) {
            $uibModalInstance.dismiss(dadosCancelar);
        };

    }
})();
(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").factory("validapermissionamento", validapermissionamento);

    validapermissionamento.$inject = ["sfContexto"];

    /**
     * @description Diretiva criada para gerenciar o momento para fixar o cabeçalho de uma tabela ao topo da aplicação 
     */
    function validapermissionamento(sfContexto) {
        return {
            validacao: validacao
        };

        /**
         * @description Teste
         */
        function validacao(grupo, servico, nivel) {
            var permissoes = sfContexto.obterValorContextoTrabalho("permissionamento");
            var permitido = false;

            if (permissoes != undefined)
            {
                //permissao por nivel de acesso do usuario
                if (nivel != "")
                {
                    if (nivel == permissoes.TOKEN.ADLG_TS_USER_UNIF_M)
                    {
                        permitido = true;                        
                    }
                }
                //permissao por grupo de servico e servico
                else if (grupo != "" && servico != "") {
                    //verifica o grupo
                        for (var permissaoGrp in permissoes.GRUPO_SERVICOS) {
                            var grp = permissoes.GRUPO_SERVICOS[permissaoGrp];
                            if (grp.ADLG_TS_CD_GRP == grupo)
                            {
                                //verifica o servico
                                for (var permissaoSrv in grp.ADLG_EV_SUBGRUPOS) {                             
                                    var srv = grp.ADLG_EV_SUBGRUPOS[permissaoSrv];
                                    if (srv.ADLG_TS_CD_SVC == servico)
                                    {
                                        //possui a permissao 
                                        permitido = true;
                                        break;
                                    }
                                }
                                if (permitido){
                                    break;
                                }
                            }
                        }    
                } 
                //validaão de permissão não se aplica
                else 
                {
                    permitido = true;
                }
            }

            return permitido;
        }
    }

})();


(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").factory("tratarExcecao", tratarExcecao);

    tratarExcecao.$inject = ["sfNavegador", "$log", "modal", "sfAutenticador"];

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.comum.factories:tratarExcecao
     * @module apl-mobile-pj.comum.tratarExcecao
     * 
     * @description
     * Factory responsável acionar o tratamento de excecao
     */
    function tratarExcecao(sfNavegador, $log, modal, sfAutenticador) {
        return {
            tratarErro: tratarErro
        };

        /**
            * @ngdoc overview
            * @name apl-mobile-pj.comum.factories:tratarExcecao.tratarErro
            * @module apl-mobile-pj.comum.tratarExcecao.tratarErro
            * 
            * @description
            * Factory responsável acionar o tratamento de excecao 
         */
        function tratarErro(erro_) {
            $log.log("Erro não tratado - Obtido pela aplicação: " + erro_);

            modal.abrirModal(
                "Segurança - Erro obtido pela aplicação",
                erro_,
                "", iniciarFluxo);
        }

        /**
         * @description Método responsável por iniciar o fluxo principal.
         */
        function iniciarFluxo() {
            sfAutenticador.logoff().then(sucesso).catch(sucesso);

            /**
             * @description Método de sucesso para a saida da aplicação
             */
            function sucesso() {
                sfNavegador.iniciarFluxo("apl-mobile-pj-login");
            }
        }
    }
})();
(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").factory("utilitariosAplicacaoFactory", utilitariosAplicacao);

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.comum.factories:utilitariosAplicacao
     * @module apl-mobile-pj.comum.utilitariosAplicacao
     * 
     * @description
     * Factory responsável por preencher espacos a direita
     */
    function utilitariosAplicacao() {
        return {
            preencheEspacosADireita: preencheEspacosADireita
        };
    }
    /**
   * @ngdoc method
   * @name preencheEspacosADireita
   *
   * @methodOf  apl-mobile-pj.comum.factories:utilitariosAplicacao
   *  
   * @description
   * Método responsável por preencher espacos a direita.
   **/
    function preencheEspacosADireita(string_, len_) {
        if (string_ && len_) {
            if (!isNaN(len_)) {
                var pad = " ";
                for (var i = 0; i < len_; i++) {
                    pad += " ";
                }
                return (string_ + pad).slice(0, len_);
            }
            else {
                return string_;
            }
        }
        else {
            return string_;
        }
    }

})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name validarSenhaFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:validarSenhaFactory
    *
    * @description
    * Factory de conexão com API validarSenhaFactory
    **/
    angular.module("apl-mobile-pj.comum")
        .factory("validarSenhaFactory", validarSenhaFactory);

    validarSenhaFactory.$inject = ["sfConectorAPI"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarCotacoesService
    *
    * @methodOf apl-mobile-pj.extrato:validarSenhaFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function validarSenhaFactory(conectorAPI) {

        return {
            validarSenha: validarSenha
        };

        /**
        * @ngdoc method
        * @name listarCotacoesService
        *
        * @methodOf apl-mobile-pj.extrato:validarSenha
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function validarSenha(requisicao) {

            var param = {
                "VLSE_RC_SENHA_ATU": requisicao.VLSE_RC_SENHA_ATU,
                "VLSE_RC_SENHA_ALT": "",
                "VLSE_RC_TP_OPER": "1",
                "VLSE_RC_ORIG": "IPJ",
                "VLSE_RC_GR_SERV": "   ",
                "VLSE_RC_SERV": "000"
            };

            var req = {
                method: "POST",
                url: "validar-senha",
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();
angular.module("apl-mobile-pj.comum").filter("custdate", function () {
    return function (value, format) {
        if (!value) {
            return "";
        }

        if (!format) {
            return "";
        }

        var newValue = "";

        if (value != "99990101") {
            if (format == "dd/MM") {
                //20160101                
                newValue = value.substring(6, 8) + "/" + value.substring(4, 6);
            }
            else {
                //20160101
                newValue = value.substring(6, 8) + "/" + value.substring(4, 6) + "/" + value.substring(0, 4);
            }
        } else {
            newValue = "Indeterm.";
        }


        return newValue;
    };
});
angular.module("apl-mobile-pj.comum").filter("cut", function () {
    return function (value, max, tail) {
        if (!value) {
            return "";
        }

        max = parseInt(max, 10);
        if (!max) {
            return value;
        }
        
        if (value.length <= max) {
            return value;
        }

        value = value.substr(0, max);

        return value + (tail || "…");
    };
});
(function () {
    "use strict";

    /**
     * @description
     * Controller para a confirmação de senhas
     */
    angular.module("apl-mobile-pj.comum").controller("confirmacaoSenhaController", confirmacaoSenhaController);

    confirmacaoSenhaController.$inject = ["$uibModalInstance",
        "dados",
        "validarSenhaFactory",
        "interpretadorComunicacao",
        "sfToken",
        "sfContexto",
        "modal"];

    /**
     * @description controller de validação de senha
     */
    function confirmacaoSenhaController($uibModalInstance,
        dados,
        validarSenhaFactory,
        interpretadorComunicacao,
        sfToken,
        sfContexto,
        modal) {

        //TODO: Implementar a validação de senhas pelo componente da arquitetura.

        var vm = this;
        vm.dados = dados;
        vm.acaoCancelar = acaoCancelar;
        vm.confirmarSenhaToken = confirmarSenhaToken;
        vm.senha = "";
        vm.token = "";
        vm.exibeToken = true;
        var dadosLogin = "";
        var serialTokenDispositivo = "";
        var serialTokenDispositivoUsuario = "";

        verificarTipoToken();

        /**
        * @ngdoc overview
        * @name confirmarSenhaToken
        *
        * @memberOf confirmacaoSenhaController
        *
        * @description
        * Método disparado ao ocorrer a confirmação no modal
        **/
        function confirmarSenhaToken() {
            validarCampos();
        }

        /**
        * @ngdoc overview
        * @name acaoCancelar
        *
        * @memberOf confirmacaoSenhaController
        *
        * @description
        * Método disparado ao ocorrer o cancelamento na modal
        **/
        function acaoCancelar() {
            $uibModalInstance.dismiss(vm.dados);
        }

        /**
         * @description validarCampos
         */
        function validarCampos() {
            var mensagemModal = "";

            if (vm.senha == "") {
                mensagemModal = "senha não informada";
            }
            else if (vm.senha.lenght < 8) {
                mensagemModal = "senha deve conter 8 caracteres";
            }

            if (vm.exibeToken) {
                if (vm.token == "") {
                    mensagemModal = "token não informado";
                }
                else if (vm.token.lenght < 6) {
                    mensagemModal = "token deve conter 6 caracteres";
                }
            }

            if (mensagemModal != "") {
                modal.abrirModal(undefined,
                    mensagemModal);
            }
            else {
                transacaoValidarSenha();
            }
        }

        /**
         * @description transacaoValidarSenha
         */
        function transacaoValidarSenha() {
            var requisicao = {
                "VLSE_RC_SENHA_ATU": vm.senha
            };

            interpretadorComunicacao.interpretar(validarSenhaFactory.validarSenha(requisicao))
                .sucesso(sucesso)
                .erro(erro)
                .aviso(erro);

            /**
             * @description sucesso
             */
            function sucesso() {

                var novoRetorno = {
                    senha: vm.senha,
                    token: vm.token,
                    dados: vm.dados
                };

                $uibModalInstance.close(novoRetorno);
            }

            /**
             * @description erro
             */
            function erro(data) {
                modal.abrirModal(undefined,
                    data.statusProcessamento.message);
            }
        }

        /**
	    * @description verificarTipoToken
	    */
        function verificarTipoToken() {
            vm.exibeToken = true;
            serialTokenDispositivo = sfContexto.obterValorContextoTrabalho("tokenSerial");
            dadosLogin = sfContexto.obterValorContextoTrabalho("dadosLogin");

            var param = {
                "tipoDevice": "",
                "tipoPessoa": "PJ",
                "device": "",
                "shortname": dadosLogin.shortname,
                "userId": dadosLogin.username
            };

            interpretadorComunicacao.interpretar(sfToken.autenticacao.validarDispositivo(param))
                .sucesso(sucesso)
                .aviso(erro)
                .erro(erro);

            /**
            * @description verificarTipoToken sucesso
            */
            function sucesso(data) {
                serialTokenDispositivoUsuario = data.serialNumberMobile;

                sfToken.obterSequencia(false)
                    .then(sequenciaSucesso)
                    .catch(sequenciaErro);
                /**
                 * @description sucesso obter sequencia
                 */
                function sequenciaSucesso(data) {
                    vm.token = data.data.sequencia;

                    if (serialTokenDispositivo == serialTokenDispositivoUsuario) {
                        vm.exibeToken = false;
                    }
                }

                /**
                 * @description erro obter sequencia
                 */
                function sequenciaErro() {
                }
            }

            /**
            * @description verificarTipoToken erro
            */
            function erro(data) {
                modal.abrirModal(undefined,
                    data.statusProcessamento.message);

            }
        }
    }

})();
(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").controller("selecionarContaController", selecionarContaController);

    selecionarContaController.$inject = ["$uibModalInstance", "dados"]; 
    
    /**
     * @description Constroller de seleção de contas.
     */
    function selecionarContaController ($uibModalInstance, dados) {

        var vm = this;

        vm.dados = dados.lista;
        vm.titulo = dados.titulo;
        vm.mensagem = dados.mensagem;
        vm.selecionarConta = selecionarConta;
        vm.acaoOK = acaoOK;
        vm.acaoCancelar = acaoCancelar;
        vm.limparSelecao = limparSelecao;
        vm.selecionarPreferencial = selecionarPreferencial;
        // limparSelecao();
        // selecionarPreferencial();

        /**
        * @ngdoc overview
        * @name acaoOK
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método disparado ao ocorrer a confirmação no modal
        **/
        function acaoOK(dadosOK) {
            $uibModalInstance.close(dadosOK);
        }

        /**
        * @ngdoc overview
        * @name acaoCancelar
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método disparado ao ocorrer o cancelamento na modal
        **/
        function acaoCancelar(dadosCancelar) {
            $uibModalInstance.dismiss(dadosCancelar);
        }

        /**
        * @ngdoc overview
        * @name selecionarConta
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método que retorna a conta selecionada na modal para a controller principal
        **/
        function selecionarConta(conta, cnpj, nome) {
            limparSelecao();
            conta.selecionado = true;
            conta.cnpj = cnpj;
            conta.nome = nome;
            vm.acaoOK(conta);
        }

        /**
        * @ngdoc overview
        * @name limparSelecao
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método utilizado para limpar a flag de seleção de conta
        **/
        function limparSelecao() {
            angular.forEach(vm.dados, function (filial) {
                angular.forEach(filial.contas, function (conta) {
                    conta.selecionado = false;
                });
            });
        }

        /**
        * @ngdoc overview
        * @name selecionarPreferencial
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método utilizado para inicializar a tela com a conta selecionad previamente
        **/
        function selecionarPreferencial() {
            angular.forEach(vm.dados, function (filial) {
                angular.forEach(filial.contas, function (conta) {
                    if (conta.agencia == vm.dados.contaSelecionada.agencia
                        && conta.conta == vm.dados.contaSelecionada.numero) {
                        conta.selecionado = true;
                        filial.selecionado = true;
                    }
                });
            });
        }
    }


    angular.module("apl-mobile-pj.comum").filter("selecionarQuandoUnico", function () {
        return function (empresas, pesquisa) {

            var primeiraFilial;
            var haFilialSelecionada;

            if (angular.isUndefined(pesquisa)) {
                return empresas;
            }

            angular.forEach(empresas, function (filial) {
                angular.forEach(filial.contas, function (conta) {
                    if ((conta.agencia.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1
                        || conta.conta.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1
                        || filial.cnpj.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1
                        || filial.nome.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1)) {

                        if (angular.isUndefined(primeiraFilial)) {
                            primeiraFilial = filial;
                        }

                        if (filial.selecionado) {
                            haFilialSelecionada = true;
                        }

                    }
                });
            });

            if (!haFilialSelecionada
                && angular.isDefined(primeiraFilial)) {
                primeiraFilial.selecionado = true;
            }

            return empresas;
        };
    });

    angular.module("apl-mobile-pj.comum").filter("pesquisarContaSeVazio", function () {
        return function (contas, pesquisa, empresa) {
            var filtrados = [];

            if (angular.isUndefined(pesquisa)) {
                return contas;
            }

            angular.forEach(contas, function (conta) {
                if (conta.agencia.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1
                    || conta.conta.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1
                    || empresa.cnpj.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1
                    || empresa.nome.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1) {
                    filtrados.push(conta);
                }
            });

            return filtrados;
        };
    });

    angular.module("apl-mobile-pj.comum").filter("cnpj", function () {
        return function (entrada) {
            var resultado = "" + Array(14 - entrada.length + 1).join("0") + entrada;
            resultado = resultado.replace(/\D/g, "")
                .replace(/^(\d{2})(\d)/, "$1.$2")
                .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
                .replace(/\.(\d{3})(\d)/, ".$1/$2")
                .replace(/(\d{4})(\d)/, "$1-$2");

            return resultado;
        };
    });

})();
(function () {
    "use strict";

    /**
   * @ngdoc overview
   * @name apl-mobile-pj.extrato
   * 
   * @require sfNavegador, comum
   * 
   * @description
   * Controller responsável pela tratativa das ações a serem realizadas na tela situação dos pagamentos 
   */
    angular.module("apl-mobile-pj.comum")
        .controller("situacaoPagamentoController", situacaoPagamentoController);

    situacaoPagamentoController.$inject = ["sfNavegador",
        "sfContexto",
        "modal",
        "interpretadorComunicacao",
        "identificarComprovanteCompartilhadoFactory",
        "exibicaoComprovanteFactory"
    ];

    /**
    * @ngdoc overview
    * @name situacaoPagamentoController
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas na tela situação dos pagamentos 
    **/
    function situacaoPagamentoController(sfNavegador,
        sfContexto,
        modal,
        interpretadorComunicacao,
        identificarComprovanteCompartilhadoFactory,
        exibicaoComprovanteFactory
    ) {
        var vm = this;

        vm.iniciar = iniciar;
        vm.voltar = voltar;
        vm.visualizarDetalhes = visualizarDetalhes;
        vm.removeAlerta = removeAlerta;
        vm.mostrarAlerta = mostrarAlerta;
        vm.separarListasPagamentos = separarListasPagamentos;
        vm.voltarParaAutorizacao = voltarParaAutorizacao;
        vm.removerFiltro = removerFiltro;
        vm.limparPesquisa = limparPesquisa;
        vm.exibirPesquisa = exibirPesquisa;
        vm.abrirCompartilhamento = abrirCompartilhamento;
        //vm.pesquisaPagamentoSelecionado = pesquisaPagamentoSelecionado;


        /*
        * AUTORIZADO
        * PARCIALMENTE-AUTORIZADO
        * NAO-AUTORIZADO
        */
        vm.situacaoPagamento = null;
        vm.listaPagamentos = null;
        vm.situacaoNavegada = null;
        vm.listaDetalhesPagamento = null;
        vm.pagamentoSelecionado = null;
        vm.pagamentoDetalhado = null;

        vm.filtroPesquisa = "";
        vm.quantidadePagamentos = 0;
        vm.valorPagamentos = 0;

        vm.pesquisaVisivel = false;
        vm.exibirDetalhesAutorizados = false;
        vm.exibirDetalhesParcialmenteAutorizados = false;
        vm.exibirDetalhesNaoAutorizados = false;
        vm.exibirCabecalhoAutorizacao = true;

        var tipoAlerta = "";

        vm.alertas = [];
        vm.listaPagamentosAutorizados = [];
        vm.listaPagamentosParcialmenteAutorizados = [];
        vm.listaPagamentosNaoAutorizados = [];

        vm.iniciar();

        /**
        * @ngdoc overview
        * @name iniciar
        * 
        * @memberOf situacaoPagamentoController.js
        *
        * @description        
        * Método responsável por inicializar as variáveis da controller
        **/
        function iniciar() {

            // sfContexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos",{"EV_OCOR": [{"SITUACAO": "AUTORIZADO","QUANTIDADE": 6,"VALOR": 724500,"PAGAMENTOS": [{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "61602199019484","EV_COMPROM": "OUT123456000","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "AUTORIZADO","EV_MENS_OCOR": "OPERACAO REALIZADA COM SUCESSO","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00034721535805","EV_COMPROM": "OUT15048490","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000000123000","EV_SITUACAO": "AUTORIZADO","EV_MENS_OCOR": "OPERACAO REALIZADA COM SUCESSO","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT123465088","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "PAGAMENTO AUTORIZADO","EV_MENS_OCOR": "OPERACAO REALIZADA COM SUCESSO","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT1234567490","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "PAGAMENTO AUTORIZADO","EV_MENS_OCOR": "OPERACAO REALIZADA COM SUCESSO","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT1515654888","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "AUTORIZADO","EV_MENS_OCOR": "OPERACAO REALIZADA COM SUCESSO","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT1234567890","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "AUTORIZADO","EV_MENS_OCOR": "OPERACAO REALIZADA COM SUCESSO","EV_I_SUCESS": "S"}]},{"SITUACAO": "PARCIALMENTE AUTORIZADO","QUANTIDADE": 7,"VALOR": 156831,"PAGAMENTOS": [{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "61086336000103","EV_COMPROM": "DDATESTE","EV_DT_PAG": "20141010","EV_VLR_COMPROM": "00000000000093918","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00000740736809","EV_COMPROM": "OUTFSGSGH","EV_DT_PAG": "20141010","EV_VLR_COMPROM": "00000000000004100","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "02878230000183","EV_COMPROM": "BLQWERWER","EV_DT_PAG": "20141107","EV_VLR_COMPROM": "00000000000000456","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00000442272138","EV_COMPROM": "OUTT1011141","EV_DT_PAG": "20141110","EV_VLR_COMPROM": "00000000000045100","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "99999900000232","EV_COMPROM": "BLL0114122739","EV_DT_PAG": "20150114","EV_VLR_COMPROM": "00000000000006512","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "99999900000151","EV_COMPROM": "BLL0114120252","EV_DT_PAG": "20150114","EV_VLR_COMPROM": "00000000000006512","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "02558157000162","EV_COMPROM": "BLL0114120456","EV_DT_PAG": "20150114","EV_VLR_COMPROM": "00000000000000233","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"}]},{"SITUACAO": "NAO AUTORIZADO","QUANTIDADE": 10,"VALOR": 2100100,"PAGAMENTOS": [{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT123456407/","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000001260000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT123456789","EV_DT_PAG": "20151014","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00008521716842","EV_COMPROM": "OUT1015000","EV_DT_PAG": "20151014","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT1234156000","EV_DT_PAG": "20151015","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00013141244987","EV_COMPROM": "OUT12312312","EV_DT_PAG": "20151015","EV_VLR_COMPROM": "00000000000100000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT1230","EV_DT_PAG": "20151016","EV_VLR_COMPROM": "00000000000123000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT123011","EV_DT_PAG": "20151016","EV_VLR_COMPROM": "00000000000015000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00011808915895","EV_COMPROM": "OUT15600","EV_DT_PAG": "20151016","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00000891373888","EV_COMPROM": "BLQ567567","EV_DT_PAG": "20151105","EV_VLR_COMPROM": "00000000000001100","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00003635343692","EV_COMPROM": "OUT123789","EV_DT_PAG": "20151205","EV_VLR_COMPROM": "00000000000001000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"}]}],"statusProcessamento": {"mensagem": {"codigo": "","descricao": "PAGAMENTOS AUTORIZADOS","severidade": "00"}}});

            vm.listaPagamentos = sfContexto.obterValorContextoTrabalho("listaAutorizacaoPagamentos");
            vm.situacaoNavegada = sfContexto.obterValorContextoTrabalho("situacaoNavegada");
            vm.estadoAutorizacao = sfContexto.obterValorContextoTrabalho("estadoAutorizacao");
            
            verificaMensagem();
            vm.separarListasPagamentos();

            vm.visualizarDetalhes(vm.situacaoNavegada);
            vm.situacaoNavegada = null;
            sfContexto.definirValorContextoTrabalho("situacaoNavegada", "");
        }

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.comum
        *
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltar() {
            sfNavegador.voltar();
        }

        /**
        * @ngdoc method
        * @name voltarParaAutorizacao
        *
        * @methodOf apl-mobile-pj.comum
        *
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltarParaAutorizacao() {
            vm.exibirCabecalhoAutorizacao = true;
            vm.situacaoPagamento = null;
            vm.removerFiltro();
            sfNavegador.voltar();
        }

        /**
        * @ngdoc method
        * @name visualizarDetalhes
        *
        * @methodOf apl-mobile-pj.comum
        *
        * @description
        * Método responsável por navegar para detalhes de pagamentos.
        **/
        function visualizarDetalhes(situacao) {

            if (situacao != ""
                && angular.isDefined(vm.listaPagamentos)) {
                switch (situacao) {
                    case "AUTORIZADO":
                        vm.listaDetalhesPagamento = vm.listaPagamentosAutorizados;
                        vm.quantidadePagamentos = vm.listaPagamentos.EV_OCOR[0].QUANTIDADE;
                        vm.valorPagamentos = vm.listaPagamentos.EV_OCOR[0].VALOR;
                        break;
                    case "PARCIALMENTE AUTORIZADO":
                        vm.listaDetalhesPagamento = vm.listaPagamentosParcialmenteAutorizados;
                        vm.quantidadePagamentos = vm.listaPagamentos.EV_OCOR[1].QUANTIDADE;
                        vm.valorPagamentos = vm.listaPagamentos.EV_OCOR[1].VALOR;
                        break;
                    case "NAO AUTORIZADO":
                        vm.listaDetalhesPagamento = vm.listaPagamentosNaoAutorizados;
                        vm.quantidadePagamentos = vm.listaPagamentos.EV_OCOR[2].QUANTIDADE;
                        vm.valorPagamentos = vm.listaPagamentos.EV_OCOR[2].VALOR;
                        break;
                    default:
                        break;
                }
                vm.exibirCabecalhoAutorizacao = false;
                vm.situacaoPagamento = situacao;
                if (vm.situacaoNavegada == null || vm.situacaoNavegada == "") {
                    sfNavegador.navegar("exibir-pagamentos-por-situacao");
                }
            } else {
                vm.situacaoPagamento = null;
            }
        }

        /** 
        * @ngdoc method
        * @name verificaMensagem
        *
        * @methodOf apl-mobile-pj.comum
        *
        * @description
        * Método responsável por interpretar status de processamento das autorizações de pagamento.
        **/
        function verificaMensagem() {
            var estadoAutorizacao = sfContexto.obterValorContextoTrabalho("estadoAutorizacao");
            if (estadoAutorizacao != undefined && estadoAutorizacao != "") {
                tipoAlerta = estadoAutorizacao.estado;
                vm.mostrarAlerta(estadoAutorizacao.estado, "");
            }
        }

        /**
        * @ngdoc method
        * @name mostrarAlerta
        *  
        * @description
        * Método responsável por exibir o alerta de acordo com o retorno da comunicação
        **/
        function mostrarAlerta(tipoAlerta, textoAlerta) {
            var caminho = "./app/assets/img/Pendencias_60x60pt_Ocre.png";

            switch (tipoAlerta) {
                case "danger":
                    if (textoAlerta.trim() == "") {
                        textoAlerta = "PAGAMENTOS NÃO AUTORIZADOS";
                    }
                    caminho = "./app/assets/img/icone_atencao_erro.png";
                    break;
                case "warning":
                    if (textoAlerta.trim() == "") {
                        textoAlerta = "PAGAMENTOS PARCIALMENTE AUTORIZADOS";
                    }
                    caminho = "./app/assets/img/Pendencias_60x60pt_Ocre.png";
                    break;
                case "success":
                    if (textoAlerta.trim() == "") {
                        textoAlerta = "PAGAMENTOS AUTORIZADOS COM SUCESSO";
                    }
                    caminho = "./app/assets/img/icone_Mensagem_SUCESSO_60x60pt.png";
                    break;
                default:
                    return;
            }
            vm.alertas.push({ tipo: tipoAlerta, texto: textoAlerta, caminho: caminho });
        }

        /**
        * @ngdoc method
        * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeAlerta() {
            vm.alertas = [];
        }

        /**
        * @ngdoc method
        * @name separarListasPagamentos
        *  
        * @description
        * Método responsável por separar listas dos pagamentos por situação
        **/
        function separarListasPagamentos() {

            if (angular.isDefined(vm.listaPagamentos)) {
                if (tipoAlerta == "success") {
                    vm.listaPagamentosAutorizados = vm.listaPagamentos.EV_OCOR[0].PAGAMENTOS;
                    vm.listaPagamentosParcialmenteAutorizados = vm.listaPagamentos.EV_OCOR[1].PAGAMENTOS;
                    vm.listaPagamentosNaoAutorizados = vm.listaPagamentos.EV_OCOR[2].PAGAMENTOS;
                }
            }
        }

        /**
        * @ngdoc method
        * @name removerFiltro
        *  
        * @description
        * Método responsável por limpar o filtro
        **/
        function removerFiltro() {
            vm.pesquisaVisivel = false;
            vm.limparPesquisa();
        }

        /**
        * @ngdoc method
        * @name limparPesquisa
        *
        * @methodOf apl-mobile-pj.comum
        *  
        * @description
        * Método responsável por limpar o filtro de pesquisa
        **/
        function limparPesquisa() {
            vm.filtroPesquisa = "";
        }

        /**
        * @ngdoc method
        * @name exibirPesquisa
        *
        * @methodOf apl-mobile-pj.comum
        *  
        * @description
        * Método responsável por limpar o filtro de pesquisa
        **/
        function exibirPesquisa() {
            vm.pesquisaVisivel = true;
        }

        /**
        * @ngdoc overview
        * @ngdoc method
        * @name abrirCompartilhamento
        *
        * @description
        * Método responsável por abrir modal de compartilhamento
        **/
        function abrirCompartilhamento(pagamento) {
            vm.pagamentoSelecionado = pagamento;
            modal.abrirModal(undefined,
                undefined,
                "modalCompartilhamento",
                pesquisaPagamentoSelecionado);
        }


        /**
        * @ngdoc overview
        * @ngdoc method
        * @name pesquisaPagamentoSelecionado
        *
        * @description
        * Método responsável por consultar detalhes do comprovante do pagamento selecionado
        **/
        function pesquisaPagamentoSelecionado() {
            //sfContexto.definirValorContextoSessao("token",
                //"Agencia=00200,Conta=1636800,CodigoCanal=IPJ,Senha=XXXXXXXX,ValorOperacao=1,CodigoCliente=000000000,ShortName=VALISERE       ,UserId=VALISERE,BaseCGC=000000000,CentralAtendimento=N,TokenValidado=S");

            var dadosLogin = sfContexto.obterValorContextoTrabalho("dadosLogin");

            var param = {
                "PGGD_RC_QT_OCOR": "0001",
                "PGGD_RC_OCOR": [{
                    "PGGD_RC_AGENCIA": vm.pagamentoSelecionado.EV_AGENCIA,// "00200",
                    "PGGD_RC_CONTA": vm.pagamentoSelecionado.EV_CONTA,//"001636800",
                    "PGGD_RC_CGC_FORN": vm.pagamentoSelecionado.EV_CGC_CPF_FORN,//"3379",
                    "PGGD_RC_COMPR": vm.pagamentoSelecionado.EV_COMPROM//"OUT4587"
                }],
                "shortname": dadosLogin.shortname,
                "userId": dadosLogin.username
            };

            interpretadorComunicacao
                .interpretar(exibicaoComprovanteFactory
                    .exibirComprovante(param))
                .sucesso(sucesso)
                .aviso(erro)
                .erro(erro);

            /**
            * @ngdoc method
            * @name sucesso
            * 
            * @memberOf situacaoPagamentoController.js
            *
            * @description        
            * Método executado em caso de sucesso ao informar que o comprovante foi exibido
            **/
            function sucesso(data) {
                vm.pagamentoDetalhado = data.PGGD_EV_ITEM;
                sfContexto.definirValorContextoTrabalho("pagamentoDetalhadoFornecedor", vm.pagamentoDetalhado);
                sfContexto.definirValorContextoTrabalho("situacaoNavegada", "AUTORIZADO");
                marcarComprovanteExibido();
            }

            /**           
           * @ngdoc method
           * @name erro
           * 
           * @memberOf situacaoPagamentoController.js
           *
           * @description
           * Método executado em caso de erro ao informar que o comprovante foi exibido
           **/
            function erro() {
            }

        }


        /**
        * @ngdoc overview
        * @ngdoc method
        * @name marcarComprovanteExibido
        *
        * @description
        * Método responsável por informar que o comprovante foi exibido
        **/
        function marcarComprovanteExibido() {
            //TODO persistência shortname e UserId
            //sfContexto.definirValorContextoSessao("token",
            //"Agencia=00000,Conta=0000000,CodigoCanal=IPJ,Senha=XXXXXXXX,ValorOperacao=1,CodigoCliente=000000000,ShortName=VALISERE       ,UserId=VALISERE,BaseCGC=000000000,CentralAtendimento=N,TokenValidado=S");
            var dadosLogin = sfContexto.obterValorContextoTrabalho("dadosLogin");

            var param = {
                "credencial": {
                    "senha": ""
                },
                "PGIM_RC_QTOC": "0001",
                "PGIM_RC_OCOR": [{

                    "PGIM_RC_AGENCIA": vm.pagamentoSelecionado.EV_AGENCIA,//"00200",
                    "PGIM_RC_CONTA": vm.pagamentoSelecionado.EV_CONTA,//"002012834",
                    "PGIM_RC_CD_FORN": vm.pagamentoSelecionado.EV_CGC_CPF_FORN,//"00022389827870",
                    "PGIM_RC_COMPR": vm.pagamentoSelecionado.EV_COMPROM,//"OUT7556",
                    "PGIM_RC_VALOR": vm.pagamentoSelecionado.EV_VLR_COMPROM,//"00000000000115644",
                    "PGIM_RC_NM_CED": "TESTE                                   ",
                    "PGIM_RC_DT_PAG": vm.pagamentoSelecionado.EV_DT_PAG,//"20160712",
                    "PGIM_RC_TP_COMPR": "TED",
                    "PGIM_RC_ST_COMPR": vm.pagamentoSelecionado.EV_SITUACAO//"AUTORIZADO     "
                }
                ],
                "shortname": dadosLogin.shortname,
                "userId": dadosLogin.username
            };


            interpretadorComunicacao
                .interpretar(identificarComprovanteCompartilhadoFactory
                    .identificarComprovanteCompartilhado(param))
                .sucesso(identificarComprovanteCompartilhadoSucesso)
                .aviso(identificarComprovanteCompartilhadoSucesso)
                .erro(identificarComprovanteCompartilhadoSucesso);



            /**
            * @ngdoc method
            * @name identificarComprovanteCompartilhadoSucesso
            * 
            * @memberOf situacaoPagamentoController.js
            *
            * @description        
            * Método executado em caso de sucesso ao informar que o comprovante foi exibido
            **/
            function identificarComprovanteCompartilhadoSucesso(data) {
                if (parseInt(data.statusProcessamento.mensagem.severidade) == 0) {
                    sfNavegador.navegar("exibir-comprovante-fornecedor");
                }
            }
        }


    }


})();
angular.module("uib/template/accordion/accordion-group.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("uib/template/accordion/accordion-group.html",
    "<div class=\"panel\" ng-class=\"panelClass || 'panel-default'\">\n" +
    "  <div role=\"tab\" id=\"{{::headingId}}\" aria-selected=\"{{isOpen}}\" class=\"panel-heading\" ng-keypress=\"toggleOpen($event)\">\n" +
    "    <h3> \n" +
    "      <a role=\"button\" data-toggle=\"collapse\" href aria-expanded=\"{{isOpen}}\" aria-controls=\"{{::panelId}}\" tabindex=\"0\" class=\"accordion-toggle\" ng-click=\"toggleOpen()\" uib-accordion-transclude=\"heading\"><span uib-accordion-header ng-class=\"{'text-muted': isDisabled}\">{{heading}}</span></a>\n" +
    "    </h3>\n" +
    "  </div>\n" +
    "  <div id=\"{{::panelId}}\" aria-labelledby=\"{{::headingId}}\" aria-hidden=\"{{!isOpen}}\" role=\"tabpanel\" class=\"panel-collapse collapse\" uib-collapse=\"!isOpen\">\n" +
    "    <div class=\"container-fluid\" ng-transclude></div>\n" +
    "  </div>\n" +
    "</div>\n" +
    "");
}]);

// angular.module("uib/template/accordion/accordion-group.html", []).run(["$templateCache", function($templateCache) {
//   $templateCache.put("uib/template/accordion/accordion-group.html",
//      "<table name=\"Template1\" class=\"panel\" ng-class=\"panelClass || 'panel-default'\">\n" +
   
//     "  <thead role=\"tab\" id=\"{{::headingId}}\" aria-selected=\"{{isOpen}}\" class=\"panel-heading\" ng-keypress=\"toggleOpen($event)\">\n" +
//     // "    <thead> \n" +
//     "      <tr role=\"button\" data-toggle=\"collapse\" href aria-expanded=\"{{isOpen}}\" aria-controls=\"{{::panelId}}\" tabindex=\"0\" class=\"accordion-toggle\" ng-click=\"toggleOpen()\" uib-accordion-transclude=\"heading\"><th uib-accordion-header ng-class=\"{'text-muted': isDisabled}\">{{heading}}</th></tr>\n" +
//     "    </thead>\n" +


//       "  <tbody id=\"{{::panelId}}\" aria-labelledby=\"{{::headingId}}\" aria-hidden=\"{{!isOpen}}\" role=\"tabpanel\" class=\"panel-collapse collapse container-fluid\" uib-collapse=\"!isOpen\" ng-transclude>\n" +
//       // "    <tr class=\"container-fluid\" ng-transclude></tr>\n" +
//       "  </tbody>\n" +
//     "  </table>\n" +
//     // "</div>\n" +
//     "");
// }]);
 
angular.module("uib/template/accordion/accordion.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("uib/template/accordion/accordion.html",
    "<div role=\"tablist\" class=\"panel-group\" ng-transclude></div>");
}]);

angular.module("uib/template/accordion/accordion-group.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("uib/template/accordion/accordion-group.html",
    "<div class=\"panel\" ng-class=\"panelClass || 'panel-default'\">\n" +
    "  <div role=\"tab\" id=\"{{::headingId}}\" aria-selected=\"{{isOpen}}\" class=\"panel-heading\" ng-keypress=\"toggleOpen($event)\">\n" +
    "    <h3> \n" +
    "      <a role=\"button\" data-toggle=\"collapse\" href aria-expanded=\"{{isOpen}}\" aria-controls=\"{{::panelId}}\" tabindex=\"0\" class=\"accordion-toggle\" ng-click=\"toggleOpen()\" uib-accordion-transclude=\"heading\"><span uib-accordion-header ng-class=\"{'text-muted': isDisabled}\">{{heading}}</span></a>\n" +
    "    </h3>\n" +
    "  </div>\n" +
    "  <div id=\"{{::panelId}}\" aria-labelledby=\"{{::headingId}}\" aria-hidden=\"{{!isOpen}}\" role=\"tabpanel\" class=\"panel-collapse collapse\" uib-collapse=\"!isOpen\">\n" +
    "    <div class=\"container-fluid\" ng-transclude></div>\n" +
    "  </div>\n" +
    "</div>\n" +
    "");
}]);

// angular.module("uib/template/accordion/accordion-group.html", []).run(["$templateCache", function($templateCache) {
//   $templateCache.put("uib/template/accordion/accordion-group.html",
//      "<table name=\"Template2\" class=\"panel\" ng-class=\"panelClass || 'panel-default'\">\n" +
   
//     "  <thead role=\"tab\" id=\"{{::headingId}}\" aria-selected=\"{{isOpen}}\" class=\"panel-heading\" ng-keypress=\"toggleOpen($event)\">\n" +
//     // "    <thead> \n" +
//     "      <tr role=\"button\" data-toggle=\"collapse\" href aria-expanded=\"{{isOpen}}\" aria-controls=\"{{::panelId}}\" tabindex=\"0\" class=\"accordion-toggle\" ng-click=\"toggleOpen()\" uib-accordion-transclude=\"heading\"><th uib-accordion-header ng-class=\"{'text-muted': isDisabled}\">{{heading}}</th></tr>\n" +
//     "    </thead>\n" +


//       "  <tbody id=\"{{::panelId}}\" aria-labelledby=\"{{::headingId}}\" aria-hidden=\"{{!isOpen}}\" role=\"tabpanel\" class=\"panel-collapse collapse container-fluid\" uib-collapse=\"!isOpen\" ng-transclude>\n" +
//       // "    <tr class=\"container-fluid\" ng-transclude></tr>\n" +
//       "  </tbody>\n" +
//     "  </table>\n" +
//     // "</div>\n" +
//     "");
// }]);
 