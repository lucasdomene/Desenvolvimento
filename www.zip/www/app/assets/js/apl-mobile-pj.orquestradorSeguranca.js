/**
* @ngdoc overview
* @name apl-mobile-pj.orquestradorSeguranca
*
* @require apl-mobile-pj.comum
*
* @description
* DescricaoComentario
**/
angular.module("apl-mobile-pj.orquestradorSeguranca", [])
    .config(orquestradorSegurancaModulo);

orquestradorSegurancaModulo.$inject = ["sfNavegadorProvider"];

/**
* @ngdoc method
* @name apl-mobile-pj.orquestradorSeguranca
*
* @param {provider} navegadorProvider instancia do navegadorProvider
*
* @description
* metodo responsavel por inicar o modulo.
**/
function orquestradorSegurancaModulo(sfNavegadorProvider) {
   sfNavegadorProvider.adicionarFluxoNavegacao(
        sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-orquestrador-seguranca")
            .adicionarEstado("orquestrar", {
                template: "<div></div>",
                controller: "orquestradorSegurancaController as osCtrl"
            }, [
                {
                    acao: "home",
                    fluxo: "apl-mobile-pj-home"
                },
                {
                    acao: "gestao-maquinas",
                    fluxo: "apl-mobile-pj-seguranca"
                },
                {
                    acao: "alterar-senha",
                    fluxo: "apl-mobile-pj-alterar-senha"
                }
            ])
            .definirEstadoInicial("orquestrar")
    );
}
(function () {
    "use strict";
    /**
    * @ngdoc controller
    * @name apl-mobile-pj.orquestradorSeguranca:orquestradorSegurancaController
    *
    * @requires
    *
    * @description
    * DescricaoComentario
    **/
    angular.module("apl-mobile-pj.orquestradorSeguranca")
        .controller("orquestradorSegurancaController", orquestradorSegurancaController);

    orquestradorSegurancaController.$inject = ["sfNavegador", "sfContexto", "validapermissionamento"];

    /**
    * @ngdoc method
    * @name orquestradorSegurancaController
    *
    * @requires
    *
    * @methodOf apl-mobile-pj.orquestradorSeguranca:orquestradorSegurancaController
    *
    * @description
    * Contem as definições do controller.
    **/
    function orquestradorSegurancaController(sfNavegador, sfContexto, validapermissionamento) {
        iniciar();

        /*Funções*/

        /**
        * @ngdoc method
        * @name iniciar
        *
        * @methodOf apl-mobile-pj.orquestradorSeguranca:orquestradorSegurancaController
        *
        * @description
        * Método responsável por carregar o estado orquestradorSeguranca dos elementos da view.
        **/
        function iniciar() {
            var permissao = validapermissionamento.validacao("", "", "MASTER");
            if (permissao) {
                sfNavegador.navegar("gestao-maquinas");
            }
            else {
                sfContexto.definirValorContextoTrabalho("usuarioLogadoSemPermissaoMaquinas", true);                
                sfNavegador.navegar("alterar-senha");
            }

        }
    }
})();