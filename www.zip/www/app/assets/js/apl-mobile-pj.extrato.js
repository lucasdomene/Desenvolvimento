(function () {

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.extrato
     * 
     * @require ui.bootstrap, ngAnimate
     * 
     * @description
     * Módulo que define os fluxos de navegacao pelos controles de cadastro e liberação de dispositivos.
     **/
    angular.module("apl-mobile-pj.extrato", ["ui.bootstrap", "ngAnimate", "rzModule"])
        .config(extratoModule)
        .run(["sfTradutor", function (tradutor) {
            tradutor.adicionarDicionarios(["app/modulos/extrato/extratoMovimentacao/internacionalizacao"]);
        }]);


    extratoModule.$inject = ["sfNavegadorProvider"];

    /**
    * @ngdoc overview
    * @name extratoModule
    * 
    * @description
    * Navegação do módulo extratoModule.
    **/
    function extratoModule(sfNavegadorProvider) {
        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-extrato")
                .adicionarEstado("extrato", {
                    templateUrl: "./app/modulos/extrato/extratoMovimentacao/views/extrato.html",
                    controller: "extratoMovimentacaoController as exmovCtrl",
                    abstract: true
                })
                .adicionarEstado("extrato.extrato-Movimentacao", {
                    templateUrl: "./app/modulos/extrato/extratoMovimentacao/views/extratoMovimentacao.html",
                    parent: "extrato"
                })
                .definirEstadoInicial("extrato.extrato-Movimentacao")
        );
    }
})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarContasFactoryFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:listarContasFactoryFactory
    *
    * @description
    * Factory de conexão com API listarContasFactory
    **/
    angular.module("apl-mobile-pj.extrato")
        .factory("listarContasFactory", listarContasFactory);

    listarContasFactory.$inject = ["sfConectorAPI"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarCotacoesService
    *
    * @methodOf apl-mobile-pj.extrato:listarContasFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarContasFactory(conectorAPI) {

        return {
            listarContas: listarContas
        };

        /**
        * @ngdoc method
        * @name listarCotacoesService
        *
        * @methodOf apl-mobile-pj.extrato:listarContas
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarContas() {
            var req = {
                method: "POST",
                url: "listar-contas",
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarLancamentosFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:listarLancamentosFactory
    *
    * @description
    * Factory de conexão com API listarLancamentosFactory
    **/
    angular.module("apl-mobile-pj.extrato")
        .factory("listarLancamentosFactory", listarLancamentosFactory);

    listarLancamentosFactory.$inject = ["sfConectorAPI"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarLancamentosFactory
    *
    * @methodOf apl-mobile-pj.extrato:listarLancamentosFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarLancamentosFactory(conectorAPI) {

        return {
            listarLancamentos: listarLancamentos
        };

        /**
        * @ngdoc method
        * @name listarLancamentos
        *
        * @methodOf apl-mobile-pj.extrato:listarLancamentos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarLancamentos(param) {
            var req = {
                method: "POST",
                url: "listar-lancamentos",
                data: param,
                dataType: "json"
            };
            
            return conectorAPI.executar(req, true);
        }
    }

})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarSaldoFactoryFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:listarSaldoFactoryFactory
    *
    * @description
    * Factory de conexão com API listarSaldoFactory
    **/
    angular.module("apl-mobile-pj.extrato")
        .factory("listarSaldoFactory", listarSaldoFactory);

    listarSaldoFactory.$inject = ["sfConectorAPI"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarCotacoesService
    *
    * @methodOf apl-mobile-pj.extrato:listarSaldoFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarSaldoFactory(conectorAPI) {

        return {
            listarSaldo: listarSaldo
        };

        /**
        * @ngdoc method
        * @name listarCotacoesService
        *
        * @methodOf apl-mobile-pj.extrato:listarSaldo
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarSaldo(agencia, conta, baseCGC, shortname, username) {
            var param = {
                "baseCGC": baseCGC,
                "agencia": agencia,
                "contaCorrente": conta,
                "shortname": shortname,
                "userId": username
             };

            var req = {
                method: "POST",
                url: "listar-saldo",
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();
(function () {
    "use strict";

    /**
    * @ngdoc overview
    * @name apl-mobile-pj.extrato
    *  
    * @require navegador
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Extrato de Movimentações.
    **/
    angular.module("apl-mobile-pj.extrato")
        .controller("extratoMovimentacaoController", extratoMovimentacaoController);

    extratoMovimentacaoController.$inject = ["sfNavegador",
        "sfContexto",
        "listarSaldoFactory",
        "listarLancamentosFactory",
        "listarContasFactory",
        "sfMemorizador",
        "modal",
        "sfUtilitarios",
        "$filter",
        "interpretadorComunicacao"
    ];

    /**
    * @ngdoc overview
    * @name extratoMovimentacaoController
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Extrato de Movimentações.
    **/
    function extratoMovimentacaoController(navegador,
        contexto,
        listarSaldoFactory,
        listarLancamentosFactory,
        listarContasFactory,
        sfMemorizador,
        modal,
        utilitarios,
        $filter,
        interpretadorComunicacao
    ) {

        var vm = this;

        vm.title = "Extrato de Movimentações";
        vm.iniciar = iniciar;
        vm.voltar = voltar;
        vm.exibir = exibir;
        vm.ocultar = ocultar;

        vm.removeFiltroData = removeFiltroData;

        vm.alertas = [];

        vm.carregarUltimosLancamentos = carregarUltimosLancamentos;
        vm.carregarLancamentosFuturos = carregarLancamentosFuturos;

        vm.atualizarOpcaoExibicaoSaldo = atualizarOpcaoExibicaoSaldo;
        vm.abrirModalSelecaoConta = abrirModalSelecaoConta;

        vm.atualizarContaEmUso = atualizarContaEmUso;

        vm.exibePesquisa = false;
        vm.exibirPesquisa = exibirPesquisa;

        vm.mostrarLupaUltimosLancamentos = false;
        vm.mostrarLupaLancamentosFuturos = false;

        vm.conta = {
            visivel: true,
            exibir: exibir,
            ocultar: ocultar,
            cnpj: null,
            agencia: null,
            numero: null,
            dv: null,
            lista: null,
            erroNaTransacao: false
        };

        vm.contaPreferencial = {
            agencia: null,
            numero: null,
            cnpj: null,
            dv: null
        };

        vm.saldo = {
            visivel: true,
            exibir: exibirSaldo,
            ocultar: ocultarSaldo,
            opcaoInicialExibicao: false,
            erroNaTransacao: false,
            valorSaldoMaisLimiteDisponivel: null,
            valorSaldo: null,
            valorLimiteDisponivel: null,
            valorSaldoBloqueado: null
        };

        vm.abaLancamentos = {
            visivel: true,
            exibir: exibir,
            ocultar: ocultar,
            valor: 1    //1 - Últimos Lançamentos | 2 - Lançamentos futuros
        };

        vm.ultimosLancamentos = {
            valorFiltro: "",
            ordemListaDesc: false,
            visivel: true,
            exibir: exibir,
            ocultar: ocultar,
            erroNaTransacao: false,
            slider: {
                visivel: true,
                exibir: exibir,
                ocultar: ocultar,
                valor: 0    // 0 | 7 | 15 | 30
            },
            calendario: {
                visivel: true,
                exibir: exibir,
                ocultar: ocultar,
                de: null,
                ate: null
            },
            tipoLancamento: {
                visivel: true,
                exibir: exibir,
                ocultar: ocultar,
                filtro: {
                    INDICADOR_CRE_DEB: "",    //'' - Todos | C - Crédito | D - Débito
                    EXCC_EV_TIPO_LH: "",
                    EXCC_EV_DTMOT: "",
                    EXCC_EV_HISTO: "",
                    EXCC_EV_SALDO: "",
                    EXCC_EV_NMFAV: "",
                    EXCC_EV_VALOR: ""
                }
            },
            extrato: {
                visivel: true,
                exibir: exibir,
                ocultar: ocultar,
                cabecalho: {
                    visivel: true,
                    exibir: exibir,
                    ocultar: ocultar
                },
                anoMes: {
                    visivel: true,
                    exibir: exibir,
                    ocultar: ocultar
                },
                saldoDia: {
                    visivel: true,
                    exibir: exibir,
                    ocultar: ocultar
                }
            }
        };

        vm.lancamentosFuturos = {
            valorFiltro: "",
            ordemListaDesc: false,
            visivel: false,
            exibir: exibir,
            ocultar: ocultar,
            erroNaTransacao: false,
            extrato: {
                visivel: true,
                exibir: exibir,
                ocultar: ocultar,
                cabecalho: {
                    visivel: true,
                    exibir: exibir,
                    ocultar: ocultar
                }
            }
        };

        //variaveis utilizadas no filtra de datas
        var dtInicio, dtFim;
        var pickerDtMaximo, pickerDtMinimo;

        vm.selecionaDtInicio = selecionaDtInicio;
        vm.filtrarUltimosLancamentos = filtrarUltimosLancamentos;
        vm.carregaDatePicker = carregaDatePicker;

        vm.iniciar();


        /**
        * @ngdoc overview
        * @name iniciar
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método responsável por inicializar as variáveis da controller
        **/
        function iniciar() {

            var opcaoInicialExibicao = sfMemorizador.obter("extrato.saldo.opcaoInicialExibicao");

            if (opcaoInicialExibicao == true) {
                vm.saldo.opcaoInicialExibicao = true;
                vm.saldo.exibir();
            }
            else {
                vm.saldo.opcaoInicialExibicao = false;
                vm.saldo.ocultar();
            }

            carregarPreferencial();
            vm.conta.exibir();

            iniciaDatePicker();
            vm.dtpickerInicioAberto = false;
            vm.dtpickerFimAberto = false;

            iniciarSlider();

            if (vm.contaPreferencial.agencia != null
                && vm.contaPreferencial.numero != null) {
                transacaoSaldo();
            } else {
                transacaoConta();
            }
        }

        /**
        * @ngdoc method
        * @name iniciaDatePicker
        *
        * @description
        * Carrega os valores iniciais do datepicker
        **/
        function iniciaDatePicker() {
            pickerDtMaximo = new Date();
            pickerDtMinimo = new Date();

            pickerDtMinimo.setDate(pickerDtMinimo.getDate() - 30);

            vm.dtOptions = {
                minDate: pickerDtMinimo,
                maxDate: pickerDtMaximo,
                maxMode: "day",
                showWeeks: false
            };
        }

        /**
        * @ngdoc method
        * @name carregarSlider
        *
        * @description
        * Método responsável por preencher os valores default do slider
        **/
        function iniciarSlider() {
            vm.buscaCalendario = false;
            inicializaDatas();
            preencheOpcoesSlider();

            vm.sliderInicio = retornaContagemDias(dtInicio);
            vm.sliderFim = retornaContagemDias(dtFim);
        }

        /**
        * @ngdoc method
        * @name retornaContagemDias
        *
        * @param {Date} a data a ser subtraida da data atual
        *
        * @description
        * Retorna a diferença da data atual para a data recebida 
        **/
        function retornaContagemDias(data) {
            var dtAtual = new Date();
            dtAtual.setHours(0);
            dtAtual.setMinutes(0);
            dtAtual.setSeconds(0);
            dtAtual.setMilliseconds(0);

            data.setHours(0);
            data.setMinutes(0);
            data.setSeconds(0);
            data.setMilliseconds(0);

            var diferencaTempo = Math.abs(dtAtual.getTime() - data.getTime());
            var diferencaDias = (diferencaTempo / (1000 * 3600 * 24));
            return diferencaDias;
        }

        /**
        * @ngdoc method
        * @name preencheOpcoesSlider
        *
        * @description
        * Método responsável por preencher os dados de funcionamento do slider
        **/
        function preencheOpcoesSlider() {
            var passos = [0, 7, 15, 30];

            vm.sliderOptions = {
                noSwitching: true,
                totalDias: "", //7 dias
                showTicksValues: true,
                rightToLeft: true,
                stepsArray: passos.map(function (v) {
                    return v;
                }),
                onChange: function (sliderId, modelValue, highValue) {
                    if (highValue != modelValue) {
                        this.totalDias = (highValue - modelValue) + " dias";
                    } else {
                        this.totalDias = "";
                    }
                },
                onEnd: function (sliderId, modelValue, highValue) {
                    if (!vm.buscaCalendario) {

                        var filtro = gerarFiltroSlider(modelValue, highValue);

                        transacaoLancamentos(filtro);
                    }
                },
                translate: function (value, sliderId, label) {
                    if (label == "high" && this.lowValue == this.highValue) {
                        return "";
                    } else if (label != "tick-value") {
                        var data = new Date();
                        if (value === 0) {
                            return "Hoje";
                        }
                        return $filter("date")(data.setDate(data.getDate() - value), "dd/MM");
                    } else {
                        return value;
                    }
                }
            };
        }

        /**
         * @description Método responsável por gerar o filtro selecionado pelo slider.
         */
        function gerarFiltroSlider(modelValue, highValue) {
            var sliderDtInicio = new Date();
            sliderDtInicio.setHours(0);
            sliderDtInicio.setMinutes(0);
            sliderDtInicio.setSeconds(0);
            sliderDtInicio.setMilliseconds(0);

            var sliderDtFim = new Date();
            sliderDtFim.setHours(0);
            sliderDtFim.setMinutes(0);
            sliderDtFim.setSeconds(0);
            sliderDtFim.setMilliseconds(0);

            sliderDtInicio.setDate(sliderDtInicio.getDate() - highValue);
            sliderDtFim.setDate(sliderDtFim.getDate() - modelValue);

            var filtro = {
                dtInicio: sliderDtInicio,
                dtFim: sliderDtFim
            };

            return filtro;
        }

        /**
        * @ngdoc method
        * @name inicializaDatas
        *
        * @description
        * Método responsável por iniciar as datas utilizadas para filtro de lançamentos
        **/
        function inicializaDatas() {
            dtInicio = new Date();
            dtFim = new Date();
            dtFim.setDate(dtFim.getDate() - 1);
        }

        /**
         * Função responsável por exibir o campo de pesquisa na tela.
         */
        function exibirPesquisa() {
            vm.exibePesquisa = true;
        }

        /**
        * @ngdoc method
        * @name selecionaDtInicio
        *
        * @description
        * Preenche a data de inicio do filtro de data a partir da seleção do datepicker e exibe o datepicker
        * de data até        
        **/
        function selecionaDtInicio() {
            vm.dtOptions.minDate = vm.dtpickerInicio;
            vm.dtpickerFimAberto = true;
        }

        /**
        * @ngdoc method
        * @name filtrarUltimosLancamentos
        *
        * @description
        * Preencha a data de fim do filtro de data a partir da seleção do datepicker e realiza a consulta
        **/
        function filtrarUltimosLancamentos() {
            vm.buscaCalendario = true;

            vm.dtOptions.minDate = pickerDtMinimo;

            var filtro = {
                dtInicio: vm.dtpickerInicio,
                dtFim: vm.dtpickerFim
            };

            mostrarAlerta("info", $filter("date")(filtro.dtInicio, "dd/MM"), $filter("date")(filtro.dtFim, "dd/MM"));

            transacaoLancamentos(filtro);
        }

        /**
        * @ngdoc method
        * @name mostrarAlerta
        *  
        * @description
        * Método responsável por exibir o alerta de acordo com o retorno da comunicação
        **/
        function mostrarAlerta(tipoAlerta, dtInicio, dtFim) {
            vm.alertas.push({ tipo: tipoAlerta, dtInicio: dtInicio, dtFim: dtFim });
        }

        /**
         * @ngdoc method
         *  * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeFiltroData(executaTran) {
            vm.alertas = [];
            vm.buscaCalendario = false;

            vm.dtpickerInicio = "";
            vm.dtpickerFim = "";

            if (executaTran) {
                var filtro = gerarFiltroSlider(vm.sliderInicio, vm.sliderFim);
                transacaoLancamentos(filtro);
            }
        }

        /**
        * @ngdoc method
        * @name carregaDatePicker
        *
        * @description
        * Exibe o datepicker
        **/
        function carregaDatePicker() {
            removeFiltroData(false);
            iniciaDatePicker();

            vm.dtpickerInicioAberto = true;
        }

        /**
        * @ngdoc overview
        * @name carregarPreferencial
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método responsável por recupeara a conta preferencial e popular a conta exibida.
        **/
        function carregarPreferencial() {
            var contaPreferencial = sfMemorizador.obter("extrato.contaPreferencial");

            if (angular.isDefined(contaPreferencial) && contaPreferencial != null) {
                vm.conta.cnpj = contaPreferencial.cnpj;
                vm.conta.agencia = contaPreferencial.agencia;
                vm.conta.numero = contaPreferencial.numero;
                vm.contaPreferencial = contaPreferencial;
                atualizarConta();
            }
        }

        /**
        * @ngdoc atualizarConta
        * @name exibir
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método responsável por atualizar a conta em uso através da conta preferencial.
        **/
        function atualizarConta() {
            vm.conta.agencia = vm.contaPreferencial.agencia;
            vm.conta.numero = vm.contaPreferencial.numero;
            vm.conta.cnpj = vm.contaPreferencial.cnpj;
        }

        /**
        * @ngdoc overview
        * @name exibir
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método responsável por mostrar o controle atráves da variável 'visivel'.
        **/
        function exibir() {
            this.visivel = true;
        }

        /**
        * @ngdoc overview
        * @name ocultar
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método responsável por esconder o controle atráves da variável 'visivel'.
        **/
        function ocultar() {
            this.visivel = false;
        }

        /**
        * @ngdoc overview
        * @name exibirSaldo
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método responsável por mostrar o controle atráves da variável 'visivel' de saldo.
        **/
        function exibirSaldo() {
            this.visivel = true;
            atualizarOpcaoExibicaoSaldo();
        }

        /**
        * @ngdoc overview
        * @name ocultar
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método responsável por esconder o controle atráves da variável 'visivel' de saldo.
        **/
        function ocultarSaldo() {
            this.visivel = false;
            atualizarOpcaoExibicaoSaldo();
        }


        /**
        * @ngdoc overview
        * @name atualizarOpcaoExibicaoSaldo
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método que atualiza na persistência local a opção de exibição de saldo
        **/
        function atualizarOpcaoExibicaoSaldo() {
            sfMemorizador.definir("extrato.saldo.opcaoInicialExibicao", vm.saldo.visivel);
        }

        /**
        * @ngdoc overview
        * @name abrirModalSelecaoConta
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método incializa e abre a modal de seleção de contas do cliente
        **/
        function abrirModalSelecaoConta() {

            transacaoConta();
        }

        /**
        * @ngdoc overview
        * @name atualizarContaEmUso
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método que atualiza a conta preferencial com base na conta selecionada na modal
        **/
        function atualizarContaEmUso(conta) {
            if (angular.isUndefined(conta)
                || conta == null
                || isNaN(conta.agencia)
                || isNaN(conta.conta)) {
                return false;
            }

            vm.contaPreferencial.agencia = conta.agencia;
            vm.contaPreferencial.numero = conta.conta;
            vm.contaPreferencial.cnpj = conta.cnpj;

            sfMemorizador.definir("extrato.contaPreferencial", vm.contaPreferencial);
            atualizarConta();

            iniciaDatePicker();
            vm.dtpickerInicioAberto = false;
            vm.dtpickerFimAberto = false;

            iniciarSlider();

            transacaoSaldo();

            return false;
        }

        /**
        * @ngdoc overview
        * @name transacaoSaldo
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método que realiza a consulta de saldo
        **/
        function transacaoSaldo() {

            //Agencia=00200,Conta=1637491,CodigoCanal=IPJ,Senha=XXXXXXXX,ValorOperacao=1,CodigoCliente=000000000,ShortName=TESTE CEL2     ,UserId=TESTE CE,BaseCGC=068053086
            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            interpretadorComunicacao.interpretar(listarSaldoFactory.listarSaldo(utilitarios.zerosAEsquerda(vm.conta.agencia, 5), vm.conta.numero, utilitarios.zerosAEsquerda(vm.conta.cnpj, 9), dadosLogin.shortname, dadosLogin.username))
                .sucesso(sucessoTransacaoSaldo)
                .aviso(erroTransacaoSaldo)
                .erro(erroTransacaoSaldo);

            /**
            * @ngdoc overview
            * @name erroTransacaoSaldo
            * 
            * @memberOf extratoMovimentacaoController.js
            *
            * @description        
            * Método executado em caso de erro na consulta de saldo
            **/
            function erroTransacaoSaldo() {
                vm.conta.ocultar();
                vm.saldo.ocultar();
                vm.saldo.erroNaTransacao = true;
            }

            /**
            * @ngdoc overview
            * @name sucessoTransacaoSaldo
            * 
            * @memberOf extratoMovimentacaoController.js
            *
            * @description        
            * Método executado em caso de sucesso na consulta de saldo
            **/
            function sucessoTransacaoSaldo(data) {
                vm.conta.exibir();
                vm.abaLancamentos.exibir();
                vm.ultimosLancamentos.exibir();
                vm.ultimosLancamentos.slider.exibir();
                vm.ultimosLancamentos.slider.valor = 0;
                vm.ultimosLancamentos.calendario.exibir();
                vm.ultimosLancamentos.tipoLancamento.exibir();
                vm.ultimosLancamentos.extrato.exibir();
                vm.ultimosLancamentos.extrato.cabecalho.exibir();
                vm.ultimosLancamentos.extrato.anoMes.exibir();
                vm.ultimosLancamentos.extrato.saldoDia.exibir();
                vm.saldo.erroNaTransacao = false;

                vm.saldo.valorSaldoMaisLimiteDisponivel = data.SLDG_EV_LIMITETOTAL;
                vm.saldo.valorSaldo = data.SLDG_EV_SPAR;
                vm.saldo.valorLimiteDisponivel = data.SLDG_EV_SLIM;
                vm.saldo.valorSaldoBloqueado = data.SLDG_EV_SBLO;

                var filtro = {
                    dtInicio: dtFim,
                    dtFim: dtInicio
                };

                transacaoLancamentos(filtro);
            }

            //TODO: Remover MOCK
            // var data = { "SLDG_EV_SIBLO": "+", "SLDG_EV_SBLO": 0, "SLDG_EV_SIPAR": "+", "SLDG_EV_SPAR": 500000, "SLDG_EV_SIREA": "+", "SLDG_EV_SREA": 0, "SLDG_EV_SILIM": "+", "SLDG_EV_SLIM": 30750000, "SLDG_EV_SILSQ": "+", "SLDG_EV_SLSQ": 0, "SLDG_EV_SIMDIA": "+", "SLDG_EV_MDIA": 572181, "SLDG_EV_CDAT": 20110803, "SLDG_EV_FLB0": 0, "SLDG_EV_SCOB0": "+", "SLDG_EV_COB0": "00000000000000000", "SLDG_EV_FLB1": 0, "SLDG_EV_SICOB1": "+", "SLDG_EV_COB1": "00000000000000000", "SLDG_EV_MENS": "", "SLDG_EV_DTLCH": "", "SLDG_EV_SIVLLES": "", "SLDG_EV_VLLES": "00000000000000000", "SLDG_EV_DTLES": "", "SLDG_EV_SIVLLFL": "", "SLDG_EV_VLLFL": "00000000000000000", "SLDG_EV_DTLFL": "", "SLDG_EV_ERR_AGE": "", "SLDG_EV_SIVLAGE": "", "SLDG_EV_VLAGE": "", "SLDG_EV_ERR_DEB": "", "SLDG_EV_SIVLDEB": "", "SLDG_EV_VLDEB": "", "SLDG_EV_SIVLPARC": "", "SLDG_EV_VLPARC": "", "SLDG_EV_DTPARC": "", "SLDG_EV_ERR_LIM": "", "SLDG_EV_SINCI": "+", "SLDG_EV_SLCI": "00000000000000000", "SLDG_EV_NMCI": "009101506", "SLDG_EV_OCOR": [{ "SLDG_EV_OC_PROD": "ALE", "SLDG_EV_OC_MODA": "GALILEO MM", "SLDG_EV_OC_TSPO": "", "SLDG_EV_OC_SIPRO": "+", "SLDG_EV_OC_SPRO": "00000000108763560", "SLDG_EV_OC_TPRO": "01", "SLDG_EV_OC_FLAP": "0", "SLDG_EV_OC_FEXT": "S", "SLDG_EV_OC_FCLI": "N" }, { "SLDG_EV_OC_PROD": "EXE", "SLDG_EV_OC_MODA": "EXECUTIVE RF", "SLDG_EV_OC_TSPO": "", "SLDG_EV_OC_SIPRO": "+", "SLDG_EV_OC_SPRO": "00000000025076925", "SLDG_EV_OC_TPRO": "01", "SLDG_EV_OC_FLAP": "0", "SLDG_EV_OC_FEXT": "S", "SLDG_EV_OC_FCLI": "N" }, { "SLDG_EV_OC_PROD": "SSP", "SLDG_EV_OC_MODA": "S&P MM", "SLDG_EV_OC_TSPO": "", "SLDG_EV_OC_SIPRO": "+", "SLDG_EV_OC_SPRO": "00000000076306461", "SLDG_EV_OC_TPRO": "01", "SLDG_EV_OC_FLAP": "0", "SLDG_EV_OC_FEXT": "S", "SLDG_EV_OC_FCLI": "N" }, { "SLDG_EV_OC_PROD": "", "SLDG_EV_OC_MODA": "TOTAL", "SLDG_EV_OC_TSPO": "", "SLDG_EV_OC_SIPRO": "+", "SLDG_EV_OC_SPRO": "00000000210146946", "SLDG_EV_OC_TPRO": "00", "SLDG_EV_OC_FLAP": "0", "SLDG_EV_OC_FEXT": "N", "SLDG_EV_OC_FCLI": "" }], "statusProcessamento": { "mensagem": { "codigo": "0000", "descricao": "", "severidade": "00" } } };

            // sucessoTransacaoSaldo(data);
        }

        /**
        * @ngdoc overview
        * @name carregarUltimosLancamentos
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método que carrega atualiza a tela de últimos lançamentos e realiza transação se necessário
        **/
        function carregarUltimosLancamentos() {
            vm.ultimosLancamentos.exibir();
            vm.lancamentosFuturos.ocultar();
        }


        /**
        * @ngdoc overview
        * @name transacaoLancamentos
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método que realiza a consulta dos lançamentos
        **/
        function transacaoLancamentos(filtro) {
            //console.log(filtro);

            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var requisicao = {
                "EXCC_RC_DT_INI": filtro.dtInicio.toISOString().slice(0, 10).replace(/-/g, ""),
                "EXCC_RC_DT_FIM": filtro.dtFim.toISOString().slice(0, 10).replace(/-/g, ""),
                "EXCC_RC_QTOC": "0001",
                "EXCC_RC_OCOR": [
                    {
                        "EXCC_RC_CNPJ": vm.conta.cnpj,
                        "EXCC_RC_AG": vm.conta.agencia,
                        "EXCC_RC_CC": vm.conta.numero
                    }
                ],

                "baseCGC": utilitarios.zerosAEsquerda(vm.conta.cnpj, 9),
                "agencia": utilitarios.zerosAEsquerda(vm.conta.agencia, 5),
                "contaCorrente": vm.conta.numero,
                "shortname": dadosLogin.shortname,
                "userId": dadosLogin.username
            };

            interpretadorComunicacao.interpretar(listarLancamentosFactory.listarLancamentos(requisicao))
                .sucesso(sucessoTransacaoLancamentos)
                .aviso(erroTransacaoLancamentos)
                .erro(erroTransacaoLancamentos);


            /**
            * @ngdoc overview
            * @name erroTransacaoLancamentos
            * 
            * @memberOf extratoMovimentacaoController.js
            *
            * @description        
            * Método executado em caso de erro na consulta dos últimos lançamentos
            **/
            function erroTransacaoLancamentos(data) {
                vm.conta.exibir();
                vm.saldo.exibir();
                vm.abaLancamentos.valor = 1;
                vm.abaLancamentos.exibir();
                vm.ultimosLancamentos.ocultar();
                vm.ultimosLancamentos.slider.ocultar();
                vm.ultimosLancamentos.calendario.ocultar();
                vm.ultimosLancamentos.tipoLancamento.ocultar();
                vm.ultimosLancamentos.extrato.cabecalho.ocultar();
                vm.ultimosLancamentos.extrato.anoMes.ocultar();
                vm.ultimosLancamentos.extrato.saldoDia.ocultar();
                vm.ultimosLancamentos.extrato.ocultar();
                vm.ultimosLancamentos.erroNaTransacao = true;
                erroTransacaoLancamentosFuturos(data);

                vm.mostrarLupaUltimosLancamentos = false;
            }

            //             var data = {
            //     "EXCC_EV_DT_INI": 20160805,
            //     "EXCC_EV_DT_FIM": 20160812,
            //     "EXCC_EV_DET": {
            //         "ultimosLancamentos": [
            //             {
            //                 "EXCC_EV_TIPO": "0",
            //                 "EXCC_EV_TIPO_LH": "00",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "11/08",
            //                 "EXCC_EV_HISTO": "SALDO INICIAL",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "11/08",
            //                 "EXCC_EV_HISTO": "SALDO DISP. CTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-5.000,00",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "11/08",
            //                 "EXCC_EV_HISTO": "SALDO DISP. C/ LIMITE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "302.500,00",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             }
            //         ],
            //         "lancamentosFuturos": [
            //             {
            //                 "EXCC_EV_TIPO": "0",
            //                 "EXCC_EV_TIPO_LH": "00",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "10/08",
            //                 "EXCC_EV_HISTO": "SALDO CONTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "11/08",
            //                 "EXCC_EV_HISTO": "SALDO INICIAL",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-90.434,02",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "11/08",
            //                 "EXCC_EV_HISTO": "SALDO DISP. CTA CORRENTE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "-5.000,00",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             },
            //             {
            //                 "INDICADOR_CRE_DEB": "C",
            //                 "EXCC_EV_TIPO": "1",
            //                 "EXCC_EV_TIPO_LH": "2",
            //                 "EXCC_EV_DTMOT": "11/08",
            //                 "EXCC_EV_HISTO": "SALDO DISP. C/ LIMITE",
            //                 "EXCC_EV_NRDOC": 0,
            //                 "EXCC_EV_VALOR": "0,00",
            //                 "EXCC_EV_SALDO": "302.500,00",
            //                 "EXCC_EV_NMFAV": "",
            //                 "EXCC_EV_CGC": ""
            //             }
            //         ]
            //     },
            //     "statusProcessamento": {
            //         "mensagem": {
            //             "codigo": "0000",
            //             "descricao": "",
            //             "severidade": "00"
            //         }
            //     }
            // };

            // sucessoTransacaoLancamentos(data);

            /**
            * @ngdoc overview
            * @name sucessoTransacaoLancamentos
            * 
            * @memberOf extratoMovimentacaoController.js
            *
            * @description        
            * Método executado em caso de sucesso na consulta dos últimos lançamentos
            **/
            function sucessoTransacaoLancamentos(data) {
                vm.ultimosLancamentos.lista = data.EXCC_EV_DET.ultimosLancamentos;
                sucessoTransacaoLancamentosFuturos(data);

                vm.ultimosLancamentos.ordemListaDesc = true;

                if (vm.ultimosLancamentos.lista != undefined && vm.ultimosLancamentos.lista != null && vm.ultimosLancamentos.lista.length > 0) {
                    vm.mostrarLupaUltimosLancamentos = true;
                } else {
                    erroTransacaoLancamentos(data);
                }
            }

            /**
            * @ngdoc overview
            * @name erroTransacaoLancamentosFuturos
            * 
            * @memberOf extratoMovimentacaoController.js
            *
            * @description        
            * Método executado em caso de erro na consulta dos lançamentos futuros
            **/
            function erroTransacaoLancamentosFuturos() {
                vm.lancamentosFuturos.extrato.ocultar();
                vm.lancamentosFuturos.extrato.cabecalho.ocultar();
                vm.lancamentosFuturos.erroNaTransacao = true;

                vm.mostrarLupaLancamentosFuturos = false;
            }

            /**
            * @ngdoc overview
            * @name sucessoTransacaoLancamentosFuturos
            * 
            * @memberOf extratoMovimentacaoController.js
            *
            * @description        
            * Método executado em caso de sucesso na consulta dos lançamentos futuros
            **/
            function sucessoTransacaoLancamentosFuturos(data) {
                vm.lancamentosFuturos.lista = data.EXCC_EV_DET.lancamentosFuturos;
                vm.lancamentosFuturos.erroNaTransacao = false;

                if (vm.lancamentosFuturos.lista != undefined && vm.lancamentosFuturos.lista != null && vm.lancamentosFuturos.lista.length > 0) {
                    vm.mostrarLupaLancamentosFuturos = true;
                } else {
                    erroTransacaoLancamentosFuturos();
                }
            }
        }

        /**
        * @ngdoc overview
        * @name carregarLancamentosFuturos
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método que carrega atualiza a tela de lançamentos futuros e realiza transação se necessário
        **/
        function carregarLancamentosFuturos() {
            vm.ultimosLancamentos.ocultar();
            vm.lancamentosFuturos.exibir();
        }

        /**
        * @ngdoc overview
        * @name transacaoConta
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método que realiza a consulta das contas vinculadas ao cliente
        **/
        function transacaoConta() {
            if (vm.conta.lista == null) {
                interpretadorComunicacao.interpretar(listarContasFactory.listarContas())
                    .sucesso(sucessoTransacaoConta)
                    .aviso(erroTransacaoConta)
                    .erro(erroTransacaoConta);

            } else {
                sucessoTransacaoConta(vm.conta.lista);
            }

            /**
            * @ngdoc overview
            * @name erroTransacaoConta
            * 
            * @memberOf extratoMovimentacaoController.js
            *
            * @description        
            * Método executado em caso de erro na consulta das contas do cliente
            **/
            function erroTransacaoConta() {
                vm.conta.erroNaTransacao = true;
            }

            /**
            * @ngdoc overview
            * @name sucessoTransacaoConta
            * 
            * @memberOf extratoMovimentacaoController.js
            *
            * @description        
            * Método executado em caso de sucesso na consulta das contas do cliente
            **/
            function sucessoTransacaoConta(data) {
                vm.conta.lista = data;

                vm.conta.exibir();
                vm.conta.erroNaTransacao = false;

                modal.abrirModal(undefined,
                    undefined,
                    "modalSelecaoConta",
                    atualizarContaEmUso,
                    undefined, {
                        "lista": data.lista,
                        "contaSelecionada": vm.contaPreferencial
                    },
                    "selecionarContaController",
                    "scCtrl");
            }

            //Agencia=00200,Conta=1637491,CodigoCanal=IPJ,Senha=XXXXXXXX,ValorOperacao=1,CodigoCliente=000000000,ShortName=TESTE CEL2     ,UserId=TESTE CE,BaseCGC=

            // var data = {
            //     "lista": [
            //         {
            //             "cnpj": "068053086",
            //             "nome": "TESTE XXXXXXXX",
            //             "tipoPessoa": "J",
            //             "contas": [{
            //                 "agencia": "00200",
            //                 "conta": "1637491",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009201410"
            //             }]
            //         },
            //         {
            //             "cnpj": "000690786",
            //             "nome": "UVIMZMXL WLFGL NZIJFVH ORHYLZ",
            //             "tipoPessoa": "F",
            //             "contas": [{
            //                 "agencia": "00200",
            //                 "conta": "001674043",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009107181"
            //             }]
            //         },
            //         {
            //             "cnpj": "001521585",
            //             "nome": "ILWSZ E SZMMZ GIZYZOSL G OGXZ",
            //             "tipoPessoa": "J",
            //             "contas": [{
            //                 "agencia": "00200",
            //                 "conta": "001675996",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009108209"
            //             }]
            //         },
            //         {
            //             "cnpj": "003281663",
            //             "nome": "YIRTSGLM VNKIVVMX V KZIG OGXZ",
            //             "tipoPessoa": "J",
            //             "contas": [{
            //                 "agencia": "09700",
            //                 "conta": "000156626",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009131171"
            //             }]
            //         },
            //         {
            //             "cnpj": "006599918",
            //             "nome": "OLGZIRL SVROYIFMM PIZFHV",
            //             "tipoPessoa": "F",
            //             "contas": [{
            //                 "agencia": "11500",
            //                 "conta": "000027638",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009207591"
            //             }]
            //         },
            //         {
            //             "cnpj": "012163378",
            //             "nome": "QZIRY YIRHLOZ XFZIGV ULTZWZ",
            //             "tipoPessoa": "F",
            //             "contas": [{
            //                 "agencia": "11500",
            //                 "conta": "000051172",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009220767"
            //             }]
            //         },
            //         {
            //             "cnpj": "033200056",
            //             "nome": "OLQZH IRZWSFVOL H Z",
            //             "tipoPessoa": "J",
            //             "contas": [{
            //                 "agencia": "11500",
            //                 "conta": "000008358",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009201088"
            //             }]
            //         },
            //         {
            //             "cnpj": "048112171",
            //             "nome": "WLN OFHGIVH HKLG WVMGVI OGXZ",
            //             "tipoPessoa": "J",
            //             "contas": [{
            //                 "agencia": "00200",
            //                 "conta": "001661464",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009103461"
            //             }]
            //         },
            //         {
            //             "cnpj": "048271128",
            //             "nome": "MVOHLM ZHWSVI",
            //             "tipoPessoa": "F",
            //             "contas": [{
            //                 "agencia": "00200",
            //                 "conta": "001670234",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009105587"
            //             }]
            //         },
            //         {
            //             "cnpj": "048435747",
            //             "nome": "R K O RMWLIK KZFORHGZ OGXZ",
            //             "tipoPessoa": "J",
            //             "contas": [{
            //                 "agencia": "09700",
            //                 "conta": "000118856",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009116406"
            //             }]
            //         },
            //         {
            //             "cnpj": "048770051",
            //             "nome": "NRIZWZGF ZFGL KLHGL OGXZ",
            //             "tipoPessoa": "J",
            //             "contas": [{
            //                 "agencia": "09700",
            //                 "conta": "000082932",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009109388"
            //             }]
            //         },
            //         {
            //             "cnpj": "049372154",
            //             "nome": "GZY WLMHG V VNK RNLY OGXZ",
            //             "tipoPessoa": "J",
            //             "contas": [{
            //                 "agencia": "09700",
            //                 "conta": "000166885",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009137438"
            //             }]
            //         },
            //         {
            //             "cnpj": "057484768",
            //             "nome": "EZORHVIV RMX V WLN OGXZ",
            //             "tipoPessoa": "J",
            //             "contas": [
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005005740",
            //                     "tipoConta": "02",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005232207",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005237381",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005242695",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005246704",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005247913",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005264532",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005270788",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005282301",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005292536",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 }
            //             ]
            //         },
            //         {
            //             "cnpj": "061100145",
            //             "nome": "RMXRZMZ HVTFILH H/Z",
            //             "tipoPessoa": "J",
            //             "contas": [{
            //                 "agencia": "00200",
            //                 "conta": "001672849",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009106605"
            //             }]
            //         },
            //         {
            //             "cnpj": "061558037",
            //             "nome": "OLIVIO GARANTIAS COMITE",
            //             "tipoPessoa": "J",
            //             "contas": [
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "001636800",
            //                     "tipoConta": "01",
            //                     "contaInvestimento": "009101476"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005028413",
            //                     "tipoConta": "02",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005031287",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005186931",
            //                     "tipoConta": "02",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005227521",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005231286",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005237021",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005247514",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005247611",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005262645",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005266993",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005269771",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005273884",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005278711",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005281372",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005289730",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "00200",
            //                     "conta": "005301331",
            //                     "tipoConta": "03",
            //                     "contaInvestimento": "000000000"
            //                 },
            //                 {
            //                     "agencia": "09700",
            //                     "conta": "005030230",
            //                     "tipoConta": "02",
            //                     "contaInvestimento": "000000000"
            //                 }
            //             ]
            //         },
            //         {
            //             "cnpj": "087122696",
            //             "nome": "ILMZOXL WLIIVZ NZIGRMH",
            //             "tipoPessoa": "F",
            //             "contas": [{
            //                 "agencia": "00200",
            //                 "conta": "001654344",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009102499"
            //             }]
            //         },
            //         {
            //             "cnpj": "116832728",
            //             "nome": "XZERX YFMWV",
            //             "tipoPessoa": "F",
            //             "contas": [{
            //                 "agencia": "11500",
            //                 "conta": "000051083",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009220678"
            //             }]
            //         },
            //         {
            //             "cnpj": "298152378",
            //             "nome": "ZXIRZMZ TRHVOV SVIGALT H OVNV",
            //             "tipoPessoa": "F",
            //             "contas": [{
            //                 "agencia": "11500",
            //                 "conta": "000050621",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009220384"
            //             }]
            //         },
            //         {
            //             "cnpj": "302723788",
            //             "nome": "EZMRZ OFWWRZ HVWWL NVIGA",
            //             "tipoPessoa": "F",
            //             "contas": [{
            //                 "agencia": "00200",
            //                 "conta": "001653925",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009102383"
            //             }]
            //         },
            //         {
            //             "cnpj": "367361128",
            //             "nome": "HVITRL IZNKRN",
            //             "tipoPessoa": "F",
            //             "contas": [{
            //                 "agencia": "00200",
            //                 "conta": "001667241",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009104785"
            //             }]
            //         },
            //         {
            //             "cnpj": "761434738",
            //             "nome": "QLZL ZOEVH XV WZIEZOSL",
            //             "tipoPessoa": "F",
            //             "contas": [{
            //                 "agencia": "00200",
            //                 "conta": "001636389",
            //                 "tipoConta": "01",
            //                 "contaInvestimento": "009101441"
            //             }]
            //         }
            //     ]
            // };

            // var data = {"lista":[{"cnpj":"000382468","nome":"WLOTZGV KZONLOREV RMX V WLN OG","tipoPessoa":"J","contas":[{"agencia":"11500","conta":"000010107","tipoConta":"01","contaInvestimento":"009201410"}]},{"cnpj":"000690786","nome":"UVIMZMXL WLFGL NZIJFVH ORHYLZ","tipoPessoa":"F","contas":[{"agencia":"00200","conta":"001674043","tipoConta":"01","contaInvestimento":"009107181"}]},{"cnpj":"001521585","nome":"ILWSZ E SZMMZ GIZYZOSL G OGXZ","tipoPessoa":"J","contas":[{"agencia":"00200","conta":"001675996","tipoConta":"01","contaInvestimento":"009108209"}]},{"cnpj":"003281663","nome":"YIRTSGLM VNKIVVMX V KZIG OGXZ","tipoPessoa":"J","contas":[{"agencia":"09700","conta":"000156626","tipoConta":"01","contaInvestimento":"009131171"}]},{"cnpj":"006599918","nome":"OLGZIRL SVROYIFMM PIZFHV","tipoPessoa":"F","contas":[{"agencia":"11500","conta":"000027638","tipoConta":"01","contaInvestimento":"009207591"}]},{"cnpj":"012163378","nome":"QZIRY YIRHLOZ XFZIGV ULTZWZ","tipoPessoa":"F","contas":[{"agencia":"11500","conta":"000051172","tipoConta":"01","contaInvestimento":"009220767"}]},{"cnpj":"033200056","nome":"OLQZH IRZWSFVOL H Z","tipoPessoa":"J","contas":[{"agencia":"11500","conta":"000008358","tipoConta":"01","contaInvestimento":"009201088"}]},{"cnpj":"048112171","nome":"WLN OFHGIVH HKLG WVMGVI OGXZ","tipoPessoa":"J","contas":[{"agencia":"00200","conta":"001661464","tipoConta":"01","contaInvestimento":"009103461"}]},{"cnpj":"048271128","nome":"MVOHLM ZHWSVI","tipoPessoa":"F","contas":[{"agencia":"00200","conta":"001670234","tipoConta":"01","contaInvestimento":"009105587"}]},{"cnpj":"048435747","nome":"R K O RMWLIK KZFORHGZ OGXZ","tipoPessoa":"J","contas":[{"agencia":"09700","conta":"000118856","tipoConta":"01","contaInvestimento":"009116406"}]},{"cnpj":"048770051","nome":"NRIZWZGF ZFGL KLHGL OGXZ","tipoPessoa":"J","contas":[{"agencia":"09700","conta":"000082932","tipoConta":"01","contaInvestimento":"009109388"}]},{"cnpj":"049372154","nome":"GZY WLMHG V VNK RNLY OGXZ","tipoPessoa":"J","contas":[{"agencia":"09700","conta":"000166885","tipoConta":"01","contaInvestimento":"009137438"}]},{"cnpj":"057484768","nome":"EZORHVIV RMX V WLN OGXZ","tipoPessoa":"J","contas":[{"agencia":"00200","conta":"005005740","tipoConta":"02","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005232207","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005237381","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005242695","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005246704","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005247913","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005264532","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005270788","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005282301","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005292536","tipoConta":"03","contaInvestimento":"000000000"}]},{"cnpj":"061100145","nome":"RMXRZMZ HVTFILH H/Z","tipoPessoa":"J","contas":[{"agencia":"00200","conta":"001672849","tipoConta":"01","contaInvestimento":"009106605"}]},{"cnpj":"061558037","nome":"OLIVIO GARANTIAS COMITE","tipoPessoa":"J","contas":[{"agencia":"00200","conta":"001636800","tipoConta":"01","contaInvestimento":"009101476"},{"agencia":"00200","conta":"005028413","tipoConta":"02","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005031287","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005186931","tipoConta":"02","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005227521","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005231286","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005237021","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005247514","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005247611","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005262645","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005266993","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005269771","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005273884","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005278711","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005281372","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005289730","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"00200","conta":"005301331","tipoConta":"03","contaInvestimento":"000000000"},{"agencia":"09700","conta":"005030230","tipoConta":"02","contaInvestimento":"000000000"}]},{"cnpj":"087122696","nome":"ILMZOXL WLIIVZ NZIGRMH","tipoPessoa":"F","contas":[{"agencia":"00200","conta":"001654344","tipoConta":"01","contaInvestimento":"009102499"}]},{"cnpj":"116832728","nome":"XZERX YFMWV","tipoPessoa":"F","contas":[{"agencia":"11500","conta":"000051083","tipoConta":"01","contaInvestimento":"009220678"}]},{"cnpj":"298152378","nome":"ZXIRZMZ TRHVOV SVIGALT H OVNV","tipoPessoa":"F","contas":[{"agencia":"11500","conta":"000050621","tipoConta":"01","contaInvestimento":"009220384"}]},{"cnpj":"367361128","nome":"HVITRL IZNKRN","tipoPessoa":"F","contas":[{"agencia":"00200","conta":"001667241","tipoConta":"01","contaInvestimento":"009104785"}]},{"cnpj":"761434738","nome":"QLZL ZOEVH XV WZIEZOSL","tipoPessoa":"F","contas":[{"agencia":"00200","conta":"001636389","tipoConta":"01","contaInvestimento":"009101441"}]}],"statusProcessamento":{"mensagem":{"codigo":"0000","descricao":"","severidade":"00"}}};

            // sucessoTransacaoConta(data);
        }

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.seguranca
        *
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltar() {
            navegador.voltar();
        }
    }
})();
angular.module("apl-mobile-pj.extrato").filter("filtroCamposTela", function () {
    return function (lista, filtro) {
        if (filtro == undefined || filtro == null || filtro == "") {
            return lista;
        }

        return lista.filter(function (item) {
            if (item.EXCC_EV_DTMOT == undefined ||
                item.EXCC_EV_HISTO == undefined ||
                item.EXCC_EV_NMFAV == undefined ||
                item.EXCC_EV_SALDO == undefined ||
                item.EXCC_EV_VALOR == undefined) {

                return false;
            } else {
                
                return item.EXCC_EV_DTMOT.toLowerCase().indexOf(filtro.toLowerCase()) > -1 ||
                    item.EXCC_EV_HISTO.toLowerCase().indexOf(filtro.toLowerCase()) > -1 ||
                    item.EXCC_EV_NMFAV.toLowerCase().indexOf(filtro.toLowerCase()) > -1 ||
                    item.EXCC_EV_SALDO.toLowerCase().indexOf(filtro.toLowerCase()) > -1 ||
                    item.EXCC_EV_VALOR.toLowerCase().indexOf(filtro.toLowerCase()) > -1;
            }
        });
    };
});