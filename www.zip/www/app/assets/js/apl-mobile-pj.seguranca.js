(function () {

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.seguranca
     * 
     * @require ui.bootstrap, ngAnimate
     * 
     * @description
     * Módulo que define os fluxos de navegacao pelos controles de cadastro e liberação de dispositivos.
     **/
    angular.module("apl-mobile-pj.seguranca", ["ui.bootstrap", "ngAnimate"])
        .config(segurancaModule)
        .run(["sfTradutor", function (tradutor) {
            tradutor.adicionarDicionarios(
                [
                    "app/modulos/seguranca/cadastroDispositivo/internacionalizacao",
                    "app/modulos/seguranca/gestaoMaquinas/internacionalizacao",
                    "app/modulos/seguranca/ativarToken/internacionalizacao"
                    
                ]
            );
        }]);

    segurancaModule.$inject = ["sfNavegadorProvider"];

    /**
    * @ngdoc overview
    * @name segurancaModule
    * 
    * @description
    * Navegação do módulo segurancaModule.
    **/
    function segurancaModule(sfNavegadorProvider) {
        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-seguranca")
                .adicionarEstado("segurancaMaquina", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/segurancaMaquina.html",
                    controller: "gestaoMaquinasController as gmCtrl",
                    abstract: true
                })

                .adicionarEstado("segurancaMaquina.gestao-maquinas", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/gestaoMaquinas.html",
                    parent: "segurancaMaquina"
                },
                [
                    {
                        acao: "liberar-maquinas",
                        estadoDestino: "segurancaMaquina.liberar.liberar-maquinas"
                    },
                    {
                        acao: "excluir-maquinas",
                        estadoDestino: "segurancaMaquina.excluir.excluir-maquinas"
                    }
                ])

                .adicionarEstado("segurancaMaquina.liberar", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/liberar.html",
                    parent: "segurancaMaquina",
                    abstract: true
                })

                .adicionarEstado("segurancaMaquina.liberar.liberar-maquinas", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/liberarMaquinas.html",
                    parent: "segurancaMaquina.liberar"
                },
                [
                    {
                        acao: "sucesso-validacao-senha",
                        estadoDestino: "segurancaMaquina.liberar.sucesso"
                    }
                ])

                .adicionarEstado("segurancaMaquina.liberar.sucesso", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/sucessoLiberacao.html",
                    parent: "segurancaMaquina.liberar"
                },
                [
                    {
                        acao: "voltar-inicio",
                        estadoDestino: "segurancaMaquina.gestao-maquinas"
                    }
                ])

                .adicionarEstado("segurancaMaquina.excluir", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/excluir.html",
                    parent: "segurancaMaquina",
                    abstract: true
                })

                .adicionarEstado("segurancaMaquina.excluir.excluir-maquinas", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/excluirMaquinas.html",
                    parent: "segurancaMaquina.excluir"
                },
                [
                    {
                        acao: "sucesso-validacao-senha",
                        estadoDestino: "segurancaMaquina.excluir.sucesso"
                    }
                ])

                .adicionarEstado("segurancaMaquina.excluir.sucesso", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/sucessoExclusao.html",
                    parent: "segurancaMaquina.excluir"
                },
                [
                    {
                        acao: "voltar-inicio",
                        estadoDestino: "segurancaMaquina.gestao-maquinas"
                    }
                ])

                .definirEstadoInicial("segurancaMaquina.gestao-maquinas")
        );

        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-novo-dispositivo")
                .adicionarEstado("novo-dispositivo", {
                    templateUrl: "./app/modulos/seguranca/cadastroDispositivo/views/cabecalho.html",
                    controller: "cadastroDispositivoController as cdCtrl",
                    abstract: true
                })

                .adicionarEstado("novo-dispositivo.novo-acesso", {
                    templateUrl: "./app/modulos/seguranca/cadastroDispositivo/views/novoAcesso.html",
                    parent: "novo-dispositivo"
                },
                [
                    {
                        acao: "cadastro",
                        estadoDestino: "novo-dispositivo.cadastro"
                    }
                ])

                .adicionarEstado("novo-dispositivo.cadastro", {
                    templateUrl: "./app/modulos/seguranca/cadastroDispositivo/views/cadastro.html",
                    parent: "novo-dispositivo"
                },
                [
                    {
                        acao: "senhaConfirmacao",
                        estadoDestino: "novo-dispositivo.senha-confirmacao"
                    }
                ])

                .adicionarEstado("novo-dispositivo.senha-confirmacao", {
                    templateUrl: "./app/modulos/seguranca/cadastroDispositivo/views/senhaConfirmacao.html",
                    parent: "novo-dispositivo"
                },
                [
                    {
                        acao: "liberacao",
                        estadoDestino: "novo-dispositivo.liberacao"
                    }
                ])

                .adicionarEstado("novo-dispositivo.liberacao", {
                    templateUrl: "./app/modulos/seguranca/cadastroDispositivo/views/liberacao.html",
                    parent: "novo-dispositivo"
                })

                .definirEstadoInicial("novo-dispositivo.novo-acesso")
        );

        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-alterar-senha")
                .adicionarEstado("alterar-senha-cabecalho", {
                    templateUrl: "./app/modulos/seguranca/alteracaoSenha/views/alterarSenhaLogin.html",
                    controller: "gestaoMaquinasController as gmCtrl",
                    abstract: true
                })
                .adicionarEstado("alterar-senha", {
                    templateUrl: "./app/modulos/seguranca/alteracaoSenha/views/alteracaoSenha.html",
                    parent: "alterar-senha-cabecalho"
                },
                [
                    {
                        acao: "login-token",
                        fluxo: "apl-mobile-pj-ativar-token"
                    }
                ])
                .definirEstadoInicial("alterar-senha")
        );

        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-ativar-token")
                .adicionarEstado("ativacao-token-cabecalho", {
                    templateUrl: "./app/modulos/seguranca/ativarToken/views/ativacaoTokenCabecalho.html",
                    controller: "ativarTokenController as attokCtrl",
                    abstract: true
                })
                .adicionarEstado("dados-token", {
                    templateUrl: "./app/modulos/seguranca/ativarToken/views/dados.html",
                    parent: "ativacao-token-cabecalho"
                },
                [
                    {
                        acao: "validar-senha-ativacao",
                        estadoDestino: "seguranca-token"
                    }
                ])
                .adicionarEstado("seguranca-token", {
                    templateUrl: "./app/modulos/seguranca/ativarToken/views/seguranca.html",
                    parent: "ativacao-token-cabecalho"
                },
                [
                    {
                        acao: "ativar-token",
                        estadoDestino: "ativacao-token"
                    }
                ])
                .adicionarEstado("ativacao-token", {
                    templateUrl: "./app/modulos/seguranca/ativarToken/views/ativacao.html",
                    parent: "ativacao-token-cabecalho"
                },
                [
                    {
                        acao: "token-ativo",
                        fluxo: "apl-mobile-pj-home"
                    }
                ])
                .definirEstadoInicial("dados-token")
        );

    }
})();
(function () {

    "use strict";

    angular.module("apl-mobile-pj.seguranca").factory("alterarValidarSenhaFactory", alterarValidarSenhaFactory);

    alterarValidarSenhaFactory.$inject = ["sfConectorAPI", "sfContexto"];

    /*Funções*/
    /**
    * @ngdoc method
    * @name iniciar
    *  
    * @description
    * Método resgistrando serviço de alterar senha
    **/
    function alterarValidarSenhaFactory(conectorAPI, sfContexto) {

        return {
            alterarValidarSenha: alterarValidarSenha
        };

        /**
        * @ngdoc alterarValidarSenha
        * @name iniciar
        *  
        * @description
        * Método responsável por alterar senha
        **/
        function alterarValidarSenha(requisicao) {
            var dadosShortnameUsername = sfContexto.obterValorContextoTrabalho("dadosLogin"); 

            var param = {
                "ADSE_RC_SENHA_ATU": requisicao.ADSE_RC_SENHA_ATU,
                "ADSE_RC_SENHA_ALT": requisicao.ADSE_RC_SENHA_ALT,
                "ADSE_RC_IC_PERFIL": "N",
                "ADSE_RC_TP_OPER": "A",
                "ADSE_RC_SENHA_BLW": "",
                "ADSE_RC_ALT_MSG": "",
                "ADSE_RC_ATIVACAO": "",
                "ADSE_RC_COD_MAQUINA": "",
                "ADSE_RC_VERSAO": "",
                "ADSE_RC_TIPO": "",
                "shortname": dadosShortnameUsername.shortname,
                "userId": dadosShortnameUsername.username
            };

            var req = {

                method: "POST",
                url: "alterar-validar-senha",
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }
})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name autenticarUsuarioFactory
    *
    * @methodOf apl-mobile-pj.seguranca:autenticarUsuarioFactory
    *
    * @description
    * Factory de conexão com API autenticarUsuarioFactory
    **/
    angular.module("apl-mobile-pj.seguranca")
        .factory("autenticarUsuarioFactory", autenticarUsuarioFactory);

    autenticarUsuarioFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name autenticarUsuario
    *
    * @methodOf apl-mobile-pj.extrato:autenticarUsuarioFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function autenticarUsuarioFactory(conectorAPI, appSettings, utilitarios) {

        return {
            autenticarUsuario: autenticarUsuario
        };

        /**
        * @ngdoc method
        * @name autenticarUsuario
        *
        * @methodOf apl-mobile-pj.extrato:autenticarUsuario
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function autenticarUsuario(requisicao) {

            var param = requisicao;
                
                // "ADSE_RC_SENHA_ALT" : requisicao.ADSE_RC_SENHA_ALT,
                // "ADSE_RC_IC_PERFIL" : requisicao.ADSE_RC_IC_PERFIL,
                // "ADSE_RC_TP_OPER" : requisicao.ADSE_RC_TP_OPER,
                // "ADSE_RC_SENHA_BLW" : requisicao.ADSE_RC_SENHA_BLW,
                // "ADSE_RC_ALT_MSG" : requisicao.ADSE_RC_ALT_MSG,
                // "ADSE_RC_BROWSER" : requisicao.ADSE_RC_BROWSER,
                // "ADSE_RC_COD_MAQUINA" :requisicao.ADSE_RC_COD_MAQUINA,
                // "ADSE_RC_VERSAO" : requisicao.ADSE_RC_VERSAO,
                // "ADSE_RC_TIPO" : requisicao.ADSE_RC_TIPO


            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "autenticar-usuario-pj"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();
(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name validarTokenFactory
    *
    * @methodOf apl-mobile-pj.seguranca:validarTokenFactory
    *
    * @description
    * Factory de conexão com API validarTokenFactory
    **/
    angular.module("apl-mobile-pj.seguranca")
        .factory("validarTokenFactory", validarTokenFactory);

    validarTokenFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name validarToken
    *
    * @methodOf apl-mobile-pj.seguranca:validarTokenFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function validarTokenFactory(conectorAPI, appSettings, utilitarios) {

        return {
            validarToken: validarToken
        };

        /**
        * @ngdoc method
        * @name validarToken
        *
        * @methodOf apl-mobile-pj.seguranca:validarToken
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function validarToken(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "validar-token"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();
(function () {
    "use strict";

    /**
    * @ngdoc overview
    * @name apl-mobile-pj.seguranca
    * 
    * @require navegador
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Ativação de Token.
    **/
    angular.module("apl-mobile-pj.seguranca").controller("ativarTokenController", ativarTokenController);

    ativarTokenController.$inject = ["sfNavegador",
        "sfContexto",
        "modal",
        "obterNomeUsuarioFactory",
        "autenticarUsuarioFactory",
        "validarTokenFactory",
        "interpretadorComunicacao",
        "sfToken"];

    /**
    * @ngdoc overview
    * @name ativarTokenController
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Ativação de Token.
    **/
    function ativarTokenController(navegador,
        contexto,
        modal,
        obterNomeUsuarioFactory,
        autenticarUsuarioFactory,
        validarTokenFactory,
        interpretadorComunicacao,
        sfToken) {

        var vm = this;

        vm.voltar = voltar;

        vm.alertas = [];
        vm.shortname = "";
        vm.username = "";
        vm.senhaEletronica = "";
        vm.usuarioLogado = "";
        vm.codigoAtivacao = "";
        vm.usuarioMaster = false;

        vm.mostrarAlerta = mostrarAlerta;
        vm.voltarInicio = voltarInicio;
        vm.carregarSegurancaToken = carregarSegurancaToken;
        vm.carregarAtivacaoToken = carregarAtivacaoToken;
        vm.ativarToken = ativarToken;
        vm.serialToken = "";


        var permissionamento = null;
        var jaPossuiTokenCadastrado = false;

        /*Funções*/

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltar() {
            navegador.voltar();
        }

        /**
        * @ngdoc method
        * @name voltarInicio
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltarInicio() {
            jaPossuiTokenCadastrado = false;
            navegador.iniciarFluxo("apl-mobile-pj-login");
        }

         /**
        * @ngdoc method
        * @name voltarInicio
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para o fluxo ativar-token.
        **/
        function fluxoAtivarToken() {
            navegador.navegar("ativar-token");
        }


        /**
        * @ngdoc method
        * @name mostrarAlerta
        *  
        * @description
        * Método responsável por exibir o alerta de acordo com o retorno da comunicação
        **/
        function mostrarAlerta(tipoAlerta, textoAlerta) {
            var caminho = "./app/assets/img/Pendencias_60x60pt_Ocre.png";

            if (tipoAlerta == "danger") {
                caminho = "./app/assets/img/icone_atencao_erro.png";
            }

            vm.alertas.push({ tipo: tipoAlerta, texto: textoAlerta, caminho: caminho });
        }

        /**
        * @ngdoc method
        * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeAlerta() {
            vm.alertas = [];
        }

        /**
        * @ngdoc overview
        * @name montarPermissionamento
        * 
        * @memberOf ativarTokenController.js
        *
        * @description
        * Método executado para montar as permissões
        **/
        function montarPermissionamento(data) {
            permissionamento = {};
            permissionamento.CONTAS = data.ADLG_EV_ITENS;
            permissionamento.GRUPO_SERVICOS = data.ADLG_EV_GRUPOS;
            permissionamento.CONTAS_POR_SERVICO = data.ADLG_EV_SERVICO;
            permissionamento.USUARIO_CPF = data.ADLG_EV_USUARIOCPF;
            permissionamento.USUARIO_DADOS = data.ADLG_EV_USUARIOCPF;
            permissionamento.MENSAGEM = data.ADLG_EV_MENSAGEM;
            permissionamento.TOKEN = data.ADLG_EV_TOKEN;

            contexto.definirValorContextoTrabalho("permissionamento", permissionamento);
        }

        /**
        * @ngdoc method
        * @name carregarSegurancaToken
        *  
        * @description
        * Método responsável por obter nome do usuário
        **/
        function carregarSegurancaToken() {

            removeAlerta();
            if ((vm.shortname != "" && vm.shortname != undefined && vm.shortname.length == 8) &&
                (vm.username != "" && vm.username != undefined && vm.username.length == 8)) {
               
                 var dadosLogin = {
                    shortname: vm.shortname,
                    username: vm.username
                };

                contexto.definirValorContextoTrabalho("dadosLogin", dadosLogin);
                
                interpretadorComunicacao.interpretar(obterNomeUsuarioFactory.obterNomeUsuario())
                    .sucesso(sucesso)
                    .aviso(erro)
                    .erro(erro);
            }

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno  de obter Nome Usuario
            **/
            function sucesso(data) {
                vm.usuarioLogado = data.ADSE_EV_NOM_USR;
                contexto.definirValorContextoTrabalho("nomeClienteUltimoAcesso", data.ADSE_EV_NOM_USR);
                navegador.navegar("validar-senha-ativacao");
            }

            /**
           * @ngdoc method
           * @name erro
           *  
           * @description
           * Método de erro do retorno da consulta  de obter Nome Usuario
           **/
            function erro(erro) {
                mostrarAlerta("danger", erro.statusProcessamento.message);
            }
        }

        /**
        * @ngdoc method
        * @name carregarAtivacaoToken
        *  
        * @description
        * Método responsável por validar a senha
        **/
        function carregarAtivacaoToken() {

            removeAlerta();
            if (vm.senhaEletronica != "" && vm.senhaEletronica != undefined && vm.senhaEletronica.length == 8) {
                
                var param = {
                    credencial: { "senha": vm.senhaEletronica },
                    "ADSE_RC_SENHA_ATU": vm.senhaEletronica,
                    "ADSE_RC_SENHA_ALT": "",
                    "ADSE_RC_IC_PERFIL": "S",
                    "ADSE_RC_TP_OPER": "L",
                    "ADSE_RC_SENHA_BLW": "",
                    "ADSE_RC_ALT_MSG": "",
                    "ADSE_RC_ATIVACAO": "",
                    "ADSE_RC_COD_MAQUINA": "",
                    "ADSE_RC_VERSAO": "",
                    "ADSE_RC_TIPO": "",
                    "shortname": vm.shortname,
                    "userId": vm.username
                };

                interpretadorComunicacao.interpretar(autenticarUsuarioFactory.autenticarUsuario(param))
                    .sucesso(sucesso)
                    .aviso(erro)
                    .erro(erro);
            }

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno do autenticar usuario
            **/
            function sucesso(data) {
                montarPermissionamento(data);
                if (permissionamento.TOKEN.ADLG_TS_USER_UNIF_M.indexOf("MASTER") != -1) {
                    vm.usuarioMaster = true;
                }
                
                validarTokenUsuario();
            }

            /**
           * @ngdoc method
           * @name erro
           *  
           * @description
           * Método de erro do retorno do autenticar usuario
           **/
            function erro(erro) {
                console.log(erro);
                //mostrarAlerta("danger", erro.statusProcessamento.message);
            }
        }

        /**
        * @ngdoc method
        * @name validarTokenUsuario
        *  
        * @description
        * Método responsável por validar o dispositivo do cliente
        **/
        function validarTokenUsuario() {

                var param = {
                    "device": "",
                    "tipoDevice": "1",
                    "tipoPessoa": "PJ",
                    "shortname": vm.shortname,
                    "userId": vm.username
                };

                interpretadorComunicacao.interpretar(sfToken.autenticacao.validarDispositivo(param))
                    .sucesso(sucesso)
                    .aviso(erro)
                    .erro(erro);
            
            
            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno de validar Token
            **/
            function sucesso(data) {
                //Token já está associado ao cliente
                if(data.indTokenMobile == 1) {
                    vm.serialToken = data.serialNumber;
                    jaPossuiTokenCadastrado = true;
                     //Abrir o modal
                    modal.abrirModal(undefined,
                        undefined,
                        "modalCadastrarToken",
                        fluxoAtivarToken,
                        voltarInicio);
                } else {
                    vm.serialToken = data.serialNumber;
                    jaPossuiTokenCadastrado = false;
                    fluxoAtivarToken();
                }
            }

            /**
            * @ngdoc method
            * @name erro
            *  
            * @description
            * Método de erro do retorno da consulta de validar Token
            **/
            function erro(erro) {
                console.log(erro);
                mostrarAlerta("danger", erro.statusProcessamento.message);
            }
            
        }

        /**
        * @ngdoc method
        * @name ativarToken
        *  
        * @description
        * Método responsável por iniciar o processo de ativação do token
        **/
        function ativarToken() {

            removeAlerta();
            if (vm.codigoAtivacao != "" && vm.codigoAtivacao != undefined) {
                
                if (jaPossuiTokenCadastrado) {
                    ativarComDesassociacao();
                } else {
                    ativarSemDesassociacao();
                }
            }
        }

        /**
        * @ngdoc method
        * @name ativarComDesassociacao
        *  
        * @description
        * Método responsável por iniciar a Ativação do token desassociando o Token existente do cliente.
        **/
        function ativarComDesassociacao() {

                var param = {
                    "opcao": "1",
                    "serialNumber": vm.serialToken,
                    "indEnviaSMS": "S",
                    "device": "",
                    "tipoDevice": "1",
                    "shortname": vm.shortname,
                    "usuario": vm.username,
                    "tipoPessoa": "PJ",
                    "email": {
                        "shortname": vm.shortname,
                        "usuario": vm.username
                    }
                };

                interpretadorComunicacao.interpretar(sfToken.autenticacao.ativarComDesassociacao(param))
                    .sucesso(sucesso)
                    .aviso(erro)
                    .erro(erro);
            
            
            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno de ativar token com desassociação
            **/
            function sucesso() {
                efetivarAtivacaoToken();
            }

            /**
            * @ngdoc method
            * @name erro
            *  
            * @description
            * Método de erro do retorno do ativar token com desassociação
            **/
            function erro(erro) {
                console.log(erro);
                mostrarAlerta("danger", erro.statusProcessamento.message);
            }
            
        }

          /**
        * @ngdoc method
        * @name ativarSemDesassociacao
        *  
        * @description
        * Método responsável por iniciar a Ativação do token sem desassociação do Token existente do cliente.
        **/
        function ativarSemDesassociacao() {

                var param = {
                    "indEnviaSMS": "S",
                    "device": "",
                    "tipoDevice": "1",
                    "shortname": vm.shortname,
                    "userId": vm.username,
                    "tipoPessoa": "PJ"
                };

                interpretadorComunicacao.interpretar(sfToken.autenticacao.ativarSemDesassociacao(param))
                    .sucesso(sucesso)
                    .aviso(erro)
                    .erro(erro);
            
            
            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno de ativar token sem desassociação
            **/
            function sucesso() {
                efetivarAtivacaoToken();
            }

            /**
            * @ngdoc method
            * @name erro
            *  
            * @description
            * Método de erro do retorno do ativar token sem desassociação
            **/
            function erro(erro) {
                console.log(erro);
                mostrarAlerta("danger", erro.statusProcessamento.message);
            }
            
        }
      
         /**
        * @ngdoc method
        * @name efetivarAtivacaoToken
        *  
        * @description
        * Método responsável por efetivar a ativação do token
        **/
        function efetivarAtivacaoToken() {

            removeAlerta();
            if (vm.codigoAtivacao != "" && vm.codigoAtivacao != undefined) {
                
                var requisicao = {
                    "indValidacaoSMS": "N",
                    "senhaSMS": vm.codigoAtivacao,
                    "serialNumber": vm.serialToken,
                    "device": "",
                    "tipoDevice": "1",
                    "shortname": vm.shortname,
                    "userId": vm.username
                };

                sfToken.ativar(requisicao)
                    .then(sucesso)
                    .catch(erro);
                    
            }

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno do efetivarAtivacaoToken
            **/
            function sucesso(data) {
                console.log(data);
                voltarInicio();                
            }

            /**
            * @ngdoc method
            * @name erro
            *  
            * @description
            * Método de erro do retorno  do efetivarAtivacaoToken
            **/
            function erro(erro) {
                mostrarAlerta("danger", erro.statusProcessamento.message);
            }
        }

        /**
        * @ngdoc method
        * @name obterSequenciaToken
        *  
        * @description
        * Método responsável por obter sequencia do token
        **/
        // function obterSequenciaToken() {

        //      sfToken.obterSequencia(false)
        //          .then(sucesso)
        //          .catch(erro);

            
        //     /**
        //     * @ngdoc method
        //     * @name sucesso
        //     *  
        //     * @description
        //     * Método de sucesso do retorno do obterSequenciaToken
        //     **/
        //     function sucesso(data) {
        //         console.log(data);
        //     }

        //     /**
        //     * @ngdoc method
        //     * @name erro
        //     *  
        //     * @description
        //     * Método de erro do retorno  do obterSequenciaToken
        //     **/
        //     function erro(erro) {
        //         mostrarAlerta("danger", erro.statusProcessamento.message);
        //     }
        // }



    }
})();
(function () {

    "use strict";

    angular.module("apl-mobile-pj.seguranca").factory("incluirMaquinasFactory", incluirMaquinasFactory);

    incluirMaquinasFactory.$inject = ["sfConectorAPI", "sfContexto"];

    /*Funções*/
    /**
    * @ngdoc method
    * @name iniciar
    *  
    * @description
    * Método resgistrando serviço de incluir máquinas
    **/
    function incluirMaquinasFactory(conectorAPI, contexto) {

        return {
            incluirMaquina: incluirMaquina
        };

        /*Funções*/

        // /**
        // * @returns GUID para utilização na tela.
        // */
        // function guid() {
        //     /**
        //      * @returns Ramdom value
        //      */
        //     function s4() {
        //         return Math.floor((1 + Math.random()) * 0x10000)
        //             .toString(16)
        //             .substring(1);
        //     }
        //     return s4() + s4() + s4() + s4();
        // }

        /**
        * @ngdoc incluirMaquina
        * @name iniciar
        *  
        * @description
        * Método responsável por incluir Maquina
        **/
        function incluirMaquina(requisicao) {
            //TODO: Remover valores fixos, disponivel pela arquitetura?
            //Agencia=00000,Conta=000000000,CodigoCanal=IPJ,Senha=XXXXXXXX,ValorOperacao=1,CodigoCliente=000000000,ShortName=VALISERE       ,UserId=TESTE   ,BaseCGC=000000000,CentralAtendimento=N,TokenValidado=S

            var dadosShortnameUsername = contexto.obterValorContextoTrabalho("dadosLogin"); 

            var param = {
                "PLCM_RC_OPCAO": "1",
                "PLCM_RC_CDMAQ": "ASDFZXCVQWER1234", // guid(), //TODO: Em definição pela arquitetura
                "PLCM_RC_APELMAQ": requisicao.apelMaquina,
                "PLCM_RC_IP": "172.16.34.169", //TODO: Em definição pela arquitetura
                "PLCM_RC_VERPLU": "1.12.3.5", //TODO: Em definição pela arquitetura
                "PLCM_RC_FLSMS_LIB": "N",
                "PLCM_RC_DTVALI": requisicao.dataValidacao,

                //TODO XASAN REMOVER
                "shortname": dadosShortnameUsername.shortname,
                    "userId": dadosShortnameUsername.username,
                "baseCGC": "000000000",
                    "agencia": "00000",
                    "contaCorrente": "000000000" //TODO XASAN aguardando correção XASAN
            };

            var req = {

                method: "POST",
                url: "incluir-maquinas",
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.seguranca.gestaoMaquinasController
     * 
     * @requires navegador
     * 
     * @description
     * Controller responsável pela tratativa das ações a serem realizadas na view Gestao de Maquinas.
     **/
    angular.module("apl-mobile-pj.seguranca").controller("gestaoMaquinasController", gestaoMaquinasController);

    gestaoMaquinasController.$inject =
        [
            "sfNavegador",
            "sfContexto",
            "listarMaquinasFactory",
            "listarMaquinasPendentesFactory",
            "liberarExcluirMaquinasFactory",
            "alterarValidarSenhaFactory",
            "modal",
            "interpretadorComunicacao",
            "autenticarUsuarioFactory"
        ];

    /*
    * @description
    * 
    */
    /**
     * @ngdoc overview
     * @name apl-mobile-pj.seguranca.gestaoMaquinasController
     * @description
     * Controller Gestao de Maquinas.
     **/
    function gestaoMaquinasController(
        navegador,
        sfContexto,
        listarMaquinasFactory,
        listarMaquinasPendentesFactory,
        liberarExcluirMaquinasFactory,
        alterarValidarSenhaFactory,
        modal,
        interpretadorComunicacao,
        autenticarUsuarioFactory) {
        var vm = this;

        vm.amimationsEnabled = true;
        vm.voltar = voltar;
        vm.voltarInicioLiberacao = voltarInicioLiberacao;
        vm.voltarInicioExclusao = voltarInicioExclusao;
        vm.selecionarTodosPendentes = selecionarTodosPendentes;
        vm.selecionarTodosLiberados = selecionarTodosLiberados;
        vm.carregarLiberarMaquinas = carregarLiberarMaquinas;
        vm.carregarExcluirMaquinas = carregarExcluirMaquinas;
        vm.atualizarchkTodasMaquinasLiberadas = atualizarchkTodasMaquinasLiberadas;
        vm.atualizarchkTodasMaquinasPendentes = atualizarchkTodasMaquinasPendentes;
        vm.confirmarSenhaToken = confirmarSenhaToken;
        vm.liberarExcluir = liberarExcluir;
        vm.confirmarLiberarMaquinas = confirmarLiberarMaquinas;
        vm.confirmarExcluirMaquinas = confirmarExcluirMaquinas;
        vm.obterListaLiberarMaquinas = obterListaLiberarMaquinas;
        vm.obterListaExcluirMaquinasLiberadas = obterListaExcluirMaquinasLiberadas;
        vm.obterListaExcluirMaquinasPendentes = obterListaExcluirMaquinasPendentes;
        vm.listarMaquinasLiberadas = listarMaquinasLiberadas;
        vm.acaoLiberadas = acaoLiberadas;

        vm.alertas = [];
        vm.removeAlerta = removeAlerta;
        vm.mostrarAlerta = mostrarAlerta;

        iniciar();

        /*Funções*/

        /**
        * @ngdoc method
        * @name iniciar
        *
        * @methodOf apl-mobile-pj.home
        *  
        * @description
        * Método responsável por carregar o estado inicial dos elementos da view.
        **/
        function iniciar() {
            vm.paginaMaquinas = {
                visivel: true
            };
            vm.paginaSenha = {
                visivel: false
            };

            vm.exibeMenuPaginaSenha = false;
            if (sfContexto.obterValorContextoTrabalho("usuarioLogadoSemPermissaoMaquinas"))
            {
                vm.exibeMenuPaginaSenha = true;                
            }                

            vm.senha = "";
            vm.token = "";

            vm.listaMaquinasPendentes = {
                visivel: true
            };

            vm.listaMaquinasLiberadas = {
                visivel: false,
                carregada: false
            };

            vm.existemMaquinasPendentes = true;
            vm.existemMaquinasLiberadas = true;

            vm.chkTodasMaquinasPendentes = false;
            vm.chkTodasMaquinasLiberadas = false;

            vm.habilitarExcluirPendentes = true;
            vm.habilitarExcluirLiberados = true;

            vm.habilitarLiberarPendentes = true;

            vm.voltarInicio = false;

            vm.fluxoLogin = false;

            listarMaquinasPendentes();
        }

        /**
        * @ngdoc method
        * @name listarMaquinasLiberadas
        *  
        * @description
        * Método responsável por chamar o serviço que consulta as maquinas liberadas
        **/
        function listarMaquinasLiberadas() {
            vm.habilitarLiberarPendentes = true;
            vm.habilitarExcluirPendentes = true;
            vm.habilitarExcluirLiberados = true;

            var dadosLogin = sfContexto.obterValorContextoTrabalho("dadosLogin");
            var PLLU_RC_CHCLI = dadosLogin.shortname;//"VALISERE";

            var PLLU_RC_TPCON = "S";

            interpretadorComunicacao.interpretar(listarMaquinasFactory.listarMaquinasLiberadas(PLLU_RC_CHCLI, PLLU_RC_TPCON))
                .sucesso(sucesso)
                .aviso(erro)
                .erro(erro);

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno da consulta as maquinas liberadas
            **/
            function sucesso(data) {
                vm.maquinasLiberadas = data.PLLU_EV_OCOR;

                if (vm.maquinasLiberadas != undefined && vm.maquinasLiberadas.length > 0) {
                    vm.existemMaquinasLiberadas = true;
                    vm.listaMaquinasLiberadas.carregada = true;
                } else {
                    vm.existemMaquinasLiberadas = false;
                }
            }

            /**
           * @ngdoc method
           * @name erro
           *  
           * @description
           * Método de erro do retorno da consulta as maquinas liberadas
           **/
            function erro(erro) {
                console.log("Erro ao listar maquinas:" + JSON.stringify(erro));
                vm.existemMaquinasLiberadas = false;
            }
        }

        /**
        * @ngdoc method
        * @name listarMaquinasPendentes
        *  
        * @description
        * Método responsável por chamar o serviço que consulta as maquinas Pendentes
        **/
        function listarMaquinasPendentes() {
            vm.habilitarLiberarPendentes = true;
            vm.habilitarExcluirPendentes = true;
            vm.habilitarExcluirLiberados = true;

            var dadosLogin = sfContexto.obterValorContextoTrabalho("dadosLogin");
            var PLLM_RC_CHCLI = dadosLogin.shortname;//"VALISERE";

            interpretadorComunicacao.interpretar(listarMaquinasPendentesFactory.listarMaquinasPendentes(PLLM_RC_CHCLI))
                .sucesso(sucesso)
                .aviso(erro)
                .erro(erro);

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno da consulta as maquinas Pendentes
            **/
            function sucesso(data) {
                vm.maquinasPendentes = data.PLLM_EV_OCOR;

                if (vm.maquinasPendentes != undefined && vm.maquinasPendentes.length > 0) {
                    vm.existemMaquinasPendentes = true;
                } else {
                    vm.existemMaquinasPendentes = false;
                }
            }

            /**
           * @ngdoc method
           * @name erro
           *  
           * @description
           * Método de erro do retorno da consulta as maquinas Pendentes
           **/
            function erro(erro) {
                console.log("Erro ao listar maquinas:" + JSON.stringify(erro));
                vm.existemMaquinasPendentes = false;
            }
        }

        /**
        * @ngdoc method
        * @name selecionarTodosPendentes
        *  
        * @description
        * Método responsável selecionar todos as máquinas pendentes
        **/
        function selecionarTodosPendentes() {
            var selecionado = vm.chkTodasMaquinasPendentes;
            for (var OCOR in vm.maquinasPendentes) {
                var element = vm.maquinasPendentes[OCOR];
                element.selecionado = selecionado;
            }

            if (selecionado) {
                vm.habilitarLiberarPendentes = false;
                vm.habilitarExcluirPendentes = false;
            } else {
                vm.habilitarLiberarPendentes = true;
                vm.habilitarExcluirPendentes = true;
            }
        }

        /**
        * @ngdoc method
        * @name selecionarTodosLiberados
        *  
        * @description
        * Método responsável selecionar todos as máquinas liberadas
        **/
        function selecionarTodosLiberados() {
            var selecionado = vm.chkTodasMaquinasLiberadas;
            for (var OCOR in vm.maquinasLiberadas) {
                var element = vm.maquinasLiberadas[OCOR];
                element.selecionado = selecionado;
            }

            if (selecionado) {
                vm.habilitarExcluirLiberados = false;
            } else {
                vm.habilitarExcluirLiberados = true;
            }
        }

        /**
        * @ngdoc method
        * @name atualizarchkTodasMaquinasLiberadas
        *  
        * @description
        * Método responsável atualizar variavel que controle o check todos as máquinas liberadas
        **/
        function atualizarchkTodasMaquinasLiberadas() {
            var itensSelecionados = vm.maquinasLiberadas.filter(function (item) {
                return item.selecionado;
            });

            vm.chkTodasMaquinasLiberadas = (itensSelecionados.length == vm.maquinasLiberadas.length);

            if (itensSelecionados.length > 0) {
                vm.habilitarExcluirLiberados = false;
            } else {
                vm.habilitarExcluirLiberados = true;
            }
        }


        /**
        * @ngdoc method
        * @name atualizarchkTodasMaquinasPendentes
        *  
        * @description
        * Método responsável atualizar variavel que controle o check todos as máquinas pendentes
        **/
        function atualizarchkTodasMaquinasPendentes() {
            var itensSelecionados = vm.maquinasPendentes.filter(function (item) {
                return item.selecionado;
            });

            vm.chkTodasMaquinasPendentes = (itensSelecionados.length == vm.maquinasPendentes.length);

            if (itensSelecionados.length > 0) {
                vm.habilitarLiberarPendentes = false;
                vm.habilitarExcluirPendentes = false;
            } else {
                vm.habilitarLiberarPendentes = true;
                vm.habilitarExcluirPendentes = true;
            }
        }


        /**
        * @ngdoc method
        * @name carregarLiberarExcluirMaquinas
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela de liberar máquina.
        **/
        function carregarLiberarMaquinas() {
            vm.obterListaLiberarMaquinas();
            navegador.navegar("liberar-maquinas");
        }

        /**
        * @ngdoc method
        * @name obterListaLiberarMaquinas
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por obter Lista LiberarMaquinas.
        **/
        function obterListaLiberarMaquinas() {
            var maquinas = [];

            var itens = vm.maquinasPendentes.filter(function (item) {
                return item.selecionado == "true" || item.selecionado == true;
            });

            for (var item in itens) {
                var element = itens[item];
                var maquina =
                    {
                        "PLMM_RC_OPCAO": "L",
                        "PLMM_RC_CHCLI": element.PLLM_EV_CHCLI,
                        "PLMM_RC_CDMAQ": element.PLLM_EV_CHMAQ,
                        "PLMM_RC_CDMAQ_LIB": "9CAD0131816C53DC", //TODO: Obter esse valor pela arquitetura -- codigo da maquina local
                        "PLMM_RC_CHAVE_LIB": "",
                        "PLMM_RC_MOT_BLOQ": "",
                        "PLMM_RC_DTVAL_LIB": element.PLLM_EV_DTVAL
                    };
                maquinas.push(maquina);

            }

            sfContexto.definirValorContextoTrabalho("listaMaquinasPendentes", maquinas);
        }

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela anterior.
        **/
        function voltar() {
            removeAlerta();
            vm.voltarInicio = false;
            navegador.voltar();
        }

        /**
        * @ngdoc method
        * @name voltarInicioLiberacao
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela inicial.
        **/
        function voltarInicioLiberacao() {
            if (vm.listaMaquinasLiberadas.visivel) {
                listarMaquinasLiberadas();
            }

            if (vm.listaMaquinasPendentes.visivel) {
                listarMaquinasPendentes();
            }

            removeAlerta();

            navegador.navegar("voltar-inicio");
            vm.voltarInicio = false;
        }

        /**
        * @ngdoc method
        * @name voltarInicioExclusao
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela inicial.
        **/
        function voltarInicioExclusao() {
            if (vm.listaMaquinasLiberadas.visivel) {
                listarMaquinasLiberadas();
            }

            if (vm.listaMaquinasPendentes.visivel) {
                listarMaquinasPendentes();
            }

            removeAlerta();

            navegador.navegar("voltar-inicio");
            vm.voltarInicio = false;
        }

        /**
        * @ngdoc method
        * @name carregarLiberarExcluirMaquinas
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela de excluir máquina.
        **/
        function carregarExcluirMaquinas() {
            if (vm.listaMaquinasPendentes.visivel) {
                vm.obterListaExcluirMaquinasPendentes();
            } else {
                vm.obterListaExcluirMaquinasLiberadas();
            }

            navegador.navegar("excluir-maquinas");
        }

        /**
        * @ngdoc method
        * @name obterListaExcluirMaquinasPendentes
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela de excluir máquina.
        **/
        function obterListaExcluirMaquinasPendentes() {
            var maquinas = [];

            var PLLM_EV_OCOR = vm.maquinasPendentes.filter(function (OCORP) {
                return OCORP.selecionado == "true" || OCORP.selecionado == true;
            });

            for (var OCORP in PLLM_EV_OCOR) {
                var elementPendente = PLLM_EV_OCOR[OCORP];
                var maquinaPendente =
                    {
                        "PLMM_RC_OPCAO": "E",
                        "PLMM_RC_CHCLI": elementPendente.PLLM_EV_CHCLI,
                        "PLMM_RC_CDMAQ": elementPendente.PLLM_EV_CHMAQ,
                        "PLMM_RC_CDMAQ_LIB": elementPendente.PLLM_EV_MAQLIB,
                        "PLMM_RC_CHAVE_LIB": "",
                        "PLMM_RC_MOT_BLOQ": "",
                        "PLMM_RC_DTVAL_LIB": elementPendente.PLLM_EV_DTVAL
                    };
                maquinas.push(maquinaPendente);
            }

            sfContexto.definirValorContextoTrabalho("listaMaquinasPendentes", maquinas);
        }

        /**
        * @ngdoc method
        * @name obterListaExcluirMaquinasLiberadas
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela de excluir máquina.
        **/
        function obterListaExcluirMaquinasLiberadas() {
            var maquinas = [];

            var PLLU_EV_OCOR = vm.maquinasLiberadas.filter(function (OCORL) {
                return OCORL.selecionado == "true" || OCORL.selecionado == true;
            });

            for (var OCORL in PLLU_EV_OCOR) {
                var elementLiberada = PLLU_EV_OCOR[OCORL];
                var maquinaLiberada =
                    {
                        "PLMM_RC_OPCAO": "E",
                        "PLMM_RC_CHCLI": elementLiberada.PLLU_EV_CHCLI,
                        "PLMM_RC_CDMAQ": elementLiberada.PLLU_EV_CHMAQ,
                        "PLMM_RC_CDMAQ_LIB": elementLiberada.PLLU_EV_MAQLIB,
                        "PLMM_RC_CHAVE_LIB": "",
                        "PLMM_RC_MOT_BLOQ": "",
                        "PLMM_RC_DTVAL_LIB": elementLiberada.PLLU_EV_DTVAL
                    };
                maquinas.push(maquinaLiberada);
            }

            sfContexto.definirValorContextoTrabalho("listaMaquinasPendentes", maquinas);
        }

        /**
        * @ngdoc method
        * @name confirmarSenhaToken
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por confirmar senha e token e acionar a operação de liberar/excluir as maquinas.
        **/
        function confirmarSenhaToken(data) {
            vm.resultadoValidacaoSenha = data;

            var listaMaquinas = sfContexto.obterValorContextoTrabalho("listaMaquinasPendentes");

            vm.liberarExcluir(listaMaquinas.pop(), data.senha, data.token);

            sfContexto.definirValorContextoTrabalho("listaMaquinasPendentes", listaMaquinas);
        }

        /**
        * @ngdoc method
        * @name cancelouSenhaToken
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por cancelar a digitação de senha token.
        **/
        function cancelouSenhaToken(data) {
            vm.resultadoValidacaoSenha = data;
            mostrarAlerta("warning", "Confirmação de senha cancelada.");
        }

        /**
        * @ngdoc method
        * @name confirmarLiberarMaquinas
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por confirmar a liberação de maquinas
        **/
        function confirmarLiberarMaquinas() {
            validarSenha();
        }

        /**
        * @ngdoc method
        * @name confirmarExcluirMaquinas
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por confirmar a exclusão de maquinas
        **/
        function confirmarExcluirMaquinas() {
            validarSenha();
        }

        /**
         * @description
         * Método para abertura e validação de senhas pelo modal.
         */
        function validarSenha() {
            removeAlerta();

            //Abrir o modal
            modal.abrirModal(undefined,
                undefined,
                "modalConfirmacaoSenha",
                confirmarSenhaToken,
                cancelouSenhaToken,
                {},
                "confirmacaoSenhaController",
                "csCtrl",
                "senha");
        }

        /**
        * @ngdoc method
        * @name liberarExcluir
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por chamar a operação de liberar/excluir as maquinas.
        **/
        function liberarExcluir(maquinas, senha, token) {

            interpretadorComunicacao.interpretar(liberarExcluirMaquinasFactory.liberarExcluirMaquinas(maquinas, senha, token))
                .sucesso(sucesso)
                .aviso(aviso)
                .erro(erro);

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno da operação de liberar/excluir as maquinas
            **/
            function sucesso(data) {

                var listaMaquinas = sfContexto.obterValorContextoTrabalho("listaMaquinasPendentes");

                if (listaMaquinas.length > 0) {

                    vm.liberarExcluir(listaMaquinas.pop(), senha, token);
                    sfContexto.definirValorContextoTrabalho("listaMaquinasPendentes", listaMaquinas);

                } else {
                    vm.voltarInicio = true;
                    vm.retornoSucessoLiberacao = data;
                    navegador.navegar("sucesso-validacao-senha");
                }
            }

            /**
           * @ngdoc method
           * @name erro
           *  
           * @description
           * Método de erro do retorno da operação de liberar/excluir as maquinas
           **/
            function erro(erro) {
                var listaMaquinas = sfContexto.obterValorContextoTrabalho("listaMaquinasPendentes");

                if (listaMaquinas.length > 0) {

                    vm.liberarExcluir(listaMaquinas.pop(), senha, token);
                    sfContexto.definirValorContextoTrabalho("listaMaquinasPendentes", listaMaquinas);

                } else {
                    removeAlerta();
                    mostrarAlerta("danger", erro.statusProcessamento.message);
                }
            }

            /**
            * @ngdoc method
            * @name Aviso
            *  
            * @description
            * Método de aviso do retorno da operação de liberar/excluir as maquinas
            **/
            function aviso(aviso) {
                mostrarAlerta("warning", aviso.statusProcessamento.message);
            }
        }

        /**
        * @ngdoc method
        * @name mostrarAlerta
        *  
        * @description
        * Método responsável por exibir o alerta de acordo com o retorno da comunicação
        **/
        function mostrarAlerta(tipoAlerta, textoAlerta) {
            var caminho = "";

            if (tipoAlerta == "warning") {

                caminho = "./app/assets/img/Pendencias_60x60pt_Ocre.png";
            }
            else if (tipoAlerta == "danger") {
                caminho = "./app/assets/img/icone_atencao_erro.png";
            }
            else {
                caminho = "./app/assets/img/icone_Mensagem_SUCESSO_60x60pt.png";
            }

            vm.alertas.push({ tipo: tipoAlerta, texto: textoAlerta, caminho: caminho });
        }

        /**
         * @ngdoc method
         *  * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeAlerta() {
            vm.alertas = [];
        }

        /**
         * @ngdoc method
         * @name acaoLiberadas
         *  
         * @description
         * Método responsável pela ação do botão de exibição de maquinas liberadas
         */
        function acaoLiberadas() {
            vm.listaMaquinasLiberadas.visivel = true;
            vm.listaMaquinasPendentes.visivel = false;

            if (!vm.listaMaquinasLiberadas.carregada) {
                listarMaquinasLiberadas();
            }
        }

        //INICIO - Alterar SENHA
        vm.alterarSenha = alterarSenha;
        vm.alterarSenhaLogin = alterarSenhaLogin;
        vm.removeAlerta = removeAlerta;
        vm.senhaAtual = null;
        vm.novaSenha = null;
        vm.confirmaSenha = null;
        vm.voltar = voltar;
        vm.senhaVencida = false;

        /*Funções*/

        /**
        * @ngdoc method
        * @name alterarSenha
        *
        * @methodOf apl-mobile-pj.seguranca:alteracaoSenhaController
        *
        * @description
        * Método responsável por realizar a troca da senha
        **/
        function validarAlteracaoSenha() {

            if (vm.novaSenha != null && vm.confirmaSenha != null && vm.senhaAtual != null) {
                if (vm.senhaAtual.toUpperCase() === vm.novaSenha.toUpperCase()) {
                    removeAlerta();
                    mostrarAlerta("danger", "A senha alterada não pode ser igual a senha atual, favor preencher novamente.");
                    return false;
                }
                else if (vm.novaSenha.toUpperCase() != vm.confirmaSenha.toUpperCase()) {
                    removeAlerta();
                    mostrarAlerta("danger", "A confirmação deve ser igual a nova senha.");
                    return false;
                }
                else {

                    if (new RegExp("\\s+").test(vm.novaSenha)) {
                        removeAlerta();
                        mostrarAlerta("danger", "A nova senha não deve conter espaços");
                        return false;
                    }

                    removeAlerta();

                    var validacao = verificaSequencia(vm.novaSenha);

                    if (validacao > 0) {
                        removeAlerta();
                        mostrarAlerta("danger", "A nova senha não deve conter sequências obvias");
                        return false;
                    }
                    else {
                        return true;
                    }

                }

            }
            return false;


            /**
            * @ngdoc method
            * @name verificaSequencia
            *
            * @methodOf apl-mobile-pj.gestaoMaquinas:gestaoMaquinasController
            *
            * @description
            * Método responsável por validar as sequencias de caracteres informados na nova senha.
            **/
            function verificaSequencia(senha) {
                var senhatmp, atual, x, charanterior, qtdseq;

                senhatmp = senha.toUpperCase();
                charanterior = "";
                atual = "";
                x = 0;
                qtdseq = 0;

                //Valida Numeros Intercalados
                //Executo duas vezes pois pode comecar ou nao da primeita posição  
                var intercalados = validaNumerosIntercalados(senha, true);
                if (intercalados > 0) {
                    return intercalados;
                }

                intercalados = validaNumerosIntercalados(senha, false);
                if (intercalados > 0) {
                    return intercalados;
                }

                while (x < 8) {
                    //Valida Caracteres repetidos XXXX
                    var charatual = senhatmp.substring(x, x + 1);
                    if (x > 0) {
                        if (charatual == charanterior) {
                            qtdseq++;
                        }
                        else {
                            qtdseq = 0;
                        }

                        if (qtdseq >= 3) {
                            return 5;
                        }
                    }
                    // if(new RegExp("^([A-Z0-9]){1,}").test(charatual))
                    charanterior = charatual;

                    atual = senhatmp.substring(x, x + 4);

                    var ordemcrescente = validaLetrasOrdemCrescente(atual);
                    var ordemdecrescente = validaLetrasOrdemDecrescente(atual);
                    var numerocrescente = validaNumeroCrescente(atual);
                    var numerodecrescente = validaNumeroDecrescente(atual);

                    if (ordemcrescente > 0) {
                        return ordemcrescente;
                    }
                    if (ordemdecrescente > 0) {
                        return ordemdecrescente;
                    }
                    if (numerocrescente > 0) {
                        return numerocrescente;
                    }
                    if (numerodecrescente > 0) {
                        return numerodecrescente;
                    }

                    x++;
                }
                return 0;
            }

            /**
             * @ngdoc method
             * @name validaNumerosIntercalados
             *
             * @methodOf apl-mobile-pj.gestaoMaquinas:validaNumerosIntercalados
             *
             * @description
             * Método responsável por validar as sequencias de caracteres númericos Intercalados.
             **/
            function validaNumerosIntercalados(posicoes, primeiraposicao) {
                var inicio = 0;
                if (!primeiraposicao) {
                    inicio = 1;
                }

                var i = inicio;
                var caracteres = "";
                while (i < 8) {
                    caracteres += posicoes.substring(i, i + 1);
                    i += 2;
                }

                var crescente = validaNumeroCrescente(caracteres);
                var decrescente = validaNumeroDecrescente(caracteres);

                if (crescente > 0 || decrescente > 0) {
                    return 6;
                }

                return 0;
            }

            /**
            * @ngdoc method
            * @name validaNumeroDecrescente
            *
            * @methodOf apl-mobile-pj.gestaoMaquinas:validaNumeroDecrescente
            *
            * @description
            * Método responsável por validar as sequencias de caracteres númericos em ordem Decrescente.
            **/
            function validaNumeroDecrescente(posicoes) {
                var i = 0;
                var invalido = "";
                var prox = 0;
                var numericodec = "9876543210";
                while (i < 10) {
                    prox = i + 4;

                    if (i <= 6) {
                        invalido = numericodec.substring(i, prox);
                    }
                    else {
                        invalido = numericodec.substring(6, prox);
                    }

                    if (posicoes.indexOf(invalido) >= 0) {
                        return 4;
                    }
                    i++;
                }

                return 0;
            }

            /**
           * @ngdoc method
           * @name validaLetrasOrdemCrescente
           *
           * @methodOf apl-mobile-pj.gestaoMaquinas:validaLetrasOrdemCrescente
           *
           * @description
           * Método responsável por validar as sequencias de caracteres númericos em ordem Crescente.
           **/
            function validaLetrasOrdemCrescente(posicoes) {
                var invalido = "";
                var prox = 0;
                var crescente = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                var i = 0;
                while (i < 26) {
                    prox = i + 4;

                    if (i <= 23) {
                        invalido = crescente.substring(i, prox);
                    }
                    else {
                        invalido = crescente.substring(21, prox);
                    }

                    if (posicoes.indexOf(invalido) >= 0) {
                        return 1;
                    }
                    i++;
                }

                return 0;
            }

            /**
           * @ngdoc method
           * @name validaLetrasOrdemDecrescente
           *
           * @methodOf apl-mobile-pj.gestaoMaquinas:validaLetrasOrdemDecrescente
           *
           * @description
           * Método responsável por validar as sequencias de caracteres em ordem Decrescente.
           **/
            function validaLetrasOrdemDecrescente(posicoes) {
                var i = 0;
                var invalido = "";
                var prox = 0;
                var decrescente = "ZYXWVUTSRQPONMLKJIHGFEDCBA";

                while (i < 26) {
                    prox = i + 4;

                    if (i <= 23) {
                        invalido = decrescente.substring(i, prox);
                    }
                    else {
                        invalido = decrescente.substring(21, prox);
                    }

                    if (posicoes.indexOf(invalido) >= 0) {
                        return 2;
                    }
                    i++;
                }

                return 0;
            }

            /**
            * @ngdoc method
            * @name validaNumeroCrescente
            *
            * @methodOf apl-mobile-pj.gestaoMaquinas:validaNumeroCrescente
            *
            * @description
            * Método responsável por validar as sequencias de caracteres númericos em ordem Crescente.
            **/
            function validaNumeroCrescente(posicoes) {
                var i = 0;
                var prox = 0;
                var numerico = "0123456789";
                var invalido = "";
                while (i < 10) {
                    prox = i + 4;

                    if (i <= 6) {
                        invalido = numerico.substring(i, prox);
                    }
                    else {
                        invalido = numerico.substring(6, prox);
                    }

                    if (posicoes.indexOf(invalido) >= 0) {
                        return 3;
                    }
                    i++;
                }

                return 0;
            }

        }

        /**
         * @description alterar senha
         */
        function transacaoAlterarSenha() {

            var param = {
                ADSE_RC_SENHA_ATU: vm.senhaAtual.toUpperCase(),
                ADSE_RC_SENHA_ALT: vm.novaSenha.toUpperCase(),
                ADSE_RC_IC_PERFIL: "N",
                ADSE_RC_TP_OPER: "A"
            };

            //RETIRAR
            // var texto = "Agencia=00000,Conta=0000000,CodigoCanal=IPJ,Senha=PAULIST1,ValorOperacao=1,CodigoCliente=000000000,ShortName=" + "VALISERE" + "       ,UserId=" + "ANDREBIZ" + ",BaseCGC=000000000";
            // sfContexto.definirValorContextoSessao("token", texto);

            // var mocksucesso = {
            //     "ADSE_EV_STATUS": "B",
            //     "ADSE_EV_NOM_USR": "",
            //     "ADSE_EV_NIV_USR": null,
            //     "ADSE_EV_DT_ULT_AC": 20160810,
            //     "ADSE_EV_COD_DEP": null,
            //     "ADSE_EV_EMAIL": "",
            //     "ADSE_EV_IC_TOKEN": "",
            //     "ADSE_EV_IC_GARAN": "N",
            //     "ADSE_EV_OCOR": [],
            //     "statusProcessamento": {
            //         "mensagem": {
            //             "codigo": "0120",
            //             "descricao": "SENHA ALTERADA COM SUCESSO",
            //             "severidade": "00"
            //         }
            //     }
            // };

            // alterarSenhaSucesso(mocksucesso);
            // return true;

            interpretadorComunicacao.interpretar(alterarValidarSenhaFactory.alterarValidarSenha(param))
                .sucesso(alterarSenhaSucesso)
                .aviso(alterarSenhaErro)
                .erro(alterarSenhaErro);


            /**
        * @ngdoc method
        * @name alterarSenhaSucesso
        *
        * @methodOf apl-mobile-pj.seguranca:alteracaoSenhaController
        *
        * @description
        * Método responsável por tratar o sucesso da chamada da factory de alterar Senha.
        **/
            function alterarSenhaSucesso(retorno) {
                if (vm.fluxoLogin) {
                    autenticarUsuario();
                }
                else {

                    vm.senhaAtual = "";
                    vm.novaSenha = "";
                    vm.confirmaSenha = "";

                    removeAlerta();
                    mostrarAlerta("success", retorno.statusProcessamento.message);
                }
            }

            /**
            * @ngdoc method
            * @name alterarSenhaErro
            *
            * @methodOf apl-mobile-pj.seguranca:alteracaoSenhaController
            *
            * @description
            * Método responsável por tratar o erro da chamada da factory de alterar Senha.
            **/
            function alterarSenhaErro(retorno) {
                mostrarAlerta("danger", retorno.statusProcessamento.message);
            }
        }

        /**
         * @description alterar senha
         */
        function alterarSenha() {
            if (validarAlteracaoSenha()) {
                transacaoAlterarSenha();
            }
        }

        /**
         * @description alterar senha do login
         */
        function alterarSenhaLogin() {
            vm.fluxoLogin = true;
            if (validarAlteracaoSenha()) {
                transacaoAlterarSenha();
            }
        }

        /**
         * @description autenticar usuario
         */
        function autenticarUsuario() {
            var param = {
                "ADSE_RC_SENHA_ATU": vm.senhaEletronica,
                "ADSE_RC_SENHA_ALT": "",
                "ADSE_RC_IC_PERFIL": "S",
                "ADSE_RC_TP_OPER": "L",
                "ADSE_RC_SENHA_BLW": "",
                "ADSE_RC_ALT_MSG": "",
                "ADSE_RC_ATIVACAO": "",
                "ADSE_RC_COD_MAQUINA": "",
                "ADSE_RC_VERSAO": "",
                "ADSE_RC_TIPO": ""
            };


            interpretadorComunicacao.interpretar(autenticarUsuarioFactory
                .autenticarUsuario(param))
                .sucesso(autenticarUsuarioSucesso)
                .aviso(autenticarUsuarioErro)
                .erro(autenticarUsuarioErro);

            /**
             * @description sucesso da autenticacao Usuario
             */
            function autenticarUsuarioSucesso(data) {
                montarPermissionamento(data);
                removeAlerta();
                navegador.navegar("login-token");
            }
            /**
             * @description erro da autenticacao Usuario
             */
            function autenticarUsuarioErro(retorno) {
                removeAlerta();
                mostrarAlerta("danger", retorno.statusProcessamento.message);
            }
        }

        /**
       * @ngdoc overview
       * @name montarPermissionamento
       * 
       * @memberOf loginController.js
       *
       * @description
       * Método executado para montar as permissões
       **/
        function montarPermissionamento(data) {
            var permissionamento = {};
            permissionamento.CONTAS = data.ADLG_EV_ITENS;
            permissionamento.GRUPO_SERVICOS = data.ADLG_EV_GRUPOS;
            permissionamento.CONTAS_POR_SERVICO = data.ADLG_EV_SERVICO;
            permissionamento.USUARIO_CPF = data.ADLG_EV_USUARIOCPF;
            permissionamento.USUARIO_DADOS = data.ADLG_EV_USUARIOCPF;
            permissionamento.MENSAGEM = data.ADLG_EV_MENSAGEM;
            permissionamento.TOKEN = data.ADLG_EV_TOKEN;

            sfContexto.definirValorContextoTrabalho("permissionamento", permissionamento);
            sfContexto.definirValorContextoTrabalho("dataUltimoAcesso", permissionamento.TOKEN.ADLG_TS_DTULAC);

            console.log(sfContexto.obterValorContextoTrabalho("permissionamento"));
        }
    }
})();
(function () {
    "use strict";

    /**
    * @ngdoc overview
    * @name apl-mobile-pj.seguranca
    * 
    * @require navegador
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Cadastro de Dispositivos.
    **/
    angular.module("apl-mobile-pj.seguranca").controller("cadastroDispositivoController", cadastroDispositivoController);

    cadastroDispositivoController.$inject = [
        "sfNavegador",
        "sfContexto",
        "interpretadorComunicacao",
        "sfDefensor",
        "sfAutenticador",
        "validarSenhaFactory"];

    /**
    * @ngdoc overview
    * @name cadastroDispositivoController
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Cadastro de Dispositivos.
    **/
    function cadastroDispositivoController(
        navegador,
        contexto,
        interpretadorComunicacao,
        sfDefensor,
        sfAutenticador,
        validarSenhaFactory) {

        var vm = this;

        vm.title = "Cadastro de Dispositivos";
        var nome = contexto.obterValorContextoTrabalho("nomeClienteUltimoAcesso");
        vm.nomeCliente = nome;
        vm.carregarCadastro = carregarCadastro;
        vm.carregarSenhaConfirmacao = carregarSenhaConfirmacao;
        vm.carregarLiberacao = carregarLiberacao;
        vm.voltar = voltar;
        vm.selecionarPrazoLiberacao = selecionarPrazoLiberacao;

        vm.alertas = [];
        vm.removeAlerta = removeAlerta;
        vm.mostrarAlerta = mostrarAlerta;
        vm.termoAlterado = termoAlterado;
        vm.sucessoIncluirMaquina = false;
        vm.voltarInicio = voltarInicio;
        vm.dataSelecionada = dataSelecionada;
        vm.selecionouIndeterminado = selecionouIndeterminado;
        vm.senha = null;
        vm.token = null;
        vm.codigoNextToken = "";
        vm.tokenValido = false;

        //TODO: Alterar o texto do termo de aceite.


        vm.termoAceito = "";

        vm.altInputFormats = ["M!/d!/yyyy"];

        vm.apelido = "";
        vm.prazoLiberacaoDeterminado = "";
        vm.CampoDataValido = false;
        vm.prazoLiberacao = "";
        vm.datePickerPrazo = {
            opened: false
        };

        vm.agora = new Date();

        vm.opcoesDatePicker = {
            dateDisabled: disabled,
            formatYear: "yy",
            maxDate: new Date(vm.agora.getFullYear(), vm.agora.getMonth(), vm.agora.getDate() + 365),
            minDate: vm.agora,
            startingDay: 0,
            showWeeks: false,
            maxMode: "day"
        };

        var cadastrarMaquinaLogin = contexto.obterValorContextoTrabalho("cadastrarMaquinaLogin");

        vm.altInputFormats = ["M!/d!/yyyy"];

        iniciar();

        /**
         * @description método responsável pela inicialização de variáveis.
         */
        function iniciar() {
            vm.codigoNextToken = "";
        }

        // Disable weekend selection
        /**
            * @ngdoc method
            * @name disabled
            *  
            * @description
            * Método de disabled do componente de data
            **/
        function disabled(data) {
            var date = data.date,
                mode = data.mode;
            var desabilita = (mode === "day" && (date.getDay() === 0 || date.getDay() === 6));
            desabilita = false;
            //Permitir inclusive final de semana
            return desabilita;
        }

        /*Funções*/

        /**
        * @ngdoc method
        * @name carregarCadastro
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para etapa de cadastro de Apelido do Dispositivo e Prazo de Liberação.
        **/
        function carregarCadastro() {
            navegador.navegar("cadastro");
        }

        /**
        * @ngdoc method
        * @name carregarSenhaConfirmacao
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para autenticação da transação por senha e token.
        **/
        function carregarSenhaConfirmacao() {
            removeAlerta();

            if (vm.prazoLiberacaoDeterminado !== "" && vm.apelido != undefined && vm.apelido != "") {
                var validaPrazo = (vm.prazoLiberacao != undefined && vm.prazoLiberacao != "" && vm.prazoLiberacao.getDate() >= vm.agora.getDate());
                var prazoDeterminado = (vm.prazoLiberacaoDeterminado == "true" || vm.prazoLiberacaoDeterminado == true);

                if (prazoDeterminado && !validaPrazo) {
                    vm.CampoDataValido = "true";
                } else {
                    vm.CampoDataValido = "false";
                }

                if (vm.termoAceito &&
                    (
                        (
                            prazoDeterminado &&
                            validaPrazo
                        )
                        ||
                        (
                            !prazoDeterminado &&
                            !validaPrazo
                        )
                    )
                ) {
                    navegador.navegar("senhaConfirmacao");
                    return true;
                } else {
                    if (!vm.termoAceito) {
                        mostrarAlerta("warning", "Termo não foi aceito.");
                    }

                    return false;
                }
            } else {
                vm.CampoDataValido = "true";
                return false;
            }
        }

        /**
        * @ngdoc method
        * @name termoAlterado
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por esconder o alerta do aceite de termo.
        **/
        function termoAlterado() {
            if (vm.termoAceito) {
                removeAlerta();
            }
        }

        /**
        * @ngdoc method
        * @name carregarLiberacao
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para tela de sucesso na liberação do dispositivo.
        **/
        function carregarLiberacao() {
            if (vm.senha == null || vm.token == null) {
                return;
            }

            var requisicao = {
                VLSE_RC_SENHA_ATU: vm.senha
            };

            interpretadorComunicacao.interpretar(validarSenhaFactory.validarSenha(requisicao))
                .sucesso(sucesso)
                .aviso(erro)
                .erro(erro);

            /**
             * @description Método de sucesso
             */
            function sucesso() {
                obterDNAIncluirMaquina();
            }

            /**
             * @description Método de erro da validação de senha
             */
            function erro(data) {
                removeAlerta();
                mostrarAlerta("danger", data.statusProcessamento.message);
            }
        }

        /**
         * @description Método responsável por obter o DNA e efetuar a inclusão da maquina
         */
        function obterDNAIncluirMaquina() {
            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var agencia = "IPJ",
                conta = dadosLogin.shortname,
                usuario = dadosLogin.username,
                tipoLogin = "PJ 1",
                applicationLayerVersion = "",
                customFields = [];


            interpretadorComunicacao.interpretar(sfDefensor.obterDNA(agencia, conta, usuario, tipoLogin, applicationLayerVersion, customFields))
                .sucesso(sucessoObterDNA)
                .aviso(erroObterDNA)
                .erro(erroObterDNA);

            /**
             * @description Método de sucesso na obtenção de DNA
             */
            function sucessoObterDNA(data) {
                incluirMaquina(data, dadosLogin.shortname, dadosLogin.username);
            }

            /**
             * @description Método de erro na obtenção de DNA
             */
            function erroObterDNA(data) {
                removeAlerta();
                mostrarAlerta("danger", data.statusProcessamento.message);
            }
        }

        /**
         * @description Método responsável por efetuar a inclusão da maquina.
         */
        function incluirMaquina(data, shortname, username) {
            var prazoLiberacaoFormatado = "";

            if (vm.prazoLiberacao != "") {
                prazoLiberacaoFormatado = vm.prazoLiberacao
                    .toISOString()
                    .slice(0, 10)
                    .replace(/-/g, "");
            } else {
                prazoLiberacaoFormatado = "99990101";
            }

            var requisicao = {
                "cipheredId": data.id,
                "cipheredKey": data.key,
                "salt": data.senha, 
                "apelidoMaquina": vm.apelido,
                "indicadorSmsLiberado": "N",
                "dataValidade": prazoLiberacaoFormatado,
                "shortname": shortname,
                "userId": username
            };

            var otp = {
                senha: vm.senha,
                serial: vm.token, //TODO: Validar o que deve ser mandado
                nextToken: vm.codigoNextToken   //Validar o momento que é preenchido
            };

            requisicao.otp = otp;
            requisicao.senha = vm.senha;

            interpretadorComunicacao.interpretar(sfDefensor.cadastrarDispositivo(requisicao))
                .sucesso(incluirMaquinaSucesso)
                .aviso(incluirMaquinaAviso)
                .erro(incluirMaquinaErro);

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno da operação de incluir as maquinas
            **/
            function incluirMaquinaSucesso(data) {
                vm.retorno = data;
                navegador.navegar("liberacao");
                vm.sucessoIncluirMaquina = true;
            }

            /**
            * @ngdoc method
            * @name erro
            *  
            * @description
            * Método de erro do retorno da operação de incluir as maquinas
            **/
            function incluirMaquinaErro(erro) {

                if (erro.httpStatusCode === 472) {
                    vm.codigoNextToken = erro.propriedades.authenticationToken[0];
                    vm.tokenValido = false;
                }

                mostrarAlerta("danger", erro.statusProcessamento.message);
            }

            /**
             * @ngdoc method
             * @name Aviso
             * 
             * @description
             * Método de aviso do retorno da operação de incluir maquinas
             */
            function incluirMaquinaAviso(erro) {
                mostrarAlerta("warning", erro.statusProcessamento.message);
            }
        }

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltar() {
            if (!vm.sucessoIncluirMaquina && cadastrarMaquinaLogin != "S") {
                navegador.voltar();
            } else {
                contexto.definirValorContextoSessao("cadastrarMaquinaLogin", "");
                voltarInicio();
            }
        }

        /**
        * @ngdoc method
        * @name voltarInicio
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltarInicio() {
            sfAutenticador.logoff().then(sucesso).catch(sucesso);

            /**
            * @description Método de sucesso para a saida da aplicação
            */
            function sucesso() {
                navegador.iniciarFluxo("apl-mobile-pj-login");
            }
        }

        /**
        * @ngdoc method
        * @name selecionarPrazoLiberacao
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por selecionar Prazo de Liberacao.
        **/
        function selecionarPrazoLiberacao() {
            vm.datePickerPrazo.aberto = true;
            selecionouIndeterminado();
        }

        /**
        * @ngdoc method
        * @name mostrarAlerta
        *  
        * @description
        * Método responsável por exibir o alerta de acordo com o retorno da comunicação
        **/
        function mostrarAlerta(tipoAlerta, textoAlerta) {
            var caminho = "./app/assets/img/Pendencias_60x60pt_Ocre.png";

            if (tipoAlerta == "danger") {
                caminho = "./app/assets/img/icone_atencao_erro.png";
            }

            vm.alertas.push({ tipo: tipoAlerta, texto: textoAlerta, caminho: caminho });
        }

        /**
        * @ngdoc method
        * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeAlerta() {
            vm.alertas = [];
        }

        /**
         * @ngdoc method
         * @name dataSelecionada
         *  
         * @description
         * Método responsável por visualizar se uma data foi selecionada na tela pelo datepicker poup
         */
        function dataSelecionada() {
            if (vm.prazoLiberacao != undefined && vm.prazoLiberacao != null && vm.prazoLiberacao != "") {
                vm.prazoLiberacaoDeterminado = "true";
            } else {
                selecionarPrazoLiberacao();
            }
        }

        /**
         * @ngdoc method
         * @name selecionouIndeterminado
         *  
         * @description
         * 
         */
        function selecionouIndeterminado() {
            //TODO XASAN MERGE ARQ -- Ver o pq dessa logica com o responsável
            if (vm.prazoLiberacao == "") {
                vm.prazoLiberacao = "";
            }
        }
    }
})();
(function () {

    "use strict";

    angular.module("apl-mobile-pj.seguranca").factory("liberarExcluirMaquinasFactory", liberarExcluirMaquinasFactory);

    liberarExcluirMaquinasFactory.$inject = ["sfConectorAPI"];

    /*Funções*/
    /**
    * @ngdoc method
    * @name iniciar
    *  
    * @description
    * Factory responsável por definir todas as funções utilizadas na gestão de máquinas
    **/
    function liberarExcluirMaquinasFactory(conectorAPI) {

        return {
            liberarExcluirMaquinas: liberarExcluirMaquinas
        };

        /**
        * @ngdoc method
        * @name iniciar
        *  
        * @description
        * Função responsável por liberar as máquinas
        **/
        function liberarExcluirMaquinas(maquinas, senha, token) {
            var otp = {
                senha: token,
                serial: "1324" //TODO XASAN Obter o serial do login
            };

            maquinas.otp = otp;
            maquinas.senha = senha;

            var req = {
                method: "POST",
                url: "liberar-excluir-maquinas",
                data: maquinas,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();
(function () {

    "use strict";

    angular.module("apl-mobile-pj.seguranca").factory("listarMaquinasFactory", listarMaquinasFactory);

    listarMaquinasFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/
    /**
    * @ngdoc method
    * @name iniciar
    *  
    * @description
    * Factory responsável por definir todas as funções utilizadas na gestão de máquinas
    **/
    function listarMaquinasFactory(conectorAPI, appSettings, utilitarios) {

        return {
            listarMaquinasLiberadas: listarMaquinasLiberadas
        };

        /**
        * @ngdoc method
        * @name iniciar
        *  
        * @description
        * Função responsável por consultar as máquinas liberadas
        **/
        function listarMaquinasLiberadas(PLLU_RC_CHCLI,PLLU_RC_TPCON) {
            var param = { 
                "PLLU_RC_CHCLI": PLLU_RC_CHCLI,
                "PLLU_RC_TPCON": PLLU_RC_TPCON
             };

            var req = {

                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "listar-maquinas-liberadas"]), 
                data: param,
                dataType: "json"
            };
            
            return conectorAPI.executar(req, true);
        }       
    }
    
    
})();
(function () {

    "use strict";

    angular.module("apl-mobile-pj.seguranca").factory("listarMaquinasPendentesFactory", listarMaquinasPendentesFactory);

    listarMaquinasPendentesFactory.$inject = ["sfConectorAPI"];
    
    /*Funções*/
    /**
    * @ngdoc method
    * @name iniciar
    *  
    * @description
    * Factory responsável por definir todas as funções utilizadas na gestão de máquinas
    **/
    function listarMaquinasPendentesFactory(conectorAPI) {

        return {
            listarMaquinasPendentes: listarMaquinasPendentes
        };

        /**
        * @ngdoc method
        * @name iniciar
        *  
        * @description
        * Função responsável por consultar as máquinas liberadas
        **/
        function listarMaquinasPendentes(PLLM_RC_CHCLI) {
            var param = {
                "PLLM_RC_CHCLI": PLLM_RC_CHCLI
             };

            var req = {
                method: "POST",
                url: "listar-maquinas-pendentes",
                data: param,
                dataType: "json"
            };
            
            return conectorAPI.executar(req, true);
        }
             
    }
    
    
})();