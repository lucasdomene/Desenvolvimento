(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name obterNomeUsuarioFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:obterNomeUsuarioFactory
    *
    * @description
    * Factory de conexão com API obterNomeUsuarioFactory
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .factory("obterNomeUsuarioFactory", obterNomeUsuarioFactory);

    obterNomeUsuarioFactory.$inject = ["sfConectorAPI", "sfContexto"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name obterNomeUsuario
    *
    * @methodOf apl-mobile-pj.extrato:obterNomeUsuarioFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function obterNomeUsuarioFactory(conectorAPI, sfContexto) {

        return {
            obterNomeUsuario: obterNomeUsuario
        };

        /**
        * @ngdoc method
        * @name obterNomeUsuario
        *
        * @methodOf apl-mobile-pj.extrato:obterNomeUsuario
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function obterNomeUsuario() {

            var dadosShortnameUsername = sfContexto.obterValorContextoTrabalho("dadosLogin");

            var req = {
                method: "POST",
                url: "obter-nome-usuario",
                data: {
                    "shortname": dadosShortnameUsername.shortname,
                    "userId": dadosShortnameUsername.username
                },
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();