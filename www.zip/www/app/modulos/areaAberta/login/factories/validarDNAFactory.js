(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name validarDNAFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:validarDNAFactory
    *
    * @description
    * Factory de conexão com API validarDNAFactory
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .factory("validarDNAFactory", validarDNAFactory);

    validarDNAFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name validarDNA
    *
    * @methodOf apl-mobile-pj.extrato:validarDNAFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function validarDNAFactory(conectorAPI, appSettings, utilitarios) {

        return {
            validarDNA: validarDNA
        };

        /**
        * @ngdoc method
        * @name validarDNA
        *
        * @methodOf apl-mobile-pj.extrato:validarDNA
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function validarDNA(requisicao) {

            var param = requisicao;

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "validar-dna-maquina"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();