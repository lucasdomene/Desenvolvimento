(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarCotacoesFactoryFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:listarCotacoesFactoryFactory
    *
    * @description
    * Factory de conexão com API listarCotacoesFactory
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .factory("listarCotacoesFactory", listarCotacoesFactory);

    listarCotacoesFactory.$inject = ["sfConectorAPI"];

    /**
    * @ngdoc method
    * @name  listarCotacoesFactory
    *
    * @methodOf apl-mobile-pj.areaAberta: listarCotacoesFactoryFactory
    *
    * @description
    * Contem as definições da factory.
    **/
    function listarCotacoesFactory(conectorAPI) {
        return {
            listarCotacoes: listarCotacoes
        };

        /*Funções*/

        /**
        * @ngdoc method
        * @name listarCotacoesService
        *
        * @methodOf apl-mobile-pj.nomeModulo:listarCotacoesFactory
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarCotacoes() {

            var req = {
                method: "POST",
                url: "listar-cotacoes",
                dataType: "json"
            };
            return conectorAPI.executar(req, false);
        }
    }

})();