(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarMoedasFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:listarMoedasFactory
    *
    * @description
    * Factory de conexão com API listarMoedas
    **/
    angular.module("apl-mobile-pj.areaAberta")
        .factory("listarMoedasFactory", listarMoedasFactory);

    listarMoedasFactory.$inject = ["sfConectorAPI"];

    /**
    * @ngdoc method
    * @name  listarMoedas
    *
    * @methodOf apl-mobile-pj.areaAberta: listarMoedasFactory
    *
    * @description
    * Contem as definições da factory.
    **/
    function listarMoedasFactory(conectorAPI) {
        return {
            listarMoedas: listarMoedas
        };

        /*Funções*/

        /**
        * @ngdoc method
        * @name listarCotacoesService
        *
        * @methodOf apl-mobile-pj.areaAberta:listarMoedas
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarMoedas() {

            var req = {
                method: "POST",
                url: "listar-moedas",
                dataType: "json"
            };
            return conectorAPI.executar(req, false);
        }
    }

})();