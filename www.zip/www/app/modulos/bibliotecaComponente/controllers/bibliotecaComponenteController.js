(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name apl-mobile-pj.bibliotecaComponente
     * 
     * @require navegador
     * 
     * @description
     * Controller responsável pela tratativa das ações a serem realizadas na Biblioteca de Componentes.
     **/
    angular.module("apl-mobile-pj.bibliotecaComponente").controller("bibliotecaComponenteController", bibliotecaComponenteController);

    bibliotecaComponenteController.$inject = ["sfNavegador"];

    /*Funções*/
    /**
    * @ngdoc method
    * @name bibliotecaComponenteController
    *
    * @methodOf apl-mobile-pj.bibliotecaComponente
    *  
    * @description
    * Método responsável por criar controller da biblioteca de Componente
    **/
    function bibliotecaComponenteController(navegador) {

        var vm = this;

        vm.carregarCadastroNovoDispositivos = carregarCadastroDispositivos;
        vm.carregarExtratoMovimentacao = carregarExtratoMovimentacao;
        vm.carregarAutorizacaoPagamento = carregarAutorizacaoPagamento;
        vm.listarMaquinas = listarMaquinas;

        /*Funções*/

        /**
         * @ngdoc method
         * @name carregarCadastroDispositivos
         * 
         * @memberOf apl-mobile-pj.bibliotecaComponente
         * 
         * @description
         * Método responsável por navegar para a tela de cadastro de dispositivos.
         */
        function carregarCadastroDispositivos() {
            navegador.navegar("seguranca.novo-dispositivo-novo-acesso");
        }

        /**
        * @ngdoc method
        * @name carregarExtratoMovimentacao
        * 
        * @memberOf apl-mobile-pj.bibliotecaComponente
        * 
        * @description
        * Método responsável por navegar para a tela de extrato de movimentacao.
        */
        function carregarExtratoMovimentacao() {
            navegador.navegar("extrato.extrato.extrato-Movimentacao");
        }
        
        /**
        * @ngdoc method
        * @name carregarAutorizacaoPagamento
        * 
        * @memberOf apl-mobile-pj.bibliotecaComponente
        * 
        * @description
        * Método responsável por navegar para a tela de extrato de movimentacao.
        */
        function carregarAutorizacaoPagamento() {
            navegador.navegar("autorizacao.pagamento");
        }

        /**
         * @ngdoc method
         * @name listarMaquinas
         * 
         * @memberOf apl-mobile-pj.bibliotecaComponentes
         * 
         * @description
         * Método responsável por executar a listagem de maquinas
         */
        function listarMaquinas() {
            navegador.navegar("seguranca.listagem-maquinas-liberadas-pendentes");
        }


        vm.today = function () {
            vm.dt = new Date();
        };
        vm.today();

        vm.clear = function () {
            vm.dt = null;
        };

        vm.inlineOptions = {
            customClass: getDayClass,
            minDate: new Date(),
            showWeeks: true
        };

        vm.dateOptions = {
            dateDisabled: disabled,
            formatYear: "yy",
            maxDate: new Date(2020, 5, 22),
            minDate: new Date(2016, 6, 20),
            startingDay: 0,
            showWeeks: false,
            maxMode: "day"
        };

        // Disable weekend selection
        /**
            * @ngdoc method
            * @name disabled
            *  
            * @description
            * Método de disabled do componente de data
            **/
        function disabled(data) {
            var date = data.date,
                mode = data.mode;
            return mode === "day" && (date.getDay() === 0 || date.getDay() === 6);
        }

        vm.toggleMin = function () {
            vm.inlineOptions.minDate = new Date();
            vm.dateOptions.minDate = vm.inlineOptions.minDate;
        };

        vm.toggleMin();

        vm.open1 = function () {
            console.log("vm.open1");
            vm.popup1.opened = true;
        };

        vm.open2 = function () {
            console.log("vm.open2");
            vm.popup2.opened = true;
        };

        vm.setDate = function (year, month, day) {
            vm.dt = new Date(year, month, day);
        };

        vm.formats = ["dd-MMMM-yyyy", "yyyy/MM/dd", "dd.MM.yyyy", "shortDate"];
        vm.format = vm.formats[0];
        vm.altInputFormats = ["M!/d!/yyyy"];

        vm.popup1 = {
            opened: false
        };

        vm.popup2 = {
            opened: false
        };

        var tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        var afterTomorrow = new Date();
        afterTomorrow.setDate(tomorrow.getDate() + 1);
        vm.events = [
            {
                date: tomorrow,
                status: "full"
            },
            {
                date: afterTomorrow,
                status: "partially"
            }
        ];

        /**
            * @ngdoc method
            * @name getDayClass
            *  
            * @description
            * Método de getDayClass do componente de data
            **/
        function getDayClass(data) {
            var date = data.date,
                mode = data.mode;
            if (mode === "day") {
                var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

                for (var i = 0; i < vm.events.length; i++) {
                    var currentDay = new Date(vm.events[i].date).setHours(0, 0, 0, 0);

                    if (dayToCheck === currentDay) {
                        return vm.events[i].status;
                    }
                }
            }

            return "";
        }
    }
})();




