(function () {

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.bibliotecaComponente
     *
     * @require apl-mobile-pj.comum, apl-mobile-pj.seguranca, ui.bootstrap, ngAnimate
     *  
     * @description
     * Módulo que define os fluxos de navegacao na biblioteca de componentes.
     **/
    angular.module("apl-mobile-pj.bibliotecaComponente", [
        "ui.bootstrap", "ngAnimate"]).config(bibliotecaComponenteModule);

    bibliotecaComponenteModule.$inject = ["sfNavegadorProvider"];

    /**
    * @ngdoc overview
    * @name bibliotecaComponenteModule
    * 
    * @description
    * Navegação do módulo bibliotecaComponenteModule.
    **/
    function bibliotecaComponenteModule(sfNavegadorProvider) {
        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-biblioteca-componente")
                .adicionarEstado("bibliotecaComponente", {
                    templateUrl: "./app/modulos/bibliotecaComponente/views/bibliotecaComponente.html",
                    controller: "bibliotecaComponenteController as bcCtrl"
                }, [
                    {
                        acao: "seguranca.novo-dispositivo-novo-acesso",
                        fluxo: "apl-mobile-pj-novo-dispositivo"
                    },
                    {
                        acao: "seguranca.listagem-maquinas-liberadas-pendentes",
                        fluxo: "apl-mobile-pj-seguranca"
                    },
                    {
                        acao: "extrato.extrato.extrato-Movimentacao",
                        fluxo: "apl-mobile-pj-extrato"
                    },
                    {
                        acao: "autorizacao.pagamento",
                        fluxo: "apl-mobile-pj-autorizacaoPagamento"
                    }
                ])
                .definirEstadoInicial("bibliotecaComponente")
        );
    }
})();