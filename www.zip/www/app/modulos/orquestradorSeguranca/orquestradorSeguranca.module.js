/**
* @ngdoc overview
* @name apl-mobile-pj.orquestradorSeguranca
*
* @require apl-mobile-pj.comum
*
* @description
* DescricaoComentario
**/
angular.module("apl-mobile-pj.orquestradorSeguranca", [])
    .config(orquestradorSegurancaModulo);

orquestradorSegurancaModulo.$inject = ["sfNavegadorProvider"];

/**
* @ngdoc method
* @name apl-mobile-pj.orquestradorSeguranca
*
* @param {provider} navegadorProvider instancia do navegadorProvider
*
* @description
* metodo responsavel por inicar o modulo.
**/
function orquestradorSegurancaModulo(sfNavegadorProvider) {
   sfNavegadorProvider.adicionarFluxoNavegacao(
        sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-orquestrador-seguranca")
            .adicionarEstado("orquestrar", {
                template: "<div></div>",
                controller: "orquestradorSegurancaController as osCtrl"
            }, [
                {
                    acao: "home",
                    fluxo: "apl-mobile-pj-home"
                },
                {
                    acao: "gestao-maquinas",
                    fluxo: "apl-mobile-pj-seguranca"
                },
                {
                    acao: "alterar-senha",
                    fluxo: "apl-mobile-pj-alterar-senha"
                }
            ])
            .definirEstadoInicial("orquestrar")
    );
}