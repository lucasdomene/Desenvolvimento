(function () {

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.seguranca
     * 
     * @require ui.bootstrap, ngAnimate
     * 
     * @description
     * Módulo que define os fluxos de navegacao pelos controles de cadastro e liberação de dispositivos.
     **/
    angular.module("apl-mobile-pj.seguranca", ["ui.bootstrap", "ngAnimate"])
        .config(segurancaModule)
        .run(["sfTradutor", function (tradutor) {
            tradutor.adicionarDicionarios(
                [
                    "app/modulos/seguranca/cadastroDispositivo/internacionalizacao",
                    "app/modulos/seguranca/gestaoMaquinas/internacionalizacao",
                    "app/modulos/seguranca/ativarToken/internacionalizacao"
                    
                ]
            );
        }]);

    segurancaModule.$inject = ["sfNavegadorProvider"];

    /**
    * @ngdoc overview
    * @name segurancaModule
    * 
    * @description
    * Navegação do módulo segurancaModule.
    **/
    function segurancaModule(sfNavegadorProvider) {
        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-seguranca")
                .adicionarEstado("segurancaMaquina", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/segurancaMaquina.html",
                    controller: "gestaoMaquinasController as gmCtrl",
                    abstract: true
                })

                .adicionarEstado("segurancaMaquina.gestao-maquinas", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/gestaoMaquinas.html",
                    parent: "segurancaMaquina"
                },
                [
                    {
                        acao: "liberar-maquinas",
                        estadoDestino: "segurancaMaquina.liberar.liberar-maquinas"
                    },
                    {
                        acao: "excluir-maquinas",
                        estadoDestino: "segurancaMaquina.excluir.excluir-maquinas"
                    }
                ])

                .adicionarEstado("segurancaMaquina.liberar", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/liberar.html",
                    parent: "segurancaMaquina",
                    abstract: true
                })

                .adicionarEstado("segurancaMaquina.liberar.liberar-maquinas", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/liberarMaquinas.html",
                    parent: "segurancaMaquina.liberar"
                },
                [
                    {
                        acao: "sucesso-validacao-senha",
                        estadoDestino: "segurancaMaquina.liberar.sucesso"
                    }
                ])

                .adicionarEstado("segurancaMaquina.liberar.sucesso", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/sucessoLiberacao.html",
                    parent: "segurancaMaquina.liberar"
                },
                [
                    {
                        acao: "voltar-inicio",
                        estadoDestino: "segurancaMaquina.gestao-maquinas"
                    }
                ])

                .adicionarEstado("segurancaMaquina.excluir", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/excluir.html",
                    parent: "segurancaMaquina",
                    abstract: true
                })

                .adicionarEstado("segurancaMaquina.excluir.excluir-maquinas", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/excluirMaquinas.html",
                    parent: "segurancaMaquina.excluir"
                },
                [
                    {
                        acao: "sucesso-validacao-senha",
                        estadoDestino: "segurancaMaquina.excluir.sucesso"
                    }
                ])

                .adicionarEstado("segurancaMaquina.excluir.sucesso", {
                    templateUrl: "./app/modulos/seguranca/gestaoMaquinas/views/sucessoExclusao.html",
                    parent: "segurancaMaquina.excluir"
                },
                [
                    {
                        acao: "voltar-inicio",
                        estadoDestino: "segurancaMaquina.gestao-maquinas"
                    }
                ])

                .definirEstadoInicial("segurancaMaquina.gestao-maquinas")
        );

        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-novo-dispositivo")
                .adicionarEstado("novo-dispositivo", {
                    templateUrl: "./app/modulos/seguranca/cadastroDispositivo/views/cabecalho.html",
                    controller: "cadastroDispositivoController as cdCtrl",
                    abstract: true
                })

                .adicionarEstado("novo-dispositivo.novo-acesso", {
                    templateUrl: "./app/modulos/seguranca/cadastroDispositivo/views/novoAcesso.html",
                    parent: "novo-dispositivo"
                },
                [
                    {
                        acao: "cadastro",
                        estadoDestino: "novo-dispositivo.cadastro"
                    }
                ])

                .adicionarEstado("novo-dispositivo.cadastro", {
                    templateUrl: "./app/modulos/seguranca/cadastroDispositivo/views/cadastro.html",
                    parent: "novo-dispositivo"
                },
                [
                    {
                        acao: "senhaConfirmacao",
                        estadoDestino: "novo-dispositivo.senha-confirmacao"
                    }
                ])

                .adicionarEstado("novo-dispositivo.senha-confirmacao", {
                    templateUrl: "./app/modulos/seguranca/cadastroDispositivo/views/senhaConfirmacao.html",
                    parent: "novo-dispositivo"
                },
                [
                    {
                        acao: "liberacao",
                        estadoDestino: "novo-dispositivo.liberacao"
                    }
                ])

                .adicionarEstado("novo-dispositivo.liberacao", {
                    templateUrl: "./app/modulos/seguranca/cadastroDispositivo/views/liberacao.html",
                    parent: "novo-dispositivo"
                })

                .definirEstadoInicial("novo-dispositivo.novo-acesso")
        );

        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-alterar-senha")
                .adicionarEstado("alterar-senha-cabecalho", {
                    templateUrl: "./app/modulos/seguranca/alteracaoSenha/views/alterarSenhaLogin.html",
                    controller: "gestaoMaquinasController as gmCtrl",
                    abstract: true
                })
                .adicionarEstado("alterar-senha", {
                    templateUrl: "./app/modulos/seguranca/alteracaoSenha/views/alteracaoSenha.html",
                    parent: "alterar-senha-cabecalho"
                },
                [
                    {
                        acao: "login-token",
                        fluxo: "apl-mobile-pj-ativar-token"
                    }
                ])
                .definirEstadoInicial("alterar-senha")
        );

        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-ativar-token")
                .adicionarEstado("ativacao-token-cabecalho", {
                    templateUrl: "./app/modulos/seguranca/ativarToken/views/ativacaoTokenCabecalho.html",
                    controller: "ativarTokenController as attokCtrl",
                    abstract: true
                })
                .adicionarEstado("dados-token", {
                    templateUrl: "./app/modulos/seguranca/ativarToken/views/dados.html",
                    parent: "ativacao-token-cabecalho"
                },
                [
                    {
                        acao: "validar-senha-ativacao",
                        estadoDestino: "seguranca-token"
                    }
                ])
                .adicionarEstado("seguranca-token", {
                    templateUrl: "./app/modulos/seguranca/ativarToken/views/seguranca.html",
                    parent: "ativacao-token-cabecalho"
                },
                [
                    {
                        acao: "ativar-token",
                        estadoDestino: "ativacao-token"
                    }
                ])
                .adicionarEstado("ativacao-token", {
                    templateUrl: "./app/modulos/seguranca/ativarToken/views/ativacao.html",
                    parent: "ativacao-token-cabecalho"
                },
                [
                    {
                        acao: "token-ativo",
                        fluxo: "apl-mobile-pj-home"
                    }
                ])
                .definirEstadoInicial("dados-token")
        );

    }
})();