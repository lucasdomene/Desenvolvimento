(function () {

    "use strict";

    angular.module("apl-mobile-pj.seguranca").factory("listarMaquinasFactory", listarMaquinasFactory);

    listarMaquinasFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/
    /**
    * @ngdoc method
    * @name iniciar
    *  
    * @description
    * Factory responsável por definir todas as funções utilizadas na gestão de máquinas
    **/
    function listarMaquinasFactory(conectorAPI, appSettings, utilitarios) {

        return {
            listarMaquinasLiberadas: listarMaquinasLiberadas
        };

        /**
        * @ngdoc method
        * @name iniciar
        *  
        * @description
        * Função responsável por consultar as máquinas liberadas
        **/
        function listarMaquinasLiberadas(PLLU_RC_CHCLI,PLLU_RC_TPCON) {
            var param = { 
                "PLLU_RC_CHCLI": PLLU_RC_CHCLI,
                "PLLU_RC_TPCON": PLLU_RC_TPCON
             };

            var req = {

                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "listar-maquinas-liberadas"]), 
                data: param,
                dataType: "json"
            };
            
            return conectorAPI.executar(req, true);
        }       
    }
    
    
})();