(function () {

    "use strict";

    angular.module("apl-mobile-pj.seguranca").factory("liberarExcluirMaquinasFactory", liberarExcluirMaquinasFactory);

    liberarExcluirMaquinasFactory.$inject = ["sfConectorAPI"];

    /*Funções*/
    /**
    * @ngdoc method
    * @name iniciar
    *  
    * @description
    * Factory responsável por definir todas as funções utilizadas na gestão de máquinas
    **/
    function liberarExcluirMaquinasFactory(conectorAPI) {

        return {
            liberarExcluirMaquinas: liberarExcluirMaquinas
        };

        /**
        * @ngdoc method
        * @name iniciar
        *  
        * @description
        * Função responsável por liberar as máquinas
        **/
        function liberarExcluirMaquinas(maquinas, senha, token) {
            var otp = {
                senha: token,
                serial: "1324" //TODO XASAN Obter o serial do login
            };

            maquinas.otp = otp;
            maquinas.senha = senha;

            var req = {
                method: "POST",
                url: "liberar-excluir-maquinas",
                data: maquinas,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();