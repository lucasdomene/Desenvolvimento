(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.seguranca.gestaoMaquinasController
     * 
     * @requires navegador
     * 
     * @description
     * Controller responsável pela tratativa das ações a serem realizadas na view Gestao de Maquinas.
     **/
    angular.module("apl-mobile-pj.seguranca").controller("gestaoMaquinasController", gestaoMaquinasController);

    gestaoMaquinasController.$inject =
        [
            "sfNavegador",
            "sfContexto",
            "listarMaquinasFactory",
            "listarMaquinasPendentesFactory",
            "liberarExcluirMaquinasFactory",
            "alterarValidarSenhaFactory",
            "modal",
            "interpretadorComunicacao",
            "autenticarUsuarioFactory"
        ];

    /*
    * @description
    * 
    */
    /**
     * @ngdoc overview
     * @name apl-mobile-pj.seguranca.gestaoMaquinasController
     * @description
     * Controller Gestao de Maquinas.
     **/
    function gestaoMaquinasController(
        navegador,
        sfContexto,
        listarMaquinasFactory,
        listarMaquinasPendentesFactory,
        liberarExcluirMaquinasFactory,
        alterarValidarSenhaFactory,
        modal,
        interpretadorComunicacao,
        autenticarUsuarioFactory) {
        var vm = this;

        vm.amimationsEnabled = true;
        vm.voltar = voltar;
        vm.voltarInicioLiberacao = voltarInicioLiberacao;
        vm.voltarInicioExclusao = voltarInicioExclusao;
        vm.selecionarTodosPendentes = selecionarTodosPendentes;
        vm.selecionarTodosLiberados = selecionarTodosLiberados;
        vm.carregarLiberarMaquinas = carregarLiberarMaquinas;
        vm.carregarExcluirMaquinas = carregarExcluirMaquinas;
        vm.atualizarchkTodasMaquinasLiberadas = atualizarchkTodasMaquinasLiberadas;
        vm.atualizarchkTodasMaquinasPendentes = atualizarchkTodasMaquinasPendentes;
        vm.confirmarSenhaToken = confirmarSenhaToken;
        vm.liberarExcluir = liberarExcluir;
        vm.confirmarLiberarMaquinas = confirmarLiberarMaquinas;
        vm.confirmarExcluirMaquinas = confirmarExcluirMaquinas;
        vm.obterListaLiberarMaquinas = obterListaLiberarMaquinas;
        vm.obterListaExcluirMaquinasLiberadas = obterListaExcluirMaquinasLiberadas;
        vm.obterListaExcluirMaquinasPendentes = obterListaExcluirMaquinasPendentes;
        vm.listarMaquinasLiberadas = listarMaquinasLiberadas;
        vm.acaoLiberadas = acaoLiberadas;

        vm.alertas = [];
        vm.removeAlerta = removeAlerta;
        vm.mostrarAlerta = mostrarAlerta;

        iniciar();

        /*Funções*/

        /**
        * @ngdoc method
        * @name iniciar
        *
        * @methodOf apl-mobile-pj.home
        *  
        * @description
        * Método responsável por carregar o estado inicial dos elementos da view.
        **/
        function iniciar() {
            vm.paginaMaquinas = {
                visivel: true
            };
            vm.paginaSenha = {
                visivel: false
            };

            vm.exibeMenuPaginaSenha = false;
            if (sfContexto.obterValorContextoTrabalho("usuarioLogadoSemPermissaoMaquinas"))
            {
                vm.exibeMenuPaginaSenha = true;                
            }                

            vm.senha = "";
            vm.token = "";

            vm.listaMaquinasPendentes = {
                visivel: true
            };

            vm.listaMaquinasLiberadas = {
                visivel: false,
                carregada: false
            };

            vm.existemMaquinasPendentes = true;
            vm.existemMaquinasLiberadas = true;

            vm.chkTodasMaquinasPendentes = false;
            vm.chkTodasMaquinasLiberadas = false;

            vm.habilitarExcluirPendentes = true;
            vm.habilitarExcluirLiberados = true;

            vm.habilitarLiberarPendentes = true;

            vm.voltarInicio = false;

            vm.fluxoLogin = false;

            listarMaquinasPendentes();
        }

        /**
        * @ngdoc method
        * @name listarMaquinasLiberadas
        *  
        * @description
        * Método responsável por chamar o serviço que consulta as maquinas liberadas
        **/
        function listarMaquinasLiberadas() {
            vm.habilitarLiberarPendentes = true;
            vm.habilitarExcluirPendentes = true;
            vm.habilitarExcluirLiberados = true;

            var dadosLogin = sfContexto.obterValorContextoTrabalho("dadosLogin");
            var PLLU_RC_CHCLI = dadosLogin.shortname;//"VALISERE";

            var PLLU_RC_TPCON = "S";

            interpretadorComunicacao.interpretar(listarMaquinasFactory.listarMaquinasLiberadas(PLLU_RC_CHCLI, PLLU_RC_TPCON))
                .sucesso(sucesso)
                .aviso(erro)
                .erro(erro);

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno da consulta as maquinas liberadas
            **/
            function sucesso(data) {
                vm.maquinasLiberadas = data.PLLU_EV_OCOR;

                if (vm.maquinasLiberadas != undefined && vm.maquinasLiberadas.length > 0) {
                    vm.existemMaquinasLiberadas = true;
                    vm.listaMaquinasLiberadas.carregada = true;
                } else {
                    vm.existemMaquinasLiberadas = false;
                }
            }

            /**
           * @ngdoc method
           * @name erro
           *  
           * @description
           * Método de erro do retorno da consulta as maquinas liberadas
           **/
            function erro(erro) {
                console.log("Erro ao listar maquinas:" + JSON.stringify(erro));
                vm.existemMaquinasLiberadas = false;
            }
        }

        /**
        * @ngdoc method
        * @name listarMaquinasPendentes
        *  
        * @description
        * Método responsável por chamar o serviço que consulta as maquinas Pendentes
        **/
        function listarMaquinasPendentes() {
            vm.habilitarLiberarPendentes = true;
            vm.habilitarExcluirPendentes = true;
            vm.habilitarExcluirLiberados = true;

            var dadosLogin = sfContexto.obterValorContextoTrabalho("dadosLogin");
            var PLLM_RC_CHCLI = dadosLogin.shortname;//"VALISERE";

            interpretadorComunicacao.interpretar(listarMaquinasPendentesFactory.listarMaquinasPendentes(PLLM_RC_CHCLI))
                .sucesso(sucesso)
                .aviso(erro)
                .erro(erro);

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno da consulta as maquinas Pendentes
            **/
            function sucesso(data) {
                vm.maquinasPendentes = data.PLLM_EV_OCOR;

                if (vm.maquinasPendentes != undefined && vm.maquinasPendentes.length > 0) {
                    vm.existemMaquinasPendentes = true;
                } else {
                    vm.existemMaquinasPendentes = false;
                }
            }

            /**
           * @ngdoc method
           * @name erro
           *  
           * @description
           * Método de erro do retorno da consulta as maquinas Pendentes
           **/
            function erro(erro) {
                console.log("Erro ao listar maquinas:" + JSON.stringify(erro));
                vm.existemMaquinasPendentes = false;
            }
        }

        /**
        * @ngdoc method
        * @name selecionarTodosPendentes
        *  
        * @description
        * Método responsável selecionar todos as máquinas pendentes
        **/
        function selecionarTodosPendentes() {
            var selecionado = vm.chkTodasMaquinasPendentes;
            for (var OCOR in vm.maquinasPendentes) {
                var element = vm.maquinasPendentes[OCOR];
                element.selecionado = selecionado;
            }

            if (selecionado) {
                vm.habilitarLiberarPendentes = false;
                vm.habilitarExcluirPendentes = false;
            } else {
                vm.habilitarLiberarPendentes = true;
                vm.habilitarExcluirPendentes = true;
            }
        }

        /**
        * @ngdoc method
        * @name selecionarTodosLiberados
        *  
        * @description
        * Método responsável selecionar todos as máquinas liberadas
        **/
        function selecionarTodosLiberados() {
            var selecionado = vm.chkTodasMaquinasLiberadas;
            for (var OCOR in vm.maquinasLiberadas) {
                var element = vm.maquinasLiberadas[OCOR];
                element.selecionado = selecionado;
            }

            if (selecionado) {
                vm.habilitarExcluirLiberados = false;
            } else {
                vm.habilitarExcluirLiberados = true;
            }
        }

        /**
        * @ngdoc method
        * @name atualizarchkTodasMaquinasLiberadas
        *  
        * @description
        * Método responsável atualizar variavel que controle o check todos as máquinas liberadas
        **/
        function atualizarchkTodasMaquinasLiberadas() {
            var itensSelecionados = vm.maquinasLiberadas.filter(function (item) {
                return item.selecionado;
            });

            vm.chkTodasMaquinasLiberadas = (itensSelecionados.length == vm.maquinasLiberadas.length);

            if (itensSelecionados.length > 0) {
                vm.habilitarExcluirLiberados = false;
            } else {
                vm.habilitarExcluirLiberados = true;
            }
        }


        /**
        * @ngdoc method
        * @name atualizarchkTodasMaquinasPendentes
        *  
        * @description
        * Método responsável atualizar variavel que controle o check todos as máquinas pendentes
        **/
        function atualizarchkTodasMaquinasPendentes() {
            var itensSelecionados = vm.maquinasPendentes.filter(function (item) {
                return item.selecionado;
            });

            vm.chkTodasMaquinasPendentes = (itensSelecionados.length == vm.maquinasPendentes.length);

            if (itensSelecionados.length > 0) {
                vm.habilitarLiberarPendentes = false;
                vm.habilitarExcluirPendentes = false;
            } else {
                vm.habilitarLiberarPendentes = true;
                vm.habilitarExcluirPendentes = true;
            }
        }


        /**
        * @ngdoc method
        * @name carregarLiberarExcluirMaquinas
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela de liberar máquina.
        **/
        function carregarLiberarMaquinas() {
            vm.obterListaLiberarMaquinas();
            navegador.navegar("liberar-maquinas");
        }

        /**
        * @ngdoc method
        * @name obterListaLiberarMaquinas
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por obter Lista LiberarMaquinas.
        **/
        function obterListaLiberarMaquinas() {
            var maquinas = [];

            var itens = vm.maquinasPendentes.filter(function (item) {
                return item.selecionado == "true" || item.selecionado == true;
            });

            for (var item in itens) {
                var element = itens[item];
                var maquina =
                    {
                        "PLMM_RC_OPCAO": "L",
                        "PLMM_RC_CHCLI": element.PLLM_EV_CHCLI,
                        "PLMM_RC_CDMAQ": element.PLLM_EV_CHMAQ,
                        "PLMM_RC_CDMAQ_LIB": "9CAD0131816C53DC", //TODO: Obter esse valor pela arquitetura -- codigo da maquina local
                        "PLMM_RC_CHAVE_LIB": "",
                        "PLMM_RC_MOT_BLOQ": "",
                        "PLMM_RC_DTVAL_LIB": element.PLLM_EV_DTVAL
                    };
                maquinas.push(maquina);

            }

            sfContexto.definirValorContextoTrabalho("listaMaquinasPendentes", maquinas);
        }

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela anterior.
        **/
        function voltar() {
            removeAlerta();
            vm.voltarInicio = false;
            navegador.voltar();
        }

        /**
        * @ngdoc method
        * @name voltarInicioLiberacao
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela inicial.
        **/
        function voltarInicioLiberacao() {
            if (vm.listaMaquinasLiberadas.visivel) {
                listarMaquinasLiberadas();
            }

            if (vm.listaMaquinasPendentes.visivel) {
                listarMaquinasPendentes();
            }

            removeAlerta();

            navegador.navegar("voltar-inicio");
            vm.voltarInicio = false;
        }

        /**
        * @ngdoc method
        * @name voltarInicioExclusao
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela inicial.
        **/
        function voltarInicioExclusao() {
            if (vm.listaMaquinasLiberadas.visivel) {
                listarMaquinasLiberadas();
            }

            if (vm.listaMaquinasPendentes.visivel) {
                listarMaquinasPendentes();
            }

            removeAlerta();

            navegador.navegar("voltar-inicio");
            vm.voltarInicio = false;
        }

        /**
        * @ngdoc method
        * @name carregarLiberarExcluirMaquinas
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela de excluir máquina.
        **/
        function carregarExcluirMaquinas() {
            if (vm.listaMaquinasPendentes.visivel) {
                vm.obterListaExcluirMaquinasPendentes();
            } else {
                vm.obterListaExcluirMaquinasLiberadas();
            }

            navegador.navegar("excluir-maquinas");
        }

        /**
        * @ngdoc method
        * @name obterListaExcluirMaquinasPendentes
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela de excluir máquina.
        **/
        function obterListaExcluirMaquinasPendentes() {
            var maquinas = [];

            var PLLM_EV_OCOR = vm.maquinasPendentes.filter(function (OCORP) {
                return OCORP.selecionado == "true" || OCORP.selecionado == true;
            });

            for (var OCORP in PLLM_EV_OCOR) {
                var elementPendente = PLLM_EV_OCOR[OCORP];
                var maquinaPendente =
                    {
                        "PLMM_RC_OPCAO": "E",
                        "PLMM_RC_CHCLI": elementPendente.PLLM_EV_CHCLI,
                        "PLMM_RC_CDMAQ": elementPendente.PLLM_EV_CHMAQ,
                        "PLMM_RC_CDMAQ_LIB": elementPendente.PLLM_EV_MAQLIB,
                        "PLMM_RC_CHAVE_LIB": "",
                        "PLMM_RC_MOT_BLOQ": "",
                        "PLMM_RC_DTVAL_LIB": elementPendente.PLLM_EV_DTVAL
                    };
                maquinas.push(maquinaPendente);
            }

            sfContexto.definirValorContextoTrabalho("listaMaquinasPendentes", maquinas);
        }

        /**
        * @ngdoc method
        * @name obterListaExcluirMaquinasLiberadas
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para a tela de excluir máquina.
        **/
        function obterListaExcluirMaquinasLiberadas() {
            var maquinas = [];

            var PLLU_EV_OCOR = vm.maquinasLiberadas.filter(function (OCORL) {
                return OCORL.selecionado == "true" || OCORL.selecionado == true;
            });

            for (var OCORL in PLLU_EV_OCOR) {
                var elementLiberada = PLLU_EV_OCOR[OCORL];
                var maquinaLiberada =
                    {
                        "PLMM_RC_OPCAO": "E",
                        "PLMM_RC_CHCLI": elementLiberada.PLLU_EV_CHCLI,
                        "PLMM_RC_CDMAQ": elementLiberada.PLLU_EV_CHMAQ,
                        "PLMM_RC_CDMAQ_LIB": elementLiberada.PLLU_EV_MAQLIB,
                        "PLMM_RC_CHAVE_LIB": "",
                        "PLMM_RC_MOT_BLOQ": "",
                        "PLMM_RC_DTVAL_LIB": elementLiberada.PLLU_EV_DTVAL
                    };
                maquinas.push(maquinaLiberada);
            }

            sfContexto.definirValorContextoTrabalho("listaMaquinasPendentes", maquinas);
        }

        /**
        * @ngdoc method
        * @name confirmarSenhaToken
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por confirmar senha e token e acionar a operação de liberar/excluir as maquinas.
        **/
        function confirmarSenhaToken(data) {
            vm.resultadoValidacaoSenha = data;

            var listaMaquinas = sfContexto.obterValorContextoTrabalho("listaMaquinasPendentes");

            vm.liberarExcluir(listaMaquinas.pop(), data.senha, data.token);

            sfContexto.definirValorContextoTrabalho("listaMaquinasPendentes", listaMaquinas);
        }

        /**
        * @ngdoc method
        * @name cancelouSenhaToken
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por cancelar a digitação de senha token.
        **/
        function cancelouSenhaToken(data) {
            vm.resultadoValidacaoSenha = data;
            mostrarAlerta("warning", "Confirmação de senha cancelada.");
        }

        /**
        * @ngdoc method
        * @name confirmarLiberarMaquinas
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por confirmar a liberação de maquinas
        **/
        function confirmarLiberarMaquinas() {
            validarSenha();
        }

        /**
        * @ngdoc method
        * @name confirmarExcluirMaquinas
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por confirmar a exclusão de maquinas
        **/
        function confirmarExcluirMaquinas() {
            validarSenha();
        }

        /**
         * @description
         * Método para abertura e validação de senhas pelo modal.
         */
        function validarSenha() {
            removeAlerta();

            //Abrir o modal
            modal.abrirModal(undefined,
                undefined,
                "modalConfirmacaoSenha",
                confirmarSenhaToken,
                cancelouSenhaToken,
                {},
                "confirmacaoSenhaController",
                "csCtrl",
                "senha");
        }

        /**
        * @ngdoc method
        * @name liberarExcluir
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por chamar a operação de liberar/excluir as maquinas.
        **/
        function liberarExcluir(maquinas, senha, token) {

            interpretadorComunicacao.interpretar(liberarExcluirMaquinasFactory.liberarExcluirMaquinas(maquinas, senha, token))
                .sucesso(sucesso)
                .aviso(aviso)
                .erro(erro);

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno da operação de liberar/excluir as maquinas
            **/
            function sucesso(data) {

                var listaMaquinas = sfContexto.obterValorContextoTrabalho("listaMaquinasPendentes");

                if (listaMaquinas.length > 0) {

                    vm.liberarExcluir(listaMaquinas.pop(), senha, token);
                    sfContexto.definirValorContextoTrabalho("listaMaquinasPendentes", listaMaquinas);

                } else {
                    vm.voltarInicio = true;
                    vm.retornoSucessoLiberacao = data;
                    navegador.navegar("sucesso-validacao-senha");
                }
            }

            /**
           * @ngdoc method
           * @name erro
           *  
           * @description
           * Método de erro do retorno da operação de liberar/excluir as maquinas
           **/
            function erro(erro) {
                var listaMaquinas = sfContexto.obterValorContextoTrabalho("listaMaquinasPendentes");

                if (listaMaquinas.length > 0) {

                    vm.liberarExcluir(listaMaquinas.pop(), senha, token);
                    sfContexto.definirValorContextoTrabalho("listaMaquinasPendentes", listaMaquinas);

                } else {
                    removeAlerta();
                    mostrarAlerta("danger", erro.statusProcessamento.message);
                }
            }

            /**
            * @ngdoc method
            * @name Aviso
            *  
            * @description
            * Método de aviso do retorno da operação de liberar/excluir as maquinas
            **/
            function aviso(aviso) {
                mostrarAlerta("warning", aviso.statusProcessamento.message);
            }
        }

        /**
        * @ngdoc method
        * @name mostrarAlerta
        *  
        * @description
        * Método responsável por exibir o alerta de acordo com o retorno da comunicação
        **/
        function mostrarAlerta(tipoAlerta, textoAlerta) {
            var caminho = "";

            if (tipoAlerta == "warning") {

                caminho = "./app/assets/img/Pendencias_60x60pt_Ocre.png";
            }
            else if (tipoAlerta == "danger") {
                caminho = "./app/assets/img/icone_atencao_erro.png";
            }
            else {
                caminho = "./app/assets/img/icone_Mensagem_SUCESSO_60x60pt.png";
            }

            vm.alertas.push({ tipo: tipoAlerta, texto: textoAlerta, caminho: caminho });
        }

        /**
         * @ngdoc method
         *  * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeAlerta() {
            vm.alertas = [];
        }

        /**
         * @ngdoc method
         * @name acaoLiberadas
         *  
         * @description
         * Método responsável pela ação do botão de exibição de maquinas liberadas
         */
        function acaoLiberadas() {
            vm.listaMaquinasLiberadas.visivel = true;
            vm.listaMaquinasPendentes.visivel = false;

            if (!vm.listaMaquinasLiberadas.carregada) {
                listarMaquinasLiberadas();
            }
        }

        //INICIO - Alterar SENHA
        vm.alterarSenha = alterarSenha;
        vm.alterarSenhaLogin = alterarSenhaLogin;
        vm.removeAlerta = removeAlerta;
        vm.senhaAtual = null;
        vm.novaSenha = null;
        vm.confirmaSenha = null;
        vm.voltar = voltar;
        vm.senhaVencida = false;

        /*Funções*/

        /**
        * @ngdoc method
        * @name alterarSenha
        *
        * @methodOf apl-mobile-pj.seguranca:alteracaoSenhaController
        *
        * @description
        * Método responsável por realizar a troca da senha
        **/
        function validarAlteracaoSenha() {

            if (vm.novaSenha != null && vm.confirmaSenha != null && vm.senhaAtual != null) {
                if (vm.senhaAtual.toUpperCase() === vm.novaSenha.toUpperCase()) {
                    removeAlerta();
                    mostrarAlerta("danger", "A senha alterada não pode ser igual a senha atual, favor preencher novamente.");
                    return false;
                }
                else if (vm.novaSenha.toUpperCase() != vm.confirmaSenha.toUpperCase()) {
                    removeAlerta();
                    mostrarAlerta("danger", "A confirmação deve ser igual a nova senha.");
                    return false;
                }
                else {

                    if (new RegExp("\\s+").test(vm.novaSenha)) {
                        removeAlerta();
                        mostrarAlerta("danger", "A nova senha não deve conter espaços");
                        return false;
                    }

                    removeAlerta();

                    var validacao = verificaSequencia(vm.novaSenha);

                    if (validacao > 0) {
                        removeAlerta();
                        mostrarAlerta("danger", "A nova senha não deve conter sequências obvias");
                        return false;
                    }
                    else {
                        return true;
                    }

                }

            }
            return false;


            /**
            * @ngdoc method
            * @name verificaSequencia
            *
            * @methodOf apl-mobile-pj.gestaoMaquinas:gestaoMaquinasController
            *
            * @description
            * Método responsável por validar as sequencias de caracteres informados na nova senha.
            **/
            function verificaSequencia(senha) {
                var senhatmp, atual, x, charanterior, qtdseq;

                senhatmp = senha.toUpperCase();
                charanterior = "";
                atual = "";
                x = 0;
                qtdseq = 0;

                //Valida Numeros Intercalados
                //Executo duas vezes pois pode comecar ou nao da primeita posição  
                var intercalados = validaNumerosIntercalados(senha, true);
                if (intercalados > 0) {
                    return intercalados;
                }

                intercalados = validaNumerosIntercalados(senha, false);
                if (intercalados > 0) {
                    return intercalados;
                }

                while (x < 8) {
                    //Valida Caracteres repetidos XXXX
                    var charatual = senhatmp.substring(x, x + 1);
                    if (x > 0) {
                        if (charatual == charanterior) {
                            qtdseq++;
                        }
                        else {
                            qtdseq = 0;
                        }

                        if (qtdseq >= 3) {
                            return 5;
                        }
                    }
                    // if(new RegExp("^([A-Z0-9]){1,}").test(charatual))
                    charanterior = charatual;

                    atual = senhatmp.substring(x, x + 4);

                    var ordemcrescente = validaLetrasOrdemCrescente(atual);
                    var ordemdecrescente = validaLetrasOrdemDecrescente(atual);
                    var numerocrescente = validaNumeroCrescente(atual);
                    var numerodecrescente = validaNumeroDecrescente(atual);

                    if (ordemcrescente > 0) {
                        return ordemcrescente;
                    }
                    if (ordemdecrescente > 0) {
                        return ordemdecrescente;
                    }
                    if (numerocrescente > 0) {
                        return numerocrescente;
                    }
                    if (numerodecrescente > 0) {
                        return numerodecrescente;
                    }

                    x++;
                }
                return 0;
            }

            /**
             * @ngdoc method
             * @name validaNumerosIntercalados
             *
             * @methodOf apl-mobile-pj.gestaoMaquinas:validaNumerosIntercalados
             *
             * @description
             * Método responsável por validar as sequencias de caracteres númericos Intercalados.
             **/
            function validaNumerosIntercalados(posicoes, primeiraposicao) {
                var inicio = 0;
                if (!primeiraposicao) {
                    inicio = 1;
                }

                var i = inicio;
                var caracteres = "";
                while (i < 8) {
                    caracteres += posicoes.substring(i, i + 1);
                    i += 2;
                }

                var crescente = validaNumeroCrescente(caracteres);
                var decrescente = validaNumeroDecrescente(caracteres);

                if (crescente > 0 || decrescente > 0) {
                    return 6;
                }

                return 0;
            }

            /**
            * @ngdoc method
            * @name validaNumeroDecrescente
            *
            * @methodOf apl-mobile-pj.gestaoMaquinas:validaNumeroDecrescente
            *
            * @description
            * Método responsável por validar as sequencias de caracteres númericos em ordem Decrescente.
            **/
            function validaNumeroDecrescente(posicoes) {
                var i = 0;
                var invalido = "";
                var prox = 0;
                var numericodec = "9876543210";
                while (i < 10) {
                    prox = i + 4;

                    if (i <= 6) {
                        invalido = numericodec.substring(i, prox);
                    }
                    else {
                        invalido = numericodec.substring(6, prox);
                    }

                    if (posicoes.indexOf(invalido) >= 0) {
                        return 4;
                    }
                    i++;
                }

                return 0;
            }

            /**
           * @ngdoc method
           * @name validaLetrasOrdemCrescente
           *
           * @methodOf apl-mobile-pj.gestaoMaquinas:validaLetrasOrdemCrescente
           *
           * @description
           * Método responsável por validar as sequencias de caracteres númericos em ordem Crescente.
           **/
            function validaLetrasOrdemCrescente(posicoes) {
                var invalido = "";
                var prox = 0;
                var crescente = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                var i = 0;
                while (i < 26) {
                    prox = i + 4;

                    if (i <= 23) {
                        invalido = crescente.substring(i, prox);
                    }
                    else {
                        invalido = crescente.substring(21, prox);
                    }

                    if (posicoes.indexOf(invalido) >= 0) {
                        return 1;
                    }
                    i++;
                }

                return 0;
            }

            /**
           * @ngdoc method
           * @name validaLetrasOrdemDecrescente
           *
           * @methodOf apl-mobile-pj.gestaoMaquinas:validaLetrasOrdemDecrescente
           *
           * @description
           * Método responsável por validar as sequencias de caracteres em ordem Decrescente.
           **/
            function validaLetrasOrdemDecrescente(posicoes) {
                var i = 0;
                var invalido = "";
                var prox = 0;
                var decrescente = "ZYXWVUTSRQPONMLKJIHGFEDCBA";

                while (i < 26) {
                    prox = i + 4;

                    if (i <= 23) {
                        invalido = decrescente.substring(i, prox);
                    }
                    else {
                        invalido = decrescente.substring(21, prox);
                    }

                    if (posicoes.indexOf(invalido) >= 0) {
                        return 2;
                    }
                    i++;
                }

                return 0;
            }

            /**
            * @ngdoc method
            * @name validaNumeroCrescente
            *
            * @methodOf apl-mobile-pj.gestaoMaquinas:validaNumeroCrescente
            *
            * @description
            * Método responsável por validar as sequencias de caracteres númericos em ordem Crescente.
            **/
            function validaNumeroCrescente(posicoes) {
                var i = 0;
                var prox = 0;
                var numerico = "0123456789";
                var invalido = "";
                while (i < 10) {
                    prox = i + 4;

                    if (i <= 6) {
                        invalido = numerico.substring(i, prox);
                    }
                    else {
                        invalido = numerico.substring(6, prox);
                    }

                    if (posicoes.indexOf(invalido) >= 0) {
                        return 3;
                    }
                    i++;
                }

                return 0;
            }

        }

        /**
         * @description alterar senha
         */
        function transacaoAlterarSenha() {

            var param = {
                ADSE_RC_SENHA_ATU: vm.senhaAtual.toUpperCase(),
                ADSE_RC_SENHA_ALT: vm.novaSenha.toUpperCase(),
                ADSE_RC_IC_PERFIL: "N",
                ADSE_RC_TP_OPER: "A"
            };

            //RETIRAR
            // var texto = "Agencia=00000,Conta=0000000,CodigoCanal=IPJ,Senha=PAULIST1,ValorOperacao=1,CodigoCliente=000000000,ShortName=" + "VALISERE" + "       ,UserId=" + "ANDREBIZ" + ",BaseCGC=000000000";
            // sfContexto.definirValorContextoSessao("token", texto);

            // var mocksucesso = {
            //     "ADSE_EV_STATUS": "B",
            //     "ADSE_EV_NOM_USR": "",
            //     "ADSE_EV_NIV_USR": null,
            //     "ADSE_EV_DT_ULT_AC": 20160810,
            //     "ADSE_EV_COD_DEP": null,
            //     "ADSE_EV_EMAIL": "",
            //     "ADSE_EV_IC_TOKEN": "",
            //     "ADSE_EV_IC_GARAN": "N",
            //     "ADSE_EV_OCOR": [],
            //     "statusProcessamento": {
            //         "mensagem": {
            //             "codigo": "0120",
            //             "descricao": "SENHA ALTERADA COM SUCESSO",
            //             "severidade": "00"
            //         }
            //     }
            // };

            // alterarSenhaSucesso(mocksucesso);
            // return true;

            interpretadorComunicacao.interpretar(alterarValidarSenhaFactory.alterarValidarSenha(param))
                .sucesso(alterarSenhaSucesso)
                .aviso(alterarSenhaErro)
                .erro(alterarSenhaErro);


            /**
        * @ngdoc method
        * @name alterarSenhaSucesso
        *
        * @methodOf apl-mobile-pj.seguranca:alteracaoSenhaController
        *
        * @description
        * Método responsável por tratar o sucesso da chamada da factory de alterar Senha.
        **/
            function alterarSenhaSucesso(retorno) {
                if (vm.fluxoLogin) {
                    autenticarUsuario();
                }
                else {

                    vm.senhaAtual = "";
                    vm.novaSenha = "";
                    vm.confirmaSenha = "";

                    removeAlerta();
                    mostrarAlerta("success", retorno.statusProcessamento.message);
                }
            }

            /**
            * @ngdoc method
            * @name alterarSenhaErro
            *
            * @methodOf apl-mobile-pj.seguranca:alteracaoSenhaController
            *
            * @description
            * Método responsável por tratar o erro da chamada da factory de alterar Senha.
            **/
            function alterarSenhaErro(retorno) {
                mostrarAlerta("danger", retorno.statusProcessamento.message);
            }
        }

        /**
         * @description alterar senha
         */
        function alterarSenha() {
            if (validarAlteracaoSenha()) {
                transacaoAlterarSenha();
            }
        }

        /**
         * @description alterar senha do login
         */
        function alterarSenhaLogin() {
            vm.fluxoLogin = true;
            if (validarAlteracaoSenha()) {
                transacaoAlterarSenha();
            }
        }

        /**
         * @description autenticar usuario
         */
        function autenticarUsuario() {
            var param = {
                "ADSE_RC_SENHA_ATU": vm.senhaEletronica,
                "ADSE_RC_SENHA_ALT": "",
                "ADSE_RC_IC_PERFIL": "S",
                "ADSE_RC_TP_OPER": "L",
                "ADSE_RC_SENHA_BLW": "",
                "ADSE_RC_ALT_MSG": "",
                "ADSE_RC_ATIVACAO": "",
                "ADSE_RC_COD_MAQUINA": "",
                "ADSE_RC_VERSAO": "",
                "ADSE_RC_TIPO": ""
            };


            interpretadorComunicacao.interpretar(autenticarUsuarioFactory
                .autenticarUsuario(param))
                .sucesso(autenticarUsuarioSucesso)
                .aviso(autenticarUsuarioErro)
                .erro(autenticarUsuarioErro);

            /**
             * @description sucesso da autenticacao Usuario
             */
            function autenticarUsuarioSucesso(data) {
                montarPermissionamento(data);
                removeAlerta();
                navegador.navegar("login-token");
            }
            /**
             * @description erro da autenticacao Usuario
             */
            function autenticarUsuarioErro(retorno) {
                removeAlerta();
                mostrarAlerta("danger", retorno.statusProcessamento.message);
            }
        }

        /**
       * @ngdoc overview
       * @name montarPermissionamento
       * 
       * @memberOf loginController.js
       *
       * @description
       * Método executado para montar as permissões
       **/
        function montarPermissionamento(data) {
            var permissionamento = {};
            permissionamento.CONTAS = data.ADLG_EV_ITENS;
            permissionamento.GRUPO_SERVICOS = data.ADLG_EV_GRUPOS;
            permissionamento.CONTAS_POR_SERVICO = data.ADLG_EV_SERVICO;
            permissionamento.USUARIO_CPF = data.ADLG_EV_USUARIOCPF;
            permissionamento.USUARIO_DADOS = data.ADLG_EV_USUARIOCPF;
            permissionamento.MENSAGEM = data.ADLG_EV_MENSAGEM;
            permissionamento.TOKEN = data.ADLG_EV_TOKEN;

            sfContexto.definirValorContextoTrabalho("permissionamento", permissionamento);
            sfContexto.definirValorContextoTrabalho("dataUltimoAcesso", permissionamento.TOKEN.ADLG_TS_DTULAC);

            console.log(sfContexto.obterValorContextoTrabalho("permissionamento"));
        }
    }
})();