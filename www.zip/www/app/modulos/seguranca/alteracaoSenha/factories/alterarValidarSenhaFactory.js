(function () {

    "use strict";

    angular.module("apl-mobile-pj.seguranca").factory("alterarValidarSenhaFactory", alterarValidarSenhaFactory);

    alterarValidarSenhaFactory.$inject = ["sfConectorAPI", "sfContexto"];

    /*Funções*/
    /**
    * @ngdoc method
    * @name iniciar
    *  
    * @description
    * Método resgistrando serviço de alterar senha
    **/
    function alterarValidarSenhaFactory(conectorAPI, sfContexto) {

        return {
            alterarValidarSenha: alterarValidarSenha
        };

        /**
        * @ngdoc alterarValidarSenha
        * @name iniciar
        *  
        * @description
        * Método responsável por alterar senha
        **/
        function alterarValidarSenha(requisicao) {
            var dadosShortnameUsername = sfContexto.obterValorContextoTrabalho("dadosLogin"); 

            var param = {
                "ADSE_RC_SENHA_ATU": requisicao.ADSE_RC_SENHA_ATU,
                "ADSE_RC_SENHA_ALT": requisicao.ADSE_RC_SENHA_ALT,
                "ADSE_RC_IC_PERFIL": "N",
                "ADSE_RC_TP_OPER": "A",
                "ADSE_RC_SENHA_BLW": "",
                "ADSE_RC_ALT_MSG": "",
                "ADSE_RC_ATIVACAO": "",
                "ADSE_RC_COD_MAQUINA": "",
                "ADSE_RC_VERSAO": "",
                "ADSE_RC_TIPO": "",
                "shortname": dadosShortnameUsername.shortname,
                "userId": dadosShortnameUsername.username
            };

            var req = {

                method: "POST",
                url: "alterar-validar-senha",
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }
})();