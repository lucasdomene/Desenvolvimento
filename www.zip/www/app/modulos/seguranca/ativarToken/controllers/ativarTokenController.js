(function () {
    "use strict";

    /**
    * @ngdoc overview
    * @name apl-mobile-pj.seguranca
    * 
    * @require navegador
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Ativação de Token.
    **/
    angular.module("apl-mobile-pj.seguranca").controller("ativarTokenController", ativarTokenController);

    ativarTokenController.$inject = ["sfNavegador",
        "sfContexto",
        "modal",
        "obterNomeUsuarioFactory",
        "autenticarUsuarioFactory",
        "validarTokenFactory",
        "interpretadorComunicacao",
        "sfToken"];

    /**
    * @ngdoc overview
    * @name ativarTokenController
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Ativação de Token.
    **/
    function ativarTokenController(navegador,
        contexto,
        modal,
        obterNomeUsuarioFactory,
        autenticarUsuarioFactory,
        validarTokenFactory,
        interpretadorComunicacao,
        sfToken) {

        var vm = this;

        vm.voltar = voltar;

        vm.alertas = [];
        vm.shortname = "";
        vm.username = "";
        vm.senhaEletronica = "";
        vm.usuarioLogado = "";
        vm.codigoAtivacao = "";
        vm.usuarioMaster = false;

        vm.mostrarAlerta = mostrarAlerta;
        vm.voltarInicio = voltarInicio;
        vm.carregarSegurancaToken = carregarSegurancaToken;
        vm.carregarAtivacaoToken = carregarAtivacaoToken;
        vm.ativarToken = ativarToken;
        vm.serialToken = "";


        var permissionamento = null;
        var jaPossuiTokenCadastrado = false;

        /*Funções*/

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltar() {
            navegador.voltar();
        }

        /**
        * @ngdoc method
        * @name voltarInicio
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltarInicio() {
            jaPossuiTokenCadastrado = false;
            navegador.iniciarFluxo("apl-mobile-pj-login");
        }

         /**
        * @ngdoc method
        * @name voltarInicio
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para o fluxo ativar-token.
        **/
        function fluxoAtivarToken() {
            navegador.navegar("ativar-token");
        }


        /**
        * @ngdoc method
        * @name mostrarAlerta
        *  
        * @description
        * Método responsável por exibir o alerta de acordo com o retorno da comunicação
        **/
        function mostrarAlerta(tipoAlerta, textoAlerta) {
            var caminho = "./app/assets/img/Pendencias_60x60pt_Ocre.png";

            if (tipoAlerta == "danger") {
                caminho = "./app/assets/img/icone_atencao_erro.png";
            }

            vm.alertas.push({ tipo: tipoAlerta, texto: textoAlerta, caminho: caminho });
        }

        /**
        * @ngdoc method
        * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeAlerta() {
            vm.alertas = [];
        }

        /**
        * @ngdoc overview
        * @name montarPermissionamento
        * 
        * @memberOf ativarTokenController.js
        *
        * @description
        * Método executado para montar as permissões
        **/
        function montarPermissionamento(data) {
            permissionamento = {};
            permissionamento.CONTAS = data.ADLG_EV_ITENS;
            permissionamento.GRUPO_SERVICOS = data.ADLG_EV_GRUPOS;
            permissionamento.CONTAS_POR_SERVICO = data.ADLG_EV_SERVICO;
            permissionamento.USUARIO_CPF = data.ADLG_EV_USUARIOCPF;
            permissionamento.USUARIO_DADOS = data.ADLG_EV_USUARIOCPF;
            permissionamento.MENSAGEM = data.ADLG_EV_MENSAGEM;
            permissionamento.TOKEN = data.ADLG_EV_TOKEN;

            contexto.definirValorContextoTrabalho("permissionamento", permissionamento);
        }

        /**
        * @ngdoc method
        * @name carregarSegurancaToken
        *  
        * @description
        * Método responsável por obter nome do usuário
        **/
        function carregarSegurancaToken() {

            removeAlerta();
            if ((vm.shortname != "" && vm.shortname != undefined && vm.shortname.length == 8) &&
                (vm.username != "" && vm.username != undefined && vm.username.length == 8)) {
               
                 var dadosLogin = {
                    shortname: vm.shortname,
                    username: vm.username
                };

                contexto.definirValorContextoTrabalho("dadosLogin", dadosLogin);
                
                interpretadorComunicacao.interpretar(obterNomeUsuarioFactory.obterNomeUsuario())
                    .sucesso(sucesso)
                    .aviso(erro)
                    .erro(erro);
            }

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno  de obter Nome Usuario
            **/
            function sucesso(data) {
                vm.usuarioLogado = data.ADSE_EV_NOM_USR;
                contexto.definirValorContextoTrabalho("nomeClienteUltimoAcesso", data.ADSE_EV_NOM_USR);
                navegador.navegar("validar-senha-ativacao");
            }

            /**
           * @ngdoc method
           * @name erro
           *  
           * @description
           * Método de erro do retorno da consulta  de obter Nome Usuario
           **/
            function erro(erro) {
                mostrarAlerta("danger", erro.statusProcessamento.message);
            }
        }

        /**
        * @ngdoc method
        * @name carregarAtivacaoToken
        *  
        * @description
        * Método responsável por validar a senha
        **/
        function carregarAtivacaoToken() {

            removeAlerta();
            if (vm.senhaEletronica != "" && vm.senhaEletronica != undefined && vm.senhaEletronica.length == 8) {
                
                var param = {
                    credencial: { "senha": vm.senhaEletronica },
                    "ADSE_RC_SENHA_ATU": vm.senhaEletronica,
                    "ADSE_RC_SENHA_ALT": "",
                    "ADSE_RC_IC_PERFIL": "S",
                    "ADSE_RC_TP_OPER": "L",
                    "ADSE_RC_SENHA_BLW": "",
                    "ADSE_RC_ALT_MSG": "",
                    "ADSE_RC_ATIVACAO": "",
                    "ADSE_RC_COD_MAQUINA": "",
                    "ADSE_RC_VERSAO": "",
                    "ADSE_RC_TIPO": "",
                    "shortname": vm.shortname,
                    "userId": vm.username
                };

                interpretadorComunicacao.interpretar(autenticarUsuarioFactory.autenticarUsuario(param))
                    .sucesso(sucesso)
                    .aviso(erro)
                    .erro(erro);
            }

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno do autenticar usuario
            **/
            function sucesso(data) {
                montarPermissionamento(data);
                if (permissionamento.TOKEN.ADLG_TS_USER_UNIF_M.indexOf("MASTER") != -1) {
                    vm.usuarioMaster = true;
                }
                
                validarTokenUsuario();
            }

            /**
           * @ngdoc method
           * @name erro
           *  
           * @description
           * Método de erro do retorno do autenticar usuario
           **/
            function erro(erro) {
                console.log(erro);
                //mostrarAlerta("danger", erro.statusProcessamento.message);
            }
        }

        /**
        * @ngdoc method
        * @name validarTokenUsuario
        *  
        * @description
        * Método responsável por validar o dispositivo do cliente
        **/
        function validarTokenUsuario() {

                var param = {
                    "device": "",
                    "tipoDevice": "1",
                    "tipoPessoa": "PJ",
                    "shortname": vm.shortname,
                    "userId": vm.username
                };

                interpretadorComunicacao.interpretar(sfToken.autenticacao.validarDispositivo(param))
                    .sucesso(sucesso)
                    .aviso(erro)
                    .erro(erro);
            
            
            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno de validar Token
            **/
            function sucesso(data) {
                //Token já está associado ao cliente
                if(data.indTokenMobile == 1) {
                    vm.serialToken = data.serialNumber;
                    jaPossuiTokenCadastrado = true;
                     //Abrir o modal
                    modal.abrirModal(undefined,
                        undefined,
                        "modalCadastrarToken",
                        fluxoAtivarToken,
                        voltarInicio);
                } else {
                    vm.serialToken = data.serialNumber;
                    jaPossuiTokenCadastrado = false;
                    fluxoAtivarToken();
                }
            }

            /**
            * @ngdoc method
            * @name erro
            *  
            * @description
            * Método de erro do retorno da consulta de validar Token
            **/
            function erro(erro) {
                console.log(erro);
                mostrarAlerta("danger", erro.statusProcessamento.message);
            }
            
        }

        /**
        * @ngdoc method
        * @name ativarToken
        *  
        * @description
        * Método responsável por iniciar o processo de ativação do token
        **/
        function ativarToken() {

            removeAlerta();
            if (vm.codigoAtivacao != "" && vm.codigoAtivacao != undefined) {
                
                if (jaPossuiTokenCadastrado) {
                    ativarComDesassociacao();
                } else {
                    ativarSemDesassociacao();
                }
            }
        }

        /**
        * @ngdoc method
        * @name ativarComDesassociacao
        *  
        * @description
        * Método responsável por iniciar a Ativação do token desassociando o Token existente do cliente.
        **/
        function ativarComDesassociacao() {

                var param = {
                    "opcao": "1",
                    "serialNumber": vm.serialToken,
                    "indEnviaSMS": "S",
                    "device": "",
                    "tipoDevice": "1",
                    "shortname": vm.shortname,
                    "usuario": vm.username,
                    "tipoPessoa": "PJ",
                    "email": {
                        "shortname": vm.shortname,
                        "usuario": vm.username
                    }
                };

                interpretadorComunicacao.interpretar(sfToken.autenticacao.ativarComDesassociacao(param))
                    .sucesso(sucesso)
                    .aviso(erro)
                    .erro(erro);
            
            
            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno de ativar token com desassociação
            **/
            function sucesso() {
                efetivarAtivacaoToken();
            }

            /**
            * @ngdoc method
            * @name erro
            *  
            * @description
            * Método de erro do retorno do ativar token com desassociação
            **/
            function erro(erro) {
                console.log(erro);
                mostrarAlerta("danger", erro.statusProcessamento.message);
            }
            
        }

          /**
        * @ngdoc method
        * @name ativarSemDesassociacao
        *  
        * @description
        * Método responsável por iniciar a Ativação do token sem desassociação do Token existente do cliente.
        **/
        function ativarSemDesassociacao() {

                var param = {
                    "indEnviaSMS": "S",
                    "device": "",
                    "tipoDevice": "1",
                    "shortname": vm.shortname,
                    "userId": vm.username,
                    "tipoPessoa": "PJ"
                };

                interpretadorComunicacao.interpretar(sfToken.autenticacao.ativarSemDesassociacao(param))
                    .sucesso(sucesso)
                    .aviso(erro)
                    .erro(erro);
            
            
            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno de ativar token sem desassociação
            **/
            function sucesso() {
                efetivarAtivacaoToken();
            }

            /**
            * @ngdoc method
            * @name erro
            *  
            * @description
            * Método de erro do retorno do ativar token sem desassociação
            **/
            function erro(erro) {
                console.log(erro);
                mostrarAlerta("danger", erro.statusProcessamento.message);
            }
            
        }
      
         /**
        * @ngdoc method
        * @name efetivarAtivacaoToken
        *  
        * @description
        * Método responsável por efetivar a ativação do token
        **/
        function efetivarAtivacaoToken() {

            removeAlerta();
            if (vm.codigoAtivacao != "" && vm.codigoAtivacao != undefined) {
                
                var requisicao = {
                    "indValidacaoSMS": "N",
                    "senhaSMS": vm.codigoAtivacao,
                    "serialNumber": vm.serialToken,
                    "device": "",
                    "tipoDevice": "1",
                    "shortname": vm.shortname,
                    "userId": vm.username
                };

                sfToken.ativar(requisicao)
                    .then(sucesso)
                    .catch(erro);
                    
            }

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno do efetivarAtivacaoToken
            **/
            function sucesso(data) {
                console.log(data);
                voltarInicio();                
            }

            /**
            * @ngdoc method
            * @name erro
            *  
            * @description
            * Método de erro do retorno  do efetivarAtivacaoToken
            **/
            function erro(erro) {
                mostrarAlerta("danger", erro.statusProcessamento.message);
            }
        }

        /**
        * @ngdoc method
        * @name obterSequenciaToken
        *  
        * @description
        * Método responsável por obter sequencia do token
        **/
        // function obterSequenciaToken() {

        //      sfToken.obterSequencia(false)
        //          .then(sucesso)
        //          .catch(erro);

            
        //     /**
        //     * @ngdoc method
        //     * @name sucesso
        //     *  
        //     * @description
        //     * Método de sucesso do retorno do obterSequenciaToken
        //     **/
        //     function sucesso(data) {
        //         console.log(data);
        //     }

        //     /**
        //     * @ngdoc method
        //     * @name erro
        //     *  
        //     * @description
        //     * Método de erro do retorno  do obterSequenciaToken
        //     **/
        //     function erro(erro) {
        //         mostrarAlerta("danger", erro.statusProcessamento.message);
        //     }
        // }



    }
})();