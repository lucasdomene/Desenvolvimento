(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name validarTokenFactory
    *
    * @methodOf apl-mobile-pj.seguranca:validarTokenFactory
    *
    * @description
    * Factory de conexão com API validarTokenFactory
    **/
    angular.module("apl-mobile-pj.seguranca")
        .factory("validarTokenFactory", validarTokenFactory);

    validarTokenFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name validarToken
    *
    * @methodOf apl-mobile-pj.seguranca:validarTokenFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function validarTokenFactory(conectorAPI, appSettings, utilitarios) {

        return {
            validarToken: validarToken
        };

        /**
        * @ngdoc method
        * @name validarToken
        *
        * @methodOf apl-mobile-pj.seguranca:validarToken
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function validarToken(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "validar-token"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();