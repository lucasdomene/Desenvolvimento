(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name autenticarUsuarioFactory
    *
    * @methodOf apl-mobile-pj.seguranca:autenticarUsuarioFactory
    *
    * @description
    * Factory de conexão com API autenticarUsuarioFactory
    **/
    angular.module("apl-mobile-pj.seguranca")
        .factory("autenticarUsuarioFactory", autenticarUsuarioFactory);

    autenticarUsuarioFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name autenticarUsuario
    *
    * @methodOf apl-mobile-pj.extrato:autenticarUsuarioFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function autenticarUsuarioFactory(conectorAPI, appSettings, utilitarios) {

        return {
            autenticarUsuario: autenticarUsuario
        };

        /**
        * @ngdoc method
        * @name autenticarUsuario
        *
        * @methodOf apl-mobile-pj.extrato:autenticarUsuario
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function autenticarUsuario(requisicao) {

            var param = requisicao;
                
                // "ADSE_RC_SENHA_ALT" : requisicao.ADSE_RC_SENHA_ALT,
                // "ADSE_RC_IC_PERFIL" : requisicao.ADSE_RC_IC_PERFIL,
                // "ADSE_RC_TP_OPER" : requisicao.ADSE_RC_TP_OPER,
                // "ADSE_RC_SENHA_BLW" : requisicao.ADSE_RC_SENHA_BLW,
                // "ADSE_RC_ALT_MSG" : requisicao.ADSE_RC_ALT_MSG,
                // "ADSE_RC_BROWSER" : requisicao.ADSE_RC_BROWSER,
                // "ADSE_RC_COD_MAQUINA" :requisicao.ADSE_RC_COD_MAQUINA,
                // "ADSE_RC_VERSAO" : requisicao.ADSE_RC_VERSAO,
                // "ADSE_RC_TIPO" : requisicao.ADSE_RC_TIPO


            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "autenticar-usuario-pj"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();