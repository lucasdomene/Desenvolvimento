(function () {
    "use strict";

    /**
    * @ngdoc overview
    * @name apl-mobile-pj.seguranca
    * 
    * @require navegador
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Cadastro de Dispositivos.
    **/
    angular.module("apl-mobile-pj.seguranca").controller("cadastroDispositivoController", cadastroDispositivoController);

    cadastroDispositivoController.$inject = [
        "sfNavegador",
        "sfContexto",
        "interpretadorComunicacao",
        "sfDefensor",
        "sfAutenticador",
        "validarSenhaFactory"];

    /**
    * @ngdoc overview
    * @name cadastroDispositivoController
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Cadastro de Dispositivos.
    **/
    function cadastroDispositivoController(
        navegador,
        contexto,
        interpretadorComunicacao,
        sfDefensor,
        sfAutenticador,
        validarSenhaFactory) {

        var vm = this;

        vm.title = "Cadastro de Dispositivos";
        var nome = contexto.obterValorContextoTrabalho("nomeClienteUltimoAcesso");
        vm.nomeCliente = nome;
        vm.carregarCadastro = carregarCadastro;
        vm.carregarSenhaConfirmacao = carregarSenhaConfirmacao;
        vm.carregarLiberacao = carregarLiberacao;
        vm.voltar = voltar;
        vm.selecionarPrazoLiberacao = selecionarPrazoLiberacao;

        vm.alertas = [];
        vm.removeAlerta = removeAlerta;
        vm.mostrarAlerta = mostrarAlerta;
        vm.termoAlterado = termoAlterado;
        vm.sucessoIncluirMaquina = false;
        vm.voltarInicio = voltarInicio;
        vm.dataSelecionada = dataSelecionada;
        vm.selecionouIndeterminado = selecionouIndeterminado;
        vm.senha = null;
        vm.token = null;
        vm.codigoNextToken = "";
        vm.tokenValido = false;

        //TODO: Alterar o texto do termo de aceite.


        vm.termoAceito = "";

        vm.altInputFormats = ["M!/d!/yyyy"];

        vm.apelido = "";
        vm.prazoLiberacaoDeterminado = "";
        vm.CampoDataValido = false;
        vm.prazoLiberacao = "";
        vm.datePickerPrazo = {
            opened: false
        };

        vm.agora = new Date();

        vm.opcoesDatePicker = {
            dateDisabled: disabled,
            formatYear: "yy",
            maxDate: new Date(vm.agora.getFullYear(), vm.agora.getMonth(), vm.agora.getDate() + 365),
            minDate: vm.agora,
            startingDay: 0,
            showWeeks: false,
            maxMode: "day"
        };

        var cadastrarMaquinaLogin = contexto.obterValorContextoTrabalho("cadastrarMaquinaLogin");

        vm.altInputFormats = ["M!/d!/yyyy"];

        iniciar();

        /**
         * @description método responsável pela inicialização de variáveis.
         */
        function iniciar() {
            vm.codigoNextToken = "";
        }

        // Disable weekend selection
        /**
            * @ngdoc method
            * @name disabled
            *  
            * @description
            * Método de disabled do componente de data
            **/
        function disabled(data) {
            var date = data.date,
                mode = data.mode;
            var desabilita = (mode === "day" && (date.getDay() === 0 || date.getDay() === 6));
            desabilita = false;
            //Permitir inclusive final de semana
            return desabilita;
        }

        /*Funções*/

        /**
        * @ngdoc method
        * @name carregarCadastro
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para etapa de cadastro de Apelido do Dispositivo e Prazo de Liberação.
        **/
        function carregarCadastro() {
            navegador.navegar("cadastro");
        }

        /**
        * @ngdoc method
        * @name carregarSenhaConfirmacao
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para autenticação da transação por senha e token.
        **/
        function carregarSenhaConfirmacao() {
            removeAlerta();

            if (vm.prazoLiberacaoDeterminado !== "" && vm.apelido != undefined && vm.apelido != "") {
                var validaPrazo = (vm.prazoLiberacao != undefined && vm.prazoLiberacao != "" && vm.prazoLiberacao.getDate() >= vm.agora.getDate());
                var prazoDeterminado = (vm.prazoLiberacaoDeterminado == "true" || vm.prazoLiberacaoDeterminado == true);

                if (prazoDeterminado && !validaPrazo) {
                    vm.CampoDataValido = "true";
                } else {
                    vm.CampoDataValido = "false";
                }

                if (vm.termoAceito &&
                    (
                        (
                            prazoDeterminado &&
                            validaPrazo
                        )
                        ||
                        (
                            !prazoDeterminado &&
                            !validaPrazo
                        )
                    )
                ) {
                    navegador.navegar("senhaConfirmacao");
                    return true;
                } else {
                    if (!vm.termoAceito) {
                        mostrarAlerta("warning", "Termo não foi aceito.");
                    }

                    return false;
                }
            } else {
                vm.CampoDataValido = "true";
                return false;
            }
        }

        /**
        * @ngdoc method
        * @name termoAlterado
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por esconder o alerta do aceite de termo.
        **/
        function termoAlterado() {
            if (vm.termoAceito) {
                removeAlerta();
            }
        }

        /**
        * @ngdoc method
        * @name carregarLiberacao
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para tela de sucesso na liberação do dispositivo.
        **/
        function carregarLiberacao() {
            if (vm.senha == null || vm.token == null) {
                return;
            }

            var requisicao = {
                VLSE_RC_SENHA_ATU: vm.senha
            };

            interpretadorComunicacao.interpretar(validarSenhaFactory.validarSenha(requisicao))
                .sucesso(sucesso)
                .aviso(erro)
                .erro(erro);

            /**
             * @description Método de sucesso
             */
            function sucesso() {
                obterDNAIncluirMaquina();
            }

            /**
             * @description Método de erro da validação de senha
             */
            function erro(data) {
                removeAlerta();
                mostrarAlerta("danger", data.statusProcessamento.message);
            }
        }

        /**
         * @description Método responsável por obter o DNA e efetuar a inclusão da maquina
         */
        function obterDNAIncluirMaquina() {
            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var agencia = "IPJ",
                conta = dadosLogin.shortname,
                usuario = dadosLogin.username,
                tipoLogin = "PJ 1",
                applicationLayerVersion = "",
                customFields = [];


            interpretadorComunicacao.interpretar(sfDefensor.obterDNA(agencia, conta, usuario, tipoLogin, applicationLayerVersion, customFields))
                .sucesso(sucessoObterDNA)
                .aviso(erroObterDNA)
                .erro(erroObterDNA);

            /**
             * @description Método de sucesso na obtenção de DNA
             */
            function sucessoObterDNA(data) {
                incluirMaquina(data, dadosLogin.shortname, dadosLogin.username);
            }

            /**
             * @description Método de erro na obtenção de DNA
             */
            function erroObterDNA(data) {
                removeAlerta();
                mostrarAlerta("danger", data.statusProcessamento.message);
            }
        }

        /**
         * @description Método responsável por efetuar a inclusão da maquina.
         */
        function incluirMaquina(data, shortname, username) {
            var prazoLiberacaoFormatado = "";

            if (vm.prazoLiberacao != "") {
                prazoLiberacaoFormatado = vm.prazoLiberacao
                    .toISOString()
                    .slice(0, 10)
                    .replace(/-/g, "");
            } else {
                prazoLiberacaoFormatado = "99990101";
            }

            var requisicao = {
                "cipheredId": data.id,
                "cipheredKey": data.key,
                "salt": data.senha, 
                "apelidoMaquina": vm.apelido,
                "indicadorSmsLiberado": "N",
                "dataValidade": prazoLiberacaoFormatado,
                "shortname": shortname,
                "userId": username
            };

            var otp = {
                senha: vm.senha,
                serial: vm.token, //TODO: Validar o que deve ser mandado
                nextToken: vm.codigoNextToken   //Validar o momento que é preenchido
            };

            requisicao.otp = otp;
            requisicao.senha = vm.senha;

            interpretadorComunicacao.interpretar(sfDefensor.cadastrarDispositivo(requisicao))
                .sucesso(incluirMaquinaSucesso)
                .aviso(incluirMaquinaAviso)
                .erro(incluirMaquinaErro);

            /**
            * @ngdoc method
            * @name sucesso
            *  
            * @description
            * Método de sucesso do retorno da operação de incluir as maquinas
            **/
            function incluirMaquinaSucesso(data) {
                vm.retorno = data;
                navegador.navegar("liberacao");
                vm.sucessoIncluirMaquina = true;
            }

            /**
            * @ngdoc method
            * @name erro
            *  
            * @description
            * Método de erro do retorno da operação de incluir as maquinas
            **/
            function incluirMaquinaErro(erro) {

                if (erro.httpStatusCode === 472) {
                    vm.codigoNextToken = erro.propriedades.authenticationToken[0];
                    vm.tokenValido = false;
                }

                mostrarAlerta("danger", erro.statusProcessamento.message);
            }

            /**
             * @ngdoc method
             * @name Aviso
             * 
             * @description
             * Método de aviso do retorno da operação de incluir maquinas
             */
            function incluirMaquinaAviso(erro) {
                mostrarAlerta("warning", erro.statusProcessamento.message);
            }
        }

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltar() {
            if (!vm.sucessoIncluirMaquina && cadastrarMaquinaLogin != "S") {
                navegador.voltar();
            } else {
                contexto.definirValorContextoSessao("cadastrarMaquinaLogin", "");
                voltarInicio();
            }
        }

        /**
        * @ngdoc method
        * @name voltarInicio
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltarInicio() {
            sfAutenticador.logoff().then(sucesso).catch(sucesso);

            /**
            * @description Método de sucesso para a saida da aplicação
            */
            function sucesso() {
                navegador.iniciarFluxo("apl-mobile-pj-login");
            }
        }

        /**
        * @ngdoc method
        * @name selecionarPrazoLiberacao
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por selecionar Prazo de Liberacao.
        **/
        function selecionarPrazoLiberacao() {
            vm.datePickerPrazo.aberto = true;
            selecionouIndeterminado();
        }

        /**
        * @ngdoc method
        * @name mostrarAlerta
        *  
        * @description
        * Método responsável por exibir o alerta de acordo com o retorno da comunicação
        **/
        function mostrarAlerta(tipoAlerta, textoAlerta) {
            var caminho = "./app/assets/img/Pendencias_60x60pt_Ocre.png";

            if (tipoAlerta == "danger") {
                caminho = "./app/assets/img/icone_atencao_erro.png";
            }

            vm.alertas.push({ tipo: tipoAlerta, texto: textoAlerta, caminho: caminho });
        }

        /**
        * @ngdoc method
        * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeAlerta() {
            vm.alertas = [];
        }

        /**
         * @ngdoc method
         * @name dataSelecionada
         *  
         * @description
         * Método responsável por visualizar se uma data foi selecionada na tela pelo datepicker poup
         */
        function dataSelecionada() {
            if (vm.prazoLiberacao != undefined && vm.prazoLiberacao != null && vm.prazoLiberacao != "") {
                vm.prazoLiberacaoDeterminado = "true";
            } else {
                selecionarPrazoLiberacao();
            }
        }

        /**
         * @ngdoc method
         * @name selecionouIndeterminado
         *  
         * @description
         * 
         */
        function selecionouIndeterminado() {
            //TODO XASAN MERGE ARQ -- Ver o pq dessa logica com o responsável
            if (vm.prazoLiberacao == "") {
                vm.prazoLiberacao = "";
            }
        }
    }
})();