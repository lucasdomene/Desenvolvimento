(function () {

    "use strict";

    angular.module("apl-mobile-pj.seguranca").factory("incluirMaquinasFactory", incluirMaquinasFactory);

    incluirMaquinasFactory.$inject = ["sfConectorAPI", "sfContexto"];

    /*Funções*/
    /**
    * @ngdoc method
    * @name iniciar
    *  
    * @description
    * Método resgistrando serviço de incluir máquinas
    **/
    function incluirMaquinasFactory(conectorAPI, contexto) {

        return {
            incluirMaquina: incluirMaquina
        };

        /*Funções*/

        // /**
        // * @returns GUID para utilização na tela.
        // */
        // function guid() {
        //     /**
        //      * @returns Ramdom value
        //      */
        //     function s4() {
        //         return Math.floor((1 + Math.random()) * 0x10000)
        //             .toString(16)
        //             .substring(1);
        //     }
        //     return s4() + s4() + s4() + s4();
        // }

        /**
        * @ngdoc incluirMaquina
        * @name iniciar
        *  
        * @description
        * Método responsável por incluir Maquina
        **/
        function incluirMaquina(requisicao) {
            //TODO: Remover valores fixos, disponivel pela arquitetura?
            //Agencia=00000,Conta=000000000,CodigoCanal=IPJ,Senha=XXXXXXXX,ValorOperacao=1,CodigoCliente=000000000,ShortName=VALISERE       ,UserId=TESTE   ,BaseCGC=000000000,CentralAtendimento=N,TokenValidado=S

            var dadosShortnameUsername = contexto.obterValorContextoTrabalho("dadosLogin"); 

            var param = {
                "PLCM_RC_OPCAO": "1",
                "PLCM_RC_CDMAQ": "ASDFZXCVQWER1234", // guid(), //TODO: Em definição pela arquitetura
                "PLCM_RC_APELMAQ": requisicao.apelMaquina,
                "PLCM_RC_IP": "172.16.34.169", //TODO: Em definição pela arquitetura
                "PLCM_RC_VERPLU": "1.12.3.5", //TODO: Em definição pela arquitetura
                "PLCM_RC_FLSMS_LIB": "N",
                "PLCM_RC_DTVALI": requisicao.dataValidacao,

                //TODO XASAN REMOVER
                "shortname": dadosShortnameUsername.shortname,
                    "userId": dadosShortnameUsername.username,
                "baseCGC": "000000000",
                    "agencia": "00000",
                    "contaCorrente": "000000000" //TODO XASAN aguardando correção XASAN
            };

            var req = {

                method: "POST",
                url: "incluir-maquinas",
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }
})();