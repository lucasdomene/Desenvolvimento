angular.module("apl-mobile-pj.comum").filter("custdate", function () {
    return function (value, format) {
        if (!value) {
            return "";
        }

        if (!format) {
            return "";
        }

        var newValue = "";

        if (value != "99990101") {
            if (format == "dd/MM") {
                //20160101                
                newValue = value.substring(6, 8) + "/" + value.substring(4, 6);
            }
            else {
                //20160101
                newValue = value.substring(6, 8) + "/" + value.substring(4, 6) + "/" + value.substring(0, 4);
            }
        } else {
            newValue = "Indeterm.";
        }


        return newValue;
    };
});