(function () {
    /**
     * @ngdoc overview
     * @name apl-mobile-pj.comum
     * 
     * @require ui.bootstrap, ngAnimate
     * 
     * @description
     * Módulo que define os fluxos de navegacao pelos controles da comum, utilizado por toda aplicação.
     **/
    angular.module("apl-mobile-pj.comum", ["ngAnimate","ui.bootstrap"])
        .config(comumModule)
        .run(["sfTradutor", function (tradutor) {
            tradutor.adicionarDicionarios(
                [
                    "app/modulos/comum/internacionalizacao/"
                ]
            );
        }]);

    comumModule.$inject = ["sfNavegadorProvider"];

    /**
    * @ngdoc overview
    * @name comumModule
    * 
    * @description
    * Navegação do módulo comum.
    **/
    function comumModule(sfNavegadorProvider) {
        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-detalhes-pagamento")
                .adicionarEstado("comum", {
                    templateUrl: "./app/modulos/comum/views/detalhespagamento/autorizacao.html",
                    controller: "situacaoPagamentoController as sitpagCtrl",
                    abstract: true
                })
                .adicionarEstado("comum.detalhes-do-pagamento", {
                    templateUrl: "./app/modulos/comum/views/detalhespagamento/sumarizador.html",
                    parent: "comum"
                },
                [
                    {
                        acao: "exibir-pagamentos-por-situacao",
                        estadoDestino: "comum.pagamentos-por-situacao"
                    }
                ])
                .adicionarEstado("comum.pagamentos-por-situacao", {
                    templateUrl: "./app/modulos/comum/views/detalhespagamento/pagamentos.html",
                    parent: "comum"
                },
                [
                    {
                        acao: "exibir-comprovante-fornecedor",
                        fluxo:"apl-mobile-pj-comprovante-fornecedor"
                    }
                ]
                )
                .definirEstadoInicial("comum.detalhes-do-pagamento")
        );
    }
    // angular.module("apl-mobile-pj.comum").directive("setClassWhenAtTop", setTopTest);

    // setTopTest.$inject = ["$window", "$document"];

    // /**
    //  * @description Teste
    //  */
    // function setTopTest($window, $document) {

    //     return {
    //         restrict: "A",
    //         link: function (scope, element, attrs) {


    //             var topClass = attrs.setClassWhenAtTop, offsetTop = 50;

    //             $document.on("scroll", function (e) {
    //                 if ($window.pageYOffset >= offsetTop) {
    //                     element.addClass(topClass);
    //                 } else {
    //                     element.removeClass(topClass);
    //                 }

    //                 console.log(e);
    //             });

    //         }
    //     };
    // }
})(); 