(function () {
    "use strict";

    /**
   * @ngdoc overview
   * @name apl-mobile-pj.extrato
   * 
   * @require sfNavegador, comum
   * 
   * @description
   * Controller responsável pela tratativa das ações a serem realizadas na tela situação dos pagamentos 
   */
    angular.module("apl-mobile-pj.comum")
        .controller("situacaoPagamentoController", situacaoPagamentoController);

    situacaoPagamentoController.$inject = ["sfNavegador",
        "sfContexto",
        "modal",
        "interpretadorComunicacao",
        "identificarComprovanteCompartilhadoFactory",
        "exibicaoComprovanteFactory"
    ];

    /**
    * @ngdoc overview
    * @name situacaoPagamentoController
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas na tela situação dos pagamentos 
    **/
    function situacaoPagamentoController(sfNavegador,
        sfContexto,
        modal,
        interpretadorComunicacao,
        identificarComprovanteCompartilhadoFactory,
        exibicaoComprovanteFactory
    ) {
        var vm = this;

        vm.iniciar = iniciar;
        vm.voltar = voltar;
        vm.visualizarDetalhes = visualizarDetalhes;
        vm.removeAlerta = removeAlerta;
        vm.mostrarAlerta = mostrarAlerta;
        vm.separarListasPagamentos = separarListasPagamentos;
        vm.voltarParaAutorizacao = voltarParaAutorizacao;
        vm.removerFiltro = removerFiltro;
        vm.limparPesquisa = limparPesquisa;
        vm.exibirPesquisa = exibirPesquisa;
        vm.abrirCompartilhamento = abrirCompartilhamento;
        //vm.pesquisaPagamentoSelecionado = pesquisaPagamentoSelecionado;


        /*
        * AUTORIZADO
        * PARCIALMENTE-AUTORIZADO
        * NAO-AUTORIZADO
        */
        vm.situacaoPagamento = null;
        vm.listaPagamentos = null;
        vm.situacaoNavegada = null;
        vm.listaDetalhesPagamento = null;
        vm.pagamentoSelecionado = null;
        vm.pagamentoDetalhado = null;

        vm.filtroPesquisa = "";
        vm.quantidadePagamentos = 0;
        vm.valorPagamentos = 0;

        vm.pesquisaVisivel = false;
        vm.exibirDetalhesAutorizados = false;
        vm.exibirDetalhesParcialmenteAutorizados = false;
        vm.exibirDetalhesNaoAutorizados = false;
        vm.exibirCabecalhoAutorizacao = true;

        var tipoAlerta = "";

        vm.alertas = [];
        vm.listaPagamentosAutorizados = [];
        vm.listaPagamentosParcialmenteAutorizados = [];
        vm.listaPagamentosNaoAutorizados = [];

        vm.iniciar();

        /**
        * @ngdoc overview
        * @name iniciar
        * 
        * @memberOf situacaoPagamentoController.js
        *
        * @description        
        * Método responsável por inicializar as variáveis da controller
        **/
        function iniciar() {

            // sfContexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos",{"EV_OCOR": [{"SITUACAO": "AUTORIZADO","QUANTIDADE": 6,"VALOR": 724500,"PAGAMENTOS": [{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "61602199019484","EV_COMPROM": "OUT123456000","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "AUTORIZADO","EV_MENS_OCOR": "OPERACAO REALIZADA COM SUCESSO","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00034721535805","EV_COMPROM": "OUT15048490","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000000123000","EV_SITUACAO": "AUTORIZADO","EV_MENS_OCOR": "OPERACAO REALIZADA COM SUCESSO","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT123465088","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "PAGAMENTO AUTORIZADO","EV_MENS_OCOR": "OPERACAO REALIZADA COM SUCESSO","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT1234567490","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "PAGAMENTO AUTORIZADO","EV_MENS_OCOR": "OPERACAO REALIZADA COM SUCESSO","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT1515654888","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "AUTORIZADO","EV_MENS_OCOR": "OPERACAO REALIZADA COM SUCESSO","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT1234567890","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "AUTORIZADO","EV_MENS_OCOR": "OPERACAO REALIZADA COM SUCESSO","EV_I_SUCESS": "S"}]},{"SITUACAO": "PARCIALMENTE AUTORIZADO","QUANTIDADE": 7,"VALOR": 156831,"PAGAMENTOS": [{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "61086336000103","EV_COMPROM": "DDATESTE","EV_DT_PAG": "20141010","EV_VLR_COMPROM": "00000000000093918","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00000740736809","EV_COMPROM": "OUTFSGSGH","EV_DT_PAG": "20141010","EV_VLR_COMPROM": "00000000000004100","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "02878230000183","EV_COMPROM": "BLQWERWER","EV_DT_PAG": "20141107","EV_VLR_COMPROM": "00000000000000456","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00000442272138","EV_COMPROM": "OUTT1011141","EV_DT_PAG": "20141110","EV_VLR_COMPROM": "00000000000045100","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "99999900000232","EV_COMPROM": "BLL0114122739","EV_DT_PAG": "20150114","EV_VLR_COMPROM": "00000000000006512","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "99999900000151","EV_COMPROM": "BLL0114120252","EV_DT_PAG": "20150114","EV_VLR_COMPROM": "00000000000006512","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "02558157000162","EV_COMPROM": "BLL0114120456","EV_DT_PAG": "20150114","EV_VLR_COMPROM": "00000000000000233","EV_SITUACAO": "AUTORIZACAO REGISTRADA","EV_MENS_OCOR": "AUTORIZACAO REGISTRADA","EV_I_SUCESS": "S"}]},{"SITUACAO": "NAO AUTORIZADO","QUANTIDADE": 10,"VALOR": 2100100,"PAGAMENTOS": [{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT123456407/","EV_DT_PAG": "20151013","EV_VLR_COMPROM": "00000000001260000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT123456789","EV_DT_PAG": "20151014","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00008521716842","EV_COMPROM": "OUT1015000","EV_DT_PAG": "20151014","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT1234156000","EV_DT_PAG": "20151015","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00013141244987","EV_COMPROM": "OUT12312312","EV_DT_PAG": "20151015","EV_VLR_COMPROM": "00000000000100000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT1230","EV_DT_PAG": "20151016","EV_VLR_COMPROM": "00000000000123000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00036923151805","EV_COMPROM": "OUT123011","EV_DT_PAG": "20151016","EV_VLR_COMPROM": "00000000000015000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00011808915895","EV_COMPROM": "OUT15600","EV_DT_PAG": "20151016","EV_VLR_COMPROM": "00000000000150000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00000891373888","EV_COMPROM": "BLQ567567","EV_DT_PAG": "20151105","EV_VLR_COMPROM": "00000000000001100","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"},{"EV_AGENCIA": "00200","EV_CONTA": "001636800","EV_CGC_CPF_FORN": "00003635343692","EV_COMPROM": "OUT123789","EV_DT_PAG": "20151205","EV_VLR_COMPROM": "00000000000001000","EV_SITUACAO": "NAO AUTORIZADO","EV_MENS_OCOR": "DATA DE PAGAMENTO INFORMADA INFERIOR A DATA DE HOJE","EV_I_SUCESS": "N"}]}],"statusProcessamento": {"mensagem": {"codigo": "","descricao": "PAGAMENTOS AUTORIZADOS","severidade": "00"}}});

            vm.listaPagamentos = sfContexto.obterValorContextoTrabalho("listaAutorizacaoPagamentos");
            vm.situacaoNavegada = sfContexto.obterValorContextoTrabalho("situacaoNavegada");
            vm.estadoAutorizacao = sfContexto.obterValorContextoTrabalho("estadoAutorizacao");
            
            verificaMensagem();
            vm.separarListasPagamentos();

            vm.visualizarDetalhes(vm.situacaoNavegada);
            vm.situacaoNavegada = null;
            sfContexto.definirValorContextoTrabalho("situacaoNavegada", "");
        }

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.comum
        *
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltar() {
            sfNavegador.voltar();
        }

        /**
        * @ngdoc method
        * @name voltarParaAutorizacao
        *
        * @methodOf apl-mobile-pj.comum
        *
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltarParaAutorizacao() {
            vm.exibirCabecalhoAutorizacao = true;
            vm.situacaoPagamento = null;
            vm.removerFiltro();
            sfNavegador.voltar();
        }

        /**
        * @ngdoc method
        * @name visualizarDetalhes
        *
        * @methodOf apl-mobile-pj.comum
        *
        * @description
        * Método responsável por navegar para detalhes de pagamentos.
        **/
        function visualizarDetalhes(situacao) {

            if (situacao != ""
                && angular.isDefined(vm.listaPagamentos)) {
                switch (situacao) {
                    case "AUTORIZADO":
                        vm.listaDetalhesPagamento = vm.listaPagamentosAutorizados;
                        vm.quantidadePagamentos = vm.listaPagamentos.EV_OCOR[0].QUANTIDADE;
                        vm.valorPagamentos = vm.listaPagamentos.EV_OCOR[0].VALOR;
                        break;
                    case "PARCIALMENTE AUTORIZADO":
                        vm.listaDetalhesPagamento = vm.listaPagamentosParcialmenteAutorizados;
                        vm.quantidadePagamentos = vm.listaPagamentos.EV_OCOR[1].QUANTIDADE;
                        vm.valorPagamentos = vm.listaPagamentos.EV_OCOR[1].VALOR;
                        break;
                    case "NAO AUTORIZADO":
                        vm.listaDetalhesPagamento = vm.listaPagamentosNaoAutorizados;
                        vm.quantidadePagamentos = vm.listaPagamentos.EV_OCOR[2].QUANTIDADE;
                        vm.valorPagamentos = vm.listaPagamentos.EV_OCOR[2].VALOR;
                        break;
                    default:
                        break;
                }
                vm.exibirCabecalhoAutorizacao = false;
                vm.situacaoPagamento = situacao;
                if (vm.situacaoNavegada == null || vm.situacaoNavegada == "") {
                    sfNavegador.navegar("exibir-pagamentos-por-situacao");
                }
            } else {
                vm.situacaoPagamento = null;
            }
        }

        /** 
        * @ngdoc method
        * @name verificaMensagem
        *
        * @methodOf apl-mobile-pj.comum
        *
        * @description
        * Método responsável por interpretar status de processamento das autorizações de pagamento.
        **/
        function verificaMensagem() {
            var estadoAutorizacao = sfContexto.obterValorContextoTrabalho("estadoAutorizacao");
            if (estadoAutorizacao != undefined && estadoAutorizacao != "") {
                tipoAlerta = estadoAutorizacao.estado;
                vm.mostrarAlerta(estadoAutorizacao.estado, "");
            }
        }

        /**
        * @ngdoc method
        * @name mostrarAlerta
        *  
        * @description
        * Método responsável por exibir o alerta de acordo com o retorno da comunicação
        **/
        function mostrarAlerta(tipoAlerta, textoAlerta) {
            var caminho = "./app/assets/img/Pendencias_60x60pt_Ocre.png";

            switch (tipoAlerta) {
                case "danger":
                    if (textoAlerta.trim() == "") {
                        textoAlerta = "PAGAMENTOS NÃO AUTORIZADOS";
                    }
                    caminho = "./app/assets/img/icone_atencao_erro.png";
                    break;
                case "warning":
                    if (textoAlerta.trim() == "") {
                        textoAlerta = "PAGAMENTOS PARCIALMENTE AUTORIZADOS";
                    }
                    caminho = "./app/assets/img/Pendencias_60x60pt_Ocre.png";
                    break;
                case "success":
                    if (textoAlerta.trim() == "") {
                        textoAlerta = "PAGAMENTOS AUTORIZADOS COM SUCESSO";
                    }
                    caminho = "./app/assets/img/icone_Mensagem_SUCESSO_60x60pt.png";
                    break;
                default:
                    return;
            }
            vm.alertas.push({ tipo: tipoAlerta, texto: textoAlerta, caminho: caminho });
        }

        /**
        * @ngdoc method
        * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeAlerta() {
            vm.alertas = [];
        }

        /**
        * @ngdoc method
        * @name separarListasPagamentos
        *  
        * @description
        * Método responsável por separar listas dos pagamentos por situação
        **/
        function separarListasPagamentos() {

            if (angular.isDefined(vm.listaPagamentos)) {
                if (tipoAlerta == "success") {
                    vm.listaPagamentosAutorizados = vm.listaPagamentos.EV_OCOR[0].PAGAMENTOS;
                    vm.listaPagamentosParcialmenteAutorizados = vm.listaPagamentos.EV_OCOR[1].PAGAMENTOS;
                    vm.listaPagamentosNaoAutorizados = vm.listaPagamentos.EV_OCOR[2].PAGAMENTOS;
                }
            }
        }

        /**
        * @ngdoc method
        * @name removerFiltro
        *  
        * @description
        * Método responsável por limpar o filtro
        **/
        function removerFiltro() {
            vm.pesquisaVisivel = false;
            vm.limparPesquisa();
        }

        /**
        * @ngdoc method
        * @name limparPesquisa
        *
        * @methodOf apl-mobile-pj.comum
        *  
        * @description
        * Método responsável por limpar o filtro de pesquisa
        **/
        function limparPesquisa() {
            vm.filtroPesquisa = "";
        }

        /**
        * @ngdoc method
        * @name exibirPesquisa
        *
        * @methodOf apl-mobile-pj.comum
        *  
        * @description
        * Método responsável por limpar o filtro de pesquisa
        **/
        function exibirPesquisa() {
            vm.pesquisaVisivel = true;
        }

        /**
        * @ngdoc overview
        * @ngdoc method
        * @name abrirCompartilhamento
        *
        * @description
        * Método responsável por abrir modal de compartilhamento
        **/
        function abrirCompartilhamento(pagamento) {
            vm.pagamentoSelecionado = pagamento;
            modal.abrirModal(undefined,
                undefined,
                "modalCompartilhamento",
                pesquisaPagamentoSelecionado);
        }


        /**
        * @ngdoc overview
        * @ngdoc method
        * @name pesquisaPagamentoSelecionado
        *
        * @description
        * Método responsável por consultar detalhes do comprovante do pagamento selecionado
        **/
        function pesquisaPagamentoSelecionado() {
            //sfContexto.definirValorContextoSessao("token",
                //"Agencia=00200,Conta=1636800,CodigoCanal=IPJ,Senha=XXXXXXXX,ValorOperacao=1,CodigoCliente=000000000,ShortName=VALISERE       ,UserId=VALISERE,BaseCGC=000000000,CentralAtendimento=N,TokenValidado=S");

            var dadosLogin = sfContexto.obterValorContextoTrabalho("dadosLogin");

            var param = {
                "PGGD_RC_QT_OCOR": "0001",
                "PGGD_RC_OCOR": [{
                    "PGGD_RC_AGENCIA": vm.pagamentoSelecionado.EV_AGENCIA,// "00200",
                    "PGGD_RC_CONTA": vm.pagamentoSelecionado.EV_CONTA,//"001636800",
                    "PGGD_RC_CGC_FORN": vm.pagamentoSelecionado.EV_CGC_CPF_FORN,//"3379",
                    "PGGD_RC_COMPR": vm.pagamentoSelecionado.EV_COMPROM//"OUT4587"
                }],
                "shortname": dadosLogin.shortname,
                "userId": dadosLogin.username
            };

            interpretadorComunicacao
                .interpretar(exibicaoComprovanteFactory
                    .exibirComprovante(param))
                .sucesso(sucesso)
                .aviso(erro)
                .erro(erro);

            /**
            * @ngdoc method
            * @name sucesso
            * 
            * @memberOf situacaoPagamentoController.js
            *
            * @description        
            * Método executado em caso de sucesso ao informar que o comprovante foi exibido
            **/
            function sucesso(data) {
                vm.pagamentoDetalhado = data.PGGD_EV_ITEM;
                sfContexto.definirValorContextoTrabalho("pagamentoDetalhadoFornecedor", vm.pagamentoDetalhado);
                sfContexto.definirValorContextoTrabalho("situacaoNavegada", "AUTORIZADO");
                marcarComprovanteExibido();
            }

            /**           
           * @ngdoc method
           * @name erro
           * 
           * @memberOf situacaoPagamentoController.js
           *
           * @description
           * Método executado em caso de erro ao informar que o comprovante foi exibido
           **/
            function erro() {
            }

        }


        /**
        * @ngdoc overview
        * @ngdoc method
        * @name marcarComprovanteExibido
        *
        * @description
        * Método responsável por informar que o comprovante foi exibido
        **/
        function marcarComprovanteExibido() {
            //TODO persistência shortname e UserId
            //sfContexto.definirValorContextoSessao("token",
            //"Agencia=00000,Conta=0000000,CodigoCanal=IPJ,Senha=XXXXXXXX,ValorOperacao=1,CodigoCliente=000000000,ShortName=VALISERE       ,UserId=VALISERE,BaseCGC=000000000,CentralAtendimento=N,TokenValidado=S");
            var dadosLogin = sfContexto.obterValorContextoTrabalho("dadosLogin");

            var param = {
                "credencial": {
                    "senha": ""
                },
                "PGIM_RC_QTOC": "0001",
                "PGIM_RC_OCOR": [{

                    "PGIM_RC_AGENCIA": vm.pagamentoSelecionado.EV_AGENCIA,//"00200",
                    "PGIM_RC_CONTA": vm.pagamentoSelecionado.EV_CONTA,//"002012834",
                    "PGIM_RC_CD_FORN": vm.pagamentoSelecionado.EV_CGC_CPF_FORN,//"00022389827870",
                    "PGIM_RC_COMPR": vm.pagamentoSelecionado.EV_COMPROM,//"OUT7556",
                    "PGIM_RC_VALOR": vm.pagamentoSelecionado.EV_VLR_COMPROM,//"00000000000115644",
                    "PGIM_RC_NM_CED": "TESTE                                   ",
                    "PGIM_RC_DT_PAG": vm.pagamentoSelecionado.EV_DT_PAG,//"20160712",
                    "PGIM_RC_TP_COMPR": "TED",
                    "PGIM_RC_ST_COMPR": vm.pagamentoSelecionado.EV_SITUACAO//"AUTORIZADO     "
                }
                ],
                "shortname": dadosLogin.shortname,
                "userId": dadosLogin.username
            };


            interpretadorComunicacao
                .interpretar(identificarComprovanteCompartilhadoFactory
                    .identificarComprovanteCompartilhado(param))
                .sucesso(identificarComprovanteCompartilhadoSucesso)
                .aviso(identificarComprovanteCompartilhadoSucesso)
                .erro(identificarComprovanteCompartilhadoSucesso);



            /**
            * @ngdoc method
            * @name identificarComprovanteCompartilhadoSucesso
            * 
            * @memberOf situacaoPagamentoController.js
            *
            * @description        
            * Método executado em caso de sucesso ao informar que o comprovante foi exibido
            **/
            function identificarComprovanteCompartilhadoSucesso(data) {
                if (parseInt(data.statusProcessamento.mensagem.severidade) == 0) {
                    sfNavegador.navegar("exibir-comprovante-fornecedor");
                }
            }
        }


    }


})();