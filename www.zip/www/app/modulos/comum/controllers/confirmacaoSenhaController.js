(function () {
    "use strict";

    /**
     * @description
     * Controller para a confirmação de senhas
     */
    angular.module("apl-mobile-pj.comum").controller("confirmacaoSenhaController", confirmacaoSenhaController);

    confirmacaoSenhaController.$inject = ["$uibModalInstance",
        "dados",
        "validarSenhaFactory",
        "interpretadorComunicacao",
        "sfToken",
        "sfContexto",
        "modal"];

    /**
     * @description controller de validação de senha
     */
    function confirmacaoSenhaController($uibModalInstance,
        dados,
        validarSenhaFactory,
        interpretadorComunicacao,
        sfToken,
        sfContexto,
        modal) {

        //TODO: Implementar a validação de senhas pelo componente da arquitetura.

        var vm = this;
        vm.dados = dados;
        vm.acaoCancelar = acaoCancelar;
        vm.confirmarSenhaToken = confirmarSenhaToken;
        vm.senha = "";
        vm.token = "";
        vm.exibeToken = true;
        var dadosLogin = "";
        var serialTokenDispositivo = "";
        var serialTokenDispositivoUsuario = "";

        verificarTipoToken();

        /**
        * @ngdoc overview
        * @name confirmarSenhaToken
        *
        * @memberOf confirmacaoSenhaController
        *
        * @description
        * Método disparado ao ocorrer a confirmação no modal
        **/
        function confirmarSenhaToken() {
            validarCampos();
        }

        /**
        * @ngdoc overview
        * @name acaoCancelar
        *
        * @memberOf confirmacaoSenhaController
        *
        * @description
        * Método disparado ao ocorrer o cancelamento na modal
        **/
        function acaoCancelar() {
            $uibModalInstance.dismiss(vm.dados);
        }

        /**
         * @description validarCampos
         */
        function validarCampos() {
            var mensagemModal = "";

            if (vm.senha == "") {
                mensagemModal = "senha não informada";
            }
            else if (vm.senha.lenght < 8) {
                mensagemModal = "senha deve conter 8 caracteres";
            }

            if (vm.exibeToken) {
                if (vm.token == "") {
                    mensagemModal = "token não informado";
                }
                else if (vm.token.lenght < 6) {
                    mensagemModal = "token deve conter 6 caracteres";
                }
            }

            if (mensagemModal != "") {
                modal.abrirModal(undefined,
                    mensagemModal);
            }
            else {
                transacaoValidarSenha();
            }
        }

        /**
         * @description transacaoValidarSenha
         */
        function transacaoValidarSenha() {
            var requisicao = {
                "VLSE_RC_SENHA_ATU": vm.senha
            };

            interpretadorComunicacao.interpretar(validarSenhaFactory.validarSenha(requisicao))
                .sucesso(sucesso)
                .erro(erro)
                .aviso(erro);

            /**
             * @description sucesso
             */
            function sucesso() {

                var novoRetorno = {
                    senha: vm.senha,
                    token: vm.token,
                    dados: vm.dados
                };

                $uibModalInstance.close(novoRetorno);
            }

            /**
             * @description erro
             */
            function erro(data) {
                modal.abrirModal(undefined,
                    data.statusProcessamento.message);
            }
        }

        /**
	    * @description verificarTipoToken
	    */
        function verificarTipoToken() {
            vm.exibeToken = true;
            serialTokenDispositivo = sfContexto.obterValorContextoTrabalho("tokenSerial");
            dadosLogin = sfContexto.obterValorContextoTrabalho("dadosLogin");

            var param = {
                "tipoDevice": "",
                "tipoPessoa": "PJ",
                "device": "",
                "shortname": dadosLogin.shortname,
                "userId": dadosLogin.username
            };

            interpretadorComunicacao.interpretar(sfToken.autenticacao.validarDispositivo(param))
                .sucesso(sucesso)
                .aviso(erro)
                .erro(erro);

            /**
            * @description verificarTipoToken sucesso
            */
            function sucesso(data) {
                serialTokenDispositivoUsuario = data.serialNumberMobile;

                sfToken.obterSequencia(false)
                    .then(sequenciaSucesso)
                    .catch(sequenciaErro);
                /**
                 * @description sucesso obter sequencia
                 */
                function sequenciaSucesso(data) {
                    vm.token = data.data.sequencia;

                    if (serialTokenDispositivo == serialTokenDispositivoUsuario) {
                        vm.exibeToken = false;
                    }
                }

                /**
                 * @description erro obter sequencia
                 */
                function sequenciaErro() {
                }
            }

            /**
            * @description verificarTipoToken erro
            */
            function erro(data) {
                modal.abrirModal(undefined,
                    data.statusProcessamento.message);

            }
        }
    }

})();