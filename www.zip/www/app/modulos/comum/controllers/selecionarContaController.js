(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").controller("selecionarContaController", selecionarContaController);

    selecionarContaController.$inject = ["$uibModalInstance", "dados"]; 
    
    /**
     * @description Constroller de seleção de contas.
     */
    function selecionarContaController ($uibModalInstance, dados) {

        var vm = this;

        vm.dados = dados.lista;
        vm.titulo = dados.titulo;
        vm.mensagem = dados.mensagem;
        vm.selecionarConta = selecionarConta;
        vm.acaoOK = acaoOK;
        vm.acaoCancelar = acaoCancelar;
        vm.limparSelecao = limparSelecao;
        vm.selecionarPreferencial = selecionarPreferencial;
        // limparSelecao();
        // selecionarPreferencial();

        /**
        * @ngdoc overview
        * @name acaoOK
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método disparado ao ocorrer a confirmação no modal
        **/
        function acaoOK(dadosOK) {
            $uibModalInstance.close(dadosOK);
        }

        /**
        * @ngdoc overview
        * @name acaoCancelar
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método disparado ao ocorrer o cancelamento na modal
        **/
        function acaoCancelar(dadosCancelar) {
            $uibModalInstance.dismiss(dadosCancelar);
        }

        /**
        * @ngdoc overview
        * @name selecionarConta
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método que retorna a conta selecionada na modal para a controller principal
        **/
        function selecionarConta(conta, cnpj, nome) {
            limparSelecao();
            conta.selecionado = true;
            conta.cnpj = cnpj;
            conta.nome = nome;
            vm.acaoOK(conta);
        }

        /**
        * @ngdoc overview
        * @name limparSelecao
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método utilizado para limpar a flag de seleção de conta
        **/
        function limparSelecao() {
            angular.forEach(vm.dados, function (filial) {
                angular.forEach(filial.contas, function (conta) {
                    conta.selecionado = false;
                });
            });
        }

        /**
        * @ngdoc overview
        * @name selecionarPreferencial
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método utilizado para inicializar a tela com a conta selecionad previamente
        **/
        function selecionarPreferencial() {
            angular.forEach(vm.dados, function (filial) {
                angular.forEach(filial.contas, function (conta) {
                    if (conta.agencia == vm.dados.contaSelecionada.agencia
                        && conta.conta == vm.dados.contaSelecionada.numero) {
                        conta.selecionado = true;
                        filial.selecionado = true;
                    }
                });
            });
        }
    }


    angular.module("apl-mobile-pj.comum").filter("selecionarQuandoUnico", function () {
        return function (empresas, pesquisa) {

            var primeiraFilial;
            var haFilialSelecionada;

            if (angular.isUndefined(pesquisa)) {
                return empresas;
            }

            angular.forEach(empresas, function (filial) {
                angular.forEach(filial.contas, function (conta) {
                    if ((conta.agencia.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1
                        || conta.conta.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1
                        || filial.cnpj.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1
                        || filial.nome.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1)) {

                        if (angular.isUndefined(primeiraFilial)) {
                            primeiraFilial = filial;
                        }

                        if (filial.selecionado) {
                            haFilialSelecionada = true;
                        }

                    }
                });
            });

            if (!haFilialSelecionada
                && angular.isDefined(primeiraFilial)) {
                primeiraFilial.selecionado = true;
            }

            return empresas;
        };
    });

    angular.module("apl-mobile-pj.comum").filter("pesquisarContaSeVazio", function () {
        return function (contas, pesquisa, empresa) {
            var filtrados = [];

            if (angular.isUndefined(pesquisa)) {
                return contas;
            }

            angular.forEach(contas, function (conta) {
                if (conta.agencia.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1
                    || conta.conta.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1
                    || empresa.cnpj.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1
                    || empresa.nome.toUpperCase().indexOf(pesquisa.toUpperCase()) != -1) {
                    filtrados.push(conta);
                }
            });

            return filtrados;
        };
    });

    angular.module("apl-mobile-pj.comum").filter("cnpj", function () {
        return function (entrada) {
            var resultado = "" + Array(14 - entrada.length + 1).join("0") + entrada;
            resultado = resultado.replace(/\D/g, "")
                .replace(/^(\d{2})(\d)/, "$1.$2")
                .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
                .replace(/\.(\d{3})(\d)/, ".$1/$2")
                .replace(/(\d{4})(\d)/, "$1-$2");

            return resultado;
        };
    });

})();