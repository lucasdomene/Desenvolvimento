(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").factory("utilitariosAplicacaoFactory", utilitariosAplicacao);

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.comum.factories:utilitariosAplicacao
     * @module apl-mobile-pj.comum.utilitariosAplicacao
     * 
     * @description
     * Factory responsável por preencher espacos a direita
     */
    function utilitariosAplicacao() {
        return {
            preencheEspacosADireita: preencheEspacosADireita
        };
    }
    /**
   * @ngdoc method
   * @name preencheEspacosADireita
   *
   * @methodOf  apl-mobile-pj.comum.factories:utilitariosAplicacao
   *  
   * @description
   * Método responsável por preencher espacos a direita.
   **/
    function preencheEspacosADireita(string_, len_) {
        if (string_ && len_) {
            if (!isNaN(len_)) {
                var pad = " ";
                for (var i = 0; i < len_; i++) {
                    pad += " ";
                }
                return (string_ + pad).slice(0, len_);
            }
            else {
                return string_;
            }
        }
        else {
            return string_;
        }
    }

})();