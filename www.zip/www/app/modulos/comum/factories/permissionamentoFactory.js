(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").factory("validapermissionamento", validapermissionamento);

    validapermissionamento.$inject = ["sfContexto"];

    /**
     * @description Diretiva criada para gerenciar o momento para fixar o cabeçalho de uma tabela ao topo da aplicação 
     */
    function validapermissionamento(sfContexto) {
        return {
            validacao: validacao
        };

        /**
         * @description Teste
         */
        function validacao(grupo, servico, nivel) {
            var permissoes = sfContexto.obterValorContextoTrabalho("permissionamento");
            var permitido = false;

            if (permissoes != undefined)
            {
                //permissao por nivel de acesso do usuario
                if (nivel != "")
                {
                    if (nivel == permissoes.TOKEN.ADLG_TS_USER_UNIF_M)
                    {
                        permitido = true;                        
                    }
                }
                //permissao por grupo de servico e servico
                else if (grupo != "" && servico != "") {
                    //verifica o grupo
                        for (var permissaoGrp in permissoes.GRUPO_SERVICOS) {
                            var grp = permissoes.GRUPO_SERVICOS[permissaoGrp];
                            if (grp.ADLG_TS_CD_GRP == grupo)
                            {
                                //verifica o servico
                                for (var permissaoSrv in grp.ADLG_EV_SUBGRUPOS) {                             
                                    var srv = grp.ADLG_EV_SUBGRUPOS[permissaoSrv];
                                    if (srv.ADLG_TS_CD_SVC == servico)
                                    {
                                        //possui a permissao 
                                        permitido = true;
                                        break;
                                    }
                                }
                                if (permitido){
                                    break;
                                }
                            }
                        }    
                } 
                //validaão de permissão não se aplica
                else 
                {
                    permitido = true;
                }
            }

            return permitido;
        }
    }

})();

