(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").factory("modal", modal);

    modal.$inject = [
        "$uibModal"
    ];

    /**
     * @description Implementação padrão do modal de exibição nas telas.
     */
    function modal($uibModal) {

        return {
            abrirModal: abrirModal
        };

        /**
         * @description Método responsável pela abertura do modal padrão.
         */
        function abrirModal(titulo,
            mensagem,
            nomeTemplate,
            acaoOK,
            acaoCancelar,
            dados,
            controller,
            controllerAs,
            size) {

            if (angular.isUndefined(nomeTemplate)
                || nomeTemplate == null || nomeTemplate == "") {
                nomeTemplate = "modalMensagem";

            }

            if (angular.isUndefined(controller)) {
                controller = "modalController";
            }

            if (angular.isUndefined(controllerAs)) {
                controllerAs = "ctrlModal";
            }

            if (angular.isUndefined(dados)) {
                dados = [];
            }

            if (titulo != undefined && titulo != null && titulo != "") {
                dados.titulo = titulo;
            }

            if (mensagem != undefined && mensagem != null && mensagem != "") {
                dados.mensagem = mensagem;
            }

            if (size == undefined || size == null || size == ""){
                size = "sm";
            }

            var instanciaModal = $uibModal.open({
                animation: true,
                templateUrl: "./app/modulos/comum/templates/modal/" + nomeTemplate + ".html",
                controller: controller,
                controllerAs: controllerAs,
                backdrop: "static",
                size: size,
                resolve: {
                    dados: function () {
                        return dados;
                    }
                }
            });

            instanciaModal.result.then(function (dadosRetornoModalOK) {
                if (acaoOK) {
                    acaoOK(dadosRetornoModalOK);
                }
            }, function (dadosRetornoModalCancelar) {
                if (acaoCancelar) {
                    acaoCancelar(dadosRetornoModalCancelar);
                }
            });

            return instanciaModal;

        }
    }

    angular.module("apl-mobile-pj.comum").controller("modalController", modalController);

    modalController.$inject = [
        "$uibModalInstance",
        "dados"
    ];

    /**
     * @description Controller base da modal de exibição para as telas.
     */
    function modalController($uibModalInstance, dados) {

        var vm = this;

        vm.dados = dados;
        vm.titulo = dados.titulo;
        vm.mensagem = dados.mensagem;

        vm.acaoOK = function (dadosOK) {
            $uibModalInstance.close(dadosOK);
        };

        vm.acaoCancelar = function (dadosCancelar) {
            $uibModalInstance.dismiss(dadosCancelar);
        };

    }
})();