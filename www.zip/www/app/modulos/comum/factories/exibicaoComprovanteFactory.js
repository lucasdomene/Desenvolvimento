(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name exibicaoComprovanteFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:exibicaoComprovanteFactory
    *
    * @description
    * Factory de conexão com API exibicaoComprovanteFactory
    **/
    angular.module("apl-mobile-pj.comum")
        .factory("exibicaoComprovanteFactory", exibicaoComprovanteFactory);

    exibicaoComprovanteFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name exibicaoComprovanteFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:exibicaoComprovanteFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function exibicaoComprovanteFactory(conectorAPI, appSettings, utilitarios) {

        return {
            exibirComprovante: exibirComprovante
        };

        /**
        * @ngdoc method
        * @name exibirComprovante
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento:exibirComprovante
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function exibirComprovante(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "exibicao-comprovante"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();