(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name validarSenhaFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:validarSenhaFactory
    *
    * @description
    * Factory de conexão com API validarSenhaFactory
    **/
    angular.module("apl-mobile-pj.comum")
        .factory("validarSenhaFactory", validarSenhaFactory);

    validarSenhaFactory.$inject = ["sfConectorAPI"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarCotacoesService
    *
    * @methodOf apl-mobile-pj.extrato:validarSenhaFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function validarSenhaFactory(conectorAPI) {

        return {
            validarSenha: validarSenha
        };

        /**
        * @ngdoc method
        * @name listarCotacoesService
        *
        * @methodOf apl-mobile-pj.extrato:validarSenha
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function validarSenha(requisicao) {

            var param = {
                "VLSE_RC_SENHA_ATU": requisicao.VLSE_RC_SENHA_ATU,
                "VLSE_RC_SENHA_ALT": "",
                "VLSE_RC_TP_OPER": "1",
                "VLSE_RC_ORIG": "IPJ",
                "VLSE_RC_GR_SERV": "   ",
                "VLSE_RC_SERV": "000"
            };

            var req = {
                method: "POST",
                url: "validar-senha",
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();