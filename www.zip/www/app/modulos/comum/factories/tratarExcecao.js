(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").factory("tratarExcecao", tratarExcecao);

    tratarExcecao.$inject = ["sfNavegador", "$log", "modal", "sfAutenticador"];

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.comum.factories:tratarExcecao
     * @module apl-mobile-pj.comum.tratarExcecao
     * 
     * @description
     * Factory responsável acionar o tratamento de excecao
     */
    function tratarExcecao(sfNavegador, $log, modal, sfAutenticador) {
        return {
            tratarErro: tratarErro
        };

        /**
            * @ngdoc overview
            * @name apl-mobile-pj.comum.factories:tratarExcecao.tratarErro
            * @module apl-mobile-pj.comum.tratarExcecao.tratarErro
            * 
            * @description
            * Factory responsável acionar o tratamento de excecao 
         */
        function tratarErro(erro_) {
            $log.log("Erro não tratado - Obtido pela aplicação: " + erro_);

            modal.abrirModal(
                "Segurança - Erro obtido pela aplicação",
                erro_,
                "", iniciarFluxo);
        }

        /**
         * @description Método responsável por iniciar o fluxo principal.
         */
        function iniciarFluxo() {
            sfAutenticador.logoff().then(sucesso).catch(sucesso);

            /**
             * @description Método de sucesso para a saida da aplicação
             */
            function sucesso() {
                sfNavegador.iniciarFluxo("apl-mobile-pj-login");
            }
        }
    }
})();