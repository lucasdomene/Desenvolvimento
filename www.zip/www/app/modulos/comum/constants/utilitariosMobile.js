(function () {
    "use strict";

    var utilitarios = {
        getTemplate: function (elem, attrs) {
            return (attrs.template ? "./app/modulos/comum/views/" + this.name + "/" + attrs.template + ".html" : "./app/modulos/comum/views/" + this.name + "/default.html");
        }
    };

    angular.module("apl-mobile-pj.comum").constant("utilitariosMobile", utilitarios);
})();