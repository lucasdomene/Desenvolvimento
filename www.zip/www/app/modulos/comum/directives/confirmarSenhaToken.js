(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("confirmarsenhatoken", confirmarsenhatokenDirective);

    confirmarsenhatokenDirective.$inject = ["utilitariosMobile"]; 

    /**
    * @ngdoc directive
    * @name confirmarsenhatokenDirective
    *
    * @description
    * Diretiva responsável por controlar o componente de confirmar senha e token
    **/
    function confirmarsenhatokenDirective(utilitariosMobile) { 
        return {
            restrict: "E",
            scope: {
                acaoconfirmar: "&",
                acaocancelar: "&",
                senha: "=senha",
                token: "=token",
                exibeToken: "=exibeToken"
            },
            templateUrl: utilitariosMobile.getTemplate,
            link: link
        };
    }

    /**
    * @ngdoc method
    * @name link
    *
    * @methodOf confirmarSenhaToken.js
    *  
    * @description
    * Método responsável por adicionar novo método ao scope.
    **/
    function link(scope) {
        scope.apenasNumeros = apenasNumeros;

        /**
        * @ngdoc method
        * @name iniciar
        *
        * @methodOf confirmarSenhaToken.js
        *  
        * @description
        * Método responsável por permitir apenas digitacao de valores númericos.
        **/
        function apenasNumeros(event) {
            if (event.code != "Enter") {
                var regex = new RegExp("^([0-9])*$");
                var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);

                if (!regex.test(key)) {
                    event.preventDefault();
                }
            }
        }
    }
})();