(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("cabecalho", cabecalhoDirective);

    cabecalhoDirective.$inject = ["utilitariosMobile"];

    /**
    * @ngdoc directive
    * @name cabecalhoDirective
    *
    * @description
    * Diretiva responsável por controlar o componente de cabeçalho
    **/
    function cabecalhoDirective(utilitariosMobile) {
        return {
            restrict: "E",
            scope: {
                acaovoltar: "&",
                acaopesquisar: "&",
                acaomenu: "&",

                titulo: "@",

                mostrarvoltar: "@",
                mostrarmenu: "@",
                mostrarlogo: "@",
                mostrarlupa: "@"
            },
            templateUrl: utilitariosMobile.getTemplate
        };
    }

})();