//IMPLEMENTATION

(function () {
    "use strict";

    //TODO: REMOVER
    var mockitensMenu = [
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_extrato-01.png",
            fluxoDestino: "",
            // fluxoDestino: "apl-mobile-pj-extrato",
            texto: "Extrato de Movimentação",
            destaque: false,
            permissaogrupo: "POS",
            permissaoservico: "004",
            permissaonivel: ""
        },
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_autorizacao-01.png",
            fluxoDestino: "",
            // fluxoDestino: "apl-mobile-pj-autorizacaoPagamento",
            texto: "Autorização de Pagamentos",
            destaque: false,
            permissaogrupo: "PAG",
            permissaoservico: "001",
            permissaonivel: ""
        },
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_recebiveis-01.png",
            fluxoDestino: "",
            texto: "Recebimentos",
            destaque: false,
            permissaogrupo: "",
            permissaoservico: "",
            permissaonivel: ""
        },
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_investimentos-01.png",
            fluxoDestino: "",
            // fluxoDestino: "apl-mobile-pj-investimentos",
            texto: "Investimentos",
            destaque: false,
            permissaogrupo: "POS",
            permissaoservico: "001",
            permissaonivel: ""
        }
    ];

    var itensMenuFixo = [
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_home.png",
            texto: "Início",
            fluxoDestino: "apl-mobile-pj-home",
            exibido: true,
            destaque: true,
            permissaogrupo: "",
            permissaoservico: "",
            nivel: "",
            delimitadorTopo: true,
            delimitadorRodape: true
        },
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_seguranca-01.png",
            fluxoDestino: "apl-mobile-pj-orquestrador-seguranca",
            texto: "Segurança",
            destaque: false,
            permissaogrupo: "",
            permissaoservico: "",
            permissaonivel: "",
            delimitadorTopo: true
        },
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_chat-01.png",
            fluxoDestino: "",
            texto: "Fale conosco",
            destaque: false,
            permissaogrupo: "",
            permissaoservico: "",
            permissaonivel: ""
        },
        {
            href: "#",
            src: "./app/assets/img/menu/00_24_agencia-01.png",
            fluxoDestino: "",
            texto: "Localize uma Agência",
            destaque: false,
            permissaogrupo: "",
            permissaoservico: "",
            permissaonivel: ""
        }
    ];

    /**
    * @ngdoc overview
    * @name apl-mobile-pj.areaPrincipal.menuDirective
    * 
    * @requires sfNavegador
    * 
    * @description
    * Directive responsável pela tratativa das ações a serem realizadas na view da menu logada.
    **/
    angular.module("apl-mobile-pj.comum").directive("menupj", menuDirective);

    menuDirective.$inject = [
        "sfNavegador",
        "utilitariosMobile",
        "sfContexto",
        "sfAutenticador"
    ];

    /**
    * @ngdoc 
    * @name menuDirective
    *
    * @methodOf apl-mobile-pj.areaPrincipal.menu
    *  
    * @description
    * Directive responsável por manipular a tela menu da área logada.
    **/
    function menuDirective(sfNavegador, utilitariosMobile, contexto, sfAutenticador) {
        return {
            restrict: "E",
            scope: {
                itemdestacado: "@",
                itensMenu: "@",
                nomeUsuario: "@",
                shortName: "@"
            },
            link: executarAcaoMenuPJ,
            templateUrl: utilitariosMobile.getTemplate
        };
        
        /**
         * @description Comment
         */
        function executarAcaoMenuPJ(scope) {      
            
            scope.sair = function () {
                sfAutenticador.logoff().then(sucesso).catch(sucesso);

                /**
                * @description Método de sucesso para a saida da aplicação
                */
                function sucesso(){
                    sfNavegador.iniciarFluxo("apl-mobile-pj-login");
                }
            };

            scope.itensMenu = [];
                 
            //adiciona o item do Inicio 
            scope.itensMenu[0] = itensMenuFixo[0];
            
            //percorro o mock e adiciono no scope os itens dinamicos
            for(var iContador = 0; iContador < mockitensMenu.length; iContador++)
            {
                //adiciono no array do menu os itens dinamicos
                 scope.itensMenu.push(mockitensMenu[iContador]);
            }
            
            //Adiciobno os ultimos itens fixos
            scope.itensMenu.push(itensMenuFixo[1]);
            scope.itensMenu.push(itensMenuFixo[2]);
            scope.itensMenu.push(itensMenuFixo[3]);

            angular.forEach(scope.itensMenu, function (item) {
                if (item.texto == scope.itemdestacado) {
                    item.destaque = true;
                }
                else {
                    item.destaque = false;
                }
            });

            scope.nomeUsuario = contexto.obterValorContextoTrabalho("nomeClienteUltimoAcesso");
            scope.shortName = contexto.obterValorContextoTrabalho("lembrarShortname");
        }
    }



})();




