(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("fixaCabecalhoTabelaComScroll", fixaCabecalhoTabelaComScroll);

    fixaCabecalhoTabelaComScroll.$inject = ["$window", "$document"];

    /**
     * @description Diretiva criada para gerenciar o momento para fixar o cabeçalho de uma tabela ao topo da aplicação 
     */
    function fixaCabecalhoTabelaComScroll($window, $document) {
        return {
            restrict: "A",
            link: executaAcao
        };

        /**
         * @description Ação que será executada na criação da Diretiva.
         */
        function executaAcao(scope, element, attrs) {
            var divScroll = angular.element($document[0].querySelector("#" + attrs.divscrollconteudo));

            var topClass = attrs.fixaCabecalhoTabelaComScroll;
            var offsetTop = attrs.posicaofixa;

            divScroll.bind("scroll", function () {
                if (this.scrollTop >= offsetTop) {
                    element.addClass(topClass);
                } else {
                    element.removeClass(topClass);
                }
            });
        }
    }
})(); 