(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("botao", botaoDirective);
    
    botaoDirective.$inject = ["utilitariosMobile"];
    
    /**
    * @ngdoc directive
    * @name botaoDirective
    *
    * @description
    * Diretiva responsável por controlar o componente de botão
    **/
    function botaoDirective(utilitariosMobile) {
        return {
            restrict: "E",
            scope: {
                texto: "@",
                acao: "&"
            },
            templateUrl: utilitariosMobile.getTemplate
        };
    }

})();