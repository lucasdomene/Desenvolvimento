(function () {
    "use strict";

    angular.module("apl-mobile-pj.comum").directive("cabecalhotoken", cabecalhotoken);
    
    cabecalhotoken.$inject = ["utilitariosMobile"];
    
    /**
    * @ngdoc directive
    * @name cabecalhotoken
    *
    * @description
    * Diretiva responsável por controlar o componente de cabeçalho de passo a passo
    **/
    function cabecalhotoken(utilitariosMobile) {
        return {
            restrict: "E",
            scope: {
                ponto: "@"
            },
            link: executaAcao,
            templateUrl: utilitariosMobile.getTemplate
        };
        
        /**
        * @ngdoc function
        * @name executaAcao
        *
        * @description
        * Função responsável por controlar a chamada de ação do componente de cabeçalho de passo a passo
        **/
        function executaAcao(scope, element, attr) {
            var passoAtual = element[0].querySelector("#" + attr.ponto);
            angular.element(passoAtual).addClass("passo-ativo");
            
            var descpassoAtual = element[0].querySelector("#desc" + attr.ponto);
            angular.element(descpassoAtual).addClass("desc-passo-ativo");
        }
    }
})();
