(function () {

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.extrato
     * 
     * @require ui.bootstrap, ngAnimate
     * 
     * @description
     * Módulo que define os fluxos de navegacao pelos controles de cadastro e liberação de dispositivos.
     **/
    angular.module("apl-mobile-pj.extrato", ["ui.bootstrap", "ngAnimate", "rzModule"])
        .config(extratoModule)
        .run(["sfTradutor", function (tradutor) {
            tradutor.adicionarDicionarios(["app/modulos/extrato/extratoMovimentacao/internacionalizacao"]);
        }]);


    extratoModule.$inject = ["sfNavegadorProvider"];

    /**
    * @ngdoc overview
    * @name extratoModule
    * 
    * @description
    * Navegação do módulo extratoModule.
    **/
    function extratoModule(sfNavegadorProvider) {
        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-extrato")
                .adicionarEstado("extrato", {
                    templateUrl: "./app/modulos/extrato/extratoMovimentacao/views/extrato.html",
                    controller: "extratoMovimentacaoController as exmovCtrl",
                    abstract: true
                })
                .adicionarEstado("extrato.extrato-Movimentacao", {
                    templateUrl: "./app/modulos/extrato/extratoMovimentacao/views/extratoMovimentacao.html",
                    parent: "extrato"
                })
                .definirEstadoInicial("extrato.extrato-Movimentacao")
        );
    }
})();