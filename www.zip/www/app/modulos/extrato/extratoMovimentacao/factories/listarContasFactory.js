(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarContasFactoryFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:listarContasFactoryFactory
    *
    * @description
    * Factory de conexão com API listarContasFactory
    **/
    angular.module("apl-mobile-pj.extrato")
        .factory("listarContasFactory", listarContasFactory);

    listarContasFactory.$inject = ["sfConectorAPI"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarCotacoesService
    *
    * @methodOf apl-mobile-pj.extrato:listarContasFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarContasFactory(conectorAPI) {

        return {
            listarContas: listarContas
        };

        /**
        * @ngdoc method
        * @name listarCotacoesService
        *
        * @methodOf apl-mobile-pj.extrato:listarContas
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarContas() {
            var req = {
                method: "POST",
                url: "listar-contas",
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();