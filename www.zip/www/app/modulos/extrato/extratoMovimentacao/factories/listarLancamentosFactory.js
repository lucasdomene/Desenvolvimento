(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarLancamentosFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:listarLancamentosFactory
    *
    * @description
    * Factory de conexão com API listarLancamentosFactory
    **/
    angular.module("apl-mobile-pj.extrato")
        .factory("listarLancamentosFactory", listarLancamentosFactory);

    listarLancamentosFactory.$inject = ["sfConectorAPI"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarLancamentosFactory
    *
    * @methodOf apl-mobile-pj.extrato:listarLancamentosFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarLancamentosFactory(conectorAPI) {

        return {
            listarLancamentos: listarLancamentos
        };

        /**
        * @ngdoc method
        * @name listarLancamentos
        *
        * @methodOf apl-mobile-pj.extrato:listarLancamentos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarLancamentos(param) {
            var req = {
                method: "POST",
                url: "listar-lancamentos",
                data: param,
                dataType: "json"
            };
            
            return conectorAPI.executar(req, true);
        }
    }

})();