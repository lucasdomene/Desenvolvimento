(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarSaldoFactoryFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:listarSaldoFactoryFactory
    *
    * @description
    * Factory de conexão com API listarSaldoFactory
    **/
    angular.module("apl-mobile-pj.extrato")
        .factory("listarSaldoFactory", listarSaldoFactory);

    listarSaldoFactory.$inject = ["sfConectorAPI"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarCotacoesService
    *
    * @methodOf apl-mobile-pj.extrato:listarSaldoFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarSaldoFactory(conectorAPI) {

        return {
            listarSaldo: listarSaldo
        };

        /**
        * @ngdoc method
        * @name listarCotacoesService
        *
        * @methodOf apl-mobile-pj.extrato:listarSaldo
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarSaldo(agencia, conta, baseCGC, shortname, username) {
            var param = {
                "baseCGC": baseCGC,
                "agencia": agencia,
                "contaCorrente": conta,
                "shortname": shortname,
                "userId": username
             };

            var req = {
                method: "POST",
                url: "listar-saldo",
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();