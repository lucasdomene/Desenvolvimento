(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name autorizarPagamentosFornecedorPorModalidadeFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:autorizarPagamentosFornecedorPorModalidadeFactory
    *
    * @description
    * Factory de conexão com API autorizarPagamentosFornecedorPorModalidadeFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoPagamento")
        .factory("autorizarPagamentosFornecedorPorModalidadeFactory", autorizarPagamentosFornecedorPorModalidadeFactory);

    autorizarPagamentosFornecedorPorModalidadeFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name autorizarPagamentosFornecedorPorModalidadeFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:autorizarPagamentosFornecedorPorModalidadeFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function autorizarPagamentosFornecedorPorModalidadeFactory(conectorAPI, appSettings, utilitarios) {

        return {
            autorizarPagamentos: autorizarPagamentos
        };

        /**
        * @ngdoc method
        * @name autorizarPagamentos
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento:autorizarPagamentos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function autorizarPagamentos(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "autorizar-pagamentos-por-modalidade"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();