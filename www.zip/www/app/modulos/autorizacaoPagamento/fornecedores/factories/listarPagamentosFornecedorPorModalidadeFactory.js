(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarPagamentosFornecedorPorModalidadeFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:listarPagamentosFornecedorPorModalidadeFactory
    *
    * @description
    * Factory de conexão com API listarPagamentosFornecedorPorModalidadeFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoPagamento")
        .factory("listarPagamentosFornecedorPorModalidadeFactory", listarPagamentosFornecedorPorModalidadeFactory);

    listarPagamentosFornecedorPorModalidadeFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarPagamentosFornecedorPorModalidadeFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:listarPagamentosFornecedorPorModalidadeFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarPagamentosFornecedorPorModalidadeFactory(conectorAPI, appSettings, utilitarios) {

        return {
            listarPagamentos: listarPagamentos
        };

        /**
        * @ngdoc method
        * @name listarPagamentos
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento:listarPagamentos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarPagamentos(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "listar-pagamento-por-modalidade"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();