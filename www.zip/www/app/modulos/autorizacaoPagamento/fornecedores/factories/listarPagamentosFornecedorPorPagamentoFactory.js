(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarPagamentosFornecedorPorPagamentoFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:listarPagamentosFornecedorPorPagamentoFactory
    *
    * @description
    * Factory de conexão com API listarPagamentosFornecedorPorPagamentoFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoPagamento")
        .factory("listarPagamentosFornecedorPorPagamentoFactory", listarPagamentosFornecedorPorPagamentoFactory);

    listarPagamentosFornecedorPorPagamentoFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarPagamentosFornecedorPorPagamentoFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoPagamento:listarPagamentosFornecedorPorPagamentoFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarPagamentosFornecedorPorPagamentoFactory(conectorAPI, appSettings, utilitarios) {

        return {
            listarPagamentos: listarPagamentos
        };

        /**
        * @ngdoc method
        * @name listarPagamentos
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento:listarPagamentos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarPagamentos(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "listar-pagamento-por-pagamento"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();