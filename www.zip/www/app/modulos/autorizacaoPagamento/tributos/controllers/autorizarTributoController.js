(function () {
    "use strict";

    /**
    * @ngdoc overview
    * @name apl-mobile-pj.extrato
    *  
    * @require navegador
    *  
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Extrato de Movimentações.
    **/
    angular.module("apl-mobile-pj.autorizacaoTributo")
        .controller("autorizarTributoController", autorizarTributoController);

    autorizarTributoController.$inject = ["sfNavegador",
        "sfMemorizador",
        "modal",
        "sfContexto",
        "sfUtilitarios",
        "interpretadorComunicacao",
        "autorizarPagamentosTributoPorModalidadeFactory",
        "autorizarPagamentosTributoPorPagamentoFactory",
        "autorizarPagamentosTributoPorContaFactory",
        "listarContasTributosFactory",
        "listarPagamentosTributoPorContaFactory",
        "listarPagamentosTributoPorModalidadeFactory",
        "listarPagamentosTributoPorPagamentoFactory",
        "$filter"
    ];

    /**
    * @ngdoc overview
    * @name autorizarTributoController
    * 
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas no Pagamento de Tributos.
    **/
    function autorizarTributoController(sfNavegador,
        sfMemorizador,
        modal,
        contexto,
        utilitarios,
        interpretadorComunicacao,
        autorizarPagamentosTributoPorModalidadeFactory,
        autorizarPagamentosTributoPorPagamentoFactory,
        autorizarPagamentosTributoPorContaFactory,
        listarContasTributosFactory,
        listarPagamentosTributoPorContaFactory,
        listarPagamentosTributoPorModalidadeFactory,
        listarPagamentosTributoPorPagamentoFactory,
        $filter
    ) {

        var vm = this;

        vm.iniciar = iniciar;
        vm.voltar = voltar;
        vm.confirmar = confirmar;

        vm.removeFiltroDataModalidade = removeFiltroDataModalidade;
        vm.removeFiltroDataPagamento = removeFiltroDataPagamento;
        vm.removeFiltroDataConta = removeFiltroDataConta;
        vm.filtrarTributoModalidade = filtrarTributoModalidade;
        vm.filtrarTributoPagamento = filtrarTributoPagamento;
        vm.filtrarTributoConta = filtrarTributoConta;
        vm.carregaDatePickerTribModalidade = carregaDatePickerTribModalidade;
        vm.carregaDatePickerTribPagamento = carregaDatePickerTribPagamento;
        vm.carregaDatePickerTribConta = carregaDatePickerTribConta;

        vm.alertasModalidade = [];
        vm.alertasPagamento = [];
        vm.alertasConta = [];
        vm.alertasDados = [];

        //variaveis utilizadas no filtra de datas
        var dtInicio;
        var pickerDtMaximo, pickerDtMinimo;
        var tipoFiltroTributoModalidade = null;

        vm.filtroAberto = false;

        vm.conta = {
            visivel: true,
            exibir: exibir,
            ocultar: ocultar,
            cnpj: null,
            agencia: null,
            numero: null,
            dv: null,
            abrirModal: abrirModalSelecaoConta,
            lista: null,
            erroNaTransacao: false
        };

        vm.contaPreferencial = {
            agencia: null,
            numero: null,
            cnpj: null,
            dv: null
        };

        vm.atualizarTotalizador = atualizarTotalizador;
        vm.atualizarTotalizadorSelecionado = atualizarTotalizadorSelecionado;

        vm.listaTributosPorConta = {};

        vm.listaTributosPorModalidade = {};

        vm.listaTributosPorPagamento = {};

        vm.validarSenha = validarSenha;

        vm.autorizarConta = {
            desabilitado: false
        };

        vm.autorizarModalidade = {
            desabilitado: false
        };

        vm.autorizarPagamento = {
            desabilitado: false
        };

        /**
        * FORNECEDORES 
        * TRIBUTOS
        **/
        vm.tipoAutorizacao = null;

        /**
        * MODALIDADE 
        * CONTA
        * PAGAMENTOS
        **/
        vm.tipoPagamento = null;

        /**
        * TRIBFEDERAIS 
        * TRIBESTADUAIS
        * MAIS
        **/
        vm.tipoFiltroTributo = null;

        vm.filtroValorMaximoTrib = null;
        vm.filtroValorMinimoTrib = null;
        vm.filtroDocumento = null;

        vm.tributoContaSelecionado = null;
        vm.selecionarTributoConta = selecionarTributoConta;

        vm.selecionarTributoModalidade = selecionarTributoModalidade;

        vm.valorTotalSelecionadoTributoPorPagamentos = 0;
        vm.valorTotalTributoPorPagamentos = 0;

        vm.abrirAutorizacaoFornecedores = abrirAutorizacaoFornecedores;
        vm.abrirAutorizacaoTributos = abrirAutorizacaoTributos;

        vm.abrirAbaModalidades = abrirAbaModalidades;
        vm.abrirAbaContas = abrirAbaContas;
        vm.abrirAbaPagamentos = abrirAbaPagamentos;
        vm.abrirFiltrarPagamentos = abrirFiltrarPagamentos;

        vm.filtrarTribFederais = filtrarTribFederais;
        vm.filtrarTribEstaduais = filtrarTribEstaduais;
        vm.filtrarTribMunicipais = filtrarTribMunicipais;
        vm.filtrarTribServicosPublicos = filtrarTribServicosPublicos;

        vm.tributo = {
            agencia: null,
            conta: null
        };

        vm.valorMinimo = null;
        vm.valorMaximo = null;

        vm.iniciar();


        /**
        * @ngdoc overview
        * @name iniciar
        * 
        * @memberOf autorizarPagamentoController.js
        *
        * @description        
        * Método responsável por inicializar as variáveis da controller
        **/
        function iniciar() {
            vm.autorizarConta.desabilitado = true;
            vm.autorizarModalidade.desabilitado = true;
            vm.autorizarPagamento.desabilitado = true;

            carregarPreferencial();

            if (vm.contaPreferencial.agencia != null
                && vm.contaPreferencial.numero != null) {

                transacaoListarTributosPorModalidade();
            } else {
                transacaoConta();
            }

            vm.tipoAutorizacao = "TRIBUTOS";
            vm.tipoPagamento = "MODALIDADE";
            vm.tipoFiltroTributo = "";

            iniciaDatePicker();
            vm.dtpickerInicioModalidadeAberto = false;
            vm.dtpickerInicioPagamentoAberto = false;
            vm.dtpickerInicioContaAberto = false;

            iniciarSlider();
        }

        /**
         * @ngdoc overview
         * 
         * @name selecionarTributoConta
         * 
         * @memberOf autorizarTributoController.js
         * 
         * @description
         * Método responsável pela seleção do pagto
         */
        function selecionarTributoConta(agencia, conta) {
            if (vm.tributoContaSelecionado != null) {
                vm.autorizarConta.desabilitado = false;
                vm.tributo.agencia = agencia;
                vm.tributo.conta = conta;
            }
            else {
                vm.autorizarConta.desabilitado = true;
            }
        }


        /**
         * @ngdoc overview
         * 
         * @name selecionarTributoModalidade
         * 
         * @memberOf autorizarTributoController.js
         * 
         * @description
         * Método responsável pela seleção do pagto
         */
        function selecionarTributoModalidade() {
            if (vm.tributoSelecionado != null) {
                vm.autorizarModalidade.desabilitado = false;
                tipoFiltroTributoModalidade = vm.tributoSelecionado;
            }
            else {
                vm.autorizarModalidade.desabilitado = true;
            }
        }

        /**
        * @ngdoc overview
        * @name carregarPreferencial
        * 
        * @memberOf autorizarTributoController.js
        *
        * @description        
        * Método responsável por recupeara a conta preferencial e popular a conta exibida.
        **/
        function carregarPreferencial() {
            var contaPreferencial = sfMemorizador.obter("autorizacaoPagamento.contaPreferencial");

            if (angular.isDefined(contaPreferencial) && contaPreferencial != null) {
                vm.conta.cnpj = contaPreferencial.cnpj;
                vm.conta.agencia = contaPreferencial.agencia;
                vm.conta.numero = contaPreferencial.numero;
                vm.contaPreferencial = contaPreferencial;
                atualizarConta();
            }
        }

        /**
        * @ngdoc overview
        * @name atualizarConta
        * 
        * @memberOf autorizarTributoController.js
        *
        * @description        
        * Método responsável por atualizar a conta em uso através da conta preferencial.
        **/
        function atualizarConta() {
            vm.conta.agencia = vm.contaPreferencial.agencia;
            vm.conta.numero = vm.contaPreferencial.numero;
            vm.conta.cnpj = vm.contaPreferencial.cnpj;
        }

        /**
        * @ngdoc overview
        * @name abrirModalSelecaoConta
        *
        * @memberOf autorizarTributoController.js
        *
        * @description
        * Método incializa e abre a modal de seleção de contas do cliente
        **/
        function abrirModalSelecaoConta() {
            transacaoConta();
        }

        /**
        * @ngdoc overview
        * @name abrirModalAutorizarPagamento
        *
        * @memberOf autorizarTributoController.js
        *
        * @description
        * Método incializa e abre a modal de seleção de contas do cliente
        **/
        function abrirModalAutorizarPagamento() {
            modal.abrirModal(undefined,
                undefined,
                "modalAutorizarPagamento",
                validarSenha,
                undefined, {
                    "valorTotalSelecionado": vm.valorTotalSelecionadoTributoPorPagamentos,
                    "quantidadeItens": "25"
                },
                undefined,
                "scCtrl",
                "md");
        }

        /**
        * @ngdoc overview
        * @name atualizarContaEmUso
        *
        * @memberOf extratoMovimentacaoController.js
        *
        * @description
        * Método que atualiza a conta preferencial com base na conta selecionada na modal
        **/
        function atualizarContaEmUso(conta) {
            if (angular.isUndefined(conta)
                || conta == null
                || isNaN(conta.agencia)
                || isNaN(conta.conta)) {
                return false;
            }

            vm.contaPreferencial.agencia = conta.agencia;
            vm.contaPreferencial.numero = conta.conta;
            vm.contaPreferencial.cnpj = conta.cnpj;
            vm.contaPreferencial.nome = conta.nome;

            sfMemorizador.definir("autorizacaoPagamento.contaPreferencial", vm.contaPreferencial);
            atualizarConta();

            iniciaDatePicker();
            vm.dtpickerInicioModalidadeAberto = false;
            vm.dtpickerInicioPagamentoAberto = false;
            vm.dtpickerInicioContaAberto = false;

            iniciarSlider();

            if (vm.tipoPagamento == "CONTA") {
                transacaoListarTributosPorConta();
            }
            else if (vm.tipoPagamento == "MODALIDADE") {
                transacaoListarTributosPorModalidade();
            }
            else if (vm.tipoPagamento == "PAGAMENTOS") {
                transacaoListarTributosPorPagamento();
            }

            return false;
        }

        /**
        * @ngdoc overview
        * @name exibir
        * 
        * @memberOf autorizarTributoController.js
        *
        * @description        
        * Método responsável por mostrar o controle atráves da variável 'visivel'.
        **/
        function exibir() {
            this.visivel = true;
        }

        /**
        * @ngdoc overview
        * @name ocultar
        * 
        * @memberOf autorizarTributoController.js
        *
        * @description        
        * Método responsável por esconder o controle atráves da variável 'visivel'.
        **/
        function ocultar() {
            this.visivel = false;
        }

        /**
       * @ngdoc overview
       * @name abrirAutorizacaoFornecedores
       * 
       * @memberOf autorizarTributoController.js
       *
       * @description        
       * Método incializar e abrir a aba de fornecedores
       **/
        function abrirAutorizacaoFornecedores() {
            vm.tipoAutorizacao = "FORNECEDORES";
            sfNavegador.navegar("autorizacao-pagamento");
        }
        /**
        * @ngdoc overview
        * @name abrirAutorizacaoTributos
        * 
        * @memberOf autorizarTributoController.js
        *
        * @description        
        * Método incializar e abrir a aba de tributos
        **/
        function abrirAutorizacaoTributos() {
            vm.tipoAutorizacao = "TRIBUTOS";
        }

        /**
        * @ngdoc overview
        * @name abrirAbaModalidades
        * 
        * @memberOf autorizarTributoController.js
        *
        * @description        
        * Método incializar e abrir a aba de modalidades
        **/
        function abrirAbaModalidades() {
            vm.tipoPagamento = "MODALIDADE";
            //limparVariaveis();
            transacaoListarTributosPorModalidade();

            selecionarTributoModalidade();
        }
        /**
        * @ngdoc overview
        * @name abrirAbaContas
        * 
        * @memberOf autorizarTributoController.js
        *
        * @description        
        * Método incializar e abrir a aba de contas
        **/
        function abrirAbaContas() {
            vm.tipoPagamento = "CONTA";
            //limparVariaveis();
            transacaoListarTributosPorConta();

            selecionarTributoConta();
        }
        /**
        * @ngdoc overview
        * @name abrirAbaPagamentos
        * 
        * @memberOf autorizarTributoController.js
        *
        * @description        
        * Método incializar e abrir a aba de pagamentos
        **/
        function abrirAbaPagamentos() {
            vm.tipoPagamento = "PAGAMENTOS";
            //limparVariaveis();
            //vm.tipoFiltroTributo = "2";
            //transacaoListarTributosPorPagamento();
            filtrarTribFederais();
        }

        /**
        * @ngdoc overview
        * @name filtrarTribFederais
        * 
        * @memberOf autorizarTributoController.js
        *
        * @description        
        * Método que filtra os pgtos
        **/
        function filtrarTribFederais() {
            vm.tipoFiltroTributo = "2";
            //limparVariaveis();
            transacaoListarTributosPorPagamento();
            //atualizarTotalizadorSelecionado();
        }
        /**
        * @ngdoc overview
        * @name filtrarTribEstaduais
        * 
        * @memberOf autorizarTributoController.js
        *
        * @description        
        * Método que filtra os pgtos
        **/
        function filtrarTribEstaduais() {
            vm.tipoFiltroTributo = "3";
            //limparVariaveis();
            transacaoListarTributosPorPagamento();
            //atualizarTotalizadorSelecionado();
        }
        /**
        * @ngdoc overview
        * @name filtrarPagamentosDDA
        * 
        * @memberOf autorizarTributoController.js
        *
        * @description        
        * Método que filtra os pgtos
        **/
        function filtrarTribMunicipais() {
            vm.tipoFiltroTributo = "4";
            //limparVariaveis();
            transacaoListarTributosPorPagamento();
            //atualizarTotalizadorSelecionado();
        }

        /**
        * @ngdoc overview
        * @name filtrarTribServicosPublicos
        * 
        * @memberOf autorizarTributoController.js
        *
        * @description        
        * Método que filtra os pgtos
        **/
        function filtrarTribServicosPublicos() {
            vm.tipoFiltroTributo = "5";
            //limparVariaveis();
            transacaoListarTributosPorPagamento();
            //atualizarTotalizadorSelecionado();
        }

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento
        *
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function voltar() {
            vm.filtroAberto = false;
            vm.valorMinimo = null;
            vm.valorMaximo = null;
            sfNavegador.voltar();
        }

        /**
        * @ngdoc method
        * @name confirmar
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento
        *
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function confirmar() {
            vm.valorMinimo = vm.filtroValorMinimoTrib;
            vm.valorMaximo = vm.filtroValorMaximoTrib;
            transacaoListarTributosPorPagamento();
            sfNavegador.voltar();
        }

        /**
        * @ngdoc method
        * @name voltar
        *
        * @methodOf apl-mobile-pj.autorizacaoTributo
        *
        * @description
        * Método responsável por navegar para tela anterior.
        **/
        function abrirFiltrarPagamentos() {
            vm.filtroAberto = true;
            vm.valorMinimo = null;
            vm.valorMaximo = null;
            sfNavegador.navegar("filtrar-pagamentos");
        }

        /**
        * @ngdoc method
        * @name transacaoListarTributosPorConta
        *
        * @methodOf apl-mobile-pj.autorizacaoTributo
        *
        * @description
        * Método responsável por realizar a transação que lista os pagamentos.
        **/
        function transacaoListarTributosPorConta() {

            var filtroData = formatarDataAAAAMMDD(obterDataSelecionada(vm.dtpickerInicioConta, vm.sliderInicioConta));
            //var filtroData = "20141027";
            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");
            //definirContexto(vm.conta.cnpj, vm.conta.agencia, vm.conta.numero);

            interpretadorComunicacao.interpretar(
                listarPagamentosTributoPorContaFactory
                    .listarTributos({
                        "TRTT_RC_DT_PGTO": filtroData,
                        "TRTT_RC_TP_CONSULTA": "C",
                        "TRTT_RC_AGENCIA": vm.conta.agencia,
                        "TRTT_RC_CONTA": vm.conta.numero,
                        "shortname": dadosLogin.shortname,
                        "userId": dadosLogin.username

                    }))
                .sucesso(listarTributosPorContaSucesso)
                .aviso(listarTributosPorContaErro)
                .erro(listarTributosPorContaErro);

            /**
            * @ngdoc method
            * @name sucesso
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de sucesso na transação de listar pagamentos.
            **/
            function listarTributosPorContaSucesso(data) {
                limparVariaveis();
                vm.listaTributosPorConta = data.TRTT_EV_OCOR;
            }

            /**
            * @ngdoc method
            * @name erro
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de erro na transação de listar pagamentos
            **/
            function listarTributosPorContaErro() {
                limparVariaveis();
                vm.alertasDados.push({ tipo: "warning", texto: "Não há dados", caminho: "./app/assets/img/Pendencias_60x60pt_Ocre.png" });
            }

        }


        /**
        * @ngdoc method
        * @name transacaoListarTributosPorModalidade
        *
        * @methodOf apl-mobile-pj.autorizacaoTributo
        *
        * @description
        * Método responsável por realizar a transação que lista os pagamentos.
        **/
        function transacaoListarTributosPorModalidade() {

            var filtroData = formatarDataAAAAMMDD(obterDataSelecionada(vm.dtpickerInicioModalidade, vm.sliderInicioModalidade));

            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var requisicao = {
                TRTT_RC_DT_PGTO: filtroData,
                TRTT_RC_AGENCIA: vm.conta.agencia,
                TRTT_RC_CONTA: vm.conta.numero, //vm.conta.numero,
                TRTT_RC_TP_CONSULTA: "T",
                agencia: vm.conta.agencia,
                contaCorrente: vm.conta.numero,
                baseCGC: vm.conta.cnpj,
                shortname: dadosLogin.shortname,
                userId: dadosLogin.username
            };

            interpretadorComunicacao
                .interpretar(listarPagamentosTributoPorModalidadeFactory
                    .listarTributos(requisicao))
                .sucesso(listarTributosPorModalidadeSucesso)
                .aviso(listarTributosPorModalidadeErro)
                .erro(listarTributosPorModalidadeErro);

            /**
            * @ngdoc method
            * @name erro
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de erro na transação de listar pagamentos
            **/
            function listarTributosPorModalidadeErro() {
                limparVariaveis();
                vm.alertasDados.push({ tipo: "warning", texto: "Não há dados", caminho: "./app/assets/img/Pendencias_60x60pt_Ocre.png" });
            }

            /**
            * @ngdoc method
            * @name sucesso
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de sucesso na transação de listar pagamentos.
            **/
            function listarTributosPorModalidadeSucesso(data) {
                limparVariaveis();
                vm.listaTributosPorModalidade = data.TRTT_EV_OCOR;
            }
        }

        /**
       * @ngdoc method
       * @name transacaoListarTributosPorPagamento
       *
       * @methodOf apl-mobile-pj.autorizacaoTributo
       *
       * @description
       * Método responsável por realizar a transação que lista os pagamentos.
       **/
        function transacaoListarTributosPorPagamento() {

            //console.log(formatarDataAAAAMMDD(obterDataSelecionada(vm.dtpickerInicioPagamento, vm.sliderInicioPagamento)));
            //var dataFormatada = "20140620";
            //var conta = "001653925";
            var dataFormatada = formatarDataAAAAMMDD(obterDataSelecionada(vm.dtpickerInicioPagamento, vm.sliderInicioPagamento));
            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var requerimento = {
                TRPT01_RC_AGENCIA: vm.conta.agencia,
                TRPT01_RC_CONTA: vm.conta.numero,
                TRPT01_RC_DT_PGTO: dataFormatada,
                TRPT01_RC_TRIB: vm.tipoFiltroTributo,
                TRPT01_RC_NR_COMPROM: vm.filtroDocumento == null ? "0" : vm.filtroDocumento,
                TRPT01_RC_VL_MINIMO: vm.valorMinimo == null ? 0 : vm.valorMinimo * 100,
                TRPT01_RC_VL_MAXIMO: vm.valorMaximo == null ? 99999999999999900 : vm.valorMaximo * 100,
                agencia: vm.conta.agencia,
                contaCorrente: vm.conta.numero,
                baseCGC: vm.conta.cnpj,
                shortname: dadosLogin.shortname,
                userId: dadosLogin.username

            };

            interpretadorComunicacao.interpretar(
                listarPagamentosTributoPorPagamentoFactory
                    .listarTributos(requerimento))
                .sucesso(listarTributosPorPagamentoSucesso)
                .aviso(listarTributosPorPagamentoErro)
                .erro(listarTributosPorPagamentoErro);

            /**
            * @ngdoc method
            * @name sucesso
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de sucesso na transação de listar pagamentos.
            **/
            function listarTributosPorPagamentoSucesso(data) {
                limparVariaveis();
                vm.listaTributosPorPagamento = data.TRPT01_EV_OCOR;
                atualizarTotalizador(data.TRPT01_EV_OCOR);
            }

            /**
            * @ngdoc method
            * @name erro
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de erro na transação de listar pagamentos
            **/
            function listarTributosPorPagamentoErro() {
                limparVariaveis();
                vm.alertasDados.push({ tipo: "warning", texto: "Não há dados", caminho: "./app/assets/img/Pendencias_60x60pt_Ocre.png" });
            }
        }


        /**
        * @ngdoc method
        * @name transacaoAutorizarPagamentosPorPagamento
        *
        * @methodOf apl-mobile-pj.autorizacaoTributo
        *
        * @description
        * Método responsável por realizar a transação que lista os pagamentos.
        **/
        function transacaoAutorizarTributosPorPagamento(senha) {

            var pagamentosSelecionados = vm.listaTributosPorPagamento
                .filter(function (data) {
                    return data.selecionado;
                });

            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var pagamentosPendenteAutorizacao = {
                "TRAL_RC_CD_SERV": "021",
                "TRAL_RC_NOM_TS_WEB": "TRAL0007",
                "TRAL_RC_ULT_ITEM_WEB": 0,
                "TRAL_RC_NOM_TS_MF": "    ",
                "TRAL_RC_NUM_TASK_MF": "0000000",
                "TRAL_RC_ULT_ITEM_MF": "00000",
                "TRAL_RC_AGENCIA": vm.conta.agencia,
                "TRAL_RC_CONTA": vm.conta.numero,
                "TRAL_RC_NOVA_DTP": "00000000",
                "TRAL_RC_SENHA": senha,
                "TRAL_RC_FLAG_OPERA": 4,
                "TRAL_RC_QTOC": pagamentosSelecionados.length, //"0001",
                "TRAL_RC_OCOR": [],
                "shortname": dadosLogin.shortname,
                "userId": dadosLogin.username

            };


            angular.forEach(pagamentosSelecionados, function (value) {
                pagamentosPendenteAutorizacao.TRAL_RC_OCOR.push({
                    "TRAL_RC_NUM_OPRC": value.TRPT01_EV_NUM_OPRC
                });
            });

            //efinirContexto(vm.conta.cnpj, vm.conta.agencia, vm.conta.numero);

            interpretadorComunicacao.interpretar(
                autorizarPagamentosTributoPorPagamentoFactory
                    .autorizarTributos(pagamentosPendenteAutorizacao))
                .sucesso(autorizarTributosPorPagamentoSucesso)
                .aviso(autorizarTributosPorPagamentoAviso)
                .erro(autorizarTributosPorPagamentoErro);


            /**
            * @ngdoc method
            * @name sucesso
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de sucesso na transação de Autorizar pagamentos.
            **/
            function autorizarTributosPorPagamentoSucesso(data) {
                var estadoAutorizacao = {
                    "estado": "success"
                };
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos", data);
                contexto.definirValorContextoTrabalho("estadoAutorizacao", estadoAutorizacao);
                sfNavegador.navegar("detalhar-pagamento");
            }

            /**
            * @ngdoc method
            * @name erro
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de erro na transação de Autorizar pagamentos
            **/
            function autorizarTributosPorPagamentoErro(data) {
                var estadoAutorizacao = {
                    "estado": "danger"
                };
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos", data);
                contexto.definirValorContextoTrabalho("estadoAutorizacao", estadoAutorizacao);
                sfNavegador.navegar("detalhar-pagamento");
            }

            /**
            * @ngdoc method
            * @name aviso
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de aviso na transação de Autorizar pagamentos
            **/
            function autorizarTributosPorPagamentoAviso(data) {
                var estadoAutorizacao = {
                    "estado": "warning"
                };
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos", data);
                contexto.definirValorContextoTrabalho("estadoAutorizacao", estadoAutorizacao);
                sfNavegador.navegar("detalhar-pagamento");
            }
        }

        /**
         * @ngdoc method
         * @name transacaoAutorizarTributosPorConta
         *
         * @methodOf apl-mobile-pj.autorizacaoTributo
         *
         * @description
         * Método responsável por realizar a transação que lista os pagamentos.
         **/
        function transacaoAutorizarTributosPorConta(dataFiltro, senha) {

            var dataFormatada = formatarDataAAAAMMDD(obterDataSelecionada(vm.dtpickerInicioPagamento, vm.sliderInicioPagamento));

            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var pagamentosPendenteAutorizacao = {
                "TRAG_RC_CD_SERV": "021",
                "TRAG_RC_NOM_TS_WEB": "TRAG0002",
                "TRAG_RC_ULT_ITEM_WEB": "00000",
                "TRAG_RC_NOM_TS_MF": "    ",
                "TRAG_RC_NUM_TASK_MF": "0000000",
                "TRAG_RC_ULT_ITEM_MF": "00000",
                "TRAG_RC_TP_CONS": "02",
                "TRAG_RC_DT_PAG_INI": dataFormatada,
                "TRAG_RC_DT_PAG_FIN": dataFormatada,
                "TRAG_RC_DT_INC": "00000000",
                "TRAG_RC_TP_TRIB": "00",
                "TRAG_RC_SITUACAO": "0",
                "TRAG_RC_USR_AUTOR": "        ",
                "TRAG_RC_VERSAO_ARQ": "00000",
                "TRAG_RC_USR_INC": "        ",
                "TRAG_RC_SENHA": senha,
                "TRAG_RC_INDIC": "N",
                "TRAG_RC_QTOC": 1,
                "TRAG_RC_OCOR": [{ "TRAG_RC_AGENCIA": vm.tributo.agencia, "TRAG_RC_CONTA": vm.tributo.conta }],
                "agencia": vm.conta.agencia,
                "contaCorrente": vm.conta.numero,
                "baseCGC": vm.conta.cnpj,
                "shortname": dadosLogin.shortname,
                "userId": dadosLogin.username

            };

            //definirContexto(vm.conta.cnpj, vm.conta.agencia, vm.conta.numero);

            interpretadorComunicacao.interpretar(
                autorizarPagamentosTributoPorContaFactory
                    .autorizarTributos(pagamentosPendenteAutorizacao))
                .sucesso(autorizarTributoPorContaSucesso)
                .aviso(autorizarTributoPorContaErro)
                .erro(autorizarTributoPorContaErro);


            /**
            * @ngdoc method
            * @name sucesso
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de sucesso na transação de Autorizar pagamentos.
            **/
            function autorizarTributoPorContaSucesso(data) {
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos",
                    data);

                sfNavegador.navegar("detalhar-pagamento");
            }

            /**
            * @ngdoc method
            * @name erro
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de erro na transação de Autorizar pagamentos
            **/
            function autorizarTributoPorContaErro(data) {
                // contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos",
                //     data);

                // sfNavegador.navegar("detalhar-pagamento");
                console.log(data);
                preencherAlertaDados("warning", "Não há dados", "./app/assets/img/Pendencias_60x60pt_Ocre.png");

            }
        }

        /**
         * @ngdoc method
         * @name transacaoAutorizarTributosPorModalidade
         *
         * @methodOf apl-mobile-pj.autorizacaoTributo
         *
         * @description
         * Método responsável por realizar a transação que lista os pagamentos.
         **/
        function transacaoAutorizarTributosPorModalidade(dataFiltro, senha) {

            var dataFormatada = formatarDataAAAAMMDD(obterDataSelecionada(vm.dtpickerInicioModalidade, vm.sliderInicioModalidade));

            var dadosLogin = contexto.obterValorContextoTrabalho("dadosLogin");

            var pagamentosPendenteAutorizacao = {
                "TRAG20_RC_AGENCIA": vm.conta.agencia,
                "TRAG20_RC_CONTA": vm.conta.numero,
                "TRAG20_RC_DT_PGTO": dataFormatada,
                "TRAG20_RC_TRIB": tipoFiltroTributoModalidade,
                "TRAG20_RC_SENHA": senha,
                "agencia": vm.conta.agencia,
                "contaCorrente": vm.conta.numero,
                "baseCGC": vm.conta.cnpj,
                "shortname": dadosLogin.shortname,
                "userId": dadosLogin.username
            };

            //definirContexto(vm.conta.cnpj, vm.conta.agencia, vm.conta.numero);

            interpretadorComunicacao.interpretar(
                autorizarPagamentosTributoPorModalidadeFactory
                    .autorizarTributos(pagamentosPendenteAutorizacao))
                .sucesso(autorizarTributoPorModalidadeSucesso)
                .aviso(autorizarTributoPorModalidadeAviso)
                .erro(autorizarTributoPorModalidadeErro);


            /**
            * @ngdoc method
            * @name sucesso
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de sucesso na transação de Autorizar pagamentos.
            **/
            function autorizarTributoPorModalidadeSucesso(data) {
                var estadoAutorizacao = {
                    "estado": "success"
                };
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos", data);
                contexto.definirValorContextoTrabalho("estadoAutorizacao", estadoAutorizacao);
                sfNavegador.navegar("detalhar-pagamento");
            }

            /**
            * @ngdoc method
            * @name erro
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de erro na transação de Autorizar pagamentos
            **/
            function autorizarTributoPorModalidadeErro(data) {
                var estadoAutorizacao = {
                    "estado": "danger"
                };
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos", data);
                contexto.definirValorContextoTrabalho("estadoAutorizacao", estadoAutorizacao);
                sfNavegador.navegar("detalhar-pagamento");
            }

            /**
            * @ngdoc method
            * @name aviso
            *
            * @methodOf apl-mobile-pj.autorizacaoTributo
            *
            * @description
            * Método de callback disparado em caso de aviso na transação de Autorizar pagamentos
            **/
            function autorizarTributoPorModalidadeAviso(data) {
                var estadoAutorizacao = {
                    "estado": "warning"
                };
                contexto.definirValorContextoTrabalho("listaAutorizacaoPagamentos", data);
                contexto.definirValorContextoTrabalho("estadoAutorizacao", estadoAutorizacao);
                sfNavegador.navegar("detalhar-pagamento");
            }
        }

        /**
        * @ngdoc method
        * @name atualizarTotalizador
        *  
        * @description
        * Método responsável atualizar valor total de pagamento por pagamentos
        **/
        function atualizarTotalizador(data) {
            var valorTotal = 0;
            for (var item in data) {
                var element = data[item];
                valorTotal += parseFloat(element.TRPT01_EV_V_OPRC);
            }

            vm.valorTotalTributoPorPagamentos = valorTotal;

            vm.filtroValorMinimoTrib = 0;
            vm.filtroValorMaximoTrib = valorTotal;//* 100; //parseInt(valorTotal);

            preencheOpcoesSliderFiltroPag(vm.filtroValorMaximoTrib);
        }

        /**
        * @ngdoc method
        * @name atualizarTotalizadorSelecionado
        *  
        * @description
        * Método responsável atualizar variavel que controle o check de pagamento por pagamentos
        * e somar o valor total selecionado
        **/
        function atualizarTotalizadorSelecionado() {

            var itensSelecionados = vm.listaTributosPorPagamento.filter(function (item) {
                return item.selecionado == true;
            });

            var quantidadeItens = 0;
            var valorTotalSelecionado = 0;
            for (var item in itensSelecionados) {
                var element = itensSelecionados[item];
                valorTotalSelecionado += parseFloat(element.TRPT01_EV_V_OPRC);
                quantidadeItens++;
            }

            vm.valorTotalSelecionadoTributoPorPagamentos = valorTotalSelecionado;

            if (quantidadeItens > 0) {
                vm.autorizarPagamento.desabilitado = false;

                if (quantidadeItens == 25) {

                    angular.forEach(vm.listaTributosPorPagamento, function (pgto) {

                        if (pgto.selecionado == true) {
                            pgto.desabilitado = false;
                        }
                        else {
                            pgto.desabilitado = true;
                        }
                    });
                    abrirModalAutorizarPagamento();
                }
                else {
                    angular.forEach(vm.listaTributosPorPagamento, function (pgto) {
                        pgto.desabilitado = false;
                    });
                }
            }
            else {
                vm.autorizarPagamento.desabilitado = true;
            }
        }

        /**
        * @ngdoc overview
        * @name transacaoConta
        * 
        * @memberOf extratoMovimentacaoController.js
        *
        * @description        
        * Método que realiza a consulta das contas vinculadas ao cliente
        **/
        function transacaoConta() {



            // interpretadorComunicacao.interpretar(listarContasFactory.listarContas())
            //     .sucesso(listarContasSucesso)
            //     .aviso(listarContasErro)
            //     .erro(listarContasErro);


            // if (vm.senhaEletronica != null) {

            //     var param = {
            //         credencial: { "senha": vm.senhaEletronica },
            //         "ADSE_RC_SENHA_ATU": vm.senhaEletronica,
            //         "ADSE_RC_SENHA_ALT": "",
            //         "ADSE_RC_IC_PERFIL": "S",
            //         "ADSE_RC_TP_OPER": "L",
            //         "ADSE_RC_SENHA_BLW": "",
            //         "ADSE_RC_ALT_MSG": "",
            //         "ADSE_RC_ATIVACAO": "",
            //         "ADSE_RC_COD_MAQUINA": "",
            //         "ADSE_RC_VERSAO": "",
            //         "ADSE_RC_TIPO": ""
            //     };
            // }
            var data = contexto.obterValorContextoTrabalho("permissionamento");
            
            // var data = { "ADSE_EV_STATUS": "L","ADSE_EV_NOM_USR": "RGXPJRER 545MANJYYY","ADSE_EV_NIV_USR": 0,"ADSE_EV_DT_ULT_AC": 20160825,"ADSE_EV_COD_DEP": 14,"ADSE_EV_EMAIL": "JOAO.MASTER@VALISERE.COM","ADSE_EV_IC_TOKEN": "S","ADSE_EV_IC_GARAN": "N","ADSE_EV_ID_T_EMP": "B","ADSE_EV_IC_CTFC": "N","ADSE_EV_DT_SIT": 1010001,"ADSE_EV_MD_ATEN": 57,"ADSE_EV_MARCA": 57,"ADSE_EV_CD_CONV": null,"ADSE_EV_NM_CONV": "","ADSE_EV_ID_OP_CAIXA": "","ADSE_EV_FL_TOKEN_US": "S","ADSE_EV_FL_RECART": "S","ADSE_EV_FL_ECPF": "N","ADLG_EV_ITENS": [{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 10158,"ADLG_TS_CGC": 60089026,"ADLG_TS_RAZ_SOC": "GRYRIRWZ WLNO OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001602280","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 12662,"ADLG_TS_CGC": 59104422,"ADLG_TS_RAZ_SOC": "ELOPHCZTVM YI OGXZ RMX E ZFGLN","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "11500","ADLG_TS_CONTA": "000009044","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 12907,"ADLG_TS_CGC": 5713778,"ADLG_TS_RAZ_SOC": "NZHHLFX B B UVORD YZIZAZMR","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "09700","ADLG_TS_CONTA": "000029748","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 15399,"ADLG_TS_CGC": 8558559,"ADLG_TS_RAZ_SOC": "UIZMWRHWL PLPRVO","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "09700","ADLG_TS_CONTA": "000028164","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 17895,"ADLG_TS_CGC": 61558037,"ADLG_TS_RAZ_SOC": "OLIVIO GARANTIAS COMITE","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 56,"ADLG_EV_CONTAS": [{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "001636800", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "003324163", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "004322458", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005028413", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005031287", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005186931", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005217216", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005227394", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005227521", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005231286", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005231421", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005233149", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005234641", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005237021", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005237608", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005244892", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005247204", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005247514", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005247611", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005248588", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005252208", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005256475", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005262149", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005262645", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005263277", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005266578", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005266993", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005267191", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005269771", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005273884", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005276956", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005277804", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005278703", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005278711", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005278991", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005281372", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005282514", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005285785", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005288547", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005288806", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005289730", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005290321", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005291785", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005291947", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005292242", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005292331", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005292528", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005295659", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005297911", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005298151", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005298895", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005300318", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005300890", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005301331", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "09700", "ADLG_TS_CONTA": "000026188", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "09700", "ADLG_TS_CONTA": "005030230", "ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 22670,"ADLG_TS_CGC": 761434738,"ADLG_TS_RAZ_SOC": "QLZL ZOEVH XV WZIEZOSL","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001636389","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 45053,"ADLG_TS_CGC": 61100145,"ADLG_TS_RAZ_SOC": "RMXRZMZ HVTFILH H/Z","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001672849","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 58199,"ADLG_TS_CGC": 87122696,"ADLG_TS_RAZ_SOC": "ILMZOXL WLIIVZ NZIGRMH","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001654344","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 58702,"ADLG_TS_CGC": 302723788,"ADLG_TS_RAZ_SOC": "EZMRZ OFWWRZ HVWWL NVIGA","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 2,"ADLG_EV_CONTAS": [{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "001653925", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "009102383", "ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 61134,"ADLG_TS_CGC": 11752098,"ADLG_TS_RAZ_SOC": "WOZFXRZ NZIRZ NFIZIR NRWSVOR","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001617210","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 72850,"ADLG_TS_CGC": 50673524,"ADLG_TS_RAZ_SOC": "KLIGLURML IVK KZIGRWRK OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001336415","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 74079,"ADLG_TS_CGC": 48435747,"ADLG_TS_RAZ_SOC": "R K O RMWLIK KZFORHGZ OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "09700","ADLG_TS_CONTA": "000118856","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 74872,"ADLG_TS_CGC": 33200056,"ADLG_TS_RAZ_SOC": "OLQZH IRZWSFVOL H Z","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "11500","ADLG_TS_CONTA": "000008358","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 78052,"ADLG_TS_CGC": 367361128,"ADLG_TS_RAZ_SOC": "HVITRL IZNKRN","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001667241","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 78607,"ADLG_TS_CGC": 61522173,"ADLG_TS_RAZ_SOC": "ILHHVG WRZ OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "002012834","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 83177,"ADLG_TS_CGC": 61596003,"ADLG_TS_RAZ_SOC": "WLN XV GVWRXLH HVRXZ OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001545774","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 92108,"ADLG_TS_CGC": 66955238,"ADLG_TS_RAZ_SOC": "LWGZERL ZFTFHGL HKVIZMARMR","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "09700","ADLG_TS_CONTA": "000170262","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 101512,"ADLG_TS_CGC": 55942312,"ADLG_TS_RAZ_SOC": "ZIZTFZR WLMHLIWRL EVRW OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001671478","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 102403,"ADLG_TS_CGC": 57484768,"ADLG_TS_RAZ_SOC": "EZORHVIV RMX V WLN OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 18,"ADLG_EV_CONTAS": [{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "001652970", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "001657106", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "001657203", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005005740", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005232207", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005237381", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005242695", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005246704", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005247913", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005264532", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005270788", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005276301", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005282301", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005287796", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005288733", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005292536", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "005292943", "ADLG_TS_IC_SEL": "S"},{ "ADLG_EV_TP_REG": 2, "ADLG_TS_AGENC": "00200", "ADLG_TS_CONTA": "006666669", "ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 111925,"ADLG_TS_CGC": 72829807,"ADLG_TS_RAZ_SOC": "NVXRZCLIPH HRHG RMU H W OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001655847","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 157722,"ADLG_TS_CGC": 71535520,"ADLG_TS_RAZ_SOC": "HRMXRWZGL NVGZOFITRWLH ZYW","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001653003","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 266165,"ADLG_TS_CGC": 41519042,"ADLG_TS_RAZ_SOC": "ORTZIV GVOVWLNFMRWZWLVH OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001670307","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 270605,"ADLG_TS_CGC": 382468,"ADLG_TS_RAZ_SOC": "WLOTZGV KZONLOREV RMX V WLN OG","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "11500","ADLG_TS_CONTA": "000010107","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 291205,"ADLG_TS_CGC": 48112171,"ADLG_TS_RAZ_SOC": "WLN OFHGIVH HKLG WVMGVI OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001661464","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 365674,"ADLG_TS_CGC": 1689775,"ADLG_TS_RAZ_SOC": "WHII WLN XV EVHGFZIRL OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001684618","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 367661,"ADLG_TS_CGC": 48770051,"ADLG_TS_RAZ_SOC": "NRIZWZGF ZFGL KLHGL OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "09700","ADLG_TS_CONTA": "000082932","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 371939,"ADLG_TS_CGC": 690786,"ADLG_TS_RAZ_SOC": "UVIMZMXL WLFGL NZIJFVH ORHYLZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001674043","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 479745,"ADLG_TS_CGC": 48271128,"ADLG_TS_RAZ_SOC": "MVOHLM ZHWSVI","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001670234","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 499107,"ADLG_TS_CGC": 2788616,"ADLG_TS_RAZ_SOC": "ZZG HRHGVNZH NLERN OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001670897","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 514302,"ADLG_TS_CGC": 3281663,"ADLG_TS_RAZ_SOC": "YIRTSGLM VNKIVVMX V KZIG OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "09700","ADLG_TS_CONTA": "000156626","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 541471,"ADLG_TS_CGC": 6599918,"ADLG_TS_RAZ_SOC": "OLGZIRL SVROYIFMM PIZFHV","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "11500","ADLG_TS_CONTA": "000027638","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 544377,"ADLG_TS_CGC": 3502134,"ADLG_TS_RAZ_SOC": "WVMGIL NVX R ZYI TZIURMPVO","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001672687","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 559472,"ADLG_TS_CGC": 3755496,"ADLG_TS_RAZ_SOC": "ZIVU GVDGRO OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001673012","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 563951,"ADLG_TS_CGC": 2971681,"ADLG_TS_RAZ_SOC": "GIZXRH OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001673110","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 564562,"ADLG_TS_CGC": 2309878,"ADLG_TS_RAZ_SOC": "WLNKZW G GVINLURDLH OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001673144","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 602561,"ADLG_TS_CGC": 73076887,"ADLG_TS_RAZ_SOC": "IZXHLM NVXRWZO OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001675741","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 607577,"ADLG_TS_CGC": 1521585,"ADLG_TS_RAZ_SOC": "ILWSZ & SZMMZ GIZYZOSL G OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001675996","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 633891,"ADLG_TS_CGC": 2428624,"ADLG_TS_RAZ_SOC": "GIRK G ZVIVL I R KGZ OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "11500","ADLG_TS_CONTA": "000036611","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 657034,"ADLG_TS_CGC": 62340674,"ADLG_TS_RAZ_SOC": "OROB LU GSV EZOOVB WLN W OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001682992","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 665646,"ADLG_TS_CGC": 43086529,"ADLG_TS_RAZ_SOC": "VONL HVIE ZFD XV VXRU HW OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001678405","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 761559,"ADLG_TS_CGC": 3331223,"ADLG_TS_RAZ_SOC": "WFHGL AVIL W R WLMU OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "00200","ADLG_TS_CONTA": "001683000","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 780915,"ADLG_TS_CGC": 298152378,"ADLG_TS_RAZ_SOC": "ZXIRZMZ TRHVOV SVIGALT H OVNV","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "11500","ADLG_TS_CONTA": "000050621","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 783346,"ADLG_TS_CGC": 49372154,"ADLG_TS_RAZ_SOC": "GZY WLMHG V VNK RNLY OGXZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "09700","ADLG_TS_CONTA": "000166885","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 786187,"ADLG_TS_CGC": 116832728,"ADLG_TS_RAZ_SOC": "XZERX YFMWV","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "11500","ADLG_TS_CONTA": "000051083","ADLG_TS_IC_SEL": "S"}]},{"ADLG_EV_TP_REG": 1,"ADLG_TS_CD_CLI": 786203,"ADLG_TS_CGC": 12163378,"ADLG_TS_RAZ_SOC": "QZIRY YIRHLOZ XFZIGV ULTZWZ","ADLG_TS_MD_ATEN": 57,"ADLG_TS_NUMERO_CONTAS": 1,"ADLG_EV_CONTAS": [{"ADLG_EV_TP_REG": 2,"ADLG_TS_AGENC": "11500","ADLG_TS_CONTA": "000051172","ADLG_TS_IC_SEL": "S"}]}],"ADLG_EV_GRUPOS": [{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "AFO","ADLG_TS_DESC_GRP": "ANTECIPACAO FORNECEDOR","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONSULTA ANTECIP. FORNEC.", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "SIMULAC. ANTECIP. FORNEC.", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "CBS","ADLG_TS_DESC_GRP": "CONVENIO/CORRESP.BANCARIO","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "CONS GERAL RECEBIMENTOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "CONSULTA REMUNERACAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "006", "ADLG_TS_DESC_SVC": "CONSULTA PARAMETROS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "007", "ADLG_TS_DESC_SVC": "MANUT OPERADORES FILIAL", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "008", "ADLG_TS_DESC_SVC": "MANUT/CONS CERTIF. PDV", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "009", "ADLG_TS_DESC_SVC": "ALCADA PARA CBS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "010", "ADLG_TS_DESC_SVC": "INCLUSAO PGTOS CAIXA AV.", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "011", "ADLG_TS_DESC_SVC": "AUTORIZACAO DE PAGAMENTOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "S", "ADLG_EV_ALCADA": [{"ADLG_EV_TP_REG": 5,"ADLG_TS_VLR_DT_PG": "000000000000000","ADLG_TS_VLR_DT_AUT": "999999999999999","ADLG_TS_VLR_COMPR": "999999999999999","ADLG_TS_IC_AUT_UNI": "S" }]},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "012", "ADLG_TS_DESC_SVC": "EXCLUSAO DE PAGAMENTOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "013", "ADLG_TS_DESC_SVC": "AUTENTICACAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "014", "ADLG_TS_DESC_SVC": "REAUTENTICACAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "015", "ADLG_TS_DESC_SVC": "CONSULTA SLD DISPONIVEL", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "CCI","ADLG_TS_DESC_GRP": "RECEBIVEIS IMOBILIARIOS","ADLG_EV_SUBGRUPOS": [{"ADLG_EV_TP_REG": 4,"ADLG_TS_CD_SVC": "001","ADLG_TS_DESC_SVC": "AVISO DE MOVIMENTACAO","ADLG_TS_IC_SEL_SVC": "S","ADLG_TS_IC_SEL_ALC": "N","ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "CCY","ADLG_TS_DESC_GRP": "CT CORRENTE INTERNACIONAL","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "EXCLUIR TRANSFERENCIAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "AUTORIZAR TRANSFERENCIAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "MENU CONTA INTERNACIONAL", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "CHQ","ADLG_TS_DESC_GRP": "TALAO DE CHEQUES","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "SOLICITACAO TALAO CHEQUES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "CONSULTA TALAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "LIBERACAO TALAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "CANCELA TALAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "010", "ADLG_TS_DESC_SVC": "PAGTO.ESPECIAL INCLUSAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "011", "ADLG_TS_DESC_SVC": "PAGTO.ESPECIAL CONSULTA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "CHS","ADLG_TS_DESC_GRP": "RECEBIVEIS - CHEQUES","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "MOVIMENTACAO DA CARTEIRA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "FLUXO DE RECEBIMENTO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "FLX RECEBIMENTO ANALITICO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "DETALHAMENTO DE CHEQUES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "008", "ADLG_TS_DESC_SVC": "CONSULTA DA CARTEIRA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "009", "ADLG_TS_DESC_SVC": "CUSTODIA/VINCULADA-CAPTUR", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "010", "ADLG_TS_DESC_SVC": "IMPRESSAO/CONS.BORDERO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "011", "ADLG_TS_DESC_SVC": "CONSULTAS GERAIS DESCONTO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "013", "ADLG_TS_DESC_SVC": "INCLUSAO OPERACOES (CAP)", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "014", "ADLG_TS_DESC_SVC": "CONSULTA OPERACOES (DES)", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "CMC","ADLG_TS_DESC_GRP": "RECEBIVEIS-CAPTURA MOVEL","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONSULTA ONLINE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "CREDENCIAMENTO MAQUINAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "HISTORICO DE CAPTURAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "CNF","ADLG_TS_DESC_GRP": "CONCILIACAO NOTAS FISCAIS","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONSULTA/MANUTENCAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "INCLUSAO DE NOTAS FISCAIS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "INCLUSAO DE PAGAMENTOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "CONCILIACAO DE PAGAMENTOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "PARAMETROS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "COB","ADLG_TS_DESC_GRP": "COBRANCA","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONSULTA GERAL DE TITULOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "MOVIMENTACAO DIARIA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "BANCO CORRESPONDENTE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "FLUXO DE RECEBIMENTO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "PARAMETROS DE CLIENTES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "006", "ADLG_TS_DESC_SVC": "REGISTRO DE OCORRENCIAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "007", "ADLG_TS_DESC_SVC": "INCLUSAO DE TITULOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "008", "ADLG_TS_DESC_SVC": "ALTERA TITULOS DO DIA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "009", "ADLG_TS_DESC_SVC": "CONS.COBRANCA TIT.INTERN.", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "011", "ADLG_TS_DESC_SVC": "OCOR/INSTRUCOES VINCULADA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "013", "ADLG_TS_DESC_SVC": "CONSULTA CLIENTE COBRANCA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "014", "ADLG_TS_DESC_SVC": "CONSULTA CADASTRO SACADOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "015", "ADLG_TS_DESC_SVC": "CADASTRO DE SACADOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "016", "ADLG_TS_DESC_SVC": "INCLUSAO TITULOS COBRANCA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "017", "ADLG_TS_DESC_SVC": "CONSULTA TITULOS EXPRESS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "018", "ADLG_TS_DESC_SVC": "CONSULTA DETALHE EXPRESS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "022", "ADLG_TS_DESC_SVC": "CONSULTA CEP", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "023", "ADLG_TS_DESC_SVC": "AUTORIZACAO DE BOLETOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "024", "ADLG_TS_DESC_SVC": "TRANSFERENCIA DE CARTEIRA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "025", "ADLG_TS_DESC_SVC": "IMPORTACAO DE TITULOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "026", "ADLG_TS_DESC_SVC": "TAB.CEP SAFRA/CORRESPOND.", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "029", "ADLG_TS_DESC_SVC": "CADASTRO DE AVALISTAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "CPR","ADLG_TS_DESC_GRP": "FINANCIAMENTOS-COMPROR","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "NEGOCIAR PAGAMENTOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "CONSULTAR OPERACOES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "CONSULTA LIMITE CREDITO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "CRC","ADLG_TS_DESC_GRP": "SAFRA NET FORNECEDORES","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONS. FORNECEDORES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "HABILITA FORNECEDORES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "CTO","ADLG_TS_DESC_GRP": "DESCONTO E CESSAO","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONSULTA GERAL DE TITULOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "MOVIMENTACAO DIARIA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "CADASTRO DE SACADOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "INCLUSAO DE OPERACOES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "006", "ADLG_TS_DESC_SVC": "CONSULTA DE OPERACOES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "007", "ADLG_TS_DESC_SVC": "CONSULTA CARTEIRA ANALISE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "008", "ADLG_TS_DESC_SVC": "CONSULTA PRACAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "009", "ADLG_TS_DESC_SVC": "IMPORTACAO DE REGISTROS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "DDA","ADLG_TS_DESC_GRP": "DEBITO DIRETO AUTORIZADO","ADLG_EV_SUBGRUPOS": [{"ADLG_EV_TP_REG": 4,"ADLG_TS_CD_SVC": "001","ADLG_TS_DESC_SVC": "DDA-INCLUSAO DE SACADOS/A","ADLG_TS_IC_SEL_SVC": "S","ADLG_TS_IC_SEL_ALC": "N","ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "EMC","ADLG_TS_DESC_GRP": "EMISSAO DE CONTRATOS","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "IMPRESSAO DE CONTRATOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "ATUALIZA FICHA CADASTRAL", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "RELACAO DE GARANTIAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "VIA ASSINADA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "FIA","ADLG_TS_DESC_GRP": "FIANCAS","ADLG_EV_SUBGRUPOS": [{"ADLG_EV_TP_REG": 4,"ADLG_TS_CD_SVC": "001","ADLG_TS_DESC_SVC": "CONSULTA DE OPERACOES","ADLG_TS_IC_SEL_SVC": "S","ADLG_TS_IC_SEL_ALC": "N","ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "FRA","ADLG_TS_DESC_GRP": "AVISOS DE MOVIMENTACAO","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "COBRANCA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "CHEQUES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "DESCONTO E CESSAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "VENDOR", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "FXG","ADLG_TS_DESC_GRP": "CAMBIO-GRUPO DE CAMBIO","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "EXTRATO DE EXPORTACAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "ORDENS RECEBIDAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "AVISO MOVIM. CONTRATO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "COMPROVANTES DARF IR", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "GOJ","ADLG_TS_DESC_GRP": "BLOQUEIO JUDICIAL","ADLG_EV_SUBGRUPOS": [{"ADLG_EV_TP_REG": 4,"ADLG_TS_CD_SVC": "001","ADLG_TS_DESC_SVC": "BLOQUEIO JUDICIAL","ADLG_TS_IC_SEL_SVC": "S","ADLG_TS_IC_SEL_ALC": "N","ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "GTC","ADLG_TS_DESC_GRP": "RECEBIVEIS-CTA GARANTIDA","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "EXTR. EMPRESTIMO E VINC.", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "MOVIMENTACAO DE RECURSOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "CONSULTA MOV. EFETUADAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "HBE","ADLG_TS_DESC_GRP": "SAFRA NET ACOES","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "ACESSO AO SITE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "RELATORIO DE OPERACOES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "JSA","ADLG_TS_DESC_GRP": "CONSULTAS-JSAFRA","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "009", "ADLG_TS_DESC_SVC": "TRANSMISSAO ARQUIVOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "010", "ADLG_TS_DESC_SVC": "CONSULTA ARQUIVOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "MNT","ADLG_TS_DESC_GRP": "SEGURANCA - CONTAS","ADLG_EV_SUBGRUPOS": [{"ADLG_EV_TP_REG": 4,"ADLG_TS_CD_SVC": "001","ADLG_TS_DESC_SVC": "CONTAS","ADLG_TS_IC_SEL_SVC": "S","ADLG_TS_IC_SEL_ALC": "N","ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "NCL","ADLG_TS_DESC_GRP": "NOTIFICADOR DE CLIENTES","ADLG_EV_SUBGRUPOS": [{"ADLG_EV_TP_REG": 4,"ADLG_TS_CD_SVC": "001","ADLG_TS_DESC_SVC": "CADASTRO CELULAR","ADLG_TS_IC_SEL_SVC": "S","ADLG_TS_IC_SEL_ALC": "N","ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "NCS","ADLG_TS_DESC_GRP": "RECEBIVEIS-CONSULT SAFRA","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "HISTORICO DE CONSULTAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "TOTAIS DE CONSULTAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "CAPTURA (CONSULT)", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "NMR","ADLG_TS_DESC_GRP": "COLETA DE NUMERARIOS","ADLG_EV_SUBGRUPOS": [{"ADLG_EV_TP_REG": 4,"ADLG_TS_CD_SVC": "001","ADLG_TS_DESC_SVC": "CONSULTA TRANSP VALORES","ADLG_TS_IC_SEL_SVC": "S","ADLG_TS_IC_SEL_ALC": "N","ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "NST","ADLG_TS_DESC_GRP": "NOVO SITE EMPRESA-NEGOCIO","ADLG_EV_SUBGRUPOS": [{"ADLG_EV_TP_REG": 4,"ADLG_TS_CD_SVC": "002","ADLG_TS_DESC_SVC": "LOGIN PARA NOVO SITE IPJ","ADLG_TS_IC_SEL_SVC": "S","ADLG_TS_IC_SEL_ALC": "N","ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "OEC","ADLG_TS_DESC_GRP": "MANUT.EMISSAO DE EXTRATO","ADLG_EV_SUBGRUPOS": [{"ADLG_EV_TP_REG": 4,"ADLG_TS_CD_SVC": "001","ADLG_TS_DESC_SVC": "CANCELAMENTO EXTRATO","ADLG_TS_IC_SEL_SVC": "S","ADLG_TS_IC_SEL_ALC": "N","ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "PAG","ADLG_TS_DESC_GRP": "PAGAMENTOS","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONS.PAGTO FORNECEDORES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "ALTERACAO COMPROMISSOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "BLOQUEIO COMPROMISSOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "DESBLOQUEIO COMPROMISSOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "ALTERACAO DATA PAGAMENTO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "006", "ADLG_TS_DESC_SVC": "INCLUSAO DE COMPROMISSOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "007", "ADLG_TS_DESC_SVC": "AUTORIZACAO PAGSAFRA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "S", "ADLG_EV_ALCADA": [{"ADLG_EV_TP_REG": 5,"ADLG_TS_VLR_DT_PG": "000000000005001","ADLG_TS_VLR_DT_AUT": "000000000005001","ADLG_TS_VLR_COMPR": "000000000005001","ADLG_TS_IC_AUT_UNI": "N" }]},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "008", "ADLG_TS_DESC_SVC": "CADASTRO DE FORNECEORES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "009", "ADLG_TS_DESC_SVC": "CONS.CADASTRO FORNECEORES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "011", "ADLG_TS_DESC_SVC": "CRIAR LISTA DE DEBITO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "012", "ADLG_TS_DESC_SVC": "IMPRIMIR LISTA DE DEBITO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "013", "ADLG_TS_DESC_SVC": "CANCELAR LISTA DE DEBITO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "014", "ADLG_TS_DESC_SVC": "CONSULTAR LISTA DE DEBITO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "015", "ADLG_TS_DESC_SVC": "COMPROVANTE PDF EM LOTE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "017", "ADLG_TS_DESC_SVC": "INCLUSAO TED MESMA TITUL.", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "020", "ADLG_TS_DESC_SVC": "MANUTENCAO ARRECADACOES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "021", "ADLG_TS_DESC_SVC": "AUTORIZACAO ARRECADACOES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "S", "ADLG_EV_ALCADA": [{"ADLG_EV_TP_REG": 5,"ADLG_TS_VLR_DT_PG": "000000000000000","ADLG_TS_VLR_DT_AUT": "999999999999999","ADLG_TS_VLR_COMPR": "999999999999999","ADLG_TS_IC_AUT_UNI": "S" }]},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "022", "ADLG_TS_DESC_SVC": "CONSULTA ARRECADACOES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "024", "ADLG_TS_DESC_SVC": "IMP. FORNECEDORES LOTE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "025", "ADLG_TS_DESC_SVC": "IMP.PAGTO FORNECEDORES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "026", "ADLG_TS_DESC_SVC": "BOLETO SIMPLIFICADO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "POR","ADLG_TS_DESC_GRP": "INVESTIMENTOS RENDA FIXA","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "APLICACAO RENDA FIXA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "S", "ADLG_EV_ALCADA": [{"ADLG_EV_TP_REG": 5,"ADLG_TS_VLR_DT_PG": "000000000000000","ADLG_TS_VLR_DT_AUT": "999999999999999","ADLG_TS_VLR_COMPR": "999999999999999","ADLG_TS_IC_AUT_UNI": "S" }]},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "RESGATE RENDA FIXA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "S", "ADLG_EV_ALCADA": [{"ADLG_EV_TP_REG": 5,"ADLG_TS_VLR_DT_PG": "000000000000000","ADLG_TS_VLR_DT_AUT": "999999999999999","ADLG_TS_VLR_COMPR": "999999999999999","ADLG_TS_IC_AUT_UNI": "S" }]},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "CONS/CANCELA RENDA FIXA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "POS","ADLG_TS_DESC_GRP": "INVESTIMENTOS","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONSULTA POSICAO INVESTID", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "EXTRATO CONTA CORRENTE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "EXTRATO SIMPLIF UNIFICADO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "009", "ADLG_TS_DESC_SVC": "CONSULTA APLIC./RESGATE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "010", "ADLG_TS_DESC_SVC": "RESGATE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "011", "ADLG_TS_DESC_SVC": "APLICACAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "012", "ADLG_TS_DESC_SVC": "AUTORIZA APLIC./RESGATE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "013", "ADLG_TS_DESC_SVC": "EXCLUSAO APLIC./RESGATE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "014", "ADLG_TS_DESC_SVC": "CANCELA APLIC./RESGATE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "015", "ADLG_TS_DESC_SVC": "AVISO LANCTO-CONSOLIDADO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "016", "ADLG_TS_DESC_SVC": "AVISO LANCTO-ANALITICO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "017", "ADLG_TS_DESC_SVC": "CONS. EXTRATO CARTAO VISA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "018", "ADLG_TS_DESC_SVC": "CONS.EXTRATO C/C(NOVO)", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "020", "ADLG_TS_DESC_SVC": "COMPOSICAO DE SALDOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "021", "ADLG_TS_DESC_SVC": "LANCAMENTOS FUTUROS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "022", "ADLG_TS_DESC_SVC": "POSICAO DE BLOQUEIOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "023", "ADLG_TS_DESC_SVC": "LIMITES DE CREDITOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "024", "ADLG_TS_DESC_SVC": "EMISSAO ELETRONICA EXTR.", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "025", "ADLG_TS_DESC_SVC": "EXTRATO SIMPLIFICADO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "026", "ADLG_TS_DESC_SVC": "OPCAO EXTRATO ELETRONICO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "027", "ADLG_TS_DESC_SVC": "EXTRATO MENSAL", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "030", "ADLG_TS_DESC_SVC": "CREDENC. CDB FLUXO CAIXA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "031", "ADLG_TS_DESC_SVC": "DESCRED. CDB FLUXO CAIXA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "032", "ADLG_TS_DESC_SVC": "NOTAS / AVISOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "033", "ADLG_TS_DESC_SVC": "DEMONSTRATIVO MENSAL CDB", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "034", "ADLG_TS_DESC_SVC": "POSICAO FINANCEIRA MENSAL", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "035", "ADLG_TS_DESC_SVC": "NOTAS/AVISOS - OPC.RECEB.", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "036", "ADLG_TS_DESC_SVC": "EXTRATO DETALHADO LOTE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "037", "ADLG_TS_DESC_SVC": "CONSULTA CODIGO IBAN", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "038", "ADLG_TS_DESC_SVC": "CONS. QUEST. SUITABYLITY", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "S", "ADLG_EV_ALCADA": [{"ADLG_EV_TP_REG": 5,"ADLG_TS_VLR_DT_PG": "000000000000000","ADLG_TS_VLR_DT_AUT": "999999999999999","ADLG_TS_VLR_COMPR": "999999999999999","ADLG_TS_IC_AUT_UNI": "S" }]},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "040", "ADLG_TS_DESC_SVC": "APL FUND ULTRACONSERVADOR", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "S", "ADLG_EV_ALCADA": [{"ADLG_EV_TP_REG": 5,"ADLG_TS_VLR_DT_PG": "000000000000000","ADLG_TS_VLR_DT_AUT": "999999999999999","ADLG_TS_VLR_COMPR": "999999999999999","ADLG_TS_IC_AUT_UNI": "S" }]},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "041", "ADLG_TS_DESC_SVC": "APL FUND CONSERVADOR", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "S", "ADLG_EV_ALCADA": [{"ADLG_EV_TP_REG": 5,"ADLG_TS_VLR_DT_PG": "000000000000000","ADLG_TS_VLR_DT_AUT": "999999999999999","ADLG_TS_VLR_COMPR": "999999999999999","ADLG_TS_IC_AUT_UNI": "S" }]},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "042", "ADLG_TS_DESC_SVC": "APL FUND MODERADO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "S", "ADLG_EV_ALCADA": [{"ADLG_EV_TP_REG": 5,"ADLG_TS_VLR_DT_PG": "000000000000000","ADLG_TS_VLR_DT_AUT": "999999999999999","ADLG_TS_VLR_COMPR": "999999999999999","ADLG_TS_IC_AUT_UNI": "S" }]},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "043", "ADLG_TS_DESC_SVC": "APL FUND DINAMICO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "S", "ADLG_EV_ALCADA": [{"ADLG_EV_TP_REG": 5,"ADLG_TS_VLR_DT_PG": "000000000000000","ADLG_TS_VLR_DT_AUT": "999999999999999","ADLG_TS_VLR_COMPR": "999999999999999","ADLG_TS_IC_AUT_UNI": "S" }]}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "REP","ADLG_TS_DESC_GRP": "REPASSES FINAME/BNDES","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONSULTA DE OPERACOES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "CREDITOS FORNECEDORES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "SAD","ADLG_TS_DESC_GRP": "ASSINATURA DIGITAL","ADLG_EV_SUBGRUPOS": [{"ADLG_EV_TP_REG": 4,"ADLG_TS_CD_SVC": "010","ADLG_TS_DESC_SVC": "VISTAR DOCUMENTOS","ADLG_TS_IC_SEL_SVC": "S","ADLG_TS_IC_SEL_ALC": "N","ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "SGA","ADLG_TS_DESC_GRP": "COBRANCA-RESUMO GARANTIAS","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "RESUMO GARANTIAS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "RESUMO POR GARANTIA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "RESUMO CONTAS CONTRATO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "RESUMO TITULOS POR DATA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "DETALHE TITULOS POR DATA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "010", "ADLG_TS_DESC_SVC": "ATIVACAO DO LAR", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "SNA","ADLG_TS_DESC_GRP": "PAGAMENTOS-SAFRANET AUTOS","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONSULTA PAGAMENTOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "INCLUSAO PAGAMENTOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "AGENDA PARCELA IPVA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "TAXAS VEICULARES EM LOTE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "SNC","ADLG_TS_DESC_GRP": "CONSULTA RESTRICOES","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONSULTA NET CHEQUE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "RESTRICOES - HISTORICO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "SNM","ADLG_TS_DESC_GRP": "SAFRANETMALOTES","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "AUTORIZACAO DE MALOTES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "S", "ADLG_EV_ALCADA": [{"ADLG_EV_TP_REG": 5,"ADLG_TS_VLR_DT_PG": "000000000000000","ADLG_TS_VLR_DT_AUT": "999999999999999","ADLG_TS_VLR_COMPR": "999999999999999","ADLG_TS_IC_AUT_UNI": "S" }]},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "MANUTECAO DE MALOTES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "CONSULTA DE MALOTES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "SNS","ADLG_TS_DESC_GRP": "PAGAMENTOS-NET SACADOS","ADLG_EV_SUBGRUPOS": [{"ADLG_EV_TP_REG": 4,"ADLG_TS_CD_SVC": "001","ADLG_TS_DESC_SVC": "CONS TITULOS POR SACADO","ADLG_TS_IC_SEL_SVC": "S","ADLG_TS_IC_SEL_ALC": "N","ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "SPO","ADLG_TS_DESC_GRP": "POUPANCA","ADLG_EV_SUBGRUPOS": [{"ADLG_EV_TP_REG": 4,"ADLG_TS_CD_SVC": "001","ADLG_TS_DESC_SVC": "CONSULTA QUESTIONARIO","ADLG_TS_IC_SEL_SVC": "S","ADLG_TS_IC_SEL_ALC": "N","ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "SQE","ADLG_TS_DESC_GRP": "CARTOES-CARTAO PAGAMENTO","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONSULTA CARTOES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "INCLUSAO DE PORTADORES", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "ALTERACAO DE PORTADOR", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "BLOQUEIO DE CARTAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "DESBLOQUEIO DE CARTAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "SRV","ADLG_TS_DESC_GRP": "RECEBIVEIS-CARTOES","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "AGENDA PREVISTA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "CREDITOS CONFIRMADOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "AGENDA NEGOCIADA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "006", "ADLG_TS_DESC_SVC": "GERAR ARQUIVO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "TAC","ADLG_TS_DESC_GRP": "TROCA DE ARQUIVOS","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "ENVIO DE ARQUIVOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "PERFIL LIGNET SAFRA", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "CONSULTA CAIXA POSTAL", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "004", "ADLG_TS_DESC_SVC": "CANCELAMENTO DE ENVIO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "PROTOCOLO / COMPROVANTE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "006", "ADLG_TS_DESC_SVC": "CONTEUDO ARQUIVO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "706", "ADLG_TS_DESC_SVC": "ARQUIVOS TAXAS E TRIBUTOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "750", "ADLG_TS_DESC_SVC": "SAFRA RECEBIMENTOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "TER","ADLG_TS_DESC_GRP": "TERMO DE ADESAO","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONSULTA TERMO DE ADESAO", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "ACEITE DE CONTRATOS", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "TKN","ADLG_TS_DESC_GRP": "SEGURANCA - TOKEN","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CHAVE DE SEGURANCA(TOKEN)", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "005", "ADLG_TS_DESC_SVC": "SOLICITACAO TOKEN MOBILE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "006", "ADLG_TS_DESC_SVC": "EXCLUSAO TOKEN MOBILE", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "VDO","ADLG_TS_DESC_GRP": "VENDOR","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "001", "ADLG_TS_DESC_SVC": "CONSULTA VENDOR", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "002", "ADLG_TS_DESC_SVC": "MANUTENCAO VENDOR", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "003", "ADLG_TS_DESC_SVC": "IMPORTACAO VENDOR", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]},{"ADLG_EV_TP_REG": 3,"ADLG_TS_CD_GRP": "XXX","ADLG_TS_DESC_GRP": "XXXXXXXXXXXXXXXXXXXXXXXXX","ADLG_EV_SUBGRUPOS": [{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "888", "ADLG_TS_DESC_SVC": "8888888888888888888888888", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []},{ "ADLG_EV_TP_REG": 4, "ADLG_TS_CD_SVC": "999", "ADLG_TS_DESC_SVC": "9999999999999999999999999", "ADLG_TS_IC_SEL_SVC": "S", "ADLG_TS_IC_SEL_ALC": "N", "ADLG_EV_ALCADA": []}]}],"ADLG_EV_SERVICO": [{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "CTO","ADLG_TS_CD_CLI_SVE": "000058199","ADLG_TS_CGC_SVE": "087122696","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001654344"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "NMR","ADLG_TS_CD_CLI_SVE": "000102403","ADLG_TS_CGC_SVE": "057484768","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001652970"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "NMR","ADLG_TS_CD_CLI_SVE": "000102403","ADLG_TS_CGC_SVE": "057484768","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "005005740"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "PAG","ADLG_TS_CD_CLI_SVE": "000010158","ADLG_TS_CGC_SVE": "060089026","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001602280"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "PAG","ADLG_TS_CD_CLI_SVE": "000017895","ADLG_TS_CGC_SVE": "061558037","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001636800"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "PAG","ADLG_TS_CD_CLI_SVE": "000017895","ADLG_TS_CGC_SVE": "061558037","ADLG_TS_AGENC_SVE": "09700","ADLG_TS_CONTA_SVE": "005030230"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "PAG","ADLG_TS_CD_CLI_SVE": "000058702","ADLG_TS_CGC_SVE": "302723788","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001653925"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "PAG","ADLG_TS_CD_CLI_SVE": "000074079","ADLG_TS_CGC_SVE": "048435747","ADLG_TS_AGENC_SVE": "09700","ADLG_TS_CONTA_SVE": "000118856"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "PAG","ADLG_TS_CD_CLI_SVE": "000102403","ADLG_TS_CGC_SVE": "057484768","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001652970"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "PAG","ADLG_TS_CD_CLI_SVE": "000102403","ADLG_TS_CGC_SVE": "057484768","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001657203"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "PAG","ADLG_TS_CD_CLI_SVE": "000102403","ADLG_TS_CGC_SVE": "057484768","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "005005740"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "PAG","ADLG_TS_CD_CLI_SVE": "000111925","ADLG_TS_CGC_SVE": "072829807","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001655847"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "PAG","ADLG_TS_CD_CLI_SVE": "000786187","ADLG_TS_CGC_SVE": "116832728","ADLG_TS_AGENC_SVE": "11500","ADLG_TS_CONTA_SVE": "000051083"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "PAG","ADLG_TS_CD_CLI_SVE": "000786203","ADLG_TS_CGC_SVE": "012163378","ADLG_TS_AGENC_SVE": "11500","ADLG_TS_CONTA_SVE": "000051172"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNA","ADLG_TS_CD_CLI_SVE": "000010158","ADLG_TS_CGC_SVE": "060089026","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001602280"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNA","ADLG_TS_CD_CLI_SVE": "000102403","ADLG_TS_CGC_SVE": "057484768","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001652970"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNC","ADLG_TS_CD_CLI_SVE": "000010158","ADLG_TS_CGC_SVE": "060089026","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001602280"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNC","ADLG_TS_CD_CLI_SVE": "000017895","ADLG_TS_CGC_SVE": "061558037","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001636800"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNC","ADLG_TS_CD_CLI_SVE": "000017895","ADLG_TS_CGC_SVE": "061558037","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "005031287"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNC","ADLG_TS_CD_CLI_SVE": "000017895","ADLG_TS_CGC_SVE": "061558037","ADLG_TS_AGENC_SVE": "09700","ADLG_TS_CONTA_SVE": "000026188"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNC","ADLG_TS_CD_CLI_SVE": "000017895","ADLG_TS_CGC_SVE": "061558037","ADLG_TS_AGENC_SVE": "09700","ADLG_TS_CONTA_SVE": "005030230"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNC","ADLG_TS_CD_CLI_SVE": "000061134","ADLG_TS_CGC_SVE": "011752098","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001617210"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNC","ADLG_TS_CD_CLI_SVE": "000074079","ADLG_TS_CGC_SVE": "048435747","ADLG_TS_AGENC_SVE": "09700","ADLG_TS_CONTA_SVE": "000118856"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNC","ADLG_TS_CD_CLI_SVE": "000074872","ADLG_TS_CGC_SVE": "033200056","ADLG_TS_AGENC_SVE": "11500","ADLG_TS_CONTA_SVE": "000008358"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNC","ADLG_TS_CD_CLI_SVE": "000102403","ADLG_TS_CGC_SVE": "057484768","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001652970"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNC","ADLG_TS_CD_CLI_SVE": "000102403","ADLG_TS_CGC_SVE": "057484768","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001657203"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNC","ADLG_TS_CD_CLI_SVE": "000102403","ADLG_TS_CGC_SVE": "057484768","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "005005740"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "SNC","ADLG_TS_CD_CLI_SVE": "000111925","ADLG_TS_CGC_SVE": "072829807","ADLG_TS_AGENC_SVE": "00200","ADLG_TS_CONTA_SVE": "001655847"},{"ADLG_EV_TP_REG": 6,"ADLG_TS_CD_GRP_SVE": "TAC","ADLG_TS_CD_CLI_SVE": "000074872","ADLG_TS_CGC_SVE": "033200056","ADLG_TS_AGENC_SVE": "11500","ADLG_TS_CONTA_SVE": "000008358"}],"ADLG_EV_USUARIOCPF": {"ADLG_EV_TP_REG": 7,"ADLG_TS_SEQ": "01","ADLG_TS_CPF": "39919943568"},"ADLG_EV_DADOSUSUARIO": {"ADLG_EV_TP_REG": 8,"ADLG_TS_DT_NASC": "19950703","ADLG_TS_CD_DOC_ID": "08","ADLG_TS_DOC_ID": "12345","ADLG_TS_DDD_FONE": "011","ADLG_TS_NRO_FONE": "456789012","ADLG_TS_RAM_FONE": "3456"},"ADLG_EV_MENSAGEM": {"ADLG_EV_TP_REG": 99,"ADLG_TS_QTMSG_NOV": "00000","ADLG_TS_QTMSG_GER": "00000","ADLG_TS_IND_UNIF": "N","ADLG_TS_SHORT_UNIF": "","ADLG_TS_USER_UNIF": "","ADLG_TS_NUM_TOKEN": "000132650354"},"ADLG_EV_TOKEN": {"ADLG_EV_TP_REG": 98,"ADLG_TS_NRTOK_M": "000031701838","ADLG_TS_IND_UNIF_M": "N","ADLG_TS_SHORT_UNIF_M": "VALISERE","ADLG_TS_USER_UNIF_M": "MASTER","ADLG_TS_CHAVE_DIF": "N","ADLG_TS_DTULAC": "20160825111406"},"statusProcessamento": {"mensagem": {"codigo": "0108","descricao": "SENHA VALIDA, PROCESSAMENTO OK","severidade": "00"}},"ADLG_TS_DTULAC": "2016-08-25T14:14:06.000Z" };

            listarContasSucesso(data);

            /**
            * @ngdoc overview
            * @name sucessoTransacaoConta
            * 
            * @memberOf extratoMovimentacaoController.js
            *
            * @description        
            * Método executado em caso de sucesso na consulta das contas do cliente
            **/
            function listarContasSucesso(data) {
                console.log("SUCESSO transacaoConta: " + JSON.stringify(data));
                //metodo que transforma o retorno para listar contas.
                var listaContas = listarContasTributos(data);

                vm.conta.lista = listaContas.lista;
                vm.conta.exibir();
                vm.conta.erroNaTransacao = false;


                modal.abrirModal(undefined,
                    undefined,
                    "modalSelecaoConta",
                    atualizarContaEmUso,
                    undefined, {
                        "lista": vm.conta.lista,
                        "contaSelecionada": vm.contaPreferencial
                    },
                    "selecionarContaController",
                    "scCtrl",
                    "md");
            }
        }

        /**
        * @ngdoc overview
        * @ngdoc method
        * @name formatarDataAAAAMMDD
        *
        * @description
        * Método responsável pela formatação
        **/
        function formatarDataAAAAMMDD(data) {
            return data.toISOString()
                .replace(/-/g, "")
                .substring(0, 8);
        }

        /**
        * @ngdoc overview
        * @ngdoc method
        * @name definirContexto
        *
        * @description
        * Método responsável incluir os dados do cliente no contexto
        **/
        // function definirContexto(cnpj, agencia, conta) {
        //     var cnpjFormatado = utilitarios.zerosAEsquerda(cnpj != null ? cnpj : 0, 9);
        //     var agenciaFormatada = utilitarios.zerosAEsquerda(agencia != null ? agencia : 0, 5);
        //     var contaFormatada = conta != null ? conta : 0;

        //     contexto.definirValorContextoSessao("token",
        //         "Agencia=" + agenciaFormatada
        //         + ",Conta=" + contaFormatada
        //         + ",CodigoCanal=IPJ,Senha=XXXXXXXX,ValorOperacao=1,CodigoCliente=000000000,ShortName=VALISERE       ,UserId=VALISERE,"
        //         + "BaseCGC=" + cnpjFormatado
        //         + ",CentralAtendimento=N,TokenValidado=S");
        // }

        /**
         * @description
         * Método para abertura e validação de senhas pelo modal.
         */
        function validarSenha() {

            //Abrir o modal
            modal.abrirModal(undefined,
                undefined,
                "modalConfirmacaoSenha",
                confirmarSenhaToken,
                cancelouSenhaToken,
                {},
                "confirmacaoSenhaController",
                "csCtrl",
                "senha",
                "md");
        }

        /**
        * @ngdoc method
        * @name confirmarSenhaToken
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por confirmar senha e token e acionar a operação de liberar/excluir as maquinas.
        **/
        function confirmarSenhaToken(data) {
            //TODO: Validação de senha arq
            vm.resultadoValidacaoSenha = data;

            switch (vm.tipoPagamento) {
                case "MODALIDADE":
                    transacaoAutorizarTributosPorModalidade(obterDataSelecionada(vm.dtpickerInicioModalidade, vm.sliderInicioModalidade), data.senha);
                    break;
                case "CONTA":
                    transacaoAutorizarTributosPorConta(obterDataSelecionada(vm.dtpickerInicioConta, vm.sliderInicioConta), data.senha);
                    break;
                case "PAGAMENTOS":
                    transacaoAutorizarTributosPorPagamento(data.senha);
                    break;
                default:
                    break;
            }
        }

        /**
         * @description Método responsável por obter a data selecionada no momento
         */
        function obterDataSelecionada(dtPicker, slider) {
            if (dtPicker != undefined && dtPicker != null && dtPicker != "") {
                return dtPicker;
            } else {
                return gerarFiltroSlider(slider);
            }
        }

        /**
        * @ngdoc method
        * @name cancelouSenhaToken
        *
        * @methodOf apl-mobile-pj.seguranca
        *  
        * @description
        * Método responsável por cancelar a digitação de senha token.
        **/
        function cancelouSenhaToken(data) {
            //TODO: Validação de senha arq
            vm.resultadoValidacaoSenha = data;
        }

        /**
        * @ngdoc method
        * @name mostrarAlerta
        *  
        * @description
        * Método responsável por exibir o alerta de acordo com o retorno da comunicação
        **/
        function mostrarAlerta(tipoAlerta, data) {

            switch (vm.tipoPagamento) {
                case "MODALIDADE":
                    vm.alertasModalidade.push({ tipo: tipoAlerta, data: data });
                    break;
                case "CONTA":
                    vm.alertasConta.push({ tipo: tipoAlerta, data: data });
                    break;
                case "PAGAMENTOS":
                    vm.alertasPagamento.push({ tipo: tipoAlerta, data: data });
                    break;
                default:
                    break;
            }
        }

        /**
         * @ngdoc method
         *  * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeFiltroDataModalidade(executaTran) {
            vm.alertasModalidade = [];
            vm.buscaCalendarioModalidade = false;

            vm.dtpickerInicioModalidade = "";

            if (executaTran) {
                transacaoListarTributosPorModalidade();
            }
        }

        /**
         * @ngdoc method
         *  * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeFiltroDataPagamento(executaTran) {
            vm.alertasPagamento = [];
            vm.buscaCalendarioPagamento = false;

            vm.dtpickerInicioPagamento = "";

            if (executaTran) {
                transacaoListarTributosPorPagamento();
            }
        }

        /**
         * @ngdoc method
         *  * @name removeAlerta
        *  
        * @description
        * Método responsável por limpar os alertas exibidos
        **/
        function removeFiltroDataConta(executaTran) {
            vm.alertasConta = [];
            vm.buscaCalendarioConta = false;

            vm.dtpickerInicioConta = "";

            if (executaTran) {
                transacaoListarTributosPorConta();
            }
        }

        /**
        * @ngdoc method
        * @name filtrarTributoModalidade
        *
        * @description
        * Preencha a data de fim do filtro de data a partir da seleção do datepicker e realiza a consulta
        **/
        function filtrarTributoModalidade() {
            vm.buscaCalendarioModalidade = true;

            vm.dtOptions.minDate = pickerDtMinimo;

            mostrarAlerta("info", $filter("date")(vm.dtpickerInicioModalidade, "dd/MM"));

            transacaoListarTributosPorModalidade();
        }

        /**
        * @ngdoc method
        * @name filtrarTributoPagamento
        *
        * @description
        * Preencha a data de fim do filtro de data a partir da seleção do datepicker e realiza a consulta
        **/
        function filtrarTributoPagamento() {
            vm.buscaCalendarioPagamento = true;

            vm.dtOptions.minDate = pickerDtMinimo;

            mostrarAlerta("info", $filter("date")(vm.dtpickerInicioPagamento, "dd/MM"));

            transacaoListarTributosPorPagamento();
        }

        /**
        * @ngdoc method
        * @name filtrarTributoConta
        *
        * @description
        * Preencha a data de fim do filtro de data a partir da seleção do datepicker e realiza a consulta
        **/
        function filtrarTributoConta() {
            vm.buscaCalendarioConta = true;

            vm.dtOptions.minDate = pickerDtMinimo;

            mostrarAlerta("info", $filter("date")(vm.dtpickerInicioConta, "dd/MM"));

            transacaoListarTributosPorConta();
        }

        /**
        * @ngdoc method
        * @name carregaDatePickerTribModalidade
        *
        * @description
        * Exibe o datepicker
        **/
        function carregaDatePickerTribModalidade() {
            removeFiltroDataModalidade(false);
            iniciaDatePicker();

            vm.dtpickerInicioModalidadeAberto = true;
        }

        /**
        * @ngdoc method
        * @name carregaDatePickerTribPagamento
        *
        * @description
        * Exibe o datepicker
        **/
        function carregaDatePickerTribPagamento() {
            removeFiltroDataPagamento(false);
            iniciaDatePicker();

            vm.dtpickerInicioPagamentoAberto = true;
        }

        /**
        * @ngdoc method
        * @name carregaDatePickerTribConta
        *
        * @description
        * Exibe o datepicker
        **/
        function carregaDatePickerTribConta() {
            removeFiltroDataConta(false);
            iniciaDatePicker();

            vm.dtpickerInicioContaAberto = true;
        }

        /**
        * @ngdoc method
        * @name iniciaDatePicker
        *
        * @description
        * Carrega os valores iniciais do datepicker
        **/
        function iniciaDatePicker() {
            pickerDtMaximo = new Date();
            pickerDtMinimo = new Date();

            pickerDtMinimo.setDate(pickerDtMinimo.getDate() + 7);

            vm.dtOptions = {
                minDate: pickerDtMaximo,
                maxDate: pickerDtMinimo,
                maxMode: "day",
                showWeeks: false
            };
        }

        /**
        * @ngdoc method
        * @name carregarSlider
        *
        * @description
        * Método responsável por preencher os valores default do slider
        **/
        function iniciarSlider() {
            vm.buscaCalendarioModalidade = false;
            vm.buscaCalendarioPagamento = false;
            vm.buscaCalendarioConta = false;
            inicializaDatas();
            preencheOpcoesSlider();

            vm.sliderInicioModalidade = retornaContagemDias(dtInicio);
            vm.sliderInicioPagamento = retornaContagemDias(dtInicio);
            vm.sliderInicioConta = retornaContagemDias(dtInicio);
        }

        /**
        * @ngdoc method
        * @name retornaContagemDias
        *
        * @param {Date} a data a ser subtraida da data atual
        *
        * @description
        * Retorna a diferença da data atual para a data recebida 
        **/
        function retornaContagemDias(data) {
            var dtAtual = new Date();
            dtAtual.setHours(0);
            dtAtual.setMinutes(0);
            dtAtual.setSeconds(0);
            dtAtual.setMilliseconds(0);

            data.setHours(0);
            data.setMinutes(0);
            data.setSeconds(0);
            data.setMilliseconds(0);

            var diferencaTempo = Math.abs(dtAtual.getTime() - data.getTime());
            var diferencaDias = (diferencaTempo / (1000 * 3600 * 24));
            return diferencaDias;
        }

        /**
        * @ngdoc method
        * @name inicializaDatas
        *
        * @description
        * Método responsável por iniciar as datas utilizadas para filtro de lançamentos
        **/
        function inicializaDatas() {
            dtInicio = new Date();
        }

        /**
        * @ngdoc method
        * @name preencheOpcoesSlider
        *
        * @description
        * Método responsável por preencher os dados de funcionamento do slider
        **/
        function preencheOpcoesSlider() {
            var passos = [0, 1, 2, 3, 4, 5, 6];

            preencheOpcoesSliderFiltroPag(100);

            vm.sliderOptions = {
                noSwitching: true,
                totalDias: "",
                showTicksValues: true,
                rightToLeft: false,
                stepsArray: passos.map(function (v) {
                    return v;
                }),
                onEnd: function () {

                    if (vm.tipoPagamento == "CONTA") {
                        transacaoListarTributosPorConta();
                    }
                    else if (vm.tipoPagamento == "MODALIDADE") {
                        transacaoListarTributosPorModalidade();
                    }
                    else if (vm.tipoPagamento == "PAGAMENTOS") {
                        transacaoListarTributosPorPagamento();
                    }

                },
                translate: function (value, sliderId, label) {
                    if (label == "high" && this.lowValue == this.highValue) {
                        return "";
                    } else if (label != "tick-value") {
                        var data = new Date();
                        if (value === 0) {
                            return "Hoje";
                        }
                        return $filter("date")(data.setDate(data.getDate() + value), "dd/MM");
                    } else {
                        return value;
                    }
                }
            };
        }

        /**
         * @description Método responsável por preencher as opçoes do slider de filtro selecionado pela tela. 
         */
        function preencheOpcoesSliderFiltroPag(valorMax) {
            vm.sliderOptionsFiltro = {
                floor: 0,
                ceil: valorMax,
                step: 0.01,
                precision: 2,
                translate: function () {
                    return "";
                }
            };
        }

        /**
         * @description Método responsável por gerar o filtro de slider
         */
        function gerarFiltroSlider(modelValue) {
            if (modelValue == undefined || modelValue == null || modelValue == "") {
                modelValue = 0;
            }

            var sliderDtFim = new Date();
            sliderDtFim.setHours(0);
            sliderDtFim.setMinutes(0);
            sliderDtFim.setSeconds(0);
            sliderDtFim.setMilliseconds(0);

            sliderDtFim.setDate(sliderDtFim.getDate() + modelValue);

            return sliderDtFim;
        }

        /**
         * limpa as listas de pagamentos
         */
        function limparVariaveis() {

            //Limpa todas as listas
            vm.listaTributosPorConta = {};

            vm.listaTributosPorModalidade = {};

            vm.listaTributosPorPagamento = {};

            vm.valorTotalTributoPorPagamentos = 0;

            vm.alertasDados = [];
        }

        /**
         * Preenche o alerta ao não encontrar dados ou der erro.
        */
        function preencherAlertaDados(type, data, location) {
            vm.alertasDados.push({
                tipo: type,
                texto: data,
                caminho: location
            });
        }

        /**
         * trata o retorno das contas para manter no padrão da lista de contas.
         */
        function listarContasTributos(data) {

            //Retorna somente as contas do grupo de pagamento.
            var contasPagamento = data.CONTAS_POR_SERVICO.filter(function (item) {
                return (item.ADLG_TS_CD_GRP_SVE == "PAG");
            });

            //Ordena a lista por cnpj
            var itensSort = contasPagamento.sort(function (element1, element2) {
                if (element1.ADLG_TS_CGC_SVE > element2.ADLG_TS_CGC_SVE) {
                    return 1;
                }

                else {
                    return -1;
                }

            });

            var listaAgrupada = [];

            //Cria a lista agrupada de CNPJ
            for (var key in itensSort) {

                var element = itensSort[key];
                var cnpjFind = element.ADLG_TS_CGC_SVE;

                var itemSuperior = {};
                itemSuperior.cnpj = element.ADLG_TS_CGC_SVE;

                //busca o nome do cliente pelo cnpj 
                var nomeCliente = data.CONTAS.filter(function (item, cnpjFind) {
                    return (item.ADLG_TS_CGC == cnpjFind);
                });

                if (nomeCliente.length > 0) {
                    itemSuperior.nome = nomeCliente.ADLG_TS_RAZ_SOC;
                } else {
                    itemSuperior.nome = "";
                }

                listaAgrupada.push(itemSuperior);

                listaAgrupada[key].contas = [];

                for (var key2 in contasPagamento) {

                    var element2 = contasPagamento[key2];
                    if (element2.ADLG_TS_CGC_SVE == cnpjFind) {
                        var itemInferior = {};
                        itemInferior.agencia = element2.ADLG_TS_AGENC_SVE;
                        itemInferior.conta = element2.ADLG_TS_CONTA_SVE;
                        itemInferior.tipoConta = "1";
                        listaAgrupada[key].contas.push(itemInferior);
                    }
                }
            }

            var retorno = {};

            retorno.lista = listaAgrupada;
            retorno.statusProcessamento = data.statusProcessamento;

            return retorno;

        }
    }
})();