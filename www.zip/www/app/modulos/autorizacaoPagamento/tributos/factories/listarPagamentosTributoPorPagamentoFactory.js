(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarPagamentosTributoPorPagamentoFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:listarPagamentosTributoPorPagamentoFactory
    *
    * @description
    * Factory de conexão com API listarPagamentosTributoPorPagamentoFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoTributo")
        .factory("listarPagamentosTributoPorPagamentoFactory", listarPagamentosTributoPorPagamentoFactory);

    listarPagamentosTributoPorPagamentoFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarPagamentosTributoPorPagamentoFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:listarPagamentosTributoPorPagamentoFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarPagamentosTributoPorPagamentoFactory(conectorAPI, appSettings, utilitarios) {

        return {
            listarTributos: listarTributos
        };

        /**
        * @ngdoc method
        * @name listarPagamentos
        *
        * @methodOf apl-mobile-pj.autorizacaoTributo:listarTributos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarTributos(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "listar-tributos-por-compromisso"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();