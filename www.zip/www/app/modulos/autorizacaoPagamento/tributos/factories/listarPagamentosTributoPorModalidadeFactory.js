(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarPagamentosTributoPorModalidadeFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:listarPagamentosTributoPorModalidadeFactory
    *
    * @description
    * Factory de conexão com API listarPagamentosTributoPorModalidadeFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoTributo")
        .factory("listarPagamentosTributoPorModalidadeFactory", listarPagamentosTributoPorModalidadeFactory);

    listarPagamentosTributoPorModalidadeFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarPagamentosTributoPorModalidadeFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:listarPagamentosTributoPorModalidadeFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarPagamentosTributoPorModalidadeFactory(conectorAPI, appSettings, utilitarios) {

        return {
            listarTributos: listarTributos
        };

        /**
        * @ngdoc method
        * @name listarTributos
        *
        * @methodOf apl-mobile-pj.autorizacaoTributo:listarTributos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarTributos(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "listar-tributos-por-modalidade"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();