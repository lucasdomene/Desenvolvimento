(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name autorizarPagamentosTributoPorModalidadeFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:autorizarPagamentosTributoPorModalidadeFactory
    *
    * @description
    * Factory de conexão com API autorizarPagamentosTributoPorModalidadeFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoTributo")
        .factory("autorizarPagamentosTributoPorModalidadeFactory", autorizarPagamentosTributoPorModalidadeFactory);

    autorizarPagamentosTributoPorModalidadeFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name autorizarPagamentosTributoPorModalidadeFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:autorizarPagamentosTributoPorModalidadeFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function autorizarPagamentosTributoPorModalidadeFactory(conectorAPI, appSettings, utilitarios) {

        return {
            autorizarTributos: autorizarTributos
        };

        /**
        * @ngdoc method
        * @name autorizarTributos
        *
        * @methodOf apl-mobile-pj.autorizacaoPagamento:autorizarTributos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function autorizarTributos(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "autorizar-tributos-por-modalidade"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();