(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarPagamentosTributoPorContaFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:listarPagamentosTributoPorContaFactory
    *
    * @description
    * Factory de conexão com API listarPagamentosTributoPorContaFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoTributo")
        .factory("listarPagamentosTributoPorContaFactory", listarPagamentosTributoPorContaFactory);

    listarPagamentosTributoPorContaFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarPagamentosTributoPorContaFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:listarPagamentosTributoPorContaFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarPagamentosTributoPorContaFactory(conectorAPI, appSettings, utilitarios) {

        return {
            listarTributos: listarTributos
        };

        /**
        * @ngdoc method
        * @name listarTributos
        *
        * @methodOf apl-mobile-pj.autorizacaoTributo:listarTributos
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarTributos(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "listar-tributos-por-modalidade"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();