(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarContasTributosFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:listarContasTributosFactory
    *
    * @description
    * Factory de conexão com API listarContasFactory
    **/
    angular.module("apl-mobile-pj.autorizacaoTributo")
        .factory("listarContasTributosFactory", listarContasTributosFactory);

    listarContasTributosFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarContasTributosFactory
    *
    * @methodOf apl-mobile-pj.autorizacaoTributo:listarContasTributosFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarContasTributosFactory(conectorAPI, appSettings, utilitarios) {

        return {
            listarContas: listarContas
        };

        /**
        * @ngdoc method
        * @name listarContas
        *
        * @methodOf apl-mobile-pj.autorizacaoTributo:listarContas
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarContas(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "autenticar-usuario-pj"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);

        }
    }

})();