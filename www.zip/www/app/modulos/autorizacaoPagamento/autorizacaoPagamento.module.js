(function () {

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.autorizacaoPagamento
     * 
     * @require ui.bootstrap
     * 
     * @description
     * Módulo que define os fluxos de navegacao pelos controles de autorizacao de pagamento.
     **/
    angular.module("apl-mobile-pj.autorizacaoPagamento", ["ui.bootstrap", "ngAnimate", "rzModule"])
        .config(autorizacaoPagamentoModule)
        .run(["sfTradutor", function (tradutor) {
            tradutor.adicionarDicionarios(["app/modulos/autorizacaoPagamento/internacionalizacao"]);
        }]);


    autorizacaoPagamentoModule.$inject = ["sfNavegadorProvider"];

    /**
    * @ngdoc overview
    * @name autorizacaoPagamentoModule
    * 
    * @description
    * Navegação do módulo autorizacaoPagamentoModule.
    **/
    function autorizacaoPagamentoModule(sfNavegadorProvider) {
       sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-autorizacaoPagamento")
                .adicionarEstado("autorizacao", {
                    templateUrl: "./app/modulos/autorizacaoPagamento/fornecedores/views/autorizacao.html",
                     controller: "autorizarPagamentoController as autpagCtrl",
                    abstract: true
                })
                .adicionarEstado("autorizacao.pagamento", {
                    templateUrl: "./app/modulos/autorizacaoPagamento/fornecedores/views/autorizacaoPagamento.html",
                    parent: "autorizacao"
                },
                [
                    {
                        acao: "filtrar-pagamentos",
                        estadoDestino: "pagamentos"
                    },
                    {
                        acao: "detalhar-pagamento",
                        fluxo: "apl-mobile-pj-detalhes-pagamento"
                    },
                    {
                        acao: "autorizacao-tributo",
                        fluxo: "apl-mobile-pj-autorizacaoTributo"
                    }
                ])
                
                .adicionarEstado("pagamentos", {
                    templateUrl: "./app/modulos/autorizacaoPagamento/fornecedores/views/filtroPagamentos.html",
                    parent: "autorizacao"
                })
                .definirEstadoInicial("autorizacao.pagamento")
        );

        sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-comprovante-fornecedor")
                .adicionarEstado("comprovante", {
                    templateUrl: "./app/modulos/autorizacaoPagamento/fornecedores/views/exibirComprovante.html",
                     controller: "comprovantesPagamentoController as compagCtrl"
                })
                .definirEstadoInicial("comprovante")
        );
    }    
})();