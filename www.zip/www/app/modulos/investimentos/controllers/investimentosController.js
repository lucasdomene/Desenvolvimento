(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name apl-mobile-pj.segurinvestimentosanca.investimentosController
     *
     * @requires navegador
     *
     * @description
     * Controller responsável pela tratativa das ações a serem realizadas na view Gestao de Maquinas.
     **/
    angular.module("apl-mobile-pj.investimentos").controller("investimentosController", investimentosController);

    investimentosController.$inject =
        [
            "sfNavegador",
            "sfContexto",
            "modal",
            "sfMemorizador",
            "sfUtilitarios",
            "interpretadorComunicacao",
            "listarSaldoInvestimentosFactory",
            "listarContasInvestimentosFactory"
        ];

    /*
    * @description
    *
    */
    /**
     * @ngdoc overview
     * @name apl-mobile-pj.seguranca.investimentosController
     * @description
     * Controller Gestao de Maquinas.
     **/
    function investimentosController(
        navegador,
        sfContexto,
        modal,
        sfMemorizador,
        utilitarios,
        interpretadorComunicacao,
        listarSaldoInvestimentosFactory,
        listarContasInvestimentosFactory) {
        var vm = this;

        vm.transacaoSaldo = transacaoSaldo;
        vm.abrirModalSelecaoConta = abrirModalSelecaoConta;
        vm.iniciar = iniciar;

        vm.produtos = {};
        vm.totalInvestido = {};
        vm.conta = {
            cnpj: null,
            agencia: null,
            numero: null,
            dv: null,
            carregarPreferencial: carregarPreferencial,
            lista: null,
            erroNaTransacao: false
        };

        vm.contaPreferencial = {
            agencia: null,
            numero: null,
            cnpj: null,
            dv: null
        };

        vm.iniciar();

        /*Funções*/

        /**
        * @ngdoc method
        * @name iniciar
        *
        * @methodOf apl-mobile-pj.investimentos
        *
        * @description
        * Método responsável por carregar o estado inicial dos elementos da view.
        **/
        function iniciar() {
            vm.conta.carregarPreferencial();
            if (vm.contaPreferencial.agencia != null
                && vm.contaPreferencial.numero != null) {
                vm.transacaoSaldo();
            } else {
                transacaoConta();
            }
        }

        /**
        * @ngdoc atualizarConta
        * @name atualizarConta
        *
        * @memberOf apl-mobile-pj.investimentos
        *
        * @description
        * Método responsável por atualizar a conta em uso através da conta preferencial.
        **/
        function atualizarConta() {
            vm.conta.agencia = vm.contaPreferencial.agencia;
            vm.conta.numero = vm.contaPreferencial.numero;
            vm.conta.cnpj = vm.contaPreferencial.cnpj;
            vm.transacaoSaldo();
        }

        /**
        * @ngdoc overview
        * @name abrirModalSelecaoConta
        *
        * @memberOf apl-mobile-pj.investimentos
        *
        * @description
        * Método incializa e abre a modal de seleção de contas do cliente
        **/
        function abrirModalSelecaoConta() {
            transacaoConta();
        }

        /**
        * @ngdoc overview
        * @name atualizarContaEmUso
        *
        * @memberOf apl-mobile-pj.investimentos
        *
        * @description
        * Método que atualiza a conta preferencial com base na conta selecionada na modal
        **/
        function atualizarContaEmUso(conta) {
            if (angular.isUndefined(conta)
                || conta == null
                || isNaN(conta.agencia)
                || isNaN(conta.conta)) {
                return false;
            }

            vm.contaPreferencial.agencia = conta.agencia;
            vm.contaPreferencial.numero = conta.conta;
            vm.contaPreferencial.cnpj = conta.cnpj;

            sfMemorizador.definir("investimentos.contaPreferencial", vm.contaPreferencial);
            atualizarConta();

            return false;
        }

        /**
        * @ngdoc overview
        * @name carregarPreferencial
        *
        * @memberOf apl-mobile-pj.investimentos
        *
        * @description
        * Método responsável por recupeara a conta preferencial e popular a conta exibida.
        **/
        function carregarPreferencial() {
            var contaPreferencial = sfMemorizador.obter("investimentos.contaPreferencial");

            if (angular.isDefined(contaPreferencial) && contaPreferencial != null) {
                vm.conta.cnpj = contaPreferencial.cnpj;
                vm.conta.agencia = contaPreferencial.agencia;
                vm.conta.numero = contaPreferencial.numero;
                vm.contaPreferencial = contaPreferencial;
                atualizarConta();
            }
        }

        /**
       * @ngdoc overview
       * @name transacaoConta
       *
       * @memberOf investimentosController.js
       *
       * @description
       * Método que realiza a consulta das contas vinculadas ao cliente
       **/
        function transacaoConta() {
            //TODO: Remover pois será tratado pela arquitetura
            //sfContexto.definirValorContextoSessao("token", "Agencia=00000,Conta=000000000,CodigoCanal=IPJ,Senha=XXXXXXXX,ValorOperacao=1,CodigoCliente=000000000,ShortName=TESTE CEL2     ,UserId=TESTE CE,BaseCGC=302723788,CentralAtendimento=N,TokenValidado=S");

            var dadosLogin = sfContexto.obterValorContextoTrabalho("dadosLogin");

            var requisicao = {
                "shortname": dadosLogin.shortname,
                "userId": dadosLogin.username
            };

            interpretadorComunicacao.interpretar(listarContasInvestimentosFactory.listarContas(requisicao))
                .sucesso(sucessoTransacaoConta)
                .aviso(erroTransacaoConta)
                .erro(erroTransacaoConta);

            /**
            * @ngdoc overview
            * @name erroTransacaoConta
            *
            * @memberOf investimentosController.js
            *
            * @description
            * Método executado em caso de erro na consulta das contas do cliente
            **/
            function erroTransacaoConta() {
                vm.conta.erroNaTransacao = true;
            }

            /**
            * @ngdoc overview
            * @name sucessoTransacaoConta
            *
            * @memberOf investimentosController.js
            *
            * @description
            * Método executado em caso de sucesso na consulta das contas do cliente
            **/
            function sucessoTransacaoConta(data) {

                modal.abrirModal(undefined,
                    undefined,
                    "modalSelecaoConta",
                    atualizarContaEmUso,
                    undefined, {
                        "lista": data.lista,
                        "contaSelecionada": vm.contaPreferencial
                    },
                    "selecionarContaController",
                    "scCtrl");
            }
        }

        /**
        * @ngdoc overview
        * @name transacaoSaldo
        *
        * @memberOf investimentoController.js
        *
        * @description
        * Método que realiza a consulta de saldo
        **/
        function transacaoSaldo() {

            //TODO: REMOVER MOCK
            //sfContexto.definirValorContextoSessao("token","Agencia=00200,Conta=1637491,CodigoCanal=IPJ,Senha=XXXXXXXX,ValorOperacao=1,CodigoCliente=000000000,ShortName=TESTE CEL2     ,UserId=TESTE CE,BaseCGC=068053086,CentralAtendimento=N,TokenValidado=S");
            // sfContexto.definirValorContextoSessao("token", "Agencia=" + utilitarios.zerosAEsquerda(vm.conta.agencia, 5) + ",Conta=" + vm.conta.numero + ",CodigoCanal=IPJ,Senha=XXXXXXXX,ValorOperacao=1,CodigoCliente=000000000,ShortName=TESTE CEL2     ,UserId=TESTE CE,BaseCGC=" + utilitarios.zerosAEsquerda(vm.conta.cnpj, 9) + ",CentralAtendimento=N,TokenValidado=S");
            var dadosLogin = sfContexto.obterValorContextoTrabalho("dadosLogin");
            var requisicao = {
                "agencia": vm.conta.agencia,
                "contaCorrente": vm.conta.numero,
                "BaseCGC": vm.conta.cnpj,
                "shortname": dadosLogin.shortname,
                "userId": dadosLogin.username
            };

            interpretadorComunicacao.interpretar(listarSaldoInvestimentosFactory.listarSaldo(requisicao))
                .sucesso(sucessoTransacaoSaldo)
                .aviso(erroTransacaoSaldo)
                .erro(erroTransacaoSaldo);

            /**
            * @ngdoc overview
            * @name erroTransacaoSaldo
            *
            * @memberOf investimentoController.js
            *
            * @description
            * Método executado em caso de erro na consulta de saldo
            **/
            function erroTransacaoSaldo(data) {
                console.log(data);
            }

            /**
            * @ngdoc overview
            * @name sucessoTransacaoSaldo
            *
            * @memberOf investimentoController.js
            *
            * @description
            * Método executado em caso de sucesso na consulta de saldo
            **/
            function sucessoTransacaoSaldo(data) {
                vm.produtos = data.SLDG_EV_OCOR;
                if (data.SLDG_EV_OCOR.length > 0) {
                    vm.totalInvestido = data.SLDG_EV_OCOR[0].SLDG_EV_OC_SPRO;
                } else {
                    vm.totalInvestido = 0;
                }
            }
        }

    }
})();