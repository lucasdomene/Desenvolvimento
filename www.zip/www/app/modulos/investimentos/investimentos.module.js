(function () {
    /**
     * @ngdoc overview
     * @name apl-mobile-pj.investimentos
     * 
     * @require ui.bootstrap
     * 
     * @description
     * Módulo que define os fluxos de navegacao pelos controles de autorizacao de pagamento.
     **/
    angular.module("apl-mobile-pj.investimentos", ["ui.bootstrap", "ngAnimate", "apl-mobile-pj.comum"])
        .config(investimentosModule)
        .run(["sfTradutor", function (tradutor) {
            tradutor.adicionarDicionarios(["app/modulos/investimentos/internacionalizacao"]);
        }]);


    investimentosModule.$inject = ["sfNavegadorProvider"];

    /**
    * @ngdoc overview
    * @name investimentosModule
    * 
    * @description
    * Navegação do módulo investimentosModule.
    **/
    function investimentosModule(sfNavegadorProvider) {
       sfNavegadorProvider.adicionarFluxoNavegacao(
            sfNavegadorProvider.criarFluxoNavegacao("apl-mobile-pj-investimentos")
                .adicionarEstado("investimentos", {
                    templateUrl: "./app/modulos/investimentos/views/investimentos.html",
                     controller: "investimentosController as investCtrl",
                    abstract: true
                })
                .adicionarEstado("investimentos.produtos", {
                    templateUrl: "./app/modulos/investimentos/views/produtos.html",
                    parent: "investimentos"
                })              
                .definirEstadoInicial("investimentos.produtos")
        );
    }    
})();