(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarContasInvestimentosFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:listarContasInvestimentosFactory
    *
    * @description
    * Factory de conexão com API listarContasInvestimentosFactory
    **/
    angular.module("apl-mobile-pj.extrato")
        .factory("listarContasInvestimentosFactory", listarContasInvestimentosFactory);

    listarContasInvestimentosFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarCotacoesService
    *
    * @methodOf apl-mobile-pj.extrato:listarContasInvestimentosFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarContasInvestimentosFactory(conectorAPI, appSettings, utilitarios) {

        return {
            listarContas: listarContas
        };

        /**
        * @ngdoc method
        * @name listarCotacoesService
        *
        * @methodOf apl-mobile-pj.extrato:listarContas
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarContas(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "listar-contas"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();