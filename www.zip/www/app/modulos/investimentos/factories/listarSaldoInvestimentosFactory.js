(function () {

    "use strict";

    /**
    * @ngdoc service
    * @name listarSaldoInvestimentosFactory
    *
    * @methodOf apl-mobile-pj.areaAberta:listarSaldoInvestimentosFactory
    *
    * @description
    * Factory de conexão com API listarSaldoInvestimentosFactory
    **/
    angular.module("apl-mobile-pj.investimentos")
        .factory("listarSaldoInvestimentosFactory", listarSaldoInvestimentosFactory);

    listarSaldoInvestimentosFactory.$inject = ["sfConectorAPI", "appSettings", "sfUtilitarios"];

    /*Funções*/

    /**
    * @ngdoc method
    * @name listarCotacoesService
    *
    * @methodOf apl-mobile-pj.extrato:listarSaldoInvestimentosFactory
    *
    * @description
    * Metodo responsavel por chamar o controlador e retornar o resultado
    **/
    function listarSaldoInvestimentosFactory(conectorAPI, appSettings, utilitarios) {

        return {
            listarSaldo: listarSaldo
        };

        /**
        * @ngdoc method
        * @name listarCotacoesService
        *
        * @methodOf apl-mobile-pj.extrato:listarSaldo
        *
        * @description
        * Metodo responsavel por chamar o controlador e retornar o resultado
        **/
        function listarSaldo(param) {

            var req = {
                method: "POST",
                url: utilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "listar-saldo"]),
                data: param,
                dataType: "json"
            };

            return conectorAPI.executar(req, true);
        }
    }

})();