 [
  {
  "modulos": [
              {
              "caminhoDownload": "http://stiap001vt.safra.com.br/ti/apl-mobile-pf",
              "modulo": "apl-mobile-pf",
              "versaoAtual": "0.0.2-beta.9",
              "hash": "1f906551ce29a89144bda224726bb36afdc820336eae178b82f633972361ac36",
              "versaoMinima": "0.0.2-beta.9"
              }
              ],
  "plataforma": "iOS",
  "versaoMinimaContainer": "0.0.1"
  },
  {
  "modulos": [
              {
              "caminhoDownload": "http://stiap001vt.safra.com.br/ti/apl-mobile-pf",
              "modulo": "apl-mobile-pf",
              "versaoAtual": "0.0.2-beta.8",
              "hash": "1f906551ce29a89144bda224726bb36afdc820336eae178b82f633972361ac36",
              "versaoMinima": "0.0.2-beta.8"
              }
              ],
  "plataforma": "Android",
  "versaoMinimaContainer": "0.0.1"
  }
  ]